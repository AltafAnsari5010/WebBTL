﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class login : System.Web.UI.Page
{
    Common cs = new Common();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Email"] != null)
        {
            Response.Redirect("index.aspx");
        }
    }
    protected void btnLogin_ServerClick(object sender, EventArgs e)
    {
        string Query = "select Id from tbl_Register where txtEmail='" + txtEmail.Value.Trim() + "' and Password = '" + txtPassword.Value.Trim() + "'";
        string Id = cs.GetColumVal(Query, "Id");
        if (!string.IsNullOrEmpty(Id))
        {
            BusinessClass BC = cs.GetBusinessClassByEmail(txtEmail.Value.Trim());
            Session["Email"] = txtEmail.Value.Trim();
            Session["UserName"] = BC.FullName;
            Session["CompanyName"] = BC.CompanyName;
            Response.Redirect("BusinessPage.aspx");
        }
        else
            txtEmail.Value = "Invalid UserName or Password!!";
    }
}