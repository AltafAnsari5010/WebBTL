﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class index : System.Web.UI.Page
{
    Common cs = new Common();
    string Email = "";
    string UserName = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["Email"] != null)
            {
                UserName = Session["UserName"].ToString();
                btnLogin.Text = "Logout";
                btnRegister.Text = "Welcome " + UserName;
                btnRegister.PostBackUrl = "";
            }

            cs.FillRepeater(rptGrid,"select * from tbl_Register");
        }
    }
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        if (btnLogin.Text.Contains("Login"))
            Response.Redirect("Login.aspx");
        else
        {
            Session.Abandon();
            Session.Clear();
            Response.Redirect("index.aspx");
        }

    }

    protected void btnRegister_Click(object sender, EventArgs e)
    {
        if (btnRegister.Text == "Register")
            Response.Redirect("signup.aspx");
        else
        {
            Response.Redirect("BusinessPage.aspx");
        }
    }

}