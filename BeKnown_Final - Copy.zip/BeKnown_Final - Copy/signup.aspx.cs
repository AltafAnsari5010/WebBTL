﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class signup : System.Web.UI.Page
{
    Common cs = new Common();
    string EmailS = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Email"] != null)
        {
            Response.Redirect("index.aspx");
        }
       

        
    }
   
    protected void btnRegister_ServerClick(object sender, EventArgs e)
    {
        string QueryE = "select * from tbl_Register where Email ='" + txtEmail.Value.Trim() + "'";
        if (!cs.IsExist(QueryE))
        {

            QueryE = "insert into tbl_Register (txtCompanyName,txtFullName,txtEmail,Password) values ('" + txtCompanyName.Value.Trim() + "','" + txtName.Value.Trim() + "','" + txtEmail.Value.Trim() + "','" + txtPassword.Value.Trim() + "')";
             if (cs.ExecuteQuery(QueryE))
            {
                Session["Email"] = txtEmail.Value.Trim();
                Session["UserName"] = txtName.Value.Trim();
                Session["CompanyName"] = txtCompanyName.Value.Trim();
                Response.Redirect("index.aspx");
            }
        }
        else
        {
            Response.Write("<script language='javascript'>alert('Email already exist');</script>");
        }

    }
}