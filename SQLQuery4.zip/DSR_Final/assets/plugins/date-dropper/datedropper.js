<HTML>
<!-- Created by HTTrack Website Copier/3.49-2 [XR&CO'2014] -->

<!-- Mirrored from codeminifier.com/new-job-stock/job-stock/assets/plugins/date-dropper/datedropper.js by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 15 Feb 2019 16:26:24 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<HEAD>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html;charset=UTF-8"><META HTTP-EQUIV="Refresh" CONTENT="0; URL=http://themezhub.com/"><TITLE>Page has moved</TITLE>
</HEAD>
<BODY>
<A HREF="http://themezhub.com/"><h3>Click here...</h3></A>
</BODY>
<!-- Created by HTTrack Website Copier/3.49-2 [XR&CO'2014] -->

<!-- Mirrored from codeminifier.com/new-job-stock/job-stock/assets/plugins/date-dropper/datedropper.js by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 15 Feb 2019 16:26:24 GMT -->
</HTML>
