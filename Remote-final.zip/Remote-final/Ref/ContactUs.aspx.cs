﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net.Mail;
using System.Web.UI.HtmlControls;
using System.Configuration;
using System.IO;

public partial class ContactUs : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        SetMasterHeader();
    }

    public void SetMasterHeader()
    {
        Page.Title = "Contact Us | PPME";
        HtmlHead headMain = (HtmlHead)Page.Master.FindControl("MasterHead");
        HtmlMeta htMeta = new HtmlMeta();
        htMeta.Attributes.Add("name", "description");
        htMeta.Attributes.Add("content", "Process Plant & Machinery Engineers is an organisation closely associated with end users, EPCs, engineering consultants, process licensors, and statutory & local bodies. The firm is managed by a group of professionals with an accumulative industry-specific experience of more than 50 years in the mid and the downstream oil and gas sector. They are technically qualified and equippedto understand detailed product specifications and applications and match them with client requirements.");


        //adding  Meta Tag to Head                
        headMain.Controls.Add(htMeta);


        //Similiarly we can add keyword Meta Tag to Head Section        
        HtmlMeta htMeta1 = new HtmlMeta();
        htMeta1.Attributes.Add("name", "keywords");
        htMeta1.Attributes.Add("content", "PPME,Process Plant & Machinery, Contact Us PPME, Engineering Firm, Sales & Service, Buyers Representative, Infrastructure Support for new businesses,MSME Services");
        // adding the Meta Tag to Head
        headMain.Controls.Add(htMeta1);
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            string Name = txtName.Value;
            string CompanyName = txtCompanyName.Value;
            string Designation = txtDesignation.Value;

            string Email = txtEmail.Value;
            string Phone = txtPhone.Value;
            string Subject = txtSubject.Value;
            string Message = txtMessage.Value;

            
            string HtmlFile = Server.MapPath("EmailTemplate.html");
            string body = PopulateBody(Name,CompanyName,Designation, Email, Phone, Subject,  Message, HtmlFile);
            
            SendHtmlFormattedEmail("info@ppme.in", "New Enquiry / Feedback Raised From PPME Website", body);

            //  EC.SendHtmlFormattedEmail("aali5010@gmail.com", "New Enquiry Raised From Big Plus Digital Website - Test Mail", body);
            ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Enquiry Mail Sent !! thank you... We Will Contact You Soon..');", true);

        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Error Message", "alert('" + ex.Message + "');", true);

        }
    }


    public string PopulateBody(string userName, string CompanyName, string Designation, string Email, string Phone, string Subject, string Message, string HtmlFile)
    {
        string body = string.Empty;
        using (StreamReader reader = new StreamReader(HtmlFile))
        {
            body = reader.ReadToEnd();
        }
        body = body.Replace("{UserName}", userName);
        body = body.Replace("{CompanyName}", CompanyName);
        body = body.Replace("{Designation}", Designation);
        body = body.Replace("{Email}", Email);
        body = body.Replace("{Phone}", Phone);
        body = body.Replace("{Subject}", Subject);
        body = body.Replace("{Message}", Message);
        return body;
    }

    public void SendHtmlFormattedEmail(string recepientEmail, string subject, string body)
    {
        using (MailMessage mailMessage = new MailMessage())
        {
            mailMessage.From = new MailAddress(ConfigurationManager.AppSettings["UserName"]);
            mailMessage.Subject = subject;
            mailMessage.Body = body;
            mailMessage.IsBodyHtml = true;
            mailMessage.To.Add(new MailAddress(recepientEmail));
            SmtpClient smtp = new SmtpClient();
            smtp.Host = ConfigurationManager.AppSettings["Host"];
            smtp.EnableSsl = Convert.ToBoolean(ConfigurationManager.AppSettings["EnableSsl"]);
            System.Net.NetworkCredential NetworkCred = new System.Net.NetworkCredential();
            NetworkCred.UserName = ConfigurationManager.AppSettings["UserName"];
            NetworkCred.Password = ConfigurationManager.AppSettings["Password"];
            smtp.UseDefaultCredentials = false;
            smtp.Credentials = NetworkCred;
            smtp.Port = int.Parse(ConfigurationManager.AppSettings["Port"]);
            smtp.Send(mailMessage);
        }
    }
}