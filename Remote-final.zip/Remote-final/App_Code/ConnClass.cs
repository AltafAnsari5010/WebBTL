﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
/// <summary>
/// Summary description for ConnClass
/// </summary>
public class ConnClass
{
    public SqlCommand cmd = new SqlCommand();
    public SqlDataAdapter sda;
    public SqlDataReader sdr;
    public DataSet ds = new DataSet();
    public SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["StrCon"].ToString());
    public string Query { get; set; }
}