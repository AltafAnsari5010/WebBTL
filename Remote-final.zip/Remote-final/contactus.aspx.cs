﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

public partial class contactus : System.Web.UI.Page
{
    EmailClass EC = new EmailClass();
    Common cs = new Common();
    protected void Page_Load(object sender, EventArgs e)
    {
        SetMasterHeader();
    }

    protected void btnSubmit_ServerClick(object sender, EventArgs e)
    {
        try
        {
            string Name = txtName.Value;
            string Mobile = txtMobile.Value;
            string Email = txtEmail.Value;
            string Message = txtMessage.Value;
            string HtmlFile = Server.MapPath("EmailTemplateContact.html");
            string EnquiryDate = DateTime.Now.ToString();
            string Body = EC.PopulateBodyContact(Name, Mobile, Email, Message, HtmlFile);
            // EC.SendHtmlFormattedEmail("info@smitadentalcentre.com", "New Enquiry / Feedback Raised From Smita Dental Clinic Website", Body);

            string Query = "insert into tbl_Enquiry (Name,Mobile,Email,Message,EDate)values('"+Name+ "','" + Mobile + "','" + Email + "','" + Message + "','" + EnquiryDate + "')";
            cs.ExecuteQuery(Query);

              EC.SendHtmlFormattedEmail("aali5010@gmail.com", "New Enquiry / Feedback Raised From Smita Dental Clinic Website - Test Mail", Body);
            ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Enquiry Mail Sent !! thank you... We Will Contact You Soon..');", true);
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Error Message", "alert('" + ex.Message + "');", true);
        }

    }

   public void SetMasterHeader()
    {
        Page.Title = "Contact Us | Smita Dental Clinic";
        HtmlHead headMain = (HtmlHead)Page.Master.FindControl("MasterHead");
        HtmlMeta htMeta = new HtmlMeta();
        htMeta.Attributes.Add("name", "description");
        htMeta.Attributes.Add("content", "Smita Dental Centre is a team of dental professionals, advanced hi- technology and Infrastructure, altogether being backed by the use of such latest dental services, we plan on creating a soothing aura clubbed with the prospect of delivering a wholehearted service at our clinic. One that caters to the well being and dental health of our clients.");


        //adding  Meta Tag to Head                
        headMain.Controls.Add(htMeta);


        //Similiarly we can add keyword Meta Tag to Head Section        
        HtmlMeta htMeta1 = new HtmlMeta();
        htMeta1.Attributes.Add("name", "keywords");
        htMeta1.Attributes.Add("content", "Dentist in Mumbai, India, Dental Clinic in Kandivali, West, - Dental Implants, Cosmetic Dentistry, Tooth Whitening, Painless Root Canal, Dental Implants, Gum Treatment | Smita dental Centre");
        // adding the Meta Tag to Head
        headMain.Controls.Add(htMeta1);
    }
}