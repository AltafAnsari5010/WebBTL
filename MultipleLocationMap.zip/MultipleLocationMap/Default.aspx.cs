﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;


public partial class _Default : System.Web.UI.Page
{
  

    protected void Page_Load(object sender, EventArgs e)
    {
    }
   
    public string ConvertDataTabletoString()
    {
        List<MapClass> MapClassList = new List<MapClass>();
        MapClassList.Add(new MapClass("Lalbagh Botanical Garden",    12.958931,   77.584088,   "Lalbagh Botanical Garden"));
        MapClassList.Add(new MapClass("Bannerghatta National Park",  12.807139,   77.578075,   "Bannerghatta National Park"));
        MapClassList.Add(new MapClass("Cubbon Park", 12.983196,   77.592239,   "Cubbon Park"));
        MapClassList.Add(new MapClass("Hotel Silicrest 3 Star - Koramangala", 12.9343927, 77.6272942, "Hotel Silicrest 3 Star - Koramangala"));
        MapClassList.Add(new MapClass("kempegowda international airport", 13.19864, 77.7044041, "kempegowda international airport"));
        System.Web.Script.Serialization.JavaScriptSerializer serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
        return serializer.Serialize(MapClassList);

    }
}


public class MapClass {

    public MapClass(string title, object lat, object lng, string description)
    {
        this.title = title;
        this.lat = lat;
        this.lng = lng;
        this.description = description;
    }

    public string title { get; set; }
    public object lat { get; set; }
    public object lng { get; set; }
    public string description { get; set; }
}
