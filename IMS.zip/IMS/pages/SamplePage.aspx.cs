﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Drawing;
using SD = System.Drawing;

public partial class SamplePage : System.Web.UI.Page
{
    Common cs = new Common();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //FillReater
        }
    }

    // Add Button Events



    //RepeaterItemCommand





    protected void btnCancel_Click(object sender, EventArgs e)
    {
        //Clear Controls
    }
}