using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Drawing;
using SD = System.Drawing;

public partial class LoanBook : System.Web.UI.Page
{
    Common cs = new Common();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            cs.FillRepeater(rptLoanBook, "select * from tbl_LoanBook"); 
 
        }
    }

    protected void btnAdd_Click(object sender, EventArgs e) 
{ 
//#AddUploadCode  
if(btnAdd.Text == "Update") 
{ 
string Query = "update tbl_LoanBook set txtPaymentDate= '"+txtPaymentDate.Text+"', txtLoanTaken= '"+txtLoanTaken.Text+"', txtLoanAmount= '"+txtLoanAmount.Text+"', txtPaymentAmount= '"+txtPaymentAmount.Text+"', txtBalanceAmount= '"+txtBalanceAmount.Text+"' where  ID=" + lbIdHidden.Text; 
if (cs.ExecuteQuery(Query)) 
{ 
cs.FillRepeater(rptLoanBook, "select * from tbl_LoanBook"); 
btnAdd.Text = "Add"; 
} 
} 
else { 
string Query = "insert into tbl_LoanBook(txtPaymentDate, txtLoanTaken, txtLoanAmount, txtPaymentAmount, txtBalanceAmount) values('"+txtPaymentDate.Text+"', '"+txtLoanTaken.Text+"', '"+txtLoanAmount.Text+"', '"+txtPaymentAmount.Text+"', '"+txtBalanceAmount.Text+"')"; 
if (cs.ExecuteQuery(Query)) 
{ 
cs.FillRepeater(rptLoanBook, "select * from tbl_LoanBook"); 
} 
} 
} 




     protected void rptLoanBook_ItemCommand(object source, RepeaterCommandEventArgs e) 
{ 
Label lbID = (Label)e.Item.FindControl("lbID"); 
Label lbtxtPaymentDate = (Label)e.Item.FindControl("lbtxtPaymentDate"); 
 Label lbtxtLoanTaken = (Label)e.Item.FindControl("lbtxtLoanTaken"); 
 Label lbtxtLoanAmount = (Label)e.Item.FindControl("lbtxtLoanAmount"); 
 Label lbtxtPaymentAmount = (Label)e.Item.FindControl("lbtxtPaymentAmount"); 
 Label lbtxtBalanceAmount = (Label)e.Item.FindControl("lbtxtBalanceAmount"); 
  
if (e.CommandName == "Delete") 
{ 
if (cs.ExecuteQuery("Delete from tbl_LoanBook where ID=" + lbID.Text))  
{ 
cs.FillRepeater(rptLoanBook, "select * from tbl_LoanBook");  
cs.ShowAlert("Loan Book Deleted!!", MessageType.Info);  
} 
} 
if (e.CommandName == "Edit") 
{ 
btnAdd.Text = "Update"; 
txtPaymentDate.Text=lbtxtPaymentDate.Text; 
 txtLoanTaken.Text=lbtxtLoanTaken.Text; 
 txtLoanAmount.Text=lbtxtLoanAmount.Text; 
 txtPaymentAmount.Text=lbtxtPaymentAmount.Text; 
 txtBalanceAmount.Text=lbtxtBalanceAmount.Text; 
 lbIdHidden.Text=lbID.Text; 
  
} 
} 






    protected void btnCancel_Click(object sender, EventArgs e)
    {
        //Clear Controls
    }
}