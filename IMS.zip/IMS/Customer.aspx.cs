using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Drawing;
using SD = System.Drawing;

public partial class Customer : System.Web.UI.Page
{
    Common cs = new Common();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            cs.FillRepeater(rptCustomer, "select * from tbl_Customer");

        }
    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {
        //#AddUploadCode  
        if (btnAdd.Text == "Update")
        {
            string Query = "update tbl_Customer set txtCustomerName= '" + txtCustomerName.Text + "', txtContact= '" + txtContact.Text + "', txtAddress= '" + txtAddress.Text + "', chkIsActive= '" + chkIsActive.Checked + "' where  ID=" + lbIdHidden.Text;
            if (cs.ExecuteQuery(Query))
            {
                cs.FillRepeater(rptCustomer, "select * from tbl_Customer");
                btnAdd.Text = "Add";
            }
        }
        else
        {
            string Query = "insert into tbl_Customer(txtCustomerName, txtContact, txtAddress, chkIsActive) values('" + txtCustomerName.Text + "', '" + txtContact.Text + "', '" + txtAddress.Text + "', '" + chkIsActive.Checked + "')";
            if (cs.ExecuteQuery(Query))
            {
                cs.FillRepeater(rptCustomer, "select * from tbl_Customer");
            }
        }
    }




    protected void rptCustomer_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        Label lbID = (Label)e.Item.FindControl("lbID");
        Label lbtxtCustomerName = (Label)e.Item.FindControl("lbtxtCustomerName");
        Label lbtxtContact = (Label)e.Item.FindControl("lbtxtContact");
        Label lbtxtAddress = (Label)e.Item.FindControl("lbtxtAddress");
        Label lbchkIsActive = (Label)e.Item.FindControl("lbchkIsActive");

        if (e.CommandName == "Delete")
        {
            if (cs.ExecuteQuery("Delete from tbl_Customer where ID=" + lbID.Text))
            {
                cs.FillRepeater(rptCustomer, "select * from tbl_Customer");
                cs.ShowAlert("Customer Deleted!!", MessageType.Info);
            }
        }
        if (e.CommandName == "Edit")
        {
            btnAdd.Text = "Update";
            txtCustomerName.Text = lbtxtCustomerName.Text;
            txtContact.Text = lbtxtContact.Text;
            txtAddress.Text = lbtxtAddress.Text;
            chkIsActive.Checked = cs.TextToBool(lbchkIsActive.Text);
            lbIdHidden.Text = lbID.Text;

        }
    }






    protected void btnCancel_Click(object sender, EventArgs e)
    {
        //Clear Controls
    }
}