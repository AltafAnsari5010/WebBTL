﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Text;
using System.IO;
using System.Drawing;
using SD = System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;

/// <summary>
/// Summary description for Common
/// </summary>
public class Common
{
    public ConnClass ConC = new ConnClass();


    #region DataBase Methods
    public bool IsExist(string Query)
    {
        bool check = false;
        try
        {
            using (ConC.cmd = new SqlCommand(Query, ConC.con))
            {
                ConC.con.Open();
                ConC.sdr = ConC.cmd.ExecuteReader();
                if (ConC.sdr.HasRows)
                    check = true;

                ConC.sdr.Close();
                ConC.con.Close();
            }
        }
        catch (Exception)
        { }
        return check;
    }

    public bool IsTableExist(string Table)
    {
        bool check = false;
        try
        {
            string Query = @"IF EXISTS(SELECT * FROM INFORMATION_SCHEMA.TABLES 
                       WHERE TABLE_NAME='" + Table + "') SELECT 1 ELSE SELECT 0"; ;
            using (ConC.cmd = new SqlCommand(Query, ConC.con))
            {
                ConC.con.Open();
                int x = Convert.ToInt32(ConC.cmd.ExecuteScalar());
                if (x == 1)
                    check = true;

                ConC.con.Close();
            }
        }
        catch (Exception)
        { }
        return check;
    }

    public bool CreateLoginTable()
    {
        bool check = false;
        string sqlsc = "CREATE TABLE tbl_Login (";
        sqlsc += "[ID] [int] IDENTITY(1,1) NOT NULL PRIMARY KEY,";
        sqlsc += "[UserName] [varchar](50) NULL,";
        sqlsc += "[Email] [varchar](50) NULL,";
        sqlsc += "[Password] [varchar](50) NULL,";
        sqlsc += "[IsActive] [bit] NULL,";
        sqlsc += "[Role] [int] NULL )";
        if (ExecuteQuery(sqlsc))
        {
            string Query = "insert into tbl_Login (UserName,Email,Password,IsActive,Role)values('admin','admin@altaf.com','admin123','True','2')";
            ExecuteQuery(Query);
            Query = "insert into tbl_Login (UserName,Email,Password,IsActive,Role)values('Web Admin','web@altaf.com','web123','True','1')";
            ExecuteQuery(Query);
        }
        return check;
    }

    public bool CreatePageTable()
    {
        bool check = false;
        string sqlsc = "CREATE TABLE tbl_PageMaster (";
        sqlsc += "[ID] [int] IDENTITY(1,1) NOT NULL PRIMARY KEY,";
        sqlsc += "[PageName] [varchar](50) NULL,";
        sqlsc += "[PageTitle] [varchar](50) NULL,";
        sqlsc += "[PageCount] [int] NULL,";
        sqlsc += "[IsActive] [bit] NULL)";

        check = ExecuteQuery(sqlsc);
        return check;
    }

    public bool CreateFieldsTable()
    {
        bool check = false;
        string sqlsc = "CREATE TABLE tbl_FieldsMaster (";
        sqlsc += "[ID] [int] IDENTITY(1,1) NOT NULL PRIMARY KEY,";
        sqlsc += "[PageID] [int] NULL,";
        sqlsc += "[PageName] [varchar](50) NULL,";
        sqlsc += "[FieldTitle] [varchar](50) NULL,";
        sqlsc += "[FieldName] [varchar](50) NULL,";
        sqlsc += "[FieldType] [varchar](50) NULL,";
        sqlsc += "[DataType] [varchar](50) NULL,";
        sqlsc += "[ValidationType] [varchar](50) NULL,";
        sqlsc += "[ddlList] [varchar](Max) NULL,";
        sqlsc += "[IsRequired] [bit] NULL,";
        sqlsc += "[IsActive] [bit] NULL)";

        check = ExecuteQuery(sqlsc);
        return check;
    }

    public void FillRepeater(Repeater rptTables, string Query)
    {
        using (ConC.cmd = new SqlCommand(Query, ConC.con))
        {
            ConC.con.Open();
            ConC.sda = new SqlDataAdapter(ConC.cmd);
            ConC.sda.Fill(ConC.ds);
            rptTables.DataSource = ConC.ds;
            rptTables.DataBind();
            ConC.con.Close();
        }
        ConC.ds.Clear();
    }

    public bool ExecuteQuery(string Query)
    {
        int j = 0;
        try
        {
            ConC.Query = Query;
            using (ConC.cmd = new SqlCommand(ConC.Query, ConC.con))
            {
                ConC.cmd.CommandType = CommandType.Text;

                if (ConC.con.State == ConnectionState.Open)
                    ConC.con.Close();

                ConC.con.Open();
                j = ConC.cmd.ExecuteNonQuery();
                ConC.con.Close();

            }
        }
        catch (Exception)
        { }

        if (j != 0)
            return true;
        else
            return false;

    }

    public string GetColumVal(string Query, string ColName)
    {
        string val = "";
        using (ConC.cmd = new SqlCommand(Query, ConC.con))
        {
            ConC.con.Open();
            ConC.sdr = ConC.cmd.ExecuteReader();
            if (ConC.sdr.HasRows)
            {
                while (ConC.sdr.Read())
                {
                    val = ConC.sdr[ColName].ToString();
                }
            }
            ConC.sdr.Close();
            ConC.con.Close();
        }

        return val;
    }

  

    public List<ControlClass> GetControlList(string ID)
    {
        List<ControlClass> ContList = new List<ControlClass>();
        try
        {
            string Query = "select * from tbl_FieldsMaster where PageID=" + ID;
            using (ConC.cmd = new SqlCommand(Query, ConC.con))
            {
                if(ConC.con.State == ConnectionState.Open)
                    ConC.con.Close();

                ConC.con.Open();
                ConC.sdr = ConC.cmd.ExecuteReader();
                if (ConC.sdr.HasRows)
                {
                    while (ConC.sdr.Read())
                    {
                        ControlClass CC = new ControlClass();
                        CC.ID = ConC.sdr["ID"].ToString();
                        CC.PageName = ConC.sdr["PageName"].ToString();
                        CC.PageID = ConC.sdr["PageID"].ToString();
                        CC.FieldName = ConC.sdr["FieldName"].ToString();
                        CC.FieldTitle = ConC.sdr["FieldTitle"].ToString();
                        CC.FieldType = ConC.sdr["FieldType"].ToString();
                        CC.DataType = ConC.sdr["DataType"].ToString();
                        CC.Validate = ConC.sdr["ValidationType"].ToString();
                        CC.IsRequired = ConC.sdr["IsRequired"].ToString();
                        CC.IsActive = ConC.sdr["IsActive"].ToString();
                        if (CC.FieldType == "DropDownList")
                            CC.DDlist = ConC.sdr["ddlList"].ToString();

                        ContList.Add(CC);
                    }
                }
                ConC.sdr.Close();
                ConC.con.Close();
            }
        }
        catch (Exception)
        { }

        return ContList;
    }

    public string GetValidation(ControlClass CC)
    {
        string RetVal = "";
        if (CC.FieldType == "TextBox")
        {
            if (CC.Validate == "Number")
                RetVal = "TextMode=\"Number\" ";
            else
                if (CC.Validate == "Email")
                RetVal = "TextMode=\"Email\" ";
            else
                if (CC.Validate == "Password")
                RetVal = " TextMode=\"Password\" ";
            else
                if (CC.Validate == "Phone")
                RetVal = " TextMode=\"Number\" ";
        }

        return RetVal;

    }

    #endregion

    #region Master Page Methods
    //Set title
    public void SetTitle(string title)
    {
        Page page = HttpContext.Current.CurrentHandler as Page;

        Label lb = (Label)page.Master.FindControl("lblSetTitle");
        lb.Text = title;
    }
    #endregion

    #region Other Methods
    public void ShowAlert(string Message, MessageType messagetype)
    {
        string Class = messagetype.ToString();
        switch (Class)
        {
            case "Success":
                Class = "alert-success";
                break;
            case "Error":
                Class = "alert-danger";
                break;
            case "Warning":
                Class = "alert-warning";
                break;
            default:
                Class = "alert-info";
                break;
        }
        Page page = HttpContext.Current.CurrentHandler as Page;
        ScriptManager.RegisterStartupScript(page, page.GetType(), System.Guid.NewGuid().ToString(), "ShowMessage('" + Message + "','" + Class + "');", true);
    }

   

    public bool IsFileLocked(FileInfo file)
    {
        FileStream stream = null;
        try
        {
            stream = file.Open(FileMode.Open, FileAccess.Read, FileShare.None);
        }
        catch (IOException)
        {
            //the file is unavailable because it is:
            //still being written to
            //or being processed by another thread
            //or does not exist (has already been processed)
            return true;
        }
        finally
        {
            if (stream != null)
                stream.Close();
        }
        //file is not locked
        return false;
    }

    //Get Dynamic File Name
    public string SetFileName(string filename)
    {
        FileInfo fi = new FileInfo(filename);
        string ext = fi.Extension;
        string name = fi.Name.Replace(ext, "");
        if (name.Contains("#"))
            name = name.Replace("#", "-");
        Random rand = new Random();
        int raNum = 0;

        raNum += rand.Next();

        string Name = name += "_" + DateTime.Now.ToString("d-M-yyyy") + "_" + raNum + ext;
        return Name;
    }

    //Remove ',' from FileList string
    public void RemoveCommaString(string FileList, List<string> ListFiles)
    {
        char[] Comma = new char[] { ',' };
        string[] oFileList = FileList.Split(Comma, StringSplitOptions.None);
        foreach (string oFile in oFileList)
            ListFiles.Add(oFile);
    }

    public string Rating(int rate)
    {
        string RateText = "";
        for (int i = 1; i <= 5; i++)
        {
            string star = "<i class='st'></i>";
            string star1 = "<i class='st-o'></i>";
            if (i <= rate)
                RateText += star;
            else
                RateText += star1;
        }
        return RateText;
    }


    public void GenratePassword(TextBox txtPwd)
    {
        string pwd = "@PES";
        string allowedChars = "";

        allowedChars = "a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,";

        allowedChars += "A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,";

        allowedChars += "1,2,3,4,5,6,7,8,9,0,!,@,#,$,%,&,?";

        char[] sep = { ',' };

        string[] arr = allowedChars.Split(sep);

        string passwordString = "";

        string temp = "";

        Random rand = new Random();

        for (int i = 0; i < 5; i++)
        {
            temp = arr[rand.Next(0, arr.Length)].ToString();
            passwordString += temp;

        }
        txtPwd.Text = pwd + passwordString;
    }

    public List<string> GetCommaSeperatedList(string List)
    {
        List<string> ReturnList = new List<string>();
        char[] Comma = new char[] { ',' };
        string[] ListData = List.Split(Comma, StringSplitOptions.None);
        foreach (string Item in ListData)
        {
            string str = Item.TrimStart();
            ReturnList.Add(Item.TrimStart());
        }

        return ReturnList;
    }

    public bool TextToBool(string Text)
    {
        if (!string.IsNullOrEmpty(Text) && Text.ToUpper() == "TRUE")
            return true;
        else
            return false;
    }

    public string GetFileName(FileUpload fi)
    {
        string filename = "";
        if (!string.IsNullOrEmpty(fi.FileName))
            filename = fi.FileName;

        return filename;
    }


    #endregion

    #region Resize Image With Best Qaulity

    public SD.Image RezizeImage(SD.Image img, int maxWidth, int maxHeight)
    {
        if (img.Height < maxHeight && img.Width < maxWidth) return img;
        using (img)
        {
            Double xRatio = (double)img.Width / maxWidth;
            Double yRatio = (double)img.Height / maxHeight;
            Double ratio = Math.Max(xRatio, yRatio);
            int nnx = (int)Math.Floor(img.Width / ratio);
            int nny = (int)Math.Floor(img.Height / ratio);
            Bitmap cpy = new Bitmap(nnx, nny, PixelFormat.Format32bppArgb);
            using (Graphics gr = Graphics.FromImage(cpy))
            {
                gr.Clear(Color.Transparent);

                // This is said to give best quality when resizing images
                gr.InterpolationMode = InterpolationMode.HighQualityBicubic;

                gr.DrawImage(img,
                    new Rectangle(0, 0, nnx, nny),
                    new Rectangle(0, 0, img.Width, img.Height),
                    GraphicsUnit.Pixel);
            }
            return cpy;
        }

    }

    private MemoryStream BytearrayToStream(byte[] arr)
    {
        return new MemoryStream(arr, 0, arr.Length);
    }

    private void HandleImageUpload(byte[] binaryImage)
    {
        SD.Image img = RezizeImage(SD.Image.FromStream(BytearrayToStream(binaryImage)), 103, 32);
        img.Save("IMAGELOCATION.png", System.Drawing.Imaging.ImageFormat.Gif);
    }
    #endregion

    #region Page Data

    public string TextBoxAdd = " <div class='col-md-6'> \n" +
                                 "<div class='form-group'> \n" +
                                  "<label>ControlTitle</label> \n" +
                                   "<div class='input-group'> \n" +
                                   "<span class='input-group-addon'><i class='fa fa-fighter-jet'></i></span> \n" +
                                   "<asp:TextBox ID = \"txtControlName\" runat='server' CssClass='form-control'></asp:TextBox> \n </div> \n </div> \n </div> \n";

    public string TextBoxEditor = " <div class=\"col-md-12\"> \n" +
                                         "<div class=\"form-group\"> \n " +
                                                "<label>ControlTitle</label> \n" +

                                        "<asp:TextBox ID = \"txtControlName\" runat=\"server\" TextMode=\"MultiLine\" CssClass=\"textarea\" style=\"width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;\"></asp:TextBox> \n" +
                                              
                                            "</div> \n" +
                                        "</div> \n";

    public string TextBoxMultiLine = " <div class=\"col-md-6\"> \n" +
                                         "<div class=\"form-group\"> \n " +
                                                "<label>ControlTitle</label> \n" +

                                        "<asp:TextBox ID = \"txtControlName\" runat=\"server\" TextMode=\"MultiLine\" CssClass=\"form-control\" style=\"width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;\"></asp:TextBox> \n" +
                                              
                                            "</div> \n" +
                                        "</div> \n";

    public string DropDownListAdd = "<div class='col-md-6'> \n" +
                                "<div class='form-group'> \n" +
                                 "<label>ControlTitle</label> \n" +
                                  "<div class='input-group'> \n" +
                                  "<span class='input-group-addon'><i class='fa fa-fighter-jet'></i></span> \n" +
                                   "<asp:DropDownList ID='ddlControlName' CssClass='form-control select2' runat='server' Width='100%'> \n" +
                                   " ListItem " +
                                   " \n </asp:DropDownList> \n </div> \n </div>\n </div> \n";

    public string AddCheckBox = "<div class='col-md-6'> \n" +
                                   "<div class=\"checkbox icheck\">\n" +
                                     "<label> \n" +
                                      "<asp:CheckBox ID=\"chkControlName\" runat=\"server\" /> ControlTitle \n" +
                                     "</label> \n" +
                                  " </div> \n" +
                                 "</div> \n";

    public string TextBoxDate=  "<div class=\"col-md-6\"> \n"+
                                "<div class=\"form-group\"> \n"+
                                "	<label>ControlTitle</label> \n"+
                                "	</asp:Label><div class=\"input-group\"> \n"+
                                "	<span class=\"input-group-addon\" ><i class=\"fa fa-calendar\"></i></span> \n"+
                                "    <asp:TextBox id=\"txtControlName\" runat=\"server\" class=\"form-control txtControlName \" ></asp:TextBox> \n" +
                                "	</div> \n"+
                                "</div> \n"+
                                "</div> \n";

    // For Date 
    public string DateJs = "$('.txtControlName').datetimepicker({ \n " +
                            "format: \"mm-dd-yyyy\", \n " +
                            "weekStart: 1, \n " +
                            "todayBtn: 1, \n " +
                            "autoclose: 1, \n " +
                            "todayHighlight: 1, \n " +
                            "startView: 2, \n " +
                            "forceParse: 0, \n " +
                            "minView: 2 \n " +
                        "}); \n ";

    // For DateTime
    public string DateTimeJs = "$('.txtControlName').datetimepicker({ \n " +
                                "format: \"mm-dd-yyyy HH:ii P\", \n " +
                                "weekStart: 1, \n " +
                                "todayBtn: 1, \n " +
                                "autoclose: 1, \n " +
                                "todayHighlight: 1, \n " +
                                "startView: 2, \n " +
                                "forceParse: 0, \n " +
                                "showMeridian: 1 \n " +
                            "}); \n ";


    public string AddFileUploadImg = " <div class=\"col-md-4\" > \n" +
                                    "<label>ControlTitle</label> \n" +
                                    "<asp:FileUpload ID=\"FileControlName\" runat=\"server\" class=\"btn btn-default\" /> \n" +
                                      "<asp:Label ID=\"lblControlName\" runat=\"server\" Text='' Visible=\"false\"></asp:Label> \n" +
		                            "</div> \n"+
		                            "<div class=\"col-md-2\"> \n"+
                                    "<img id=\"ImgControlName\" src='' class=\"user-image\" style=\"height: 100px;\" /> \n" +
		                            "</div> \n";

    public string AddFileUploadFile = " <div class=\"col-md-6\" > \n" +
                                "<label>ControlTitle</label> \n" +
                                "<asp:FileUpload ID=\"FileControlName\" runat=\"server\" class=\"btn btn-default\" /> \n" +
                                 "<asp:Label ID=\"lblControlName\" runat=\"server\" Text='' Visible=\"false\"></asp:Label> \n" +
                                "</div> \n";
                                

    public string FileUploadOnChangeJS = "$(document).on('change', '#<%= FileControlName.ClientID%>', function (e) { \n" +
                                            "var tmppath = URL.createObjectURL(e.target.files[0]); \n" +
                                            "$('#ImgControlName').attr('src', tmppath); \n" +
                                           "}); \n ";


    public string FileUploadCodeImgCS = "if (#FileUpload.HasFile) \n" +
                                    "{ \n" +
                                    "     string FileDirectory = Server.MapPath(\"/\") + \"/Uploads/#TableName/\"; \n" +
                                    "     if (!Directory.Exists(FileDirectory)) \n" +
                                    "         Directory.CreateDirectory(FileDirectory); \n" +
                                  
                                    "     string FileWithPath= FileDirectory + #FileUpload.FileName; \n"+
                                    "     #FileUpload.SaveAs(FileWithPath); \n" +
                                    "     SD.Image img = SD.Image.FromFile(FileWithPath); \n"+
                                    "     SD.Image img1 = cs.RezizeImage(img, 500, 500); // Image Specify File Size \n"+
                                    "     img1.Save(FileWithPath); \n"+
                                    "     #lblControlName.Text = #FileUpload.FileName; \n" +
                                    " } \n";

    public string FileUploadCodeCS = "if (#FileUpload.HasFile) \n" +
                                "{ \n" +
                                "     string FileDirectory = Server.MapPath(\"/\") + \"/Uploads/#TableName/\"; \n" +
                                "     if (!Directory.Exists(FileDirectory)) \n" +
                                "         Directory.CreateDirectory(FileDirectory); \n" +

                                "     string FileWithPath= FileDirectory + #FileUpload.FileName; \n" +
                                "     #FileUpload.SaveAs(FileWithPath); \n" +
                                "     #lblControlName.Text = #FileUpload.FileName; \n" +
                                " } \n";
    public string UploadTrigger = "<Triggers> \n" +
                                "	<asp:PostBackTrigger ControlID=\"btnAdd\" /> \n"+
                                "</Triggers> \n";


    public string RepeaterSection = "<%--Repeater Section--%>";

    public string RepeaterText = " <asp:UpdatePanel ID='upTask' runat='server'> \n"+
                                 "<ContentTemplate> \n" +
                                 "<div class='row'> \n" +
                                 "<div class='col-md-12'> \n" +
                                 "<div class='box box-purple'> \n" +
                                 "<div class='box-header with-border bg-Black-light'> \n" +
                                  "<h3 class='box-title text-gray'>Title84101 List</h3> \n" +
                                  "</div> \n" +
                                "<div class='box-body'> \n" +
                                 "<div class='dataTables_wrapper'> \n" +
                                  "<table id = 'tbl_Name' class='table table-bordered table-hover'> \n" +
                                  "<thead> \n" +
                                  "<tr> \n" +
                                     "<th>ID</th> \n" +
                                       "<th>th84101</th> \n" +
                                        
                                        "<th>Edit</th> \n" +
                                         "</tr> \n" +
                                          "</thead> \n" +
                                            "<tbody> \n" +
                                             "<asp:Repeater ID = 'rptName' runat='server' OnItemCommand='rptName_ItemCommand'> \n" +
                                               "<ItemTemplate> \n" +
                                                 "<tr> \n" +
                                                  "<td><asp:Label ID = 'lbID' runat='server' Text='<%# Eval(\"ID\") %>'></asp:Label></td> \n" +
                                                    "<td><%# Eval(\"Eval84101\") %></td> \n" +
                                                     "<td>"+
                                                       "<asp:Button ID = 'btnDelete' Text='Delete' CssClass='btn btn-danger' runat='server' CommandName='Delete' OnClientClick=\"javascript:return confirm('Are you sure You want to Delete?');\" formnovalidate /> " +
                                      "<asp:Button ID=\"btnEdit\" runat=\"server\" CssClass=\"btn btn-success\" CommandName=\"Edit\" Text=\"Edit\" formnovalidate /> \n" +
                                         "</td> \n" +
                                            
                                                        "</tr> \n" +
                                                    "</ItemTemplate> \n" +
                                               "</asp:Repeater> \n" +
                                            "</tbody> \n" +
                                        "</table> \n" +
                                    "</div> \n" +
                                "</div> \n" +
                            "</div> \n" +
                        "</div> \n" +
                    "</div> \n" +
                "</ContentTemplate> \n" +
            "</asp:UpdatePanel> \n";


    public string rptItemCommand = " protected void rptName_ItemCommand(object source, RepeaterCommandEventArgs e) \n" +
   "{ \n" +
       "Label lbID = (Label)e.Item.FindControl(\"lbID\"); \n" +
       "#FindControls \n" +

       "if (e.CommandName == \"Delete\") \n" +
       "{ \n" +
           "if (cs.ExecuteQuery(\"Delete from tbl_Name where ID=\" + lbID.Text))  \n" +
           "{ \n" +
               "cs.FillRepeater(rptName, \"select * from tbl_Name\");  \n" +
               "cs.ShowAlert(\"Title84101 Deleted!!\", MessageType.Info);  \n" +
           "} \n" +
       "} \n" +

       "if (e.CommandName == \"Edit\") \n" +
       "{ \n" +
           "btnAdd.Text = \"Update\"; \n" +
            "#DisplayValues \n"+
       "} \n" +

   "} \n";

    public string AddText = "protected void btnAdd_Click(object sender, EventArgs e) \n" +
                            "{ \n" +

                                "//#AddUploadCode  \n" +
                                "if(btnAdd.Text == \"Update\") \n" +
                                    "{ \n" +
                                            "string Query = \"update tbl_Name set #UpdateParam where  ID=\" + lbIdHidden.Text; \n" +
                                            "if (cs.ExecuteQuery(Query)) \n" +
                                            "{ \n" +
                                               "cs.FillRepeater(rptName, \"select * from tbl_Name\"); \n" +
                                                "btnAdd.Text = \"Add\"; \n" +
                                            "} \n" +
                                        "} \n" +
                                    "else { \n" +
                                        
                                        "string Query = \"insert into tbl_Name(#param) values(#values)\"; \n" +
                                        "if (cs.ExecuteQuery(Query)) \n" +
                                        "{ \n" +
                                           "cs.FillRepeater(rptName, \"select * from tbl_Name\"); \n" +
                                        "} \n" +
                                "} \n" +
                            "} \n";


    #region  Validation

    public string Required = " required=\"\" ";

    #endregion



    #endregion
}

public enum MessageType { Success, Error, Warning, Info }

public class ControlClass
{
    public string ID { get; set; }
    public string PageID { get; set; }
    public string DDlist { get; set; }
    public string PageName { get; set; }
    public string FieldTitle { get; set; }
    public string FieldName { get; set; }
    public string FieldType { get; set; }
    public string DataType { get; set; }
    public string Validate { get; set; }
    public string IsRequired { get; set; }
    public string IsActive { get; set; }
}