﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;

public partial class CreatePage : System.Web.UI.Page
{
    Common cs = new Common();
    public string SamplePage = "pages/SamplePage.aspx";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (!cs.IsTableExist("tbl_PageMaster"))
                cs.CreatePageTable();

            cs.FillRepeater(rptPageMaster, "select * from tbl_PageMaster");
        }
    }

    protected void btnUsers_Click(object sender, EventArgs e)
    {
        if (!string.IsNullOrEmpty(txtPageName.Text))
        {
            string DDlist = "";
            string PageName = txtPageName.Text;
            string FieldName = txtFieldName.Text;
            string FieldType = ddlField.SelectedItem.Text;
            string DataType = ddlDataType.SelectedItem.Text;
            string Validate = ddlValidate.SelectedItem.Text;

            if (FieldType == "DropDownList")
                DDlist = txtDDlist.Text;

            bool IsRequired = chkRequired.Checked;
            DataTable dt = GetDataTable(FieldName);
            DataRow NewRow = dt.NewRow();
            NewRow[0] = PageName;
            NewRow[1] = FieldName;
            NewRow[2] = FieldType;
            NewRow[3] = DataType;
            NewRow[4] = Validate;
            NewRow[5] = IsRequired;
            NewRow[6] = DDlist;
            dt.Rows.Add(NewRow);
            gvFieldData.DataSource = dt;
            gvFieldData.DataBind();

        }
    }

    private DataTable GetDataTable(string FieldName)
    {
        DataTable dt = new DataTable();
        dt.Columns.Add("PageName", typeof(string));
        dt.Columns.Add("FieldName", typeof(string));
        dt.Columns.Add("FieldType", typeof(string));
        dt.Columns.Add("DataType", typeof(string));
        dt.Columns.Add("Validate", typeof(string));
        dt.Columns.Add("Required", typeof(bool));
        dt.Columns.Add("ddlList", typeof(string));
        if (gvFieldData.Rows.Count != 0)
        {
            foreach (GridViewRow gvr in gvFieldData.Rows)
            {
                DataRow dr = dt.NewRow();
                Label lbPageName = gvr.FindControl("lbPageName") as Label;
                Label lbFieldName = gvr.FindControl("lbFieldName") as Label;
                Label lbFieldType = gvr.FindControl("lbFieldType") as Label;
                Label lbDataType = gvr.FindControl("lbDataType") as Label;
                Label lbValidate = gvr.FindControl("lbValidate") as Label;
                Label lbRequired = gvr.FindControl("lbRequired") as Label;
                Label lbddlList = gvr.FindControl("lbddlList") as Label;
                if (FieldName != lbFieldName.Text)
                {
                    dr[0] = lbPageName.Text;
                    dr[1] = lbFieldName.Text;
                    dr[2] = lbFieldType.Text;
                    dr[3] = lbDataType.Text;
                    dr[4] = lbValidate.Text;
                    dr[5] = lbRequired.Text;
                    dr[6] = lbddlList.Text;
                    dt.Rows.Add(dr);
                }
            }

        }
        return dt;

    }

    protected void gvFieldData_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        Label lbFieldName = gvFieldData.Rows[e.RowIndex].FindControl("lbFieldName") as Label;
        DataTable dt = GetDataTable(lbFieldName.Text);
        gvFieldData.DataSource = dt;
        gvFieldData.DataBind();
    }

    protected void btnAddPage_Click(object sender, EventArgs e)
    {
        try
        {
            if (!cs.IsTableExist("tbl_PageMaster"))
                cs.CreatePageTable();

            if (!cs.IsTableExist("tbl_FieldsMaster"))
                cs.CreateFieldsTable();

            if (gvFieldData.Rows.Count > 0 && !string.IsNullOrEmpty(txtPageName.Text))
            {
                string Query = "select ID from tbl_PageMaster where PageTitle='" + txtPageName.Text + "'";
                string ID = cs.GetColumVal(Query, "ID");
                string PageName = GetPageName(txtPageName.Text);
                string PageAspx = "";
                if (string.IsNullOrEmpty(ID))
                {
                    string InsertPageQ = "insert into tbl_PageMaster ([PageName],[PageTitle],[PageCount],[IsActive])values('" + PageName + "', '" + txtPageName.Text + "',0,'True')";
                    if (cs.ExecuteQuery(InsertPageQ))
                        ID = cs.GetColumVal(Query, "ID");
                }

                foreach (GridViewRow gvr in gvFieldData.Rows)
                {

                    Label lbPageName = gvr.FindControl("lbPageName") as Label;
                    Label lbFieldName = gvr.FindControl("lbFieldName") as Label;
                    Label lbFieldType = gvr.FindControl("lbFieldType") as Label;
                    Label lbDataType = gvr.FindControl("lbDataType") as Label;
                    Label lbValidate = gvr.FindControl("lbValidate") as Label;
                    Label lbRequired = gvr.FindControl("lbRequired") as Label;
                    Label lbddlList = gvr.FindControl("lbddlList") as Label;

                    if (lbFieldName != null)
                    {
                        if (!cs.IsExist("select * from tbl_FieldsMaster where [FieldTitle]='" + lbFieldName.Text + "' AND [PageID]=" + ID))
                        {
                            string FieldName = GetFieldName(lbFieldName.Text, lbFieldType.Text);

                            Query = "insert into tbl_FieldsMaster ([PageID],[PageName],[FieldName],[FieldTitle],[FieldType],[DataType],[ValidationType],[ddlList],[IsRequired],[IsActive])values(" + ID + ",'" + lbPageName.Text + "','" + FieldName + "','" + lbFieldName.Text + "','" + lbFieldType.Text + "','" + lbDataType.Text + "','" + lbValidate.Text + "','" + lbddlList.Text + "','" + lbRequired.Text + "','True')";
                            cs.ExecuteQuery(Query);
                        }

                    }
                }

                if (!string.IsNullOrEmpty(ID))
                {
                    PageAspx = CreatePageFile(PageName, txtPageName.Text);
                    List<ControlClass> ContList = cs.GetControlList(ID);
                    if (File.Exists(PageAspx) && ContList.Count > 0)
                    {
                        List<string> AllTextColl = File.ReadAllLines(PageAspx).ToList();
                        List<string> ControlText = new List<string>();
                        List<string> AllTextNew = new List<string>();

                        string FileonChangeCode = "";
                        string DateJsCode = "";
                        foreach (ControlClass CC in ContList)
                        {
                            string Required = "";
                            if (CC.IsRequired == "True")
                                Required = cs.Required;

                            if (CC.FieldType == "TextBox")
                            {
                                string Validate = cs.GetValidation(CC);

                                if (CC.IsRequired== "True")
                                    Validate += cs.Required;

                                if (CC.DataType == "DateTime" || CC.DataType == "Date")
                                {
                                    string DateJs = cs.DateTimeJs;
                                    if (CC.DataType == "Date")
                                        DateJs = cs.DateJs;
                                    DateJs = DateJs.Replace("txtControlName", CC.FieldName);
                                    DateJsCode += DateJs;

                                    string textstr = cs.TextBoxDate;
                                    textstr = textstr.Replace("ControlTitle", CC.FieldTitle);
                                    textstr = textstr.Replace("txtControlName\"", CC.FieldName + "\" " + Validate);
                                    textstr = textstr.Replace("txtControlName ", CC.FieldName);
                                    ControlText.Add(textstr);
                                }
                                else
                                {
                                    string textstr = cs.TextBoxAdd;
                                    textstr = textstr.Replace("ControlTitle", CC.FieldTitle);
                                    textstr = textstr.Replace("txtControlName\"", CC.FieldName + "\" " + Validate);
                                    ControlText.Add(textstr);
                                }

                              



                            }
                            if (CC.FieldType == "TextBoxMultiLine")
                            {
                                string textstr = cs.TextBoxMultiLine;
                                textstr = textstr.Replace("ControlTitle", CC.FieldTitle);
                                textstr = textstr.Replace("txtControlName\"", CC.FieldName + "\" " + Required);
                                ControlText.Add(textstr);


                            }
                            if (CC.FieldType == "TextBoxEditor")
                            {
                                string textstr = cs.TextBoxEditor;
                                textstr = textstr.Replace("ControlTitle", CC.FieldTitle);
                                textstr = textstr.Replace("txtControlName\"", CC.FieldName + "\" " + Required);
                                ControlText.Add(textstr);


                            }

                            if (CC.FieldType == "FileUploadImage")
                            {
                                string textstr = cs.AddFileUploadImg;
                                textstr = textstr.Replace("ControlTitle", CC.FieldTitle);
                                textstr = textstr.Replace("FileControlName", CC.FieldName);
                                textstr = textstr.Replace("ImgControlName", "Img" + CC.FieldName);
                                textstr = textstr.Replace("lblControlName", "lbl" + CC.FieldName);
                                ControlText.Add(textstr);

                                string FileonChangeCodes = cs.FileUploadOnChangeJS;
                                FileonChangeCodes = FileonChangeCodes.Replace("FileControlName", CC.FieldName);
                                FileonChangeCodes = FileonChangeCodes.Replace("ImgControlName", "Img" + CC.FieldName);
                                FileonChangeCode += FileonChangeCodes;


                            }

                            if (CC.FieldType == "FileUploadFile")
                            {
                                string textstr = cs.AddFileUploadFile;
                                textstr = textstr.Replace("ControlTitle", CC.FieldTitle);
                                textstr = textstr.Replace("FileControlName", CC.FieldName);
                                textstr = textstr.Replace("lblControlName", "lbl" + CC.FieldName);
                                ControlText.Add(textstr);


                            }

                            if (CC.FieldType == "Checkbox")
                            {
                                string textstr = cs.AddCheckBox;
                                textstr = textstr.Replace("ControlTitle", CC.FieldTitle);
                                textstr = textstr.Replace("chkControlName", CC.FieldName);
                                ControlText.Add(textstr);


                            }
                            if (CC.FieldType == "DropDownList")
                            {
                                string textstr = cs.DropDownListAdd;
                                textstr = textstr.Replace("ControlTitle", CC.FieldTitle);
                                textstr = textstr.Replace("ddlControlName", CC.FieldName);
                                if (!string.IsNullOrEmpty(CC.DDlist))
                                {
                                    List<string> ItemList = cs.GetCommaSeperatedList(CC.DDlist);
                                    string stritemlist = "";
                                    foreach (string str in ItemList)
                                    {
                                        string item = "<asp:ListItem>" + str + "</asp:ListItem> \n";
                                        stritemlist += item;

                                    }

                                    if (stritemlist != "")
                                        textstr = textstr.Replace("ListItem", stritemlist);
                                }
                                ControlText.Add(textstr);
                            }

                        }

                        if (ControlText.Count > 0)
                        {
                            string textFind = (from p in AllTextColl where p.Contains("<div class='row' id='DivControls'>") select p).FirstOrDefault();
                            int ind = AllTextColl.IndexOf(textFind) + 1;
                            AllTextNew.AddRange(AllTextColl.Take(ind));
                            AllTextNew.AddRange(ControlText);
                            AllTextColl.Skip(ind);
                            AllTextNew.AddRange(AllTextColl.Skip(ind).Take(AllTextColl.Count));
                            string result = String.Join("\n", AllTextNew.ToArray());
                            if (FileonChangeCode != "")
                                result = result.Replace("//OnFileChange", FileonChangeCode);

                            if (DateJsCode != "")
                                result = result.Replace("//#DateJS", DateJsCode);

                            File.WriteAllText(PageAspx, result);

                        }
                    }
                    CreatePageTable(ContList, PageName, ID);
                    CreateRepeater(ContList, PageName, ID, PageAspx);
                    cs.FillRepeater(rptPageMaster, "select * from tbl_PageMaster");
                    Response.Redirect("CreatePage.aspx");
                }

            }
        }
        catch (Exception)
        { }
    }

    // Create Page File .aspx and .cs
    private string CreatePageFile(string pageName, string PageTitle)
    {
        string RetPageName = "";

        try
        {
            string TableName = "tbl_" + pageName.Replace(".aspx", "");
            string SamplePathaspx = Server.MapPath(SamplePage);
            string SamplePathcs = Server.MapPath(SamplePage + ".cs");
            if (File.Exists(SamplePathaspx))
            {
                FileInfo f1 = new FileInfo(SamplePathaspx);
                FileInfo f2 = new FileInfo(SamplePathcs);
                string PagePath = Server.MapPath("~/admin/");
                string FilePageAspx = PagePath + pageName;
                string FilePagecs = PagePath + pageName + ".cs";
                if (!File.Exists(FilePageAspx))
                {
                    File.Copy(SamplePathaspx, PagePath + f1.Name, true);
                    File.Copy(SamplePathcs, PagePath + f2.Name, true);
                    File.Move(PagePath + f1.Name, FilePageAspx);
                    File.Move(PagePath + f2.Name, FilePagecs);

                    string pageNames = pageName.Replace(".aspx", "");
                    if (File.Exists(FilePageAspx))
                    {
                        string AllTextStr = File.ReadAllText(FilePageAspx);
                        AllTextStr = AllTextStr.Replace("SamplePage", pageNames);
                        AllTextStr = AllTextStr.Replace("~/MasterPage.master", "MasterPage.master");
                        AllTextStr = AllTextStr.Replace("Page Header", PageTitle);
                        AllTextStr = AllTextStr.Replace("Add Page ", PageTitle);
                        AllTextStr = AllTextStr.Replace("tbl_Name", TableName);
                        File.WriteAllText(FilePageAspx, AllTextStr);
                    }

                    if (File.Exists(FilePagecs))
                    {
                        string AllTextStr = File.ReadAllText(FilePagecs);
                        AllTextStr = AllTextStr.Replace("SamplePage", pageNames);

                        File.WriteAllText(FilePagecs, AllTextStr);
                    }

                    RetPageName = FilePageAspx;
                }
            }
        }
        catch (Exception)
        { }

        return RetPageName;
    }

    // Creating Repeater With Its Functions
    private bool CreateRepeater(List<ControlClass> ContList, string PageName, string ID, string PageFile)
    {
        bool RetCheck = false;
        try
        {
            string FolderName = PageName.Replace(".aspx", "");
            string TableName = "tbl_" + FolderName;
            string RepeaterName = "rpt" + FolderName;

            // .Aspx File
            if (File.Exists(PageFile) && ContList.Count > 0)
            {
                string RepText = cs.RepeaterText;
                RepText = RepText.Replace("tbl_Name", TableName);
                RepText = RepText.Replace("rptName", RepeaterName);
                string Title = txtPageName.Text;

                if (Title.Contains("Master"))
                    Title = Title.Replace("Master", "");

                RepText = RepText.Replace("Title84101", Title);

                string AllText = File.ReadAllText(PageFile);

                string HeaderList = "";
                string ItemList = "";
                foreach (ControlClass CC in ContList)
                {

                    //<img id="ImgDisp" src="" class="user-image" style="height: 100px;" />
                    HeaderList += "<th>" + CC.FieldTitle + "</th> \n";
                    if (CC.FieldType == "FileUploadImage")
                    {
                        string imgCode = "<img id=\"ImgDisp\" src='/admin/Uploads/" + FolderName + "/<%# Eval(\"" + CC.FieldName + "\") %>' class=\"user-image\" style =\"height: 100px;\" />  \n ";
                        string lablecode = "<asp:Label ID = 'lb" + CC.FieldName + "' Visible=\"false\" runat ='server' Text='<%# Eval(\"" + CC.FieldName + "\") %>'></asp:Label>";
                        ItemList += "<td>" + imgCode + lablecode + "</td> \n";
                    }
                    else
                        ItemList += "<td><asp:Label ID = 'lb" + CC.FieldName + "' runat='server' Text='<%# Eval(\"" + CC.FieldName + "\") %>'></asp:Label></td> \n";
                }

                RepText = RepText.Replace("<th>th84101</th>", HeaderList);
                RepText = RepText.Replace("<td><%# Eval(\"Eval84101\") %></td>", ItemList);
                AllText = AllText.Replace("ID=\"btnAdd\"", "ID=\"btnAdd\" OnClick=\"btnAdd_Click\" ");
                AllText = AllText.Replace(cs.RepeaterSection, RepText);

                ControlClass C = (from c in ContList where c.FieldType == "FileUploadImage" || c.FieldType == "FileUploadFile" select c).FirstOrDefault();
                if (C != null)
                    AllText = AllText.Replace("<%--BtnAddTrigger--%>", cs.UploadTrigger);

                File.WriteAllText(PageFile, AllText);
            }

            // .cs File
            string PageNameCS = PageFile + ".cs";
            if (File.Exists(PageNameCS) && ContList.Count > 0)
            {
                // Repeater Item Command
                string RepText = cs.rptItemCommand;
                RepText = RepText.Replace("tbl_Name", TableName);
                RepText = RepText.Replace("rptName", RepeaterName);
                string Title = txtPageName.Text;

                if (Title.Contains("Master"))
                    Title = Title.Replace("Master", "");

                RepText = RepText.Replace("Title84101", Title);
                string FindControlsList = "";
                string DisplayValList = "";
                foreach (ControlClass CC in ContList)
                {
                    string ParamType = ".Text";

                    if (CC.FieldType == "DropDownList")
                        ParamType = ".SelectedItem.Text";
                    else if (CC.FieldType == "Checkbox")
                        ParamType = ".Checked";

                    if (CC.FieldType == "Checkbox")
                        DisplayValList += CC.FieldName + ParamType + "=" + "cs.TextToBool(lb" + CC.FieldName + ".Text); \n ";
                    else if (CC.FieldType == "FileUploadImage" || CC.FieldType == "FileUploadFile")
                        DisplayValList += "lbl" + CC.FieldName + ParamType + "=" + "lb" + CC.FieldName + ".Text; \n ";
                    else
                        DisplayValList += CC.FieldName + ParamType + "=" + "lb" + CC.FieldName + ".Text; \n ";


                    FindControlsList += "Label lb" + CC.FieldName + " = (Label)e.Item.FindControl(\"lb" + CC.FieldName + "\"); \n ";

                }

                DisplayValList += "lbIdHidden.Text=lbID.Text; \n ";
                RepText = RepText.Replace("#FindControls", FindControlsList);
                RepText = RepText.Replace("#DisplayValues", DisplayValList);

                string AllText = File.ReadAllText(PageNameCS);

                AllText = AllText.Replace("//RepeaterItemCommand", RepText);
                string FillRepeat = "cs.FillRepeater(" + RepeaterName + ", \"select * from " + TableName + "\"); \n ";
                AllText = AllText.Replace("//FillReater", FillRepeat);


                string Param = "";
                string Values = "";
                string UpdateParam = "";
                string FilesUploadCode = "";
                // Creating Add Function
                int count = 0;


                foreach (ControlClass CC in ContList)
                {
                    count++;

                    if (count == ContList.Count)
                        Param += CC.FieldName;
                    else
                        Param += CC.FieldName + ", ";

                    string TempP = CC.FieldName;

                    string ParamType = ".Text";

                    if (CC.FieldType == "DropDownList")
                        ParamType = ".SelectedItem.Text";
                    else if (CC.FieldType == "Checkbox")
                        ParamType = ".Checked";

                    string coma = ", ";
                    if (count == ContList.Count)
                        coma = "";

                    if (CC.FieldType == "FileUploadFile" || CC.FieldType == "FileUploadImage")
                    {
                        Values += "'\"+ lbl" + CC.FieldName + ParamType + "+\"'" + coma;
                        UpdateParam += CC.FieldName + "= '\"+lbl" + CC.FieldName + ParamType + "+\"'" + coma;

                        FilesUploadCode += GetFileUploadCode(CC, FolderName);
                    }
                    else
                    {
                        Values += "'\"+" + CC.FieldName + ParamType + "+\"'" + coma;
                        UpdateParam += CC.FieldName + "= '\"+" + CC.FieldName + ParamType + "+\"'" + coma;
                    }

                }

                string AddFunction = cs.AddText;

                if (FilesUploadCode != "")
                    AddFunction = AddFunction.Replace("//#AddUploadCode", FilesUploadCode);

                AddFunction = AddFunction.Replace("#UpdateParam", UpdateParam);
                AddFunction = AddFunction.Replace("#param", Param);
                AddFunction = AddFunction.Replace("#values", Values);
                AddFunction = AddFunction.Replace("tbl_Name", TableName);
                AddFunction = AddFunction.Replace("rptName", RepeaterName);

                AllText = AllText.Replace("// Add Button Events", AddFunction);

                File.WriteAllText(PageNameCS, AllText);
            }
        }
        catch (Exception)
        { }


        return RetCheck;

    }

    private string GetFileUploadCode(ControlClass CC, string FolderName)
    {
        string RetCode = "";

        if (CC.FieldType == "FileUploadFile")
            RetCode = cs.FileUploadCodeCS;
        else
            RetCode = cs.FileUploadCodeImgCS;

        RetCode = RetCode.Replace("#FileUpload", CC.FieldName);
        RetCode = RetCode.Replace("#lblControlName", "lbl" + CC.FieldName);
        RetCode = RetCode.Replace("#TableName", FolderName);

        return RetCode;

    }

    // Creating Page Table In SQL
    private bool CreatePageTable(List<ControlClass> ContList, string PageName, string ID)
    {
        bool RetCheck = false;
        try
        {
            string TableName = "tbl_" + PageName.Replace(".aspx", "");
            if (!cs.IsTableExist(TableName))
            {
                string sqlsc = "CREATE TABLE " + TableName + " (";
                sqlsc += "[ID] [int] IDENTITY(1,1) NOT NULL PRIMARY KEY,";

                int Count = 0;
                foreach (ControlClass CC in ContList)
                {
                    Count++;
                    string DataType = "[varchar](50)";

                    if (CC.FieldType == "TextBoxMultiLine" || CC.FieldType == "TextBoxEditor")
                        DataType = "[varchar](Max)";

                    if (CC.DataType == "Integer")
                        DataType = "[int]";
                    if (CC.DataType == "double")
                        DataType = "decimal(18, 0)";
                    if (CC.DataType == "Bool")
                        DataType = "[bit]";
                    if (CC.DataType == "DateTime")
                        DataType = "[datetime]";
                    if (CC.DataType == "Date")
                        DataType = "[date]";

                    if (Count == ContList.Count)
                        sqlsc += "[" + CC.FieldName + "] " + DataType + " NULL)";
                    else
                        sqlsc += "[" + CC.FieldName + "] " + DataType + " NULL,";
                }

                RetCheck = cs.ExecuteQuery(sqlsc);
            }
        }
        catch (Exception )
        { }


        return RetCheck;

    }

    private string GetPageName(string PageTitle)
    {
        string PageNameasp = PageTitle + ".aspx";
        if (PageNameasp.Contains(" "))
            PageNameasp = PageNameasp.Replace(" ", "");

        return PageNameasp;
    }

    private string GetFieldName(string FieldTitle, string fType)
    {
        string FieldName = FieldTitle.Trim();
        if (FieldName.Contains(" "))
            FieldName = FieldName.Replace(" ", "");


        if (fType == "DropDownList")
            FieldName = "ddl" + FieldName;
        else if (fType == "Checkbox")
            FieldName = "chk" + FieldName;
        else if (fType == "Radio Button")
            FieldName = "rbtn" + FieldName;
        else if (fType == "FileUploadImage")
            FieldName = "fuImg" + FieldName;
        else if (fType == "FileUploadFile")
            FieldName = "fuFile" + FieldName;
        else
            FieldName = "txt" + FieldName;

        return FieldName;

    }

    protected void rptPageMaster_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        Label lbID = (Label)e.Item.FindControl("lbID");
        Label lbPageName = (Label)e.Item.FindControl("lbPageName");
        if (e.CommandName == "Delete")
        {
            string Query = "delete from tbl_PageMaster where ID=" + lbID.Text;
            if (cs.ExecuteQuery(Query))
            {
                Query = "delete from tbl_FieldsMaster where PageID=" + lbID.Text;
                if (cs.ExecuteQuery(Query))
                {
                    string TableName = "tbl_" + lbPageName.Text;
                    TableName = TableName.Replace(".aspx", "");
                    Query = "drop table " + TableName;
                    if (cs.ExecuteQuery(Query))
                    {
                        cs.FillRepeater(rptPageMaster, "select * from tbl_PageMaster");
                        DeletePageFile(lbPageName.Text);
                    }
                }
            }
        }

        if (e.CommandName == "DeleteFile")
        {
            DeletePageFile(lbPageName.Text);
        }
    }

    public void DeletePageFile(string PageName)
    {
        string PageFileAspx = Server.MapPath("~/admin/") + PageName;
        string PageFileCS = Server.MapPath("~/admin/") + PageName + ".cs";

        if (File.Exists(PageFileAspx))
            File.Delete(PageFileAspx);

        if (File.Exists(PageFileCS))
            File.Delete(PageFileCS);
    }
}
