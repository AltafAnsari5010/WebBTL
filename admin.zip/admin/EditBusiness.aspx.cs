using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Drawing;
using SD = System.Drawing;

public partial class EditBusiness : System.Web.UI.Page
{
    Common cs = new Common();
    BusinessClass BC = new BusinessClass();
    string Email = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["Email"] != null)
            {
                Email = Session["Email"].ToString();
                DisplayData();
            }
            else
                Response.Redirect("../index.aspx");
            //cs.FillRepeater(rptRegister, "select * from tbl_Register");

        }
    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {
        if (fuImgLogo.HasFile)
        {
            string FileDirectory = Server.MapPath("~/") + "/admin/Uploads/Register/";
            if (!Directory.Exists(FileDirectory))
                Directory.CreateDirectory(FileDirectory);
            string FileWithPath = FileDirectory + fuImgLogo.FileName;
            fuImgLogo.SaveAs(FileWithPath);
            SD.Image img = SD.Image.FromFile(FileWithPath);
            SD.Image img1 = cs.RezizeImage(img, 500, 500); // Image Specify File Size 
            try
            {
                img1.Save(FileWithPath);
            }
            catch (Exception ex)
            { }
            lblfuImgLogo.Text = fuImgLogo.FileName;
        }
        if (fuImgBackgroundBanner.HasFile)
        {
            string FileDirectory = Server.MapPath("~/") + "/admin/Uploads/Register/";
            if (!Directory.Exists(FileDirectory))
                Directory.CreateDirectory(FileDirectory);
            string FileWithPath = FileDirectory + fuImgBackgroundBanner.FileName;
            fuImgBackgroundBanner.SaveAs(FileWithPath);
            SD.Image img = SD.Image.FromFile(FileWithPath);
            SD.Image img1 = cs.RezizeImage(img, 500, 500); // Image Specify File Size 
            img1.Save(FileWithPath);
            lblfuImgBackgroundBanner.Text = fuImgBackgroundBanner.FileName;
        }

        string Query = "insert into tbl_Register(txtCompanyName, txtEmail, txtFullName, txtCompanyWebsite, txtFoundedYear, txtContact, txtLocation, txtCompanySize, txtCompanyDetailShort, txtCompanyDetails, fuImgLogo, fuImgBackgroundBanner, txtKeywords, txtIndustryType, txtFacebookLink, txtGoogleLink, txtYoutubeLink, txtInsta, txtTwitter, txtLinkedIn,Tagline) values('" + txtCompanyName.Text + "', '" + txtEmail.Text + "', '" + txtFullName.Text + "', '" + txtCompanyWebsite.Text + "', '" + txtFoundedYear.Text + "', '" + txtContact.Text + "', '" + txtLocation.Text + "', '" + txtCompanySize.Text + "', '" + txtCompanyDetailShort.Text + "', '" + txtCompanyDetails.Text + "', '" + lblfuImgLogo.Text + "', '" + lblfuImgBackgroundBanner.Text + "', '" + txtKeywords.Text + "', '" + txtIndustryType.Text + "', '" + txtFacebookLink.Text + "', '" + txtGoogleLink.Text + "', '" + txtYoutubeLink.Text + "', '" + txtInsta.Text + "', '" + txtTwitter.Text + "', '" + txtLinkedIn.Text + "',, '" + txtTagline.Text + "')";
        if (cs.ExecuteQuery(Query))
        {
            Response.Redirect("BusinessPage.aspx");
            //cs.FillRepeater(rptRegister, "select * from tbl_Register");

        }


    }

    private void DisplayData()
    {
        BC = cs.GetBusinessClassByEmail(Email);
        txtCompanyName.Text = BC.CompanyName;
        txtEmail.Text = BC.Email;
        txtFullName.Text = BC.FullName;
        txtCompanyWebsite.Text = BC.CompanyWebsite;
        txtFoundedYear.Text = BC.FoundedYear;
        txtContact.Text = BC.Contact;
        txtLocation.Text = BC.Location;
        txtCompanySize.Text = BC.CompanySize;
        txtCompanyDetailShort.Text = BC.CompanyDetailShort;
        txtCompanyDetails.Text = BC.CompanyDetails;
        lblfuImgLogo.Text = BC.ImgLogo;
        lblfuImgBackgroundBanner.Text = BC.ImgBackgroundBanner;
        txtKeywords.Text = BC.Keywords;
        txtIndustryType.Text = BC.IndustryType;
        txtFacebookLink.Text = BC.FacebookLink;
        txtGoogleLink.Text = BC.GoogleLink;
        txtYoutubeLink.Text = BC.YoutubeLink;
        txtInsta.Text = BC.Insta;
        txtTwitter.Text = BC.Twitter;
        txtLinkedIn.Text = BC.LinkedIn;
        lbIdHidden.Text = BC.ID;
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        //Clear Controls
        Response.Redirect("../BusinessPage.aspx");
    }
}