﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class SearchPage1 : System.Web.UI.Page
{
    Common cs = new Common();
    public string SearchKey = "";
    string Location = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            SearchKey = Request.QueryString["SearchKey"];
            Location = Request.QueryString["Location"];
            FillGrid();

        }
    }

    protected void btnSearch_ServerClick(object sender, EventArgs e)
    {
         SearchKey = txtSearch.Value.Trim();
         Location = txtSearchByL.Value.Trim();
         FillGrid();
    }

    private void FillGrid()
    {
        if (SearchKey == "" && Location == "")
            cs.FillRepeater(rptGrid, "select * from tbl_Register");
        else
        {
            if (Location == "")
            {
                cs.FillRepeater(rptGrid, "select * from tbl_Register where txtCompanyName LIKE '%" + SearchKey + "%' OR ddlCategory LIKE '%" + SearchKey + "%' OR txtKeywords LIKE '%" + SearchKey + "%' OR ddlCategory LIKE '%" + SearchKey + "%' OR ddlSubCategory LIKE '%" + SearchKey + "%'");
            }
            else
            {
                cs.FillRepeater(rptGrid, "select * from tbl_Register where txtLocation LIKE '%" + SearchKey + "%' AND txtCompanyName LIKE '%" + SearchKey + "%' OR ddlCategory LIKE '%" + SearchKey + "%' OR txtKeywords LIKE '%" + SearchKey + "%' OR ddlCategory LIKE '%" + SearchKey + "%' OR ddlSubCategory LIKE '%" + SearchKey + "%'");
            }
        }
    }

    [WebMethod]
    public static List<string> GetSearchInfo(string SearchKey)
    {
        List<string> BkResult = new List<string>();
        Common cs = new Common();
        BkResult.AddRange(cs.GetColumValList("select * from tbl_Category where txtCategoryName LIKE '%" + SearchKey + "%' ", "txtCategoryName"));
        BkResult.AddRange(cs.GetColumValList("select * from tbl_SubCategory where txtSubCategoryName LIKE '%" + SearchKey + "%'", "txtSubCategoryName"));
        BkResult.AddRange(cs.GetColumValList("select * from tbl_Register where txtCompanyName LIKE '%" + SearchKey + "%'", "txtCompanyName"));
        List<string> HastTagList = cs.GetColumValList("select * from tbl_Register where txtKeywords LIKE '%" + SearchKey + "%'", "txtKeywords");

        foreach (string str in HastTagList)
        {
            BkResult.AddRange(cs.GetCommaSeperatedList(str));
        }

        // BkResult = (from s in BkResult where s.Contains(SearchKey) select s).ToList();

        return BkResult;
    }
}