﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class BusinessPage : System.Web.UI.Page
{
    Common cs = new Common();
    public BusinessClass BC = new BusinessClass();
    string Email = "";
    public List<string> KeyWords = new List<string>();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["Email"] != null)
            {
                Email = Session["Email"].ToString();
                BC = cs.GetBusinessClassByEmail(Email);
                if (!string.IsNullOrEmpty(BC.Keywords))
                {
                    KeyWords = cs.GetCommaSeperatedList(BC.Keywords);
                    //rptKeywords.DataSource = KeyWords.ToArray();
                    //rptKeywords.DataBind();
                    rptKeyWords1.DataSource = KeyWords.ToArray();
                    rptKeyWords1.DataBind();
                }
            }
            else
                Response.Redirect("Login.aspx");
        }
    }



}