﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class SearchPage : System.Web.UI.Page
{
    Common cs = new Common();
    public string SearchKey = "";
    string Location = "";
    string UserName ="";
    DataTable dtPage = new DataTable();
    int PageSize = 20;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["Email"] != null)
            {
                UserName = Session["UserName"].ToString();
                btnLogin.Text = "Logout";
                btnRegister.Text = "Welcome " + UserName;
                btnRegister.PostBackUrl = "";

            }

            SearchKey = Request.QueryString["SearchKey"];
            Location = Request.QueryString["Location"];
            FillGrid();
            FillMenu();

        }
    }

    private void FillMenu()
    {
        List<string> MenuList = cs.GetColumValList("select * from tbl_Category where chkDisplayinMenu='True'", "txtCategoryName");
        rptMenu.DataSource = MenuList;
        rptMenu.DataBind();
    }


    protected void btnLogin_Click(object sender, EventArgs e)
    {
        if (btnLogin.Text.Contains("Login"))
            Response.Redirect("Login.aspx");
        else
        {
            Session.Abandon();
            Session.Clear();
            Response.Redirect("index.aspx");
        }

    }

    protected void btnRegister_Click(object sender, EventArgs e)
    {
        if (btnRegister.Text.Contains("Register"))
            Response.Redirect("signup.aspx");
        else
        {
            Response.Redirect("BusinessPage.aspx");
        }
    }

    protected void btnSearch_ServerClick(object sender, EventArgs e)
    {
        SearchKey = txtSearch.Value.Trim();
        Location = txtSearchByL.Value.Trim();
        FillGrid();
    }


    [WebMethod]
    public static List<string> GetSearchInfo(string SearchKey)
    {
        List<string> BkResult = new List<string>();
        Common cs = new Common();
        BkResult.AddRange(cs.GetColumValList("select * from tbl_Category where txtCategoryName LIKE '%" + SearchKey + "%' ", "txtCategoryName"));
        BkResult.AddRange(cs.GetColumValList("select * from tbl_SubCategory where txtSubCategoryName LIKE '%" + SearchKey + "%'", "txtSubCategoryName"));
        BkResult.AddRange(cs.GetColumValList("select * from tbl_Register where txtCompanyName LIKE '%" + SearchKey + "%'", "txtCompanyName"));
        List<string> HastTagList = cs.GetColumValList("select * from tbl_Register where txtKeywords LIKE '%" + SearchKey + "%'", "txtKeywords");

        foreach (string str in HastTagList)
        {
            BkResult.AddRange(cs.GetCommaSeperatedList(str));
        }

        // BkResult = (from s in BkResult where s.Contains(SearchKey) select s).ToList();

        return BkResult;
    }

    private void FillGrid()
    {
        if (dtPage.Rows.Count == 0)
        {
            string QueryRpt = "";
            if (SearchKey == "" && Location == "")
                QueryRpt =  "select * from tbl_Register";
            else
            {
                if (Location == "")
                {
                    QueryRpt = "select * from tbl_Register where txtCompanyName LIKE '%" + SearchKey + "%' OR ddlCategory LIKE '%" + SearchKey + "%' OR txtKeywords LIKE '%" + SearchKey + "%' OR ddlCategory LIKE '%" + SearchKey + "%' OR ddlSubCategory LIKE '%" + SearchKey + "%'";
                }
                else
                {
                    QueryRpt = "select * from tbl_Register where txtLocation LIKE '%" + SearchKey + "%' AND txtCompanyName LIKE '%" + SearchKey + "%' OR ddlCategory LIKE '%" + SearchKey + "%' OR txtKeywords LIKE '%" + SearchKey + "%' OR ddlCategory LIKE '%" + SearchKey + "%' OR ddlSubCategory LIKE '%" + SearchKey + "%'";
                }
            }

            dtPage = cs.GetDataTable(QueryRpt);
        }

        PagedDataSource PgD = new PagedDataSource();
        PgD.DataSource = dtPage.DefaultView;
        PgD.AllowPaging = true;
        PgD.PageSize = PageSize;
        PgD.CurrentPageIndex = PageNumber - 1;

        if (PgD.PageCount > 0)
        {
            ArrayList Pages = new ArrayList();
            for (int i = 1; i <= PgD.PageCount; i++)
            {
                Pages.Add(i.ToString());
            }
            rptPager.DataSource = Pages;
            rptPager.DataBind();
        }
        else
            rptPager.Visible = false;

        rptGrid.DataSource = PgD;
        rptGrid.DataBind();
    }

    protected void rptPaging_ItemCommand(object source, System.Web.UI.WebControls.RepeaterCommandEventArgs e)
    {
        PageNumber = Convert.ToInt32(e.CommandArgument) - 1;
        FillGrid();
    }

    public int PageNumber
    {
        get
        {
            if (ViewState["PageNumber"] != null)
                return Convert.ToInt32(ViewState["PageNumber"]);
            else
                return 1;
        }
        set { ViewState["PageNumber"] = value; }

    }

}