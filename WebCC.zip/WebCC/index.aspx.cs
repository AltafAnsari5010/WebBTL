﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class index : System.Web.UI.Page
{
    Common cs = new Common();
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnSubmit_ServerClick(object sender, EventArgs e)
    {
        ContactClass CC = new ContactClass();
        CC.Name = txtName.Value.Trim();
        CC.Email = txtEmail.Value.Trim();
        CC.Contact = txtPhone.Value.Trim();
        CC.Message = txtMessage.Value.Trim();
        CC.DateS = DateTime.Now.ToString();
        string Query = "insert into tbl_Contacts (DateS,Name,Email,Contact,Subject,Message) values ('" + CC.DateS + "', '" + CC.Name + "', '" + CC.Email + "', '" + CC.Contact + "', '', '" + CC.Message + "')";
        if (cs.ExecuteQuery(Query))
            SendEmail(CC);

    }

    private void SendEmail(ContactClass CC)
    {
        try
        {
            EmailClass EC = new EmailClass();
            string HtmlFile = Server.MapPath("EmailTemplateContact.html");
            string EnquiryDate = DateTime.Now.ToString();
            string Body = EC.PopulateBodyContactF(CC, HtmlFile);
            EC.SendHtmlFormattedEmail("services@alsumooduae.com", "New Enquiry / Feedback Raised From Al Sumood Group Website ", Body);
            Response.Write("<script language='javascript'>alert('Thank you for connecting with us, we will contact you soon..!!');</script>");
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Error Message", "alert('" + ex.Message + "');", true);
        }
    }
}