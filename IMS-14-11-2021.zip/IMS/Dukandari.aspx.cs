using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Drawing;
using SD = System.Drawing;

public partial class Dukandari : System.Web.UI.Page
{
    Common cs = new Common();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Page.Title = "Dukandari | IMS - SKS";
            cs.FillRepeater(rptDukandari, "select * from tbl_Dukandari");
            FillVepari();

        }
    }

    private void FillVepari()
    {
        string Query = "select * from tbl_Vender where chkIsActive='True'";
        List<string> VenderNames = cs.GetColumValList(Query, "txtVenderName");

        foreach (string str in VenderNames)
        {
            ddlVepariName.Items.Add(new ListItem(str, str));
        }



    }


    protected void btnAdd_Click(object sender, EventArgs e)
    {
        //#AddUploadCode  
        if (btnAdd.Text == "Update")
        {
            string Query = "update tbl_Dukandari set ddlCustomerName= '" + ddlVepariName.SelectedItem.Text + "', txtQuantity= '" + txtQuantity.Text + "', txtAmount= '" + txtAmount.Text + "', txtInvoiceDate= '" + txtInvoiceDate.Text + "' where  ID=" + lbIdHidden.Text;
            if (cs.ExecuteQuery(Query))
            {
                cs.FillRepeater(rptDukandari, "select * from tbl_Dukandari");
                btnAdd.Text = "Add";
            }
        }
        else
        {
            string Query = "insert into tbl_Dukandari(ddlCustomerName, txtQuantity, txtAmount, txtInvoiceDate, txtBalanceAmount) values('" + ddlVepariName.SelectedItem.Text + "', '" + txtQuantity.Text + "', '" + txtAmount.Text + "', '" + txtInvoiceDate.Text + "', '" + txtAmount.Text + "')";
            if (cs.ExecuteQuery(Query))
            {
                cs.FillRepeater(rptDukandari, "select * from tbl_Dukandari");
            }
        }
    }




    protected void rptDukandari_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        Label lbID = (Label)e.Item.FindControl("lbID");
        Label lbddlCustomerName = (Label)e.Item.FindControl("lbddlCustomerName");
        Label lbtxtQuantity = (Label)e.Item.FindControl("lbtxtQuantity");
        Label lbtxtAmount = (Label)e.Item.FindControl("lbtxtAmount");
        Label lbtxtInvoiceDate = (Label)e.Item.FindControl("lbtxtInvoiceDate");

        if (e.CommandName == "Delete")
        {
            if (cs.ExecuteQuery("Delete from tbl_Dukandari where ID=" + lbID.Text))
            {
                cs.FillRepeater(rptDukandari, "select * from tbl_Dukandari");
                cs.ShowAlert("Dukandari Deleted!!", MessageType.Info);
            }
        }
        if (e.CommandName == "Edit")
        {
            btnAdd.Text = "Update";
            ddlVepariName.SelectedItem.Text = lbddlCustomerName.Text;
            txtQuantity.Text = lbtxtQuantity.Text;
            txtAmount.Text = lbtxtAmount.Text;
            txtInvoiceDate.Text = lbtxtInvoiceDate.Text;
            lbIdHidden.Text = lbID.Text;

        }
    }






    protected void btnCancel_Click(object sender, EventArgs e)
    {
        //Clear Controls
    }
}