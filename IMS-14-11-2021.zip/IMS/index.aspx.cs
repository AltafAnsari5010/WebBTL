﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class index : System.Web.UI.Page
{
    Common cs = new Common();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!cs.IsTableExist("tbl_Login"))
        {
            cs.CreateLoginTable();
        }
    }

    protected void btnSignIn_Click(object sender, EventArgs e)
    {
        if (chkRemember.Checked == true)
        {
            Response.Cookies["EmailA"].Value = txtEmail.Value.Trim();
            Response.Cookies["Pwd"].Value = txtPassword.Value.Trim();
            Response.Cookies["EmailA"].Expires = DateTime.Now.AddDays(5);
            Response.Cookies["Pwd"].Expires = DateTime.Now.AddDays(5);
        }
        else
        {
            Response.Cookies["EmailA"].Expires = DateTime.Now.AddDays(-1);
            Response.Cookies["Pwd"].Expires = DateTime.Now.AddDays(-1);
        }

        string Query = "select * from tbl_Login where Email='" + txtEmail.Value + "' and Password='" + txtPassword.Value + "'";

        if (!cs.IsExist(Query))
            txtEmail.Value = "Invalid Email or Password!!";
        else
        {
            Session["EmailA"] = txtEmail.Value.Trim();
            string UserName = cs.GetColumVal(Query, "UserName");
            Session["UserNameA"] = UserName;
            //if (UserName == "admin")
            //    Response.Redirect("CreatePage.aspx");
            //else
                Response.Redirect("WelcomePage.aspx");

        }
    }
}