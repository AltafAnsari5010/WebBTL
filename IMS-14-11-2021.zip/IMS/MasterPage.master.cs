﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MasterPage : System.Web.UI.MasterPage
{
    Common cs = new Common();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserNameA"] != null)
            {
                FillUserInfo();
                //if (cs.IsTableExist("tbl_PageMaster"))
                //    cs.FillRepeater(rptPageMenu, "select * from tbl_PageMaster where IsActive='True'");
                   
                
            }
            else
                Response.Redirect("index.aspx");
        }
    }




    private void FillUserInfo()
    {
      string UserName =   Session["UserNameA"].ToString();
        lbUserName.Text = UserName;
        lbUserName1.Text = UserName;
        lbUserName2.Text = UserName;
    }

    protected void lbtnLogOut_Click(object sender, EventArgs e)
    {
        Session.Clear();
        Session.Abandon();
        Response.Redirect("index.aspx");
    }
}
