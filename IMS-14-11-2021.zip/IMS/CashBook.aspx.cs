using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Drawing;
using SD = System.Drawing;

public partial class CashBook : System.Web.UI.Page
{
    Common cs = new Common();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Page.Title = "Cash Book | IMS - SKS";
            FillCustomers();
            cs.FillRepeater(rptCashBook, "select * from tbl_CashBook");

        }
    }

    private void FillCustomers()
    {
        string Query = "select * from tbl_Customer where chkIsActive='True'";
        List<string> CustomerNames = cs.GetColumValList(Query, "txtCustomerName");

        foreach (string str in CustomerNames)
        {
            ddlCustomerName.Items.Add(new ListItem(str, str));
        }

      
       
    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {
        //#AddUploadCode  
        if (btnAdd.Text == "Update")
        {
            string Query = "update tbl_CashBook set ddlCustomerName= '" + ddlCustomerName.SelectedItem.Text + "', txtPaymentDate= '" + txtPaymentDate.Text + "', txtAmount= '" + txtAmount.Text + "', txtBalanceAmount= '" + txtBalanceAmount.Text + "' where  ID=" + lbIdHidden.Text;
            if (cs.ExecuteQuery(Query))
            {
                cs.FillRepeater(rptCashBook, "select * from tbl_CashBook");
                btnAdd.Text = "Add";
            }
        }
        else
        {
            string Query = "insert into tbl_CashBook(ddlCustomerName, txtPaymentDate, txtAmount, txtBalanceAmount) values('" + ddlCustomerName.SelectedItem.Text + "', '" + txtPaymentDate.Text + "', '" + txtAmount.Text + "', '" + txtBalanceAmount.Text + "')";
            if (cs.ExecuteQuery(Query))
            {
                cs.FillRepeater(rptCashBook, "select * from tbl_CashBook");
            }
        }
    }

    protected void rptCashBook_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        Label lbID = (Label)e.Item.FindControl("lbID");
        Label lbddlCustomerName = (Label)e.Item.FindControl("lbddlCustomerName");
        Label lbtxtPaymentDate = (Label)e.Item.FindControl("lbtxtPaymentDate");
        Label lbtxtAmount = (Label)e.Item.FindControl("lbtxtAmount");
        Label lbtxtBalanceAmount = (Label)e.Item.FindControl("lbtxtBalanceAmount");

        if (e.CommandName == "Delete")
        {
            if (cs.ExecuteQuery("Delete from tbl_CashBook where ID=" + lbID.Text))
            {
                cs.FillRepeater(rptCashBook, "select * from tbl_CashBook");
                cs.ShowAlert("Cash Book Deleted!!", MessageType.Info);
            }
        }
        if (e.CommandName == "Edit")
        {
            btnAdd.Text = "Update";
            SetIndex(ddlCustomerName, lbddlCustomerName.Text);
           // ddlCustomerName.SelectedItem.Text = lbddlCustomerName.Text;
            txtPaymentDate.Text = lbtxtPaymentDate.Text;
            txtAmount.Text = lbtxtAmount.Text;
            txtBalanceAmount.Text = lbtxtBalanceAmount.Text;
            lbIdHidden.Text = lbID.Text;

        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        //Clear Controls
    }

    private void SetIndex(DropDownList ddl, string text)
    {
        try
        {
            ddl.SelectedItem.Selected = false;
            ddl.Items.OfType<ListItem>().Where(x => x.Text == text).FirstOrDefault().Selected = true;
        }
        catch (Exception ex)
        { }
    }

}