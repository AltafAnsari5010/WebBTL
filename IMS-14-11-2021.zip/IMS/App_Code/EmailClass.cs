﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net.Mail;
using System.Configuration;
using System.IO;

public class EmailClass
{

    public string PopulateBody(string userName, string Email, string Subject, string Phone, string Message, string HtmlFile)
    {
        string body = string.Empty;
        using (StreamReader reader = new StreamReader(HtmlFile))
        {
            body = reader.ReadToEnd();
        }
        body = body.Replace("{UserName}", userName);
        body = body.Replace("{Email}", Email);
        body = body.Replace("{Subject}", Subject);
        body = body.Replace("{Phone}", Phone);
        body = body.Replace("{Message}", Message);
        return body;
    }

    public string PopulateBodyRegister(string userName, string Link, string HtmlFile)
    {
        string body = string.Empty;
        using (StreamReader reader = new StreamReader(HtmlFile))
        {
            body = reader.ReadToEnd();
        }

        body = body.Replace("{UserName}", userName);
        body = body.Replace("{Link}", Link);

        return body;
    }

    public string PopulateBodyForgotPwd(string userName, string Password, string HtmlFile)
    {
        string body = string.Empty;
        using (StreamReader reader = new StreamReader(HtmlFile))
        {
            body = reader.ReadToEnd();
        }
        body = body.Replace("{UserName}", userName);
        body = body.Replace("{Password}", Password);

        return body;
    }

    public string PopulateBodyContact(string userName, string Email, string Message, string Subject, string HtmlFile)
    {
        string body = string.Empty;
        using (StreamReader reader = new StreamReader(HtmlFile))
        {
            body = reader.ReadToEnd();
        }

        body = body.Replace("{UserName}", userName);
        body = body.Replace("{Email}", Email);
        body = body.Replace("{Subject}", Subject);
        body = body.Replace("{Message}", Message);

        return body;
    }

    public string PopulateBodyCareer(CareerClass CC, string HtmlFile)
    {
        string body = string.Empty;
        using (StreamReader reader = new StreamReader(HtmlFile))
        {
            body = reader.ReadToEnd();
        }

        body = body.Replace("{UserName}", CC.Name);
        body = body.Replace("{Email}", CC.Email);
        body = body.Replace("{Gender}", CC.Gender);
        body = body.Replace("{Phone}", CC.Phone);
        body = body.Replace("{BirthDate}", CC.BirthDate);
        body = body.Replace("{CVFile}", CC.CVFile);
        body = body.Replace("{Message}", CC.Message);

        return body;
    }

    public void SendHtmlFormattedEmail(string recepientEmail, string subject, string body)
    {
        using (MailMessage mailMessage = new MailMessage())
        {
            mailMessage.From = new MailAddress(ConfigurationManager.AppSettings["UserName"]);
            mailMessage.Subject = subject;
            mailMessage.Body = body;
            mailMessage.IsBodyHtml = true;
            mailMessage.To.Add(new MailAddress(recepientEmail));
            SmtpClient smtp = new SmtpClient();
            smtp.Host = ConfigurationManager.AppSettings["Host"];
            smtp.EnableSsl = Convert.ToBoolean(ConfigurationManager.AppSettings["EnableSsl"]);
            System.Net.NetworkCredential NetworkCred = new System.Net.NetworkCredential();
            NetworkCred.UserName = ConfigurationManager.AppSettings["UserName"];
            NetworkCred.Password = ConfigurationManager.AppSettings["Password"];
            smtp.UseDefaultCredentials = false;
            smtp.Credentials = NetworkCred;
            smtp.Port = int.Parse(ConfigurationManager.AppSettings["Port"]);
            smtp.Send(mailMessage);
        }
    }

    public void SendHtmlFormattedEmail(string recepientEmail, string attachement, Stream stream, string subject, string body)
    {
        using (MailMessage mailMessage = new MailMessage())
        {
            mailMessage.From = new MailAddress(ConfigurationManager.AppSettings["UserName"]);
            mailMessage.Subject = subject;
            mailMessage.Body = body;
            mailMessage.IsBodyHtml = true;
            mailMessage.To.Add(new MailAddress(recepientEmail));

            mailMessage.Attachments.Add(new Attachment(stream, attachement));
            SmtpClient smtp = new SmtpClient();
            smtp.Host = ConfigurationManager.AppSettings["Host"];
            smtp.EnableSsl = Convert.ToBoolean(ConfigurationManager.AppSettings["EnableSsl"]);
            System.Net.NetworkCredential NetworkCred = new System.Net.NetworkCredential();
            NetworkCred.UserName = ConfigurationManager.AppSettings["UserName"];
            NetworkCred.Password = ConfigurationManager.AppSettings["Password"];
            smtp.UseDefaultCredentials = false;
            smtp.Credentials = NetworkCred;
            smtp.Port = int.Parse(ConfigurationManager.AppSettings["Port"]);

            smtp.Send(mailMessage);
        }
    }


}

public class CareerClass
{
    public string Name { get; set; }
    public string DateS { get; set; }
    public string BirthDate { get; set; }
    public string Gender { get; set; }
    public string Email { get; set; }
    public string Phone { get; set; }
    public string Message { get; set; }
    public string CVFile { get; set; }

}