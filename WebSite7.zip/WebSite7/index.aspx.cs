﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class index : System.Web.UI.Page
{
    dbEntities db = new dbEntities();
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnLogin_ServerClick(object sender, EventArgs e)
    {
        tbl_Users user = (from p in db.tbl_Users where p.Email == txtEmail.Value.Trim() && p.Password == txtPassword.Value.Trim() select p).FirstOrDefault();
        if (user != null)
        {
            Session["Email"] = user.Email;
            Session["UserName"] = user.UserName;
            Response.Redirect("DashBoardaspx.aspx");
        }
        else
            txtEmail.Value = "Invalid Email or Password!!";

    }
}