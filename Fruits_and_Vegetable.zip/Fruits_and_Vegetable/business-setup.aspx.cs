﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

public partial class services_details : System.Web.UI.Page
{
    Common cs = new Common();
    public ServiceClass SC = new ServiceClass();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            string name = Request.QueryString["name"];
            //if (!string.IsNullOrEmpty(name))
            //{
               

            SetMasterHeader();
            //    //  cs.FillRepeater(rptBlogs, "select * from tbl_Blog");
            //    if (string.IsNullOrEmpty(SC.txtName))
            //        Response.Redirect("ErrorPage");
            //}
            //else
            //    Response.Redirect("ErrorPage");
        }
    }


    public void SetMasterHeader()
    {
        Page.Title = "Business Setup | Al Sumood Group";
        HtmlHead headMain = (HtmlHead)Page.Master.FindControl("MasterHead");
        HtmlMeta htMeta = new HtmlMeta();
        htMeta.Attributes.Add("name", "description");
        htMeta.Attributes.Add("content", "");

        //adding  Meta Tag to Head                
        headMain.Controls.Add(htMeta);


        //Similiarly we can add keyword Meta Tag to Head Section        
        HtmlMeta htMeta1 = new HtmlMeta();
        htMeta1.Attributes.Add("name", "keywords");
        htMeta1.Attributes.Add("content", "Al Sumood Group, Al Sumood Group Blog, " + cs.Kewords);
        // adding the Meta Tag to Head
        headMain.Controls.Add(htMeta1);
    }


    public string GetDate(string Dates)
    {
        string RetDate = Dates;

        DateTime dt = new DateTime();
        if (DateTime.TryParse(Dates, out dt))
            RetDate = dt.ToString("dddd, dd MMMM yyyy");

        return RetDate;
    }

    protected void rptBlogs_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
       
    }
}