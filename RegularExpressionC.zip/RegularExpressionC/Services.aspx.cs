﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

public partial class Services : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        SetMasterHeader();
    }

    public void SetMasterHeader()
    {
        Page.Title = "Services | Phoenix Alliance";
        HtmlHead headMain = (HtmlHead)Page.Master.FindControl("MasterHead");
        HtmlMeta htMeta = new HtmlMeta();
        htMeta.Attributes.Add("name", "description");
        htMeta.Attributes.Add("content", "Phoenix Alliance is a group of people specialist in all type of website Design, development, Web Application Design & Development, Domain & Hosting and Graphic & Logo Designing.");


        //adding  Meta Tag to Head                
        headMain.Controls.Add(htMeta);


        //Similiarly we can add keyword Meta Tag to Head Section        
        HtmlMeta htMeta1 = new HtmlMeta();
        htMeta1.Attributes.Add("name", "keywords");
        htMeta1.Attributes.Add("content", "Phoenix alliance, Website Design, Website Design in Mumbai, Website Design and development, Website Design and development in Mumbai, Freelancer, freelance web designer, freelance web developer, Best IT Company in Mumbai, Best IT Company in India");
        // adding the Meta Tag to Head
        headMain.Controls.Add(htMeta1);
    }
}