﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

public partial class contactus : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        SetMasterHeader();
    }

    public void SetMasterHeader()
    {
        Page.Title = "Contact Us | Phoenix Alliance";
        HtmlHead headMain = (HtmlHead)Page.Master.FindControl("MasterHead");
        HtmlMeta htMeta = new HtmlMeta();
        htMeta.Attributes.Add("name", "description");
        htMeta.Attributes.Add("content", "Phoenix Alliance is a group of people specialist in all type of website Design, development, Web Application Design & Development, Domain & Hosting and Graphic & Logo Designing.");

        //adding  Meta Tag to Head                
        headMain.Controls.Add(htMeta);


        //Similiarly we can add keyword Meta Tag to Head Section        
        HtmlMeta htMeta1 = new HtmlMeta();
        htMeta1.Attributes.Add("name", "keywords");
        htMeta1.Attributes.Add("content", "Phoenix alliance, Website Design, Website Design in Mumbai, Website Design and development, Website Design and development in Mumbai, Freelancer, freelance web designer, freelance web developer, Best IT Company in Mumbai, Best IT Company in India");
        // adding the Meta Tag to Head
        headMain.Controls.Add(htMeta1);
    }

    protected void btnSubmit_ServerClick(object sender, EventArgs e)
    {
       
        try
        {
            EmailClass EC = new EmailClass();
            string Name = txtName.Value;
            string Mobile = txtPhone.Value;
            string Email = txtEmail.Value;
            string Subject = txtSubject.Value;
            string Message = txtMessage.Value;
            string HtmlFile = Server.MapPath("EmailTemplateContact.html");
            string EnquiryDate = DateTime.Now.ToString();
            string Body = EC.PopulateBodyContact(Name, Mobile, Email, Subject, Message, HtmlFile);
            // EC.SendHtmlFormattedEmail("info@smitadentalcentre.com", "New Enquiry / Feedback Raised From Smita Dental Clinic Website", Body);

          
            EC.SendHtmlFormattedEmail("aali5010@gmail.com", "New Enquiry / Feedback Raised From Smita Dental Clinic Website - Test Mail", Body);
            ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Enquiry Mail Sent !! thank you... We Will Contact You Soon..');", true);
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Error Message", "alert('" + ex.Message + "');", true);
        }
    }
}