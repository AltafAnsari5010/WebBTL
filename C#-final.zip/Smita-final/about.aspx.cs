﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

public partial class about : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        SetMasterHeader();
    }

    public void SetMasterHeader()
    {
        Page.Title = "About Us | Smita Dental Clinic";
        HtmlHead headMain = (HtmlHead)Page.Master.FindControl("MasterHead");
        HtmlMeta htMeta = new HtmlMeta();
        htMeta.Attributes.Add("name", "description");
        htMeta.Attributes.Add("content", "is a team of dental professionals, advanced hi- technology and Infrastructure, altogether being backed by the use of such latest dental services, we plan on creating a soothing aura clubbed with the prospect of delivering a wholehearted service at our clinic. One that caters to the well being and dental health of our clients.");


        //adding  Meta Tag to Head                
        headMain.Controls.Add(htMeta);


        //Similiarly we can add keyword Meta Tag to Head Section        
        HtmlMeta htMeta1 = new HtmlMeta();
        htMeta1.Attributes.Add("name", "keywords");
        htMeta1.Attributes.Add("content", "Dentist in Mumbai, India, Dental Clinic in Kandivali, West, - Dental Implants, Cosmetic Dentistry, Tooth Whitening, Painless Root Canal, Dental Implants, Gum Treatment | Smita dental Centre");
        // adding the Meta Tag to Head
        headMain.Controls.Add(htMeta1);
    }
}