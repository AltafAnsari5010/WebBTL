using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Drawing;
using SD = System.Drawing;

using static Common;

public partial class StudentMaster : System.Web.UI.Page
{
    Common cs = new Common();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            cs.FillRepeater(rptStudentMaster, "select * from tbl_StudentMaster"); 
 
        }
    }

    protected void btnAdd_Click(object sender, EventArgs e) 
{ 
//#AddUploadCode  
if(btnAdd.Text == "Update") 
{ 
string Query = "update tbl_StudentMaster set txtStudentName= '"+txtStudentName.Text+"', txtRollNumber= '"+txtRollNumber.Text+"', txtMobile= '"+txtMobile.Text+"' where  ID=" + lbIdHidden.Text; 
if (cs.ExecuteQuery(Query)) 
{ 
cs.FillRepeater(rptStudentMaster, "select * from tbl_StudentMaster"); 
btnAdd.Text = "Add"; 
} 
} 
else { 
string Query = "insert into tbl_StudentMaster(txtStudentName, txtRollNumber, txtMobile) values('"+txtStudentName.Text+"', '"+txtRollNumber.Text+"', '"+txtMobile.Text+"')"; 
if (cs.ExecuteQuery(Query)) 
{ 
cs.FillRepeater(rptStudentMaster, "select * from tbl_StudentMaster"); 
} 
} 
} 




     protected void rptStudentMaster_ItemCommand(object source, RepeaterCommandEventArgs e) 
{ 
Label lbID = (Label)e.Item.FindControl("lbID"); 
Label lbtxtStudentName = (Label)e.Item.FindControl("lbtxtStudentName"); 
 Label lbtxtRollNumber = (Label)e.Item.FindControl("lbtxtRollNumber"); 
 Label lbtxtMobile = (Label)e.Item.FindControl("lbtxtMobile"); 
  
if (e.CommandName == "Delete") 
{ 
if (cs.ExecuteQuery("Delete from tbl_StudentMaster where ID=" + lbID.Text))  
{ 
cs.FillRepeater(rptStudentMaster, "select * from tbl_StudentMaster");  
cs.ShowAlert("Student  Deleted!!", MessageType.Info);  
} 
} 
if (e.CommandName == "Edit") 
{ 
btnAdd.Text = "Update"; 
txtStudentName.Text=lbtxtStudentName.Text; 
 txtRollNumber.Text=lbtxtRollNumber.Text; 
 txtMobile.Text=lbtxtMobile.Text; 
 lbIdHidden.Text=lbID.Text; 
  
} 
} 





}