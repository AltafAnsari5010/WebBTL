using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Drawing;
using SD = System.Drawing;

using static Common;

public partial class EmplyeeMaster : System.Web.UI.Page
{
    Common cs = new Common();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            cs.FillRepeater(rptEmplyeeMaster, "select * from tbl_EmplyeeMaster"); 
 
        }
    }

    protected void btnAdd_Click(object sender, EventArgs e) 
{ 
//#AddUploadCode  
if(btnAdd.Text == "Update") 
{ 
string Query = "update tbl_EmplyeeMaster set txtEmployeeName= '"+txtEmployeeName.Text+"', txtDateOfBirth= '"+txtDateOfBirth.Text+"', txtDateofJoining= '"+txtDateofJoining.Text+"' where  ID=" + lbIdHidden.Text; 
if (cs.ExecuteQuery(Query)) 
{ 
cs.FillRepeater(rptEmplyeeMaster, "select * from tbl_EmplyeeMaster"); 
btnAdd.Text = "Add"; 
} 
} 
else { 
string Query = "insert into tbl_EmplyeeMaster(txtEmployeeName, txtDateOfBirth, txtDateofJoining) values('"+txtEmployeeName.Text+"', '"+txtDateOfBirth.Text+"', '"+txtDateofJoining.Text+"')"; 
if (cs.ExecuteQuery(Query)) 
{ 
cs.FillRepeater(rptEmplyeeMaster, "select * from tbl_EmplyeeMaster"); 
} 
} 
} 




     protected void rptEmplyeeMaster_ItemCommand(object source, RepeaterCommandEventArgs e) 
{ 
Label lbID = (Label)e.Item.FindControl("lbID"); 
Label lbtxtEmployeeName = (Label)e.Item.FindControl("lbtxtEmployeeName"); 
 Label lbtxtDateOfBirth = (Label)e.Item.FindControl("lbtxtDateOfBirth"); 
 Label lbtxtDateofJoining = (Label)e.Item.FindControl("lbtxtDateofJoining"); 
  
if (e.CommandName == "Delete") 
{ 
if (cs.ExecuteQuery("Delete from tbl_EmplyeeMaster where ID=" + lbID.Text))  
{ 
cs.FillRepeater(rptEmplyeeMaster, "select * from tbl_EmplyeeMaster");  
cs.ShowAlert("Emplyee  Deleted!!", MessageType.Info);  
} 
} 
if (e.CommandName == "Edit") 
{ 
btnAdd.Text = "Update"; 
txtEmployeeName.Text=lbtxtEmployeeName.Text; 
 txtDateOfBirth.Text=lbtxtDateOfBirth.Text; 
 txtDateofJoining.Text=lbtxtDateofJoining.Text; 
 lbIdHidden.Text=lbID.Text; 
  
} 
} 






    protected void btnCancel_Click(object sender, EventArgs e)
    {
        //Clear Controls
    }
}