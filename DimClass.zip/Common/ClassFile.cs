﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Tekla.Structures;
using Tekla.Structures.Drawing;
using Tekla.Structures.Geometry3d;
using TSG = Tekla.Structures.Geometry3d;
using Tekla.Structures.Model;
using TSD = Tekla.Structures.Drawing;
using TSM = Tekla.Structures.Model;

namespace Auto_Detailing_Tool_Beam
{


    public class PartPoints
    {
        public Point CentP { get; set; }
        public Point P1 { get; set; }
        public Point P2 { get; set; }
        public Point P3 { get; set; }
        public Point P4 { get; set; }
        public Point P5 { get; set; }
        public Point P6 { get; set; }
        public Point P7 { get; set; }
        public Point P8 { get; set; }
    }

    public class GussetClass
    {
        public TSM.Part GussetPlate { get; set; }
        public BoltGroup BoltM { get; set; }
        public BoltGroup BoltL { get; set; }
        public BoltGroup BoltR { get; set; }
        public BoltGroup BoltS { get; set; }
        public PartPoints Points { get; set; }
        public Beam Brace { get; set; }
        public Point RefPBrace { get; set; }
        public Point IntPoint { get; set; }
        public Point IntPointB { get; set; }
        public Point IntPointTop { get; set; }
        public Point IntPointBott { get; set; }
        public string BracePos { get; set; }
        public double Degree { get; set; }
        public bool IsGussetSlop = false;

    }

    public class GussetClassB
    {
        public TSM.Part GussetPlate { get; set; }
        public PartPoints Points { get; set; }
        public GussetBrace LB { get; set; }
        public GussetBrace RB { get; set; }
        public bool IsGussetSlop = false;

    }

    public class GussetBrace
    {
        public BoltGroup BoltM { get; set; }
        public PointList BoltMP { get; set; }
        public BoltGroup BoltM1 { get; set; }
        public BoltGroup BoltL { get; set; }
        public BoltGroup BoltR { get; set; }
        public Beam Brace { get; set; }
        public Point RefPBrace { get; set; }
        public Point IntPoint { get; set; }
        public Point IntPointB { get; set; }
        public double Degree { get; set; }
    }

    public class AngleClass
    {
        public Beam Angle { get; set; }
        public PointList BoltPList { get; set; }
        public PartPoints Points { get; set; }
        public PartPoints CutPoints { get; set; }
    }


    public class PartClass
    {
        public TSM.Part part { get; set; }
        public PointList BoltPList { get; set; }
        public PartPoints Points { get; set; }
    
    }



    public class StiffClass
    {
        public TSM.Part Stiff { get; set; }
        public PartPoints Points { get; set; }
    }


    public class SpacerClass
    {
        public PointList BoltsPList { get; set; }
        public PartPoints Points { get; set; }
        public int ID { get; set; }
    }

    public class FillerClass
    {
        public PointList BoltsPList { get; set; }
        public PartPoints Points { get; set; }
        public int ID { get; set; }
    }

    public class CapClass
    {
        public PartPoints Points { get; set; }
        public int ID { get; set; }
    }

    public enum DetailType
    {
        Type1,
        Type2,
        Type3
    }

    public class CutPoints
    {
        public Point P1 { get; set; }
        public Point P2 { get; set; }
        public Point P3 { get; set; }
        public Point P4 { get; set; }
        public Point P5 { get; set; }
        public Point P6 { get; set; }
    }
}
