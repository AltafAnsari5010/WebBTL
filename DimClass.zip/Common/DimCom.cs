﻿using System;
using System.Collections;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using System.Globalization;
using System.IO;
using System.Collections.Generic;

//Tekla
using Tekla.Structures;
using TSD = Tekla.Structures.Drawing;
using TSM = Tekla.Structures.Model;
using Tekla.Structures.Geometry3d;
using TSMO = Tekla.Structures.Model.Operations;
using DIS = Tekla.Structures.Datatype.Distance;
using dist = Tekla.Structures.Geometry3d.Distance;
using Tekla.Structures.Drawing;
using Tekla.Structures.Model;
using Tekla.Structures.Solid;
using System.Xml;

namespace Auto_Detailing_Tool_Beam
{
    class DimCom
    {
        Model MyModel = new Model();
        public TSM.Part MainHandrail = new Beam();

        string[] PNameList = { "BEAM","BEAM_GRID","BEAM_MOM","BEAM_BRACED","BEAM_DRAG_W","BEAM_DRAG_B","BEAM_ROLLED","SLOPING BEAM","SKEWED BEAM","PANELASS",
                       "COLUMN","COLUMN_MOM","COLUMN_BRACED","POST",
                       "BOX_COLUMN","BOX_GIRDER","BOX_BEAM","BOX_COLUMN_SHAFT","BOX_GIRDER_SHAFT","BOX_BEAM_SHAFT",
                       "BUILT-UP_BEAM","BUILT-UP_COLUMN","BUILT-UP_PLATE_GIRDER","BUILT-UP_GIRDER_SHAFT","BUILT-UP_COLUMN_SHAFT","BUILT-UP_BEAM_SHAFT",
                       "VERTICAL BRACE","VERTICAL_BRACE", "VERT. BRACE", "VB", "HORIZONTAL BRACE","HORIZONTAL_BRACE",  "HORZ. BRACE", "HB", "BRACE",
                       "GUSSET PLATE", "GUSSET_PLATE","X-GUSSET PLATE",
                       "GIRT","PURLIN",
                       "HANDRAIL","HAND_RAIL","STAIR HANDRAIL","STAIR_HANDRAIL","WALL RAIL","WALL_RAIL","TOE PLATE","TOE_PLATE",
                       "STAIR","STRINGER","TREAD",
                       "TRUSS","TOP CHORD","BOTTOM CHORD","VERTICAL CHORD","DIAGONAL BRACE",
                       "EMBED PLATE","EMBED_PLATE","ANCHOR BOLT","SAG ROD","END PLATE","WEB PLATE","WEB_PLATE","FLANGE PLATE","FLANGE_PLATE","FLANGE PLATE UP","X-FLANGE PLATE","FILLER PLATE","BASE PLATE","BASE_PLATE","CAP PLATE","CAP_PLATE","LEVELING PLATE","PLATE WASHER","PLATE_WASHER","SHEAR PLATE","SHEAR_PLATE","LIFTING LUG","LIFTING_LUG","SHEAR KEY","SHEAR_KEY","STIFFENER","REINFORCEMENT PLATE","REINF. PLATE","STUB","COLUMN_STUB","ANGLE","RAIL","BENT PLATE","BENT_PLATE","SLAB BENT PLATE","TONGUE PLATE","CLOSURE PLATE","CLOSURE_PLATE","GRATING","CHECKERED PLATE","CHECKERED_PLATE","HOOK","BACKUP-BAR","BACK-UP BAR","FIRE PROOFING","FIREPROOFING","SURFACE","OUTRIGGER","SPACER PLATE","SHIM PLATE","WEDGE LOCK","LADDER CAGE","LADDER PLATE","COMP FLANGE PLATE","COMP PLATE","ROD","RING PLATE","DOUBLER PLATE","BAR",
                       "HAUNCH PLATE","HAUNCH_PLATE","HAUNCH FLANGE PLATE","HAUNCH_FLANGE_PLATE","HAUNCH WEB PLATE","HAUNCH_WEB_PLATE","HAUNCH PROFILE","HAUNCH_PROFILE",
                       "PEBGIRT","PEBPURLIN","PEBBEAM","PEBCOLUMN",
                       "PREP","M CUT"};

        public TSD.PointList DimPointList(TSD.DimensionSetBase xpsV)
        {

            Tekla.Structures.Drawing.PointList PList = null;
            Type drawingType = xpsV.GetType();
            System.Reflection.PropertyInfo propertyInfo = drawingType.GetProperty("DimensionPoints", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic);
            object value = propertyInfo.GetValue(xpsV, null);
            if (value is TSD.PointList)
                PList = value as TSD.PointList;

            return PList;
        }

        public Vector DimDirection(TSD.DimensionSetBase xpsV)
        {

            Vector dir = null;
            Type Direction = xpsV.GetType();
            System.Reflection.PropertyInfo propertyInfo = Direction.GetProperty("UpDirection", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic);
            object value = propertyInfo.GetValue(xpsV, null);
            if (value is Vector)
                dir = value as Vector;

            dir = dir.GetNormal();
            dir = new Vector(Math.Round(dir.X, 4), Math.Round(dir.Y, 4), Math.Round(dir.Z, 4));

            return dir;
        }

        public TSD.StraightDimensionSet.StraightDimensionSetAttributes StraightDimAttr(TSD.StraightDimension xpsV)
        {

            TSD.StraightDimensionSet.StraightDimensionSetAttributes attr = null;
            //DimensionSetAttributes = {Tekla.Structures.Drawing.StraightDimensionSet.StraightDimensionSetAttributes}
            Type Direction = xpsV.GetType();
            System.Reflection.PropertyInfo propertyInfo = Direction.GetProperty("DimensionSetAttributes", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic);
            object value = propertyInfo.GetValue(xpsV, null);
            if (value is TSD.StraightDimensionSet.StraightDimensionSetAttributes)
                attr = value as TSD.StraightDimensionSet.StraightDimensionSetAttributes;

            return attr;
        }

        public double RemoveMinusValue(double val)
        {
            double roundval = Math.Round(val);
            double FinalVal = 0;
            string vals = roundval.ToString();

            if (vals.Contains("-"))
            {
                vals = vals.Replace("-", "");
                FinalVal = Convert.ToDouble(vals);
            }
            else
            {
                FinalVal = val;
            }

            return FinalVal;
        }

        public double RemoveMinusValueVect(double val)
        {
            double FinalVal = 0;
            string vals = val.ToString();

            if (vals.Contains("-"))
            {
                vals = vals.Replace("-", "");
                FinalVal = Convert.ToDouble(vals);
            }
            else
            {
                FinalVal = val;
            }

            return FinalVal;
        }

        public void ReInsertDim(TSD.View Currentview, TSD.StraightDimensionSet xpsV, TSD.PointList ptList)
        {
            TSD.StraightDimensionSet.StraightDimensionSetAttributes attr = xpsV.Attributes;
            double Dist = xpsV.Distance;
            Vector vect = DimDirection(xpsV);
            DrawingHandler dh = new DrawingHandler();
            Drawing CurrentDrawing = dh.GetActiveDrawing();
            // secDimension = new StraightDimensionSetHandler().CreateDimensionSet(Currentview, asspoints, new Vector(0, 10, 0), distance1, attr);
            TSD.StraightDimensionSet secDimension = new TSD.StraightDimensionSetHandler().CreateDimensionSet(Currentview, ptList, vect, Dist, attr);
            if (secDimension != null)
            {
                secDimension.Distance = Dist;
                secDimension.Modify();
                xpsV.Delete();
                CurrentDrawing.CommitChanges();
            }
        }

        public TSD.StraightDimensionSet InsertDim(TSD.View Currentview, TSD.PointList ptList, Vector vect, double Distance, TSD.StraightDimensionSet.StraightDimensionSetAttributes Attributes)
        {
            TSD.StraightDimensionSet StDimension = null;
            try
            {

                DrawingHandler dh = new DrawingHandler();
                Drawing CurrentDrawing = dh.GetActiveDrawing();
                StDimension = new TSD.StraightDimensionSetHandler().CreateDimensionSet(Currentview, ptList, vect, Distance, Attributes);
                if (StDimension != null)
                {
                    StDimension.Attributes.Placing.Placing = DimensionSetBaseAttributes.Placings.Fixed;
                    StDimension.Distance = Distance;
                    StDimension.Modify();
                    CurrentDrawing.CommitChanges();

                }
            }
            catch (Exception ex)
            {
                StDimension = null;
            }

            return StDimension;
        }

        public TSD.StraightDimensionSet InsertDimm(TSD.View Currentview, TSD.PointList ptList, Vector vect, double Distance, TSD.StraightDimensionSet.StraightDimensionSetAttributes Attributes)
        {
            TSD.StraightDimensionSet StDimension = null;
            try
            {

                DrawingHandler dh = new DrawingHandler();
                Drawing CurrentDrawing = dh.GetActiveDrawing();
                StDimension = new TSD.StraightDimensionSetHandler().CreateDimensionSet(Currentview, ptList, vect, Distance, Attributes);

            }
            catch (Exception ex)
            {
                StDimension = null;
            }

            return StDimension;
        }

        #region Trasnform Points & Dim

        public void TransformDimPlacing(TSD.View CurrentView, int KnockOffID, TSD.StraightDimensionSet.StraightDimensionSetAttributes Attributes)
        {
            TransformationPlane ModelPlane = new TransformationPlane(GetModelCoordinateSystem(CurrentView));
            TransformationPlane LocalPlane = new TransformationPlane(GetLocalCoordinateSystem(CurrentView));
            Type[] ty = new Type[] { typeof(StraightDimensionSet), typeof(AngleDimension), typeof(TSD.Line) };
            DrawingObjectEnumerator allObjects = CurrentView.GetAllObjects(ty);
            int count = allObjects.GetSize();

            while (allObjects.MoveNext())
            {
                if (allObjects.Current is StraightDimensionSet)
                {
                    try
                    {
                        StraightDimensionSet stdim = allObjects.Current as StraightDimensionSet;
                        int id1 = GetDimID(stdim);
                        if (id1 != KnockOffID)
                        {
                            stdim.Attributes.Placing.Placing = DimensionSetBaseAttributes.Placings.Fixed;
                            stdim.Modify();
                            if (stdim.Attributes.DimensionType == DimensionSetBaseAttributes.DimensionTypes.Elevation)
                            { }

                            Vector LeftVect = DimDirection(stdim);
                            Vector newVect = TransformVectorToLocal(LeftVect);
                            PointList OldPlist = DimPointList(stdim);
                            PointList NewPlist = TransfromPointList(OldPlist, ModelPlane, LocalPlane);
                            StraightDimensionSet BoltDH = InsertDim(CurrentView, NewPlist, newVect, stdim.Distance, stdim.Attributes);
                            if (BoltDH != null)
                            {
                                BoltDH.Distance = stdim.Distance;
                                BoltDH.Modify();


                                new DrawingHandler().GetDrawingObjectSelector().SelectObject(BoltDH);
                                BoltDH = EnumtoArray(new DrawingHandler().GetDrawingObjectSelector().GetSelected().GetEnumerator()).Cast<DrawingObject>().ToList().Where(x => (x is StraightDimensionSet)).Cast<StraightDimensionSet>().ToList()[0];
                                if (BoltDH.Attributes.CombinedDimension.Format != DimensionSetBaseAttributes.CombineFormats.Off)
                                {
                                    BoltDH.Attributes.CombinedDimension.Format = DimensionSetBaseAttributes.CombineFormats.Off;
                                    BoltDH.Modify();
                                }
                                new DrawingHandler().GetDrawingObjectSelector().UnselectObject(BoltDH);

                                stdim.Delete();
                            }
                        }
                    }
                    catch (Exception ex)
                    { }

                }

                if (allObjects.Current is AngleDimension)
                {
                    try
                    {
                        AngleDimension stdim = allObjects.Current as AngleDimension;
                        stdim.Attributes.Placing.Placing = DimensionSetBaseAttributes.Placings.Fixed;
                        stdim.Modify();
                        PointList OldPlist = new PointList();
                        OldPlist.Add(stdim.Origin);
                        OldPlist.Add(stdim.Point1);
                        OldPlist.Add(stdim.Point2);
                        PointList NewPlist = TransfromPointList(OldPlist, ModelPlane, LocalPlane);
                        AngleDimension AngDim = InsertAngelDim(CurrentView, NewPlist[0], NewPlist[1], NewPlist[2], stdim.Distance, stdim.Attributes);
                        if (AngDim != null)
                        {
                            stdim.Delete();
                        }

                    }
                    catch (Exception ex)
                    { }

                }

                if (allObjects.Current is TSD.Line)
                {
                    try
                    {
                        TSD.Line stdim = allObjects.Current as TSD.Line;

                        PointList OldPlist = new PointList();
                        OldPlist.Add(stdim.StartPoint);
                        OldPlist.Add(stdim.EndPoint);
                        PointList NewPlist = TransfromPointList(OldPlist, ModelPlane, LocalPlane);
                        DrawLine(CurrentView, NewPlist[0], NewPlist[1]); // Horizontal
                        stdim.Delete();


                    }
                    catch (Exception ex)
                    { }

                }
            }
        }

        public ArrayList EnumtoArray(IEnumerator ienum)
        {
            ArrayList RetArrList = new ArrayList();
            while (ienum.MoveNext())
            {
                RetArrList.Add(ienum.Current);
            }
            return RetArrList;
        }

        public ArrayList EnumtoArray(IEnumerator ienum, ProgressBar prog, Label lbResult, string msg, int count)
        {
            ArrayList RetArrList = new ArrayList();
            if (count > 0)
            {
                prog.Maximum = count;
                prog.Value = 0;

                while (ienum.MoveNext())
                {

                    RetArrList.Add(ienum.Current);
                    if (prog.Value < prog.Maximum)
                    {
                        Application.DoEvents();
                        prog.Value++;
                        Application.DoEvents();
                        string result = String.Format(msg, prog.Value, (count - prog.Value));
                        lbResult.Text = result;

                    }
                }
            }
            prog.Value = prog.Maximum;
            return RetArrList;
        }

        public TSD.StraightDimensionSet InsertDimL(out PointList TransformedPList, TSD.View Currentview, TSD.PointList ptList, Vector vect, double Distance, TSD.StraightDimensionSet.StraightDimensionSetAttributes Attributes)
        {

            TSD.StraightDimensionSet StDimension = null;
            PointList ptList1 = new PointList();
            try
            {
                TransformationPlane ModelPlane = new TransformationPlane(GetModelCoordinateSystem(Currentview));
                TransformationPlane LocalPlane = new TransformationPlane(GetLocalCoordinateSystem(Currentview));
                ptList1 = TransfromPointList(ptList, ModelPlane, LocalPlane);
                Vector Vect1 = TransformVectorToLocal(vect);

                StDimension = new TSD.StraightDimensionSetHandler().CreateDimensionSet(Currentview, ptList1, Vect1, Distance, Attributes);
                if (StDimension != null)
                {
                    StDimension.Distance = Distance;
                    StDimension.Modify();
                }
            }
            catch (Exception ex)
            {
                StDimension = null;
            }

            TransformedPList = ptList1;
            return StDimension;
        }

        public CoordinateSystem GetLocalCoordinateSystem(TSD.View CurrentView)
        {
            // Model to Local
            CoordinateSystem co = new CoordinateSystem();
            if (CurrentView.Name == "Front View")
                co = new CoordinateSystem(CurrentView.DisplayCoordinateSystem.Origin, new Vector(0, 0, 1), new Vector(0, 1, 0));

            else if (CurrentView.Name == "Top View")
                co = new CoordinateSystem(CurrentView.DisplayCoordinateSystem.Origin, new Vector(0, 0, 1), new Vector(1, 0, 0));

            else if (CurrentView.Name == "Bottom View")
                co = new CoordinateSystem(CurrentView.DisplayCoordinateSystem.Origin, new Vector(0, 0, 1), new Vector(-1, 0, 0));

            return co;
        }

        public CoordinateSystem GetModelCoordinateSystem(TSD.View CurrentView)
        {
            // Model to Local
            CoordinateSystem co = new CoordinateSystem();
            if (CurrentView.Name == "Front View")
                co = new CoordinateSystem(CurrentView.DisplayCoordinateSystem.Origin, new Vector(0, -1, 0), new Vector(0, 0, 1));

            else if (CurrentView.Name == "Top View")
                co = new CoordinateSystem(CurrentView.DisplayCoordinateSystem.Origin, new Vector(-1, 0, 0), new Vector(0, 0, 1));

            else if (CurrentView.Name == "Bottom View")
                co = new CoordinateSystem(CurrentView.DisplayCoordinateSystem.Origin, new Vector(1, 0, 0), new Vector(0, 0, 1));

            return co;
        }

        public PointList TransfromPointList(PointList ptlist, TransformationPlane OldPlane, TransformationPlane NewPlane)
        {
            PointList RetPList = new PointList();

            foreach (Point OldP in ptlist)
            {
                Point NewPoint = NewPlane.TransformationMatrixToLocal.Transform(OldPlane.TransformationMatrixToGlobal.Transform(OldP));
                RetPList.Add(NewPoint);
            }

            return RetPList;
        }

        public Vector TransformVectorToLocal(Vector Vector1) //
        {

            Vector vect = new Vector();
            if (Vector1.X != 0 && Vector1.Y != 0)
            {
                if (Vector1.X < 0 && Vector1.Y > 0) //A
                    vect = new Vector(MinusValue(Vector1.X / 2.6310), Vector1.Y, 0);

                else if (Vector1.X > 0 && Vector1.Y > 0) // B
                    vect = new Vector((Vector1.X), (-(Vector1.Y / 4.5855)), 0);

                else if (Vector1.X > 0 && Vector1.Y < 0) // C
                    vect = new Vector((-(Vector1.X / 4.5855)), Vector1.Y, 0);

                else if (Vector1.X < 0 && Vector1.Y < 0) // D
                    vect = new Vector((Vector1.X), MinusValue(Vector1.Y / 4.5855), 0);

            }
            else
            {
                if (Vector1.X < 0)
                    vect = new Vector(0, 1, 0);
                else if (Vector1.X > 0)
                    vect = new Vector(0, -1, 0);

                else if (Vector1.Y < 0)
                    vect = new Vector(-1, 0, 0);
                else
                    vect = new Vector(1, 0, 0);
            }

            // vect = vect.GetNormal();
            return vect;
        }


        #endregion

        #region Sorting PointList

        #region Old Methods
        public PointList SortPointListByMinY1(TSD.PointList ptList11)
        {
            PointList SortedList = new PointList();
            PointList ptList1 = new PointList();
            ptList1.AddRange(ptList11);
            while (ptList1.Count > 0)
            {
                int j = 0;
                for (int i = 1; i < ptList1.Count; i++)
                {
                    if (ptList1[j].Y > ptList1[i].Y)
                        j = i;

                }
                SortedList.Add(ptList1[j]);
                ptList1.RemoveAt(j);
            }

            return SortedList;

        }

        public PointList SortPointListByMaxY1(TSD.PointList ptList11)
        {
            PointList SortedList = new PointList();
            PointList ptList1 = new PointList();
            ptList1.AddRange(ptList11);
            while (ptList1.Count > 0)
            {
                int j = 0;
                for (int i = 1; i < ptList1.Count; i++)
                {
                    if (ptList1[j].Y < ptList1[i].Y)
                        j = i;

                }
                SortedList.Add(ptList1[j]);
                ptList1.RemoveAt(j);
            }

            return SortedList;

        }

        public PointList SortPointListByMinX1(TSD.PointList ptList11)
        {
            PointList SortedList = new PointList();
            PointList ptList = new PointList();
            ptList.AddRange(ptList11);
            while (ptList.Count > 0)
            {
                int j = 0;
                for (int i = 1; i < ptList.Count; i++)
                {
                    if (ptList[j].X > ptList[i].X)
                        j = i;

                }
                SortedList.Add(ptList[j]);
                ptList.RemoveAt(j);
            }

            return SortedList;

        }

        public PointList SortPointListByMaxX1(TSD.PointList ptList11)
        {
            PointList SortedList = new PointList();
            PointList ptList = new PointList();
            ptList.AddRange(ptList11);
            while (ptList.Count > 0)
            {
                int j = 0;
                for (int i = 1; i < ptList.Count; i++)
                {
                    if (ptList[j].X < ptList[i].X)
                        j = i;

                }
                SortedList.Add(ptList[j]);
                ptList.RemoveAt(j);
            }

            return SortedList;

        }
        #endregion

        public PointList SortPointListByMinY(TSD.PointList ptList11)
        {
            return ListType2PointList(PointList2ListType(ptList11).OrderBy(o => o.Y).ToList());
        }

        public PointList SortPointListByMaxY(TSD.PointList ptList11)
        {
            List<Point> ptList = PointList2ListType(ptList11).OrderBy(o => o.Y).ToList();
            ptList.Reverse();
            PointList SortedList = ListType2PointList(ptList);

            return SortedList;
        }

        public PointList SortPointListByMinX(TSD.PointList ptList11)
        {
            return ListType2PointList(PointList2ListType(ptList11).OrderBy(o => o.X).ToList());
        }

        public PointList SortPointListByMaxX(TSD.PointList ptList11)
        {
            List<Point> ptList = PointList2ListType(ptList11).OrderBy(o => o.X).ToList();
            ptList.Reverse();
            PointList SortedList = ListType2PointList(ptList);

            return SortedList;
        }

        public List<Point> PointList2ListType(TSD.PointList ptList11)
        {
            List<Point> RetList = new List<Point>();

            foreach (Point p in ptList11)
                RetList.Add(p);

            return RetList;
        }

        public TSD.PointList ListType2PointList(List<Point> ptList11)
        {
            TSD.PointList RetList = new TSD.PointList();

            foreach (Point p in ptList11)
                RetList.Add(p);

            return RetList;
        }

        #endregion

        #region Filter PartList
        public List<int> FilterPartListByMinY(List<int> FilteredPartArr)
        {
            List<int> FilteredPartArr1 = new List<int>();

            List<int> FilteredPartArrTemp = new List<int>();
            FilteredPartArrTemp.AddRange(FilteredPartArr);

            TSM.Part ba = null;

            double BoltMiny1 = 0;
            int count = FilteredPartArrTemp.Count;
            for (int i = 0; i < count; i++)
            {
                for (int j = 0; j < FilteredPartArrTemp.Count; j++)
                {
                    TSM.Part bArray = MyModel.SelectModelObject(new Identifier(FilteredPartArrTemp[j])) as TSM.Part;
                    double BoltMinY = bArray.GetSolid().MaximumPoint.Y;

                    if (j == 0)
                    {
                        BoltMiny1 = BoltMinY;
                        ba = bArray;
                    }
                    if (BoltMinY < BoltMiny1)
                    {
                        BoltMiny1 = BoltMinY;
                        ba = bArray;
                    }
                }
                FilteredPartArr1.Add(ba.Identifier.ID);
                FilteredPartArrTemp.Remove(ba.Identifier.ID);
            }

            return FilteredPartArr = FilteredPartArr1;
        }

        public List<int> FilterPartListByMaxY(List<int> FilteredPartArr)
        {
            List<int> FilteredPartArr1 = new List<int>();

            List<int> FilteredPartArrTemp = new List<int>();
            FilteredPartArrTemp.AddRange(FilteredPartArr);

            TSM.Part ba = null;

            double BoltMaxy1 = 0;
            int count = FilteredPartArrTemp.Count;
            for (int i = 0; i < count; i++)
            {
                for (int j = 0; j < FilteredPartArrTemp.Count; j++)
                {
                    TSM.Part bArray = MyModel.SelectModelObject(new Identifier(FilteredPartArrTemp[j])) as TSM.Part;
                    double BoltMaxY = bArray.GetSolid().MinimumPoint.Y;

                    if (j == 0)
                    {
                        BoltMaxy1 = BoltMaxY;
                        ba = bArray;
                    }
                    if (BoltMaxY < BoltMaxy1)
                    {
                        BoltMaxy1 = BoltMaxY;
                        ba = bArray;
                    }
                }
                FilteredPartArr1.Add(ba.Identifier.ID);
                FilteredPartArrTemp.Remove(ba.Identifier.ID);
            }

            return FilteredPartArr = FilteredPartArr1;
        }

        public List<int> FilterPartListByMinX(List<int> FilteredPartArr)
        {
            List<int> FilteredPartArr1 = new List<int>();

            List<int> FilteredPartArrTemp = new List<int>();
            FilteredPartArrTemp.AddRange(FilteredPartArr);

            TSM.Part ba = null;

            double BoltMinx1 = 0;
            int count = FilteredPartArrTemp.Count;
            for (int i = 0; i < count; i++)
            {
                for (int j = 0; j < FilteredPartArrTemp.Count; j++)
                {
                    TSM.Part bArray = MyModel.SelectModelObject(new Identifier(FilteredPartArrTemp[j])) as TSM.Part;
                    double BoltMinX = bArray.GetSolid().MaximumPoint.X;

                    if (j == 0)
                    {
                        BoltMinx1 = BoltMinX;
                        ba = bArray;
                    }
                    if (BoltMinX < BoltMinx1)
                    {
                        BoltMinx1 = BoltMinX;
                        ba = bArray;
                    }
                }
                FilteredPartArr1.Add(ba.Identifier.ID);
                FilteredPartArrTemp.Remove(ba.Identifier.ID);
            }

            return FilteredPartArr = FilteredPartArr1;
        }

        public List<int> FilterPartListByMaxX(List<int> FilteredPartArr)
        {
            List<int> FilteredPartArr1 = new List<int>();

            List<int> FilteredPartArrTemp = new List<int>();
            FilteredPartArrTemp.AddRange(FilteredPartArr);

            TSM.Part ba = null;

            double BoltMaxx1 = 0;
            int count = FilteredPartArrTemp.Count;
            for (int i = 0; i < count; i++)
            {
                for (int j = 0; j < FilteredPartArrTemp.Count; j++)
                {
                    TSM.Part bArray = MyModel.SelectModelObject(new Identifier(FilteredPartArrTemp[j])) as TSM.Part;
                    double BoltMaxX = bArray.GetSolid().MinimumPoint.X;

                    if (j == 0)
                    {
                        BoltMaxx1 = BoltMaxX;
                        ba = bArray;
                    }
                    if (BoltMaxX < BoltMaxx1)
                    {
                        BoltMaxx1 = BoltMaxX;
                        ba = bArray;
                    }
                }
                FilteredPartArr1.Add(ba.Identifier.ID);
                FilteredPartArrTemp.Remove(ba.Identifier.ID);
            }

            return FilteredPartArr = FilteredPartArr1;
        }

        public List<TSM.Part> FilterPartListByMinY(List<TSM.Part> FilteredPartArr)
        {
            List<TSM.Part> FilteredPartArr1 = new List<TSM.Part>();

            List<int> PartArrIDList = FilteredPartArr.OfType<TSM.Part>().Select(x => x.Identifier.ID).ToList();
            List<int> FPartArrIDList = FilterPartListByMinY(PartArrIDList);

            //foreach (int id1 in FPartArrIDList)
            //    FilteredPartArr1.Add(MyModel.SelectModelObject(new Identifier(id1)) as TSM.Part);

            FPartArrIDList.ForEach(x => FilteredPartArr1.Add(MyModel.SelectModelObject(new Identifier(x)) as TSM.Part));
            return FilteredPartArr1;
        }

        public List<TSM.Part> FilterPartListByMaxY(List<TSM.Part> FilteredPartArr)
        {
            List<TSM.Part> FilteredPartArr1 = new List<TSM.Part>();

            List<int> PartArrIDList = FilteredPartArr.OfType<TSM.Part>().Select(x => x.Identifier.ID).ToList();
            List<int> FPartArrIDList = FilterPartListByMaxY(PartArrIDList);

            //foreach (int id1 in FPartArrIDList)
            //    FilteredPartArr1.Add(MyModel.SelectModelObject(new Identifier(id1)) as TSM.Part);

            FPartArrIDList.ForEach(x => FilteredPartArr1.Add(MyModel.SelectModelObject(new Identifier(x)) as TSM.Part));
            return FilteredPartArr1;
        }

        public List<TSM.Part> FilterPartListByMinX(List<TSM.Part> FilteredPartArr)
        {
            List<TSM.Part> FilteredPartArr1 = new List<TSM.Part>();

            List<int> PartArrIDList = FilteredPartArr.OfType<TSM.Part>().Select(x => x.Identifier.ID).ToList();
            List<int> FPartArrIDList = FilterPartListByMinX(PartArrIDList);

            //foreach (int id1 in FPartArrIDList)
            //    FilteredPartArr1.Add(MyModel.SelectModelObject(new Identifier(id1)) as TSM.Part);

            FPartArrIDList.ForEach(x => FilteredPartArr1.Add(MyModel.SelectModelObject(new Identifier(x)) as TSM.Part));
            return FilteredPartArr1;
        }

        public List<TSM.Part> FilterPartListByMaxX(List<TSM.Part> FilteredPartArr)
        {
            List<TSM.Part> FilteredPartArr1 = new List<TSM.Part>();

            List<int> PartArrIDList = FilteredPartArr.OfType<TSM.Part>().Select(x => x.Identifier.ID).ToList();
            List<int> FPartArrIDList = FilterPartListByMaxX(PartArrIDList);

            //foreach (int id1 in FPartArrIDList)
            //    FilteredPartArr1.Add(MyModel.SelectModelObject(new Identifier(id1)) as TSM.Part);

            FPartArrIDList.ForEach(x => FilteredPartArr1.Add(MyModel.SelectModelObject(new Identifier(x)) as TSM.Part));
            return FilteredPartArr1;
        }
        #endregion

        #region Filter BoltGList
        public List<BoltGroup> FilterBoltGListByMinY(List<BoltGroup> FilteredBoltArr)
        {
            List<BoltGroup> FilteredBoltArr1 = new List<BoltGroup>();

            List<BoltGroup> FilteredBoltArrTemp = new List<BoltGroup>();
            FilteredBoltArrTemp.AddRange(FilteredBoltArr);

            BoltGroup ba = null;

            double BoltMiny1 = 0;
            int count = FilteredBoltArrTemp.Count;
            for (int i = 0; i < count; i++)
            {
                for (int j = 0; j < FilteredBoltArrTemp.Count; j++)
                {
                    BoltGroup bArray = FilteredBoltArrTemp[j];
                    double BoltMinY = bArray.GetSolid().MaximumPoint.Y;

                    if (j == 0)
                    {
                        BoltMiny1 = BoltMinY;
                        ba = bArray;
                    }
                    if (BoltMinY < BoltMiny1)
                    {
                        BoltMiny1 = BoltMinY;
                        ba = bArray;
                    }
                }
                FilteredBoltArr1.Add(ba);
                FilteredBoltArrTemp.Remove(ba);
            }

            return FilteredBoltArr = FilteredBoltArr1;
        }

        public List<BoltGroup> FilterBoltGListByMaxY(List<BoltGroup> FilteredBoltArr)
        {
            List<BoltGroup> FilteredBoltArr1 = new List<BoltGroup>();

            List<BoltGroup> FilteredBoltArrTemp = new List<BoltGroup>();
            FilteredBoltArrTemp.AddRange(FilteredBoltArr);

            BoltGroup ba = null;

            double BoltMaxy1 = 0;
            int count = FilteredBoltArrTemp.Count;
            for (int i = 0; i < count; i++)
            {
                for (int j = 0; j < FilteredBoltArrTemp.Count; j++)
                {
                    BoltGroup bArray = FilteredBoltArrTemp[j];
                    double BoltMaxY = bArray.GetSolid().MinimumPoint.Y;

                    if (j == 0)
                    {
                        BoltMaxy1 = BoltMaxY;
                        ba = bArray;
                    }
                    if (BoltMaxY < BoltMaxy1)
                    {
                        BoltMaxy1 = BoltMaxY;
                        ba = bArray;
                    }
                }
                FilteredBoltArr1.Add(ba);
                FilteredBoltArrTemp.Remove(ba);
            }

            return FilteredBoltArr = FilteredBoltArr1;
        }

        public List<BoltGroup> FilterBoltGListByMinX(List<BoltGroup> FilteredBoltArr)
        {
            List<BoltGroup> FilteredBoltArr1 = new List<BoltGroup>();

            List<BoltGroup> FilteredBoltArrTemp = new List<BoltGroup>();
            FilteredBoltArrTemp.AddRange(FilteredBoltArr);

            BoltGroup ba = null;

            double BoltMinx1 = 0;
            int count = FilteredBoltArrTemp.Count;
            for (int i = 0; i < count; i++)
            {
                for (int j = 0; j < FilteredBoltArrTemp.Count; j++)
                {
                    BoltGroup bArray = FilteredBoltArrTemp[j];
                    double BoltMinX = bArray.GetSolid().MaximumPoint.X;

                    if (j == 0)
                    {
                        BoltMinx1 = BoltMinX;
                        ba = bArray;
                    }
                    if (BoltMinX < BoltMinx1)
                    {
                        BoltMinx1 = BoltMinX;
                        ba = bArray;
                    }
                }
                FilteredBoltArr1.Add(ba);
                FilteredBoltArrTemp.Remove(ba);
            }

            return FilteredBoltArr = FilteredBoltArr1;
        }

        public List<BoltGroup> FilterBoltGListByMaxX(List<BoltGroup> FilteredBoltArr)
        {
            List<BoltGroup> FilteredBoltArr1 = new List<BoltGroup>();

            List<BoltGroup> FilteredBoltArrTemp = new List<BoltGroup>();
            FilteredBoltArrTemp.AddRange(FilteredBoltArr);

            BoltGroup ba = null;

            double BoltMaxx1 = 0;
            int count = FilteredBoltArrTemp.Count;
            for (int i = 0; i < count; i++)
            {
                for (int j = 0; j < FilteredBoltArrTemp.Count; j++)
                {
                    BoltGroup bArray = FilteredBoltArrTemp[j];
                    double BoltMaxX = bArray.GetSolid().MinimumPoint.X;

                    if (j == 0)
                    {
                        BoltMaxx1 = BoltMaxX;
                        ba = bArray;
                    }
                    if (BoltMaxX < BoltMaxx1)
                    {
                        BoltMaxx1 = BoltMaxX;
                        ba = bArray;
                    }
                }
                FilteredBoltArr1.Add(ba);
                FilteredBoltArrTemp.Remove(ba);
            }

            return FilteredBoltArr = FilteredBoltArr1;
        }
        #endregion

        #region ContourPoints in PointList Methods

        //Convert All Contour Point To PointList 
        public TSD.PointList ContPList(TSM.Part Cplate)
        {
            TSD.PointList pointList = new TSD.PointList();
            if (Cplate is Beam)
            {
                pointList.AddRange(GetAllEdgesPList(Cplate));
            }
            else if (Cplate is PolyBeam)
            {
                foreach (TSM.ContourPoint pts in (Cplate as PolyBeam).Contour.ContourPoints)
                {
                    pointList.Add(new Point(pts.X, pts.Y));
                }
            }
            else if (Cplate is ContourPlate)
            {
                foreach (TSM.ContourPoint pts in (Cplate as ContourPlate).Contour.ContourPoints)
                {
                    pointList.Add(new Point(pts.X, pts.Y));
                }
            }
            return pointList;
        }

        public TSD.PointList ContPList(ArrayList ArrPtlist)
        {
            TSD.PointList pointList = new TSD.PointList();
            try
            {
                foreach (TSM.ContourPoint pts in ArrPtlist)
                {
                    pointList.Add(new Point(pts.X, pts.Y, pts.Z));
                }
            }
            catch (Exception ex)
            { }

            return pointList;
        }

        //Convert All Contour Point To PointList With Chamfer Point
        public TSD.PointList ContPListChamfer(TSM.Part Cplate)
        {
            TSD.PointList pointList = new TSD.PointList();
            if (Cplate is PolyBeam)
            {
                foreach (TSM.ContourPoint pts in (Cplate as PolyBeam).Contour.ContourPoints)
                {
                    if (pts.Chamfer.Type != TSM.Chamfer.ChamferTypeEnum.CHAMFER_NONE)
                        pointList.Add(new Point(pts.X, pts.Y));
                }
            }
            else if (Cplate is ContourPlate)
            {
                foreach (TSM.ContourPoint pts in (Cplate as ContourPlate).Contour.ContourPoints)
                {
                    if (pts.Chamfer.Type != TSM.Chamfer.ChamferTypeEnum.CHAMFER_NONE)
                        pointList.Add(new Point(pts.X, pts.Y));
                }
            }
            return pointList;
        }

        //Convert All Contour Point To PointList Without Chamfer Point
        public TSD.PointList ContPListNoChamfer(TSM.Part Cplate)
        {
            TSD.PointList pointList = new TSD.PointList();
            if (Cplate is PolyBeam)
            {
                foreach (TSM.ContourPoint pts in (Cplate as PolyBeam).Contour.ContourPoints)
                {
                    if (pts.Chamfer.Type == TSM.Chamfer.ChamferTypeEnum.CHAMFER_NONE)
                        pointList.Add(new Point(pts.X, pts.Y));
                }
            }
            else if (Cplate is ContourPlate)
            {
                foreach (TSM.ContourPoint pts in (Cplate as ContourPlate).Contour.ContourPoints)
                {
                    if (pts.Chamfer.Type == TSM.Chamfer.ChamferTypeEnum.CHAMFER_NONE)
                        pointList.Add(new Point(pts.X, pts.Y));
                }
            }
            return pointList;
        }

        public List<ContourPoint> ContPtList(TSM.Part Cplate)
        {
            List<ContourPoint> CPpList = new List<ContourPoint>();
            if (Cplate is PolyBeam)
            {
                foreach (TSM.ContourPoint pts in (Cplate as PolyBeam).Contour.ContourPoints)
                    CPpList.Add(pts);
            }
            else if (Cplate is ContourPlate)
            {
                foreach (TSM.ContourPoint pts in (Cplate as ContourPlate).Contour.ContourPoints)
                    CPpList.Add(pts);
            }

            return CPpList;
        }

        #endregion

        #region NearestPoint Methods

        public Point NearestPoint(Point sp, Point ep, Point refp)
        {
            Point NPoint = null;
            double D1 = dist.PointToPoint(sp, refp);
            double D2 = dist.PointToPoint(ep, refp);

            if (D1 < D2)   // Start->Plate
                NPoint = sp;
            else
                NPoint = ep;

            return NPoint;
        }

        public Point NearestPointInList(PointList plist, Point refp)
        {
            Point NPoint = null;
            double D1 = 999999900009999999;
            int disti = -1;
            for (int i = 0; i < plist.Count; i++)
            {
                double dist = Distance.PointToPoint(new Point(plist[i].X, plist[i].Y), new Point(refp.X, refp.Y));
                disti = (int)dist;
                if (disti != 0)
                {
                    if (D1 > dist)
                    {
                        D1 = dist;
                        NPoint = plist[i];
                    }
                }

            }
            return NPoint;
        }

        #endregion

        #region NearestXYPoint Quadrant

        public Point NPQuad1(Point refp, TSD.PointList ptList)  // I Quadrant TopRight
        {
            int c = 0, j = 0;
            double d = 0;
            for (int i = 0; i < ptList.Count; i++)
            {
                if (ptList[i].X > refp.X && ptList[i].Y > refp.Y)
                {
                    if (c == 0)
                    {
                        d = Tekla.Structures.Geometry3d.Distance.PointToPoint(refp, ptList[i]);
                        j = i;
                        c++;
                    }
                    if (d > Tekla.Structures.Geometry3d.Distance.PointToPoint(refp, ptList[i]))
                    {
                        d = Tekla.Structures.Geometry3d.Distance.PointToPoint(refp, ptList[i]);
                        j = i;
                    }


                }

            }

            return new Point(ptList[j].X, ptList[j].Y);

        }
        public Point NPQuad2(Point refp, TSD.PointList ptList) // II Quadrant TopLeft
        {
            int c = 0, j = 0;
            double d = 0;
            for (int i = 0; i < ptList.Count; i++)
            {

                if (ptList[i].X < refp.X && ptList[i].Y > refp.Y)
                {
                    if (c == 0)
                    {
                        d = Tekla.Structures.Geometry3d.Distance.PointToPoint(refp, ptList[i]);
                        j = i;
                        c++;
                    }
                    if (d > Tekla.Structures.Geometry3d.Distance.PointToPoint(refp, ptList[i]))
                    {
                        d = Tekla.Structures.Geometry3d.Distance.PointToPoint(refp, ptList[i]);
                        j = i;
                    }


                }

            }

            return new Point(ptList[j].X, ptList[j].Y);

        }
        public Point NPQuad3(Point refp, TSD.PointList ptList)    // III Quadrant BottomLeft
        {
            int c = 0, j = 0;
            double d = 0;
            for (int i = 0; i < ptList.Count; i++)
            {

                if (ptList[i].X < refp.X && ptList[i].Y < refp.Y)
                {
                    if (c == 0)
                    {
                        d = Tekla.Structures.Geometry3d.Distance.PointToPoint(refp, ptList[i]);
                        j = i;
                        c++;
                    }
                    if (d > Tekla.Structures.Geometry3d.Distance.PointToPoint(refp, ptList[i]))
                    {
                        d = Tekla.Structures.Geometry3d.Distance.PointToPoint(refp, ptList[i]);
                        j = i;
                    }


                }

            }

            return new Point(ptList[j].X, ptList[j].Y);

        }
        public Point NPQuad4(Point refp, TSD.PointList ptList) // IV Quadrant BottomRight
        {
            int c = 0, j = 0;
            double d = 0;
            for (int i = 0; i < ptList.Count; i++)
            {

                if (ptList[i].X > refp.X && ptList[i].Y < refp.Y)
                {
                    if (c == 0)
                    {
                        d = Tekla.Structures.Geometry3d.Distance.PointToPoint(refp, ptList[i]);
                        j = i;
                        c++;
                    }
                    if (d > Tekla.Structures.Geometry3d.Distance.PointToPoint(refp, ptList[i]))
                    {
                        d = Tekla.Structures.Geometry3d.Distance.PointToPoint(refp, ptList[i]);
                        j = i;
                    }


                }

            }

            return new Point(ptList[j].X, ptList[j].Y);

        }

        public PointList GetNearestPointsXAxis(PointList ptList, Point RefPoint)
        {

            PointList RetPointList = new PointList();
            try
            {

                Point LeftP1 = new Point();
                Point RightP1 = new Point();

                double minx = 99999999;
                double maxx = -99999999;

                int j = 0;
                int k = 0;
                for (int i = 1; i < ptList.Count; i++)
                {
                    if (ptList[i].X > RefPoint.X)
                    {
                        if (minx > ptList[i].X)
                        {
                            minx = ptList[i].X;
                            j = i;
                        }
                    }
                    if (ptList[i].X < RefPoint.X)
                    {
                        if (maxx < ptList[i].X)
                        {
                            maxx = ptList[i].X;
                            k = i;
                        }
                    }
                }

                RightP1 = ptList[j];
                LeftP1 = ptList[k];


                RetPointList.Add(LeftP1);
                RetPointList.Add(RightP1);


            }
            catch (Exception ex)
            { }




            return RetPointList;

        }

        public PointList GetNearestPointsYAxis(PointList ptList, Point RefPoint)
        {

            PointList RetPointList = new PointList();
            try
            {

                Point TopP1 = new Point();
                Point BottomP1 = new Point();

                double minx = 99999999;
                double maxx = -99999999;

                int j = 0;
                int k = 0;
                for (int i = 1; i < ptList.Count; i++)
                {
                    if (ptList[i].Y > RefPoint.Y)
                    {
                        if (minx > ptList[i].Y)
                        {
                            minx = ptList[i].Y;
                            j = i;
                        }
                    }
                    if (ptList[i].Y < RefPoint.Y)
                    {
                        if (maxx < ptList[i].Y)
                        {
                            maxx = ptList[i].Y;
                            k = i;
                        }
                    }
                }

                BottomP1 = ptList[j];
                TopP1 = ptList[k];
                RetPointList.Add(TopP1);
                RetPointList.Add(BottomP1);


            }
            catch (Exception ex)
            { }




            return RetPointList;

        }

        #endregion

        #region Conversion Methods

        public List<Point> ConvertArrayListToListPoint(ArrayList tArrayList)
        {
            //List<Point> pList = new List<Point>();
            //if (tArrayList.Count < 1) return null;

            //if (tArrayList.Count > 0)
            //{
            //    foreach (Tekla.Structures.Geometry3d.Point point in tArrayList)
            //        pList.Add(point);
            //}
            return (tArrayList.OfType<Point>().ToList());
        }

        public TSD.PointList ConvertArrayListToPointList(ArrayList tArrayList)
        {
            // if (tArrayList.Count < 1) return null;
            var pList = new TSD.PointList();
            //if (tArrayList.Count > 0)
            //{
            //    foreach (Point point in tArrayList)
            //        pList.Add(point);
            //}

            tArrayList.OfType<Point>().ToList().ForEach(x => { if (x is Point) { pList.Add(x); } });
            return pList;
        }

        public List<int> ConvertIdentListToIDList(List<Identifier> IdentList)
        {
            //List<int> IDList = new List<int>();
            //if (IdentList.Count > 0)
            //{
            //    foreach (Identifier Ident in IdentList)
            //    {
            //        IDList.Add(Ident.ID);
            //    }
            // }

            return (IdentList.Select(x => x.ID).ToList());
        }

        public PointList ConvertListofPointlistToPointList(List<PointList> ptlist)
        {
            PointList pList = new PointList();

            //foreach (PointList p1 in ptlist)
            //    foreach (Point p in p1)
            //        pList.Add(p);

            ptlist.ForEach(x => { if (x is PointList) { pList.AddRange(x); } });
            return pList;
        }

        public PointList ConvertListPointToPointList(List<Point> ListP)
        {
            PointList pList = new PointList();
            //foreach (Point p in ListP)
            //    pList.Add(p);

            //ListP.ToArray<Point>();
            //ArrayList arList = new ArrayList();
            //arList.AddRange(ListP.ToArray<Point>());
            ListP.ForEach(x => { if (x is Point) { pList.Add(x); } });
            return pList;
        }

        /*---------------------------------------------------------------------*/

        public double ConvertFeetInchtoMM(string dist)
        {
            double dimVal = 0;
            try
            {
                try
                {
                    dimVal = Convert.ToDouble(dist);
                }
                catch (Exception) { }

                if (dimVal == 0)
                {
                    if (dist.Contains("\\"))
                        dist = dist.Replace("\\", "\"");

                    if (dist.Contains("-"))
                        dist = dist.Replace("-", "");

                    int i = dist.IndexOf("\"");
                    int j = dist.LastIndexOf("\"");

                    if (i != j)
                    {
                        dist = dist.Substring(0, j);

                    }

                    DIS.CurrentUnitType = DIS.UnitType.Foot;
                    DIS.UseFractionalFormat = true;
                    DIS distt = DIS.Parse(dist, CultureInfo.DefaultThreadCurrentCulture, DIS.UnitType.Foot);
                    dimVal = Math.Round(distt.Millimeters, 2);
                }
            }
            catch (Exception ex)
            {

            }

            return dimVal;
        }

        public double RoundOffInch(double val)
        {
            string inchVal = (Math.Round(((val / 25.4) / 0.0625), 4)).ToString();
            double RoundMMval = val;
            double decval = 0;
            int incVal = 0;
            if (inchVal.Contains("."))
            {
                string decvalStr = inchVal.Substring(inchVal.LastIndexOf(".") + 1);
                decval = Convert.ToDouble("0." + decvalStr);
                if (decval >= 0.5)
                    decval = 1;
                else
                    decval = 0;

            }
            if (decval > 0)
                RoundMMval = (((Convert.ToDouble(inchVal) - decval) + 1) * 0.0625) * 25.4;

            return RoundMMval;
        }

        public double RoundOffDim(double val)
        {
            string inInch = (val / 25.4).ToString();
            string inchVal = (val / 304.8).ToString();
            double RoundMMval = val;
            double decval = 0;
            if (inInch.Contains("."))
            {
                string decvalStr1 = inInch.Substring(inInch.LastIndexOf(".") + 1);
                double decval1 = Convert.ToDouble("0." + decvalStr1);
                string decvalStr = inchVal.Substring(inchVal.LastIndexOf(".") + 1);
                decval = Convert.ToDouble("0." + decvalStr);
                if (decval1 > 0)
                {
                    double d = 15 % 2;
                    if (decval % 304.8 != 0)
                    {
                        double RoundVal = 0;
                        double r = decval * 304.8;
                        RoundVal = GetRoundVal(r);
                        RoundMMval = val + RoundVal;
                    }
                }
            }

            return RoundMMval;
        }

        private double GetRoundVal(double val)
        {
            double by128 = 0.1984375;
            double by64 = 0.396875;
            double by32 = 0.79375;
            double by16 = 0;

            if (val % by128 == 0)
                return by128;
            if (val % by64 == 0)
                return by64;
            if (val % by32 == 0)
                return by32;
            else
                return by16;

        }

        #endregion

        public TSD.StraightDimensionSet ChangeDimPoints(TSD.StraightDimensionSet CurrDim, TSD.View Currentview, TSD.PointList PtList)
        {
            TSD.StraightDimensionSet xpsV1 = null;
            try
            {
                TSD.StraightDimensionSet.StraightDimensionSetAttributes attr1 = CurrDim.Attributes;
                Vector vect = DimDirection(CurrDim);

                double Px = 0;
                double distance = CurrDim.Distance;
                TSD.PointList OldPt = DimPointList(CurrDim);

                vect = ChangeVector(vect);

                CurrDim.Delete();
                TSD.StraightDimensionSet xpsV = InsertDim(Currentview, PtList, vect, distance, attr1);
                xpsV.Distance = distance;
                xpsV.Modify();
                TSD.PointList NewPtt = DimPointList(xpsV);
                vect = DimDirection(xpsV);

                //if (vect.X != 0)
                //    Px = dist.PointToPoint(new Point(MinX(OldPt).X, MinX(OldPt).Y), new Point(MinX(NewPtt).X, MinX(NewPtt).Y));
                //else
                //double CutpLength = 0, cutScale=0;
                //if (Currentview.Attributes.Shortening.CutParts)
                //{
                //    CutpLength=Currentview.Attributes.Shortening.MinimumLength;
                //    Px = dist.PointToPoint(new Point(OldPt[0].X, OldPt[0].Y), new Point(NewPtt[0].X, NewPtt[0].Y));
                //    if (CutpLength != 0 && Px!=0)
                //    {
                //        cutScale = (Px / CutpLength);
                //        if(cutScale>=1)
                //            Px = (Px / cutScale) + CutpLength + distance;
                //    }
                //}
                //else

                //if (vect.X != 0 && vect.Y == 0) //Vert Dim
                //    Px = dist.PointToPoint(new Point(MinX(PtList).X, 0), new Point(MaxX(PtList).X, 0)); // Xdist
                //else if (vect.X == 0 && vect.Y != 0)
                //    Px = dist.PointToPoint(new Point(MinY(PtList).Y, 0), new Point(MaxY(PtList).Y, 0)); // Ydist
                //else
                Px = dist.PointToPoint(new Point(OldPt[0].X, OldPt[0].Y), new Point(NewPtt[0].X, NewPtt[0].Y));

                //if(Px==0)
                //    Px = dist.PointToPoint(new Point(OldPt[1].X, OldPt[1].Y), new Point(NewPtt[1].X, NewPtt[1].Y));

                vect = ChangeVector(vect);

                xpsV.Delete();
                xpsV1 = InsertDim(Currentview, NewPtt, vect, distance, attr1);
                //  if (NewPtt[0].X != NewPtt[1].X && NewPtt[0].Y != NewPtt[1].Y)
                xpsV1.Distance = distance + Px;
                xpsV1.Modify();


            }
            catch (Exception ex)
            { }

            return xpsV1;
        }

        public void ChangeDimPoints1(TSD.StraightDimensionSet CurrDim, TSD.View Currentview, TSD.PointList PtList, Point refP)
        {
            try
            {
                TSD.StraightDimensionSet.StraightDimensionSetAttributes attr1 = CurrDim.Attributes;
                Vector vect = DimDirection(CurrDim);
                double Px = 0;
                double distance = CurrDim.Distance;
                TSD.PointList OldPt = DimPointList(CurrDim);

                vect = ChangeVector(vect);

                CurrDim.Delete();
                TSD.StraightDimensionSet xpsV = new TSD.StraightDimensionSetHandler().CreateDimensionSet(Currentview, PtList, vect, distance, attr1);
                xpsV.Distance = distance;
                xpsV.Modify();
                TSD.PointList NewPtt = DimPointList(xpsV);
                vect = DimDirection(xpsV);
                if ((Math.Round(OldPt[0].X) == Math.Round(refP.X)) && (Math.Round(OldPt[0].Y) == Math.Round(refP.Y)))
                    Px = ((dist.PointToPoint(OldPt[1], NewPtt[1])) / 2);
                else
                    Px = dist.PointToPoint(OldPt[0], NewPtt[0]);

                vect = ChangeVector(vect);

                xpsV.Delete();
                TSD.StraightDimensionSet xpsV1 = new TSD.StraightDimensionSetHandler().CreateDimensionSet(Currentview, NewPtt, vect, distance, attr1);
                //  if (NewPtt[0].X != NewPtt[1].X && NewPtt[0].Y != NewPtt[1].Y)
                xpsV1.Distance = distance + Px;
                xpsV1.Modify();
            }
            catch (Exception ex)
            { }
        }

        public bool CheckBoltDiffX(TSM.BoltGroup boltArr, TSM.Beam mainbeam)
        {
            TSM.Beam B = new TSM.Beam();
            TSM.ContourPlate Cp = new TSM.ContourPlate();
            bool check = false;
            Tekla.Structures.Model.Part part;
            if (boltArr.PartToBeBolted.Identifier.ID != mainbeam.Identifier.ID)
                part = boltArr.PartToBeBolted;
            else
                part = boltArr.PartToBoltTo;

            if (part is TSM.Beam)
            {
                B = part as TSM.Beam;

                if (B.Name.Contains("ANGLE") || B.Name.Contains("Angle") || B.Name.Contains("angle") || B.Name.Contains("PLATE") || B.Name.Contains("Plate") || B.Name.Contains("plate"))
                {
                    List<Point> Blist = ConvertArrayListToListPoint(boltArr.BoltPositions);
                    if (Blist.Count > 2)
                    {
                        if (Math.Round(Blist[0].X) != Math.Round(Blist[Blist.Count - 1].X))
                            check = true;
                    }
                }
            }
            if (part is TSM.ContourPlate)
            {
                Cp = part as TSM.ContourPlate;
                if (Cp.Name.Contains("PLATE") || Cp.Name.Contains("Plate") || Cp.Name.Contains("plate"))
                {
                    List<Point> Blist = ConvertArrayListToListPoint(boltArr.BoltPositions);
                    if (Blist.Count > 2)
                    {
                        if (Math.Round(Blist[0].X) != Math.Round(Blist[Blist.Count - 1].X))
                            check = true;
                    }
                }
            }

            return check;
        }

        #region CenterPoint Methods

        public Point CenterPoint(Point Sp, Point Ep)
        {
            double distance = (Tekla.Structures.Geometry3d.Distance.PointToPoint(Sp, Ep));
            double x = ((Ep.X - Sp.X) / distance) * (distance / 2) + Sp.X;
            double y = ((Ep.Y - Sp.Y) / distance) * (distance / 2) + Sp.Y;
            double z = ((Ep.Z - Sp.Z) / distance) * (distance / 2) + Sp.Z;

            Point CenterPoint = new Point();
            if (!double.IsNaN(x) && !double.IsNaN(y) && !double.IsNaN(z))
                CenterPoint = new Point(x, y, z);

            return CenterPoint;
        }

        public Point CenterPoint(TSM.Part part)
        {
            return CenterPoint(part.GetSolid().MinimumPoint, part.GetSolid().MaximumPoint);
        }


        public Point FindCenterPoint(TSD.PointList pttList)
        {
            Point pa = new Point(pttList[0]);
            Point pb = new Point(pttList[pttList.Count - 1]);
            double distance = (Tekla.Structures.Geometry3d.Distance.PointToPoint(pa, pb));

            double x = ((pb.X - pa.X) / distance) * (distance / 2) + pa.X;
            double y = ((pb.Y - pa.Y) / distance) * (distance / 2) + pa.Y;
            double z = ((pb.Z - pa.Z) / distance) * (distance / 2) + pa.Z;

            Point CenterPoint = new Point();

            if (!double.IsNaN(x) && !double.IsNaN(y) && !double.IsNaN(z))
                CenterPoint = new Point(x, y, z);

            return CenterPoint;
        }

        #endregion

        #region Gusset Plate Methods

        public List<TSM.Part> GetBoltOtherPart(BoltGroup blt)
        {
            List<TSM.Part> prtlist = new List<TSM.Part>();
            ArrayList boltaarr = blt.OtherPartsToBolt;
            foreach (TSM.Part prt in boltaarr)
            {
                prtlist.Add(prt);
            }

            return prtlist;
        }

        public List<TSM.Beam> GetBrace(TSM.Part myCPlate)
        {
            List<TSM.Beam> myBraceList = new List<TSM.Beam>();
            try
            {
                TSM.ModelObjectEnumerator BoltEnumm = myCPlate.GetBolts();
                while (BoltEnumm.MoveNext())
                {
                    bool IsBraceFound = false;
                    TSM.BoltGroup tBoltGroup = BoltEnumm.Current as TSM.BoltGroup;

                    List<TSM.Part> ObjList = new List<TSM.Part>();

                    if (IsGpOtherPart(tBoltGroup, myCPlate))
                    {
                        ObjList.Add(tBoltGroup.PartToBeBolted);
                        ObjList.Add(tBoltGroup.PartToBoltTo);
                    }
                    else
                    {
                        if (tBoltGroup.PartToBeBolted.Identifier.ID == myCPlate.Identifier.ID)
                            ObjList.Add(tBoltGroup.PartToBoltTo);

                        else if (tBoltGroup.PartToBoltTo.Identifier.ID == myCPlate.Identifier.ID)
                            ObjList.Add(tBoltGroup.PartToBeBolted);
                    }

                    foreach (TSM.Part Mobj in ObjList)
                    {
                        string ProType = "";
                        TSM.Part RefBeam = Mobj as TSM.Part;
                        ProType = GetProType(RefBeam);

                        if (IsBrace(RefBeam))       //Direct Brace
                        {
                            TSM.Beam RefBeam1 = Mobj as TSM.Beam;
                            if (!IsInList(myBraceList, RefBeam1))
                            {
                                myBraceList.Add(RefBeam1);
                                IsBraceFound = true;
                            }
                        }
                        else if (ProType == "B")        //Brace connected via "PLATE"
                        {
                            Tekla.Structures.Model.ModelObject mobj = RefBeam.GetAssembly().GetMainPart();

                            TSM.Part tempb = mobj as TSM.Part;
                            ProType = GetProType(tempb);
                            if (IsBrace(tempb))
                            {
                                TSM.Beam tempb1 = mobj as TSM.Beam;
                                if (!IsInList(myBraceList, tempb1))
                                {
                                    myBraceList.Add(tempb1);
                                    IsBraceFound = true;
                                }
                            }
                            else
                            {
                                TSM.ModelObjectEnumerator BoltEnum = tempb.GetBolts();
                                int size = BoltEnum.GetSize();
                                if (size > 1)
                                {
                                    while (BoltEnum.MoveNext())
                                    {
                                        if (BoltEnum.Current.Identifier.ID != tBoltGroup.Identifier.ID)
                                        {
                                            TSM.BoltGroup braceBolt = BoltEnum.Current as TSM.BoltGroup;

                                            TSM.Part ObjPart = braceBolt.PartToBeBolted as TSM.Part;
                                            if (!IsBraceFound && IsBrace(braceBolt.PartToBeBolted))
                                            {
                                                if (!IsInList(myBraceList, (braceBolt.PartToBeBolted as TSM.Beam)))
                                                {
                                                    myBraceList.Add(braceBolt.PartToBeBolted as TSM.Beam);
                                                    IsBraceFound = true;
                                                }
                                            }
                                            else if (!IsBraceFound && IsBrace(GetMP(ObjPart)))
                                            {
                                                if (!IsInList(myBraceList, (GetMP(ObjPart) as TSM.Beam)))
                                                {
                                                    myBraceList.Add(GetMP(ObjPart) as TSM.Beam);
                                                    IsBraceFound = true;
                                                }
                                            }

                                            ObjPart = braceBolt.PartToBoltTo as TSM.Part;
                                            if (!IsBraceFound && IsBrace(braceBolt.PartToBoltTo))
                                            {
                                                if (!IsInList(myBraceList, (braceBolt.PartToBoltTo as TSM.Beam)))
                                                {
                                                    myBraceList.Add(braceBolt.PartToBoltTo as TSM.Beam);
                                                    IsBraceFound = true;
                                                }
                                            }

                                            else if (!IsBraceFound && IsBrace(GetMP(ObjPart)))
                                            {
                                                if (!IsInList(myBraceList, (GetMP(ObjPart) as TSM.Beam)))
                                                {
                                                    myBraceList.Add(GetMP(ObjPart) as TSM.Beam);
                                                    IsBraceFound = true;
                                                }
                                            }

                                            if (!IsBraceFound)
                                            {
                                                List<TSM.Part> OtherPartList = GetBoltOtherPart(braceBolt);
                                                foreach (TSM.Part prt in OtherPartList)
                                                {
                                                    if (!IsBraceFound && IsBrace(prt))
                                                    {
                                                        if (!IsInList(myBraceList, (prt as TSM.Beam)))
                                                        {
                                                            myBraceList.Add(prt as TSM.Beam);
                                                            IsBraceFound = true;
                                                        }
                                                    }
                                                    if (!IsBraceFound && IsBrace(GetMP(prt)))
                                                    {
                                                        if (!IsInList(myBraceList, GetMP(prt) as TSM.Beam))
                                                        {
                                                            myBraceList.Add(GetMP(prt) as TSM.Beam);
                                                            IsBraceFound = true;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        else if (IsAngle(RefBeam))      //Brace connected via "ANGLE"
                        {
                            Tekla.Structures.Model.ModelObject mobj = RefBeam.GetAssembly().GetMainPart();
                            if (mobj is TSM.Beam)
                            {
                                TSM.Beam tempb = mobj as TSM.Beam;
                                if (IsBrace(tempb))
                                {
                                    if (!IsInList(myBraceList, tempb))
                                    {
                                        myBraceList.Add(tempb);
                                        IsBraceFound = true;
                                    }
                                }
                                else
                                {
                                    TSM.ModelObjectEnumerator BoltEnum = tempb.GetBolts();
                                    int size = BoltEnum.GetSize();
                                    if (size > 1)
                                    {
                                        while (BoltEnum.MoveNext())
                                        {
                                            if (BoltEnum.Current.Identifier.ID != tBoltGroup.Identifier.ID)
                                            {
                                                TSM.BoltGroup braceBolt = BoltEnum.Current as TSM.BoltGroup;

                                                TSM.Part ObjPart = braceBolt.PartToBeBolted as TSM.Part;
                                                if (!IsBraceFound && IsBrace(braceBolt.PartToBeBolted))
                                                {
                                                    if (!IsInList(myBraceList, (braceBolt.PartToBeBolted as TSM.Beam)))
                                                    {
                                                        myBraceList.Add(braceBolt.PartToBeBolted as TSM.Beam);
                                                        IsBraceFound = true;
                                                    }
                                                }
                                                else if (!IsBraceFound && IsBrace(GetMP(ObjPart)))
                                                {
                                                    if (!IsInList(myBraceList, (GetMP(ObjPart) as TSM.Beam)))
                                                    {
                                                        myBraceList.Add(GetMP(ObjPart) as TSM.Beam);
                                                        IsBraceFound = true;
                                                    }
                                                }

                                                ObjPart = braceBolt.PartToBoltTo as TSM.Part;
                                                if (!IsBraceFound && IsBrace(braceBolt.PartToBoltTo))
                                                {
                                                    if (!IsInList(myBraceList, (braceBolt.PartToBoltTo as TSM.Beam)))
                                                    {
                                                        myBraceList.Add(braceBolt.PartToBoltTo as TSM.Beam);
                                                        IsBraceFound = true;
                                                    }
                                                }
                                                else if (!IsBraceFound && IsBrace(GetMP(ObjPart)))
                                                {
                                                    if (!IsInList(myBraceList, (GetMP(ObjPart) as TSM.Beam)))
                                                    {
                                                        myBraceList.Add(GetMP(ObjPart) as TSM.Beam);
                                                        IsBraceFound = true;
                                                    }
                                                }

                                                if (!IsBraceFound)
                                                {
                                                    List<TSM.Part> OtherPartList = GetBoltOtherPart(braceBolt);
                                                    foreach (TSM.Part prt in OtherPartList)
                                                    {
                                                        if (!IsBraceFound && IsBrace(prt))
                                                        {
                                                            if (!IsInList(myBraceList, (prt as TSM.Beam)))
                                                            {
                                                                myBraceList.Add(prt as TSM.Beam);
                                                                IsBraceFound = true;
                                                            }
                                                        }
                                                        if (!IsBraceFound && IsBrace(GetMP(prt)))
                                                        {
                                                            if (!IsInList(myBraceList, GetMP(prt) as TSM.Beam))
                                                            {
                                                                myBraceList.Add(GetMP(prt) as TSM.Beam);
                                                                IsBraceFound = true;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        if (!IsBraceFound)
                        {
                            List<TSM.Part> OtherPartList = GetBoltOtherPart(tBoltGroup);
                            foreach (TSM.Part prt in OtherPartList)
                            {
                                if (IsBrace(prt))
                                {
                                    if (!IsInList(myBraceList, (prt as TSM.Beam)))
                                    {
                                        myBraceList.Add(prt as TSM.Beam);
                                        IsBraceFound = true;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex) { }

            return myBraceList;
        }

        public PointList GetBraceAllBolt(TSM.Part myCPlate, Beam Brace)
        {
            PointList BraceBoltList = new PointList();
            try
            {
                TSM.ModelObjectEnumerator BoltEnumm = myCPlate.GetBolts();
                while (BoltEnumm.MoveNext())
                {
                    bool IsBraceFound = false;
                    TSM.BoltGroup tBoltGroup = BoltEnumm.Current as TSM.BoltGroup;

                    List<TSM.Part> ObjList = new List<TSM.Part>();

                    if (IsGpOtherPart(tBoltGroup, myCPlate))
                    {
                        ObjList.Add(tBoltGroup.PartToBeBolted);
                        ObjList.Add(tBoltGroup.PartToBoltTo);
                    }
                    else
                    {
                        if (tBoltGroup.PartToBeBolted.Identifier.ID == myCPlate.Identifier.ID)
                            ObjList.Add(tBoltGroup.PartToBoltTo);

                        else if (tBoltGroup.PartToBoltTo.Identifier.ID == myCPlate.Identifier.ID)
                            ObjList.Add(tBoltGroup.PartToBeBolted);
                    }

                    foreach (TSM.Part Mobj in ObjList)
                    {
                        string ProType = "";
                        TSM.Part RefBeam = Mobj as TSM.Part;
                        ProType = GetProType(RefBeam);
                        if (IsBrace(RefBeam) && RefBeam.Identifier.ID == Brace.Identifier.ID)       //Direct Brace
                        {
                            BraceBoltList.AddRange(ConvertArrayListToPointList(tBoltGroup.BoltPositions));
                            IsBraceFound = true;
                        }
                        else if (ProType == "B")        //Brace connected via "PLATE"
                        {
                            Tekla.Structures.Model.ModelObject mobj = RefBeam.GetAssembly().GetMainPart();
                            if (mobj is TSM.Part)
                            {
                                TSM.Part tempb = mobj as TSM.Part;
                                if (IsBrace(tempb) && tempb.Identifier.ID == Brace.Identifier.ID)
                                {
                                    BraceBoltList.AddRange(ConvertArrayListToPointList(tBoltGroup.BoltPositions));
                                    IsBraceFound = true;
                                }
                                else
                                {
                                    TSM.ModelObjectEnumerator BoltEnum = tempb.GetBolts();
                                    int size = BoltEnum.GetSize();
                                    if (size > 1)
                                    {
                                        while (BoltEnum.MoveNext())
                                        {
                                            if (BoltEnum.Current.Identifier.ID != tBoltGroup.Identifier.ID)
                                            {
                                                TSM.BoltGroup braceBolt = BoltEnum.Current as TSM.BoltGroup;

                                                TSM.Part ObjPart = braceBolt.PartToBeBolted as TSM.Part;
                                                if (!IsBraceFound && IsBrace(ObjPart))
                                                {
                                                    if (ObjPart.Identifier.ID == Brace.Identifier.ID)
                                                    {
                                                        BraceBoltList.AddRange(ConvertArrayListToPointList(tBoltGroup.BoltPositions));
                                                        IsBraceFound = true;
                                                    }
                                                }
                                                if (!IsBraceFound && IsBrace(GetMP(ObjPart)))
                                                {
                                                    if (GetMP(ObjPart).Identifier.ID == Brace.Identifier.ID)
                                                    {
                                                        BraceBoltList.AddRange(ConvertArrayListToPointList(tBoltGroup.BoltPositions));
                                                        IsBraceFound = true;
                                                    }
                                                }

                                                ObjPart = braceBolt.PartToBoltTo as TSM.Part;
                                                if (!IsBraceFound && IsBrace(braceBolt.PartToBoltTo))
                                                {
                                                    if (ObjPart.Identifier.ID == Brace.Identifier.ID)
                                                    {
                                                        BraceBoltList.AddRange(ConvertArrayListToPointList(tBoltGroup.BoltPositions));
                                                        IsBraceFound = true;
                                                    }
                                                }
                                                if (!IsBraceFound && IsBrace(GetMP(ObjPart)))
                                                {
                                                    if (GetMP(ObjPart).Identifier.ID == Brace.Identifier.ID)
                                                    {
                                                        BraceBoltList.AddRange(ConvertArrayListToPointList(tBoltGroup.BoltPositions));
                                                        IsBraceFound = true;
                                                    }
                                                }

                                                if (!IsBraceFound)
                                                {
                                                    List<TSM.Part> OtherPartList = GetBoltOtherPart(braceBolt);
                                                    foreach (TSM.Part prt in OtherPartList)
                                                    {
                                                        if (!IsBraceFound && IsBrace(prt))
                                                        {
                                                            if (prt.Identifier.ID == Brace.Identifier.ID)
                                                            {
                                                                BraceBoltList.AddRange(ConvertArrayListToPointList(tBoltGroup.BoltPositions));
                                                                IsBraceFound = true;
                                                            }
                                                        }
                                                        if (!IsBraceFound && IsBrace(GetMP(prt)))
                                                        {
                                                            if (GetMP(prt).Identifier.ID == Brace.Identifier.ID)
                                                            {
                                                                BraceBoltList.AddRange(ConvertArrayListToPointList(tBoltGroup.BoltPositions));
                                                                IsBraceFound = true;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        else if (IsAngle(RefBeam))      //Brace connected via "ANGLE"
                        {
                            Tekla.Structures.Model.ModelObject mobj = RefBeam.GetAssembly().GetMainPart();
                            if (mobj is TSM.Part)
                            {
                                TSM.Part tempb = mobj as TSM.Part;
                                if (IsBrace(tempb) && tempb.Identifier.ID == Brace.Identifier.ID)
                                {
                                    BraceBoltList.AddRange(ConvertArrayListToPointList(tBoltGroup.BoltPositions));
                                    IsBraceFound = true;
                                }
                                else
                                {
                                    TSM.ModelObjectEnumerator BoltEnum = tempb.GetBolts();
                                    int size = BoltEnum.GetSize();
                                    if (size > 1)
                                    {
                                        while (BoltEnum.MoveNext())
                                        {
                                            if (BoltEnum.Current.Identifier.ID != tBoltGroup.Identifier.ID)
                                            {
                                                TSM.BoltGroup braceBolt = BoltEnum.Current as TSM.BoltGroup;

                                                TSM.Part ObjPart = braceBolt.PartToBeBolted as TSM.Part;
                                                if (!IsBraceFound && IsBrace(ObjPart))
                                                {
                                                    if (ObjPart.Identifier.ID == Brace.Identifier.ID)
                                                    {
                                                        BraceBoltList.AddRange(ConvertArrayListToPointList(tBoltGroup.BoltPositions));
                                                        IsBraceFound = true;
                                                    }
                                                }
                                                if (!IsBraceFound && IsBrace(GetMP(ObjPart)))
                                                {
                                                    if (GetMP(ObjPart).Identifier.ID == Brace.Identifier.ID)
                                                    {
                                                        BraceBoltList.AddRange(ConvertArrayListToPointList(tBoltGroup.BoltPositions));
                                                        IsBraceFound = true;
                                                    }
                                                }

                                                ObjPart = braceBolt.PartToBoltTo as TSM.Part;
                                                if (!IsBraceFound && IsBrace(braceBolt.PartToBoltTo))
                                                {
                                                    if (ObjPart.Identifier.ID == Brace.Identifier.ID)
                                                    {
                                                        BraceBoltList.AddRange(ConvertArrayListToPointList(tBoltGroup.BoltPositions));
                                                        IsBraceFound = true;
                                                    }
                                                }
                                                if (!IsBraceFound && IsBrace(GetMP(ObjPart)))
                                                {
                                                    if (GetMP(ObjPart).Identifier.ID == Brace.Identifier.ID)
                                                    {
                                                        BraceBoltList.AddRange(ConvertArrayListToPointList(tBoltGroup.BoltPositions));
                                                        IsBraceFound = true;
                                                    }
                                                }

                                                if (!IsBraceFound)
                                                {
                                                    List<TSM.Part> OtherPartList = GetBoltOtherPart(braceBolt);
                                                    foreach (TSM.Part prt in OtherPartList)
                                                    {
                                                        if (!IsBraceFound && IsBrace(prt))
                                                        {
                                                            if (prt.Identifier.ID == Brace.Identifier.ID)
                                                            {
                                                                BraceBoltList.AddRange(ConvertArrayListToPointList(tBoltGroup.BoltPositions));
                                                                IsBraceFound = true;
                                                            }
                                                        }
                                                        if (!IsBraceFound && IsBrace(GetMP(prt)))
                                                        {
                                                            if (GetMP(prt).Identifier.ID == Brace.Identifier.ID)
                                                            {
                                                                BraceBoltList.AddRange(ConvertArrayListToPointList(tBoltGroup.BoltPositions));
                                                                IsBraceFound = true;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (!IsBraceFound)
                    {
                        List<TSM.Part> OtherPartList = GetBoltOtherPart(tBoltGroup);
                        foreach (TSM.Part prt in OtherPartList)
                        {
                            if (IsBrace(prt) && (prt.Identifier.ID == Brace.Identifier.ID || IsSameBracePoints(prt, Brace)))
                            {
                                BraceBoltList.AddRange(ConvertArrayListToPointList(tBoltGroup.BoltPositions));
                                break;
                            }
                        }
                    }
                }
            }
            catch (Exception ex) { }

            return BraceBoltList;
        }

        public PointList GetBracePlateBolt(TSM.Part myCPlate, Beam Brace)
        {
            PointList BraceBoltList = new PointList();
            try
            {
                TSM.ModelObjectEnumerator BoltEnumm = myCPlate.GetBolts();
                while (BoltEnumm.MoveNext())
                {
                    bool IsBraceFound = false;
                    TSM.BoltGroup tBoltGroup = BoltEnumm.Current as TSM.BoltGroup;
                    List<TSM.Part> ObjList = new List<TSM.Part>();

                    if (IsGpOtherPart(tBoltGroup, myCPlate))
                    {
                        ObjList.Add(tBoltGroup.PartToBeBolted);
                        ObjList.Add(tBoltGroup.PartToBoltTo);
                    }
                    else
                    {
                        if (tBoltGroup.PartToBeBolted.Identifier.ID == myCPlate.Identifier.ID)
                            ObjList.Add(tBoltGroup.PartToBoltTo);

                        else if (tBoltGroup.PartToBoltTo.Identifier.ID == myCPlate.Identifier.ID)
                            ObjList.Add(tBoltGroup.PartToBeBolted);
                    }

                    foreach (TSM.Part Mobj in ObjList)
                    {
                        TSM.Part RefBeam = Mobj as TSM.Part;
                        string ProType = "";
                        ProType = GetProType(RefBeam);

                        if (ProType == "B")          //Brace connected via "PLATE"
                        {
                            Tekla.Structures.Model.ModelObject mobj = RefBeam.GetAssembly().GetMainPart();
                            if (mobj is TSM.Part)
                            {
                                TSM.Part tempb = mobj as TSM.Part;
                                if (IsBrace(tempb) && (tempb.Identifier.ID == Brace.Identifier.ID || IsSameBracePoints(tempb, Brace)))
                                {
                                    BraceBoltList.AddRange(ConvertArrayListToPointList(tBoltGroup.BoltPositions));
                                    IsBraceFound = true;
                                }
                                else
                                {
                                    TSM.ModelObjectEnumerator BoltEnum = tempb.GetBolts();
                                    int size = BoltEnum.GetSize();
                                    if (size > 1)
                                    {
                                        while (BoltEnum.MoveNext())
                                        {
                                            if (BoltEnum.Current.Identifier.ID != tBoltGroup.Identifier.ID)
                                            {
                                                TSM.BoltGroup braceBolt = BoltEnum.Current as TSM.BoltGroup;

                                                TSM.Part ObjPart = braceBolt.PartToBeBolted as TSM.Part;
                                                if (!IsBraceFound && IsBrace(ObjPart))
                                                {
                                                    if (ObjPart.Identifier.ID == Brace.Identifier.ID || IsSameBracePoints(ObjPart, Brace))
                                                    {
                                                        BraceBoltList.AddRange(ConvertArrayListToPointList(tBoltGroup.BoltPositions));
                                                        IsBraceFound = true;
                                                    }
                                                }

                                                if (!IsBraceFound && IsBrace(GetMP(ObjPart)))
                                                {
                                                    if (GetMP(ObjPart).Identifier.ID == Brace.Identifier.ID || IsSameBracePoints(GetMP(ObjPart), Brace))
                                                    {
                                                        BraceBoltList.AddRange(ConvertArrayListToPointList(tBoltGroup.BoltPositions));
                                                        IsBraceFound = true;
                                                    }
                                                }

                                                ObjPart = braceBolt.PartToBoltTo as TSM.Part;
                                                if (!IsBraceFound && IsBrace(braceBolt.PartToBoltTo))
                                                {
                                                    if (ObjPart.Identifier.ID == Brace.Identifier.ID || IsSameBracePoints(ObjPart, Brace))
                                                    {
                                                        BraceBoltList.AddRange(ConvertArrayListToPointList(tBoltGroup.BoltPositions));
                                                        IsBraceFound = true;
                                                    }
                                                }

                                                if (!IsBraceFound && IsBrace(GetMP(ObjPart)))
                                                {
                                                    if (GetMP(ObjPart).Identifier.ID == Brace.Identifier.ID || IsSameBracePoints(GetMP(ObjPart), Brace))
                                                    {
                                                        BraceBoltList.AddRange(ConvertArrayListToPointList(tBoltGroup.BoltPositions));
                                                        IsBraceFound = true;
                                                    }
                                                }

                                                if (!IsBraceFound)
                                                {
                                                    List<TSM.Part> OtherPartList = GetBoltOtherPart(braceBolt);
                                                    foreach (TSM.Part prt in OtherPartList)
                                                    {
                                                        if (!IsBraceFound && IsBrace(prt))
                                                        {
                                                            if (prt.Identifier.ID == Brace.Identifier.ID || IsSameBracePoints(prt, Brace))
                                                            {
                                                                BraceBoltList.AddRange(ConvertArrayListToPointList(tBoltGroup.BoltPositions));
                                                                IsBraceFound = true;
                                                            }
                                                        }
                                                        if (!IsBraceFound && IsBrace(GetMP(prt)))
                                                        {
                                                            if (GetMP(prt).Identifier.ID == Brace.Identifier.ID || IsSameBracePoints(GetMP(prt), Brace))
                                                            {
                                                                BraceBoltList.AddRange(ConvertArrayListToPointList(tBoltGroup.BoltPositions));
                                                                IsBraceFound = true;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (!IsBraceFound)
                    {
                        List<TSM.Part> OtherPartList = GetBoltOtherPart(tBoltGroup);
                        foreach (TSM.Part prt in OtherPartList)
                        {
                            if (IsBrace(prt) && (prt.Identifier.ID == Brace.Identifier.ID || IsSameBracePoints(prt, Brace)))
                            {
                                BraceBoltList.AddRange(ConvertArrayListToPointList(tBoltGroup.BoltPositions));
                                break;
                            }
                        }
                    }
                }
            }
            catch (Exception ex) { }

            return BraceBoltList;
        }

        public PointList GetBraceBolt(TSM.Part myCPlate, Beam Brace)
        {
            PointList BraceBoltList = new PointList();
            try
            {
                TSM.ModelObjectEnumerator BoltEnumm = myCPlate.GetBolts();
                while (BoltEnumm.MoveNext())
                {
                    bool IsBraceFound = false;
                    TSM.BoltGroup tBoltGroup = BoltEnumm.Current as TSM.BoltGroup;
                    List<TSM.Part> ObjList = new List<TSM.Part>();

                    if (IsGpOtherPart(tBoltGroup, myCPlate))
                    {
                        ObjList.Add(tBoltGroup.PartToBeBolted);
                        ObjList.Add(tBoltGroup.PartToBoltTo);
                    }
                    else
                    {
                        if (tBoltGroup.PartToBeBolted.Identifier.ID == myCPlate.Identifier.ID)
                            ObjList.Add(tBoltGroup.PartToBoltTo);

                        else if (tBoltGroup.PartToBoltTo.Identifier.ID == myCPlate.Identifier.ID)
                            ObjList.Add(tBoltGroup.PartToBeBolted);
                    }



                    foreach (TSM.Part Mobj in ObjList)
                    {
                        TSM.Part RefBeam = Mobj as TSM.Part;
                        string ProType = "";
                        ProType = GetProType(RefBeam);

                        if (IsBrace(RefBeam) && (RefBeam.Identifier.ID == Brace.Identifier.ID || IsSameBracePoints(RefBeam, Brace)))        //Direct Brace
                        {
                            BraceBoltList.AddRange(ConvertArrayListToPointList(tBoltGroup.BoltPositions));
                            IsBraceFound = true;
                        }
                        else if (IsAngle(RefBeam))      //Brace connected via "ANGLE"
                        {
                            Tekla.Structures.Model.ModelObject mobj = RefBeam.GetAssembly().GetMainPart();
                            if (mobj is TSM.Part)
                            {
                                TSM.Part tempb = mobj as TSM.Part;
                                if (IsBrace(tempb) && (tempb.Identifier.ID == Brace.Identifier.ID || IsSameBracePoints(tempb, Brace)))
                                {
                                    BraceBoltList.AddRange(ConvertArrayListToPointList(tBoltGroup.BoltPositions));
                                    IsBraceFound = true;
                                }
                                else
                                {
                                    TSM.ModelObjectEnumerator BoltEnum = tempb.GetBolts();
                                    int size = BoltEnum.GetSize();
                                    if (size > 1)
                                    {
                                        while (BoltEnum.MoveNext())
                                        {
                                            if (BoltEnum.Current.Identifier.ID != tBoltGroup.Identifier.ID)
                                            {
                                                TSM.BoltGroup braceBolt = BoltEnum.Current as TSM.BoltGroup;

                                                TSM.Part ObjPart = braceBolt.PartToBeBolted as TSM.Part;
                                                if (!IsBraceFound && IsBrace(ObjPart))
                                                {
                                                    if (ObjPart.Identifier.ID == Brace.Identifier.ID || IsSameBracePoints(ObjPart, Brace))
                                                    {
                                                        BraceBoltList.AddRange(ConvertArrayListToPointList(tBoltGroup.BoltPositions));
                                                        IsBraceFound = true;
                                                    }
                                                }
                                                if (!IsBraceFound && IsBrace(GetMP(ObjPart)))
                                                {
                                                    if (GetMP(ObjPart).Identifier.ID == Brace.Identifier.ID || IsSameBracePoints(GetMP(ObjPart), Brace))
                                                    {
                                                        BraceBoltList.AddRange(ConvertArrayListToPointList(tBoltGroup.BoltPositions));
                                                        IsBraceFound = true;
                                                    }
                                                }

                                                ObjPart = braceBolt.PartToBoltTo as TSM.Part;
                                                if (!IsBraceFound && IsBrace(braceBolt.PartToBoltTo))
                                                {
                                                    if (ObjPart.Identifier.ID == Brace.Identifier.ID || IsSameBracePoints(ObjPart, Brace))
                                                    {
                                                        BraceBoltList.AddRange(ConvertArrayListToPointList(tBoltGroup.BoltPositions));
                                                        IsBraceFound = true;
                                                    }
                                                }
                                                if (!IsBraceFound && IsBrace(GetMP(ObjPart)))
                                                {
                                                    if (GetMP(ObjPart).Identifier.ID == Brace.Identifier.ID || IsSameBracePoints(GetMP(ObjPart), Brace))
                                                    {
                                                        BraceBoltList.AddRange(ConvertArrayListToPointList(tBoltGroup.BoltPositions));
                                                        IsBraceFound = true;
                                                    }
                                                }

                                                if (!IsBraceFound)
                                                {
                                                    List<TSM.Part> OtherPartList = GetBoltOtherPart(braceBolt);
                                                    foreach (TSM.Part prt in OtherPartList)
                                                    {
                                                        if (!IsBraceFound && IsBrace(prt))
                                                        {
                                                            if (prt.Identifier.ID == Brace.Identifier.ID || IsSameBracePoints(prt, Brace))
                                                            {
                                                                BraceBoltList.AddRange(ConvertArrayListToPointList(tBoltGroup.BoltPositions));
                                                                IsBraceFound = true;
                                                            }
                                                        }
                                                        if (!IsBraceFound && IsBrace(GetMP(prt)))
                                                        {
                                                            if (GetMP(prt).Identifier.ID == Brace.Identifier.ID || IsSameBracePoints(GetMP(prt), Brace))
                                                            {
                                                                BraceBoltList.AddRange(ConvertArrayListToPointList(tBoltGroup.BoltPositions));
                                                                IsBraceFound = true;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (!IsBraceFound)
                    {
                        List<TSM.Part> OtherPartList = GetBoltOtherPart(tBoltGroup);
                        foreach (TSM.Part prt in OtherPartList)
                        {
                            if (IsBrace(prt) && (prt.Identifier.ID == Brace.Identifier.ID || IsSameBracePoints(prt, Brace)))
                            {
                                BraceBoltList.AddRange(ConvertArrayListToPointList(tBoltGroup.BoltPositions));
                                break;
                            }
                        }
                    }
                }
            }
            catch (Exception ex) { }

            return BraceBoltList;
        }

        public CoordinateSystem GetBraceBoltCordSys(TSM.Part myCPlate, Beam Brace)
        {
            CoordinateSystem cos = new CoordinateSystem();
            try
            {
                TSM.ModelObjectEnumerator BoltEnumm = myCPlate.GetBolts();

                while (BoltEnumm.MoveNext())
                {
                    bool IsBraceFound = false;
                    TSM.BoltGroup tBoltGroup = BoltEnumm.Current as TSM.BoltGroup;
                    List<TSM.Part> ObjList = new List<TSM.Part>();

                    if (IsGpOtherPart(tBoltGroup, myCPlate))
                    {
                        ObjList.Add(tBoltGroup.PartToBeBolted);
                        ObjList.Add(tBoltGroup.PartToBoltTo);
                    }
                    else
                    {
                        if (tBoltGroup.PartToBeBolted.Identifier.ID == myCPlate.Identifier.ID)
                            ObjList.Add(tBoltGroup.PartToBoltTo);

                        else if (tBoltGroup.PartToBoltTo.Identifier.ID == myCPlate.Identifier.ID)
                            ObjList.Add(tBoltGroup.PartToBeBolted);
                    }

                    foreach (TSM.Part Mobj in ObjList)
                    {
                        string ProType = "";
                        TSM.Part RefBeam = Mobj as TSM.Part;
                        ProType = GetProType(RefBeam);
                        if (IsBrace(RefBeam) && RefBeam.Identifier.ID == Brace.Identifier.ID)       //Direct Brace
                        {
                            cos = tBoltGroup.GetCoordinateSystem();
                            IsBraceFound = true;
                        }
                        else if (ProType == "B")            //Brace connected via "PLATE"
                        {
                            Tekla.Structures.Model.ModelObject mobj = RefBeam.GetAssembly().GetMainPart();
                            if (mobj is TSM.Part)
                            {
                                TSM.Part tempb = mobj as TSM.Part;
                                bool bh = IsBrace(tempb);
                                if (IsBrace(tempb) && tempb.Identifier.ID == Brace.Identifier.ID)
                                {
                                    cos = tBoltGroup.GetCoordinateSystem();
                                    IsBraceFound = true;
                                }
                                else
                                {
                                    TSM.ModelObjectEnumerator BoltEnum = tempb.GetBolts();
                                    int size = BoltEnum.GetSize();
                                    if (size > 1)
                                    {
                                        while (BoltEnum.MoveNext())
                                        {
                                            if (BoltEnum.Current.Identifier.ID != tBoltGroup.Identifier.ID)
                                            {
                                                TSM.BoltGroup braceBolt = BoltEnum.Current as TSM.BoltGroup;

                                                TSM.Part ObjPart = braceBolt.PartToBeBolted as TSM.Part;
                                                if (!IsBraceFound && (IsBrace(ObjPart) || IsBrace(GetMP(ObjPart))) && (Brace.Identifier.ID == ObjPart.Identifier.ID || Brace.Identifier.ID == GetMP(ObjPart).Identifier.ID))
                                                {
                                                    cos = tBoltGroup.GetCoordinateSystem();
                                                    IsBraceFound = true;
                                                }

                                                ObjPart = braceBolt.PartToBoltTo as TSM.Part;
                                                if (!IsBraceFound && (IsBrace(ObjPart) || IsBrace(GetMP(ObjPart))) && (Brace.Identifier.ID == ObjPart.Identifier.ID || Brace.Identifier.ID == GetMP(ObjPart).Identifier.ID))
                                                {
                                                    cos = tBoltGroup.GetCoordinateSystem();
                                                    IsBraceFound = true;
                                                }

                                                if (!IsBraceFound)
                                                {
                                                    List<TSM.Part> OtherPartList = GetBoltOtherPart(braceBolt);
                                                    foreach (TSM.Part prt in OtherPartList)
                                                    {
                                                        if (!IsBraceFound && (IsBrace(prt) || IsBrace(GetMP(prt))) && (Brace.Identifier.ID == prt.Identifier.ID || Brace.Identifier.ID == GetMP(prt).Identifier.ID))
                                                        {
                                                            cos = tBoltGroup.GetCoordinateSystem();
                                                            IsBraceFound = true;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        else if (IsAngle(RefBeam))          //Brace connected via "ANGLE"
                        {
                            Tekla.Structures.Model.ModelObject mobj = RefBeam.GetAssembly().GetMainPart();
                            if (mobj is TSM.Part)
                            {
                                TSM.Part tempb = mobj as TSM.Part;
                                if (IsBrace(tempb) && tempb.Identifier.ID == Brace.Identifier.ID)
                                {
                                    cos = tBoltGroup.GetCoordinateSystem();
                                    IsBraceFound = true;
                                }
                                else
                                {
                                    TSM.ModelObjectEnumerator BoltEnum = tempb.GetBolts();
                                    int size = BoltEnum.GetSize();
                                    if (size > 1)
                                    {
                                        while (BoltEnum.MoveNext())
                                        {
                                            if (BoltEnum.Current.Identifier.ID != tBoltGroup.Identifier.ID)
                                            {
                                                TSM.BoltGroup braceBolt = BoltEnum.Current as TSM.BoltGroup;

                                                TSM.Part ObjPart = braceBolt.PartToBeBolted as TSM.Part;
                                                if (!IsBraceFound && (IsBrace(ObjPart) || IsBrace(GetMP(ObjPart))) && (Brace.Identifier.ID == ObjPart.Identifier.ID || Brace.Identifier.ID == GetMP(ObjPart).Identifier.ID))
                                                {
                                                    cos = tBoltGroup.GetCoordinateSystem();
                                                    IsBraceFound = true;
                                                }

                                                ObjPart = braceBolt.PartToBoltTo as TSM.Part;
                                                if (!IsBraceFound && (IsBrace(ObjPart) || IsBrace(GetMP(ObjPart))) && (Brace.Identifier.ID == ObjPart.Identifier.ID || Brace.Identifier.ID == GetMP(ObjPart).Identifier.ID))
                                                {
                                                    cos = tBoltGroup.GetCoordinateSystem();
                                                    IsBraceFound = true;
                                                }

                                                if (!IsBraceFound)
                                                {
                                                    List<TSM.Part> OtherPartList = GetBoltOtherPart(braceBolt);
                                                    foreach (TSM.Part prt in OtherPartList)
                                                    {
                                                        if (!IsBraceFound && (IsBrace(prt) || IsBrace(GetMP(prt))) && (Brace.Identifier.ID == prt.Identifier.ID || Brace.Identifier.ID == GetMP(prt).Identifier.ID))
                                                        {
                                                            cos = tBoltGroup.GetCoordinateSystem();
                                                            IsBraceFound = true;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if (!IsBraceFound)
                    {
                        List<TSM.Part> OtherPartList = GetBoltOtherPart(tBoltGroup);
                        foreach (TSM.Part prt in OtherPartList)
                        {
                            if (IsBrace(prt) && prt.Identifier.ID == Brace.Identifier.ID)
                            {
                                cos = tBoltGroup.GetCoordinateSystem();
                                IsBraceFound = true;
                            }
                        }
                    }
                }
            }
            catch (Exception ex) { }

            return cos;
        }

        public bool IsSameBracePoints(TSM.ModelObject brace1, Beam brace2)
        {
            bool check = false;
            if (brace1 is Beam)
            {
                Beam brace11 = brace1 as Beam;
                if (IsEqualPoints(brace11.StartPoint, brace2.StartPoint) && IsEqualPoints(brace11.EndPoint, brace2.EndPoint))
                    check = true;
                else if (IsEqualPoints(brace11.StartPoint, brace2.EndPoint) && IsEqualPoints(brace11.EndPoint, brace2.StartPoint))
                    check = true;
            }
            return check;
        }

        public bool IsBraceBolt(TSM.Part myCPlate, BoltGroup bolt)
        {
            bool check = false;
            try
            {
                TSM.ModelObjectEnumerator BoltEnumm = myCPlate.GetBolts();
                while (BoltEnumm.MoveNext())
                {
                    TSM.BoltGroup tBoltGroup = BoltEnumm.Current as TSM.BoltGroup;
                    if (bolt.Identifier.ID == tBoltGroup.Identifier.ID)
                    {
                        List<TSM.Part> ObjList = new List<TSM.Part>();

                        if (IsGpOtherPart(tBoltGroup, myCPlate))
                        {
                            ObjList.Add(tBoltGroup.PartToBeBolted);
                            ObjList.Add(tBoltGroup.PartToBoltTo);
                        }
                        else
                        {
                            if (tBoltGroup.PartToBeBolted.Identifier.ID == myCPlate.Identifier.ID)
                                ObjList.Add(tBoltGroup.PartToBoltTo);

                            else if (tBoltGroup.PartToBoltTo.Identifier.ID == myCPlate.Identifier.ID)
                                ObjList.Add(tBoltGroup.PartToBeBolted);
                        }

                        foreach (TSM.Part Mobj in ObjList)
                        {
                            TSM.Part RefBeam = Mobj as TSM.Part;
                            string ProType = "";
                            ProType = GetProType(RefBeam);

                            if (IsBrace(RefBeam))   //Direct Brace
                            {
                                check = true;
                            }
                            else if (ProType == "B")         //Brace connected via "PLATE"
                            {
                                Tekla.Structures.Model.ModelObject mobj = RefBeam.GetAssembly().GetMainPart();
                                if (mobj is TSM.Part)
                                {
                                    TSM.Part tempb = mobj as TSM.Part;
                                    if (IsBrace(tempb))
                                    {
                                        check = true;
                                    }
                                    else
                                    {
                                        TSM.ModelObjectEnumerator BoltEnum = tempb.GetBolts();
                                        int size = BoltEnum.GetSize();
                                        if (size > 1)
                                        {
                                            while (BoltEnum.MoveNext())
                                            {
                                                if (BoltEnum.Current.Identifier.ID != tBoltGroup.Identifier.ID)
                                                {
                                                    TSM.BoltGroup braceBolt = BoltEnum.Current as TSM.BoltGroup;
                                                    if (IsBrace(braceBolt.PartToBeBolted) || IsBrace(GetMP(braceBolt.PartToBeBolted)))
                                                        check = true;

                                                    else if (IsBrace(braceBolt.PartToBoltTo) || IsBrace(GetMP(braceBolt.PartToBoltTo)))
                                                        check = true;

                                                    if (!check)
                                                    {
                                                        List<TSM.Part> OtherPartList = GetBoltOtherPart(braceBolt);
                                                        foreach (TSM.Part prt in OtherPartList)
                                                        {
                                                            if (IsBrace(prt))
                                                                check = true;
                                                            if (IsBrace(GetMP(prt)))
                                                                check = true;
                                                        }
                                                    }
                                                }

                                            }
                                        }

                                    }

                                }

                            }
                            else if (IsAngle(RefBeam))      //Brace connected via "ANGLE"
                            {
                                Tekla.Structures.Model.ModelObject mobj = RefBeam.GetAssembly().GetMainPart();
                                if (mobj is TSM.Part)
                                {
                                    TSM.Part tempb = mobj as TSM.Part;
                                    if (IsBrace(tempb))
                                    {
                                        check = true;
                                    }
                                    else
                                    {
                                        TSM.ModelObjectEnumerator BoltEnum = tempb.GetBolts();
                                        int size = BoltEnum.GetSize();
                                        if (size > 1)
                                        {
                                            while (BoltEnum.MoveNext())
                                            {
                                                if (BoltEnum.Current.Identifier.ID != tBoltGroup.Identifier.ID)
                                                {
                                                    TSM.BoltGroup braceBolt = BoltEnum.Current as TSM.BoltGroup;
                                                    if (IsBrace(braceBolt.PartToBeBolted) || IsBrace(GetMP(braceBolt.PartToBeBolted)))
                                                        check = true;

                                                    else if (IsBrace(braceBolt.PartToBoltTo) || IsBrace(GetMP(braceBolt.PartToBoltTo)))
                                                        check = true;

                                                    if (!check)
                                                    {
                                                        List<TSM.Part> OtherPartList = GetBoltOtherPart(braceBolt);
                                                        foreach (TSM.Part prt in OtherPartList)
                                                        {
                                                            if (IsBrace(prt))
                                                                check = true;
                                                            if (IsBrace(GetMP(prt)))
                                                                check = true;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }

                                }

                            }
                        }

                        if (!check)
                        {
                            List<TSM.Part> OtherPartList = GetBoltOtherPart(tBoltGroup);
                            foreach (TSM.Part prt in OtherPartList)
                            {
                                if (IsBrace(prt))
                                {
                                    check = true;
                                }

                            }

                        }

                    }
                }
            }
            catch (Exception ex) { }

            return check;
        }

        public bool IsBraceBolt(TSM.Part myCPlate, BoltGroup bolt, Beam brace)
        {
            bool check = false;
            try
            {
                TSM.ModelObjectEnumerator BoltEnumm = myCPlate.GetBolts();
                while (BoltEnumm.MoveNext())
                {
                    TSM.BoltGroup tBoltGroup = BoltEnumm.Current as TSM.BoltGroup;
                    if (bolt.Identifier.ID == tBoltGroup.Identifier.ID)
                    {
                        List<TSM.Part> ObjList = new List<TSM.Part>();

                        if (IsGpOtherPart(tBoltGroup, myCPlate))
                        {
                            ObjList.Add(tBoltGroup.PartToBeBolted);
                            ObjList.Add(tBoltGroup.PartToBoltTo);
                        }
                        else
                        {
                            if (tBoltGroup.PartToBeBolted.Identifier.ID == myCPlate.Identifier.ID)
                                ObjList.Add(tBoltGroup.PartToBoltTo);

                            else if (tBoltGroup.PartToBoltTo.Identifier.ID == myCPlate.Identifier.ID)
                                ObjList.Add(tBoltGroup.PartToBeBolted);
                        }

                        foreach (TSM.Part Mobj in ObjList)
                        {
                            TSM.Part RefBeam = Mobj as TSM.Part;
                            string ProType = "";
                            ProType = GetProType(RefBeam);

                            if (IsBrace(RefBeam) && brace.Identifier.ID == RefBeam.Identifier.ID)       //Direct Brace
                            {
                                check = true;
                            }
                            else if (ProType == "B")     //Brace connected via "PLATE"
                            {
                                Tekla.Structures.Model.ModelObject mobj = RefBeam.GetAssembly().GetMainPart();
                                if (mobj is TSM.Part)
                                {
                                    TSM.Part tempb = mobj as TSM.Part;
                                    if (IsBrace(tempb) && brace.Identifier.ID == tempb.Identifier.ID)
                                    {
                                        check = true;
                                    }
                                    else
                                    {
                                        TSM.ModelObjectEnumerator BoltEnum = tempb.GetBolts();
                                        int size = BoltEnum.GetSize();
                                        if (size > 1)
                                        {
                                            while (BoltEnum.MoveNext())
                                            {
                                                if (BoltEnum.Current.Identifier.ID != tBoltGroup.Identifier.ID)
                                                {
                                                    TSM.BoltGroup braceBolt = BoltEnum.Current as TSM.BoltGroup;

                                                    TSM.Part ObjPart = braceBolt.PartToBeBolted as TSM.Part;
                                                    if ((IsBrace(ObjPart) || IsBrace(GetMP(ObjPart))) && (brace.Identifier.ID == ObjPart.Identifier.ID || brace.Identifier.ID == GetMP(ObjPart).Identifier.ID))
                                                    {
                                                        check = true;
                                                    }

                                                    ObjPart = braceBolt.PartToBoltTo as TSM.Part;
                                                    if ((IsBrace(ObjPart) || IsBrace(GetMP(ObjPart))) && (brace.Identifier.ID == ObjPart.Identifier.ID || brace.Identifier.ID == GetMP(ObjPart).Identifier.ID))
                                                    {
                                                        check = true;
                                                    }

                                                    if (!check)
                                                    {
                                                        List<TSM.Part> OtherPartList = GetBoltOtherPart(braceBolt);
                                                        foreach (TSM.Part prt in OtherPartList)
                                                        {
                                                            if (IsBrace(prt) && brace.Identifier.ID == prt.Identifier.ID)
                                                                check = true;
                                                            if (IsBrace(GetMP(prt)) && brace.Identifier.ID == GetMP(prt).Identifier.ID)
                                                                check = true;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            else if (IsAngle(RefBeam))      //Brace connected via "ANGLE"
                            {
                                Tekla.Structures.Model.ModelObject mobj = RefBeam.GetAssembly().GetMainPart();
                                if (mobj is TSM.Part)
                                {
                                    TSM.Part tempb = mobj as TSM.Part;
                                    if (IsBrace(tempb) && brace.Identifier.ID == tempb.Identifier.ID)
                                    {
                                        check = true;
                                    }
                                    else
                                    {
                                        TSM.ModelObjectEnumerator BoltEnum = tempb.GetBolts();
                                        int size = BoltEnum.GetSize();
                                        if (size > 1)
                                        {
                                            while (BoltEnum.MoveNext())
                                            {
                                                if (BoltEnum.Current.Identifier.ID != tBoltGroup.Identifier.ID)
                                                {
                                                    TSM.BoltGroup braceBolt = BoltEnum.Current as TSM.BoltGroup;

                                                    TSM.Part ObjPart = braceBolt.PartToBeBolted as TSM.Part;
                                                    if ((IsBrace(ObjPart) || IsBrace(GetMP(ObjPart))) && (brace.Identifier.ID == ObjPart.Identifier.ID || brace.Identifier.ID == GetMP(ObjPart).Identifier.ID))
                                                    {
                                                        check = true;
                                                    }

                                                    ObjPart = braceBolt.PartToBoltTo as TSM.Part;
                                                    if ((IsBrace(ObjPart) || IsBrace(GetMP(ObjPart))) && (brace.Identifier.ID == ObjPart.Identifier.ID || brace.Identifier.ID == GetMP(ObjPart).Identifier.ID))
                                                    {
                                                        check = true;
                                                    }

                                                    if (!check)
                                                    {
                                                        List<TSM.Part> OtherPartList = GetBoltOtherPart(braceBolt);
                                                        foreach (TSM.Part prt in OtherPartList)
                                                        {
                                                            if (IsBrace(prt) && brace.Identifier.ID == prt.Identifier.ID)
                                                                check = true;
                                                            if (IsBrace(GetMP(prt)) && brace.Identifier.ID == GetMP(prt).Identifier.ID)
                                                                check = true;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        if (!check)
                        {
                            List<TSM.Part> OtherPartList = GetBoltOtherPart(tBoltGroup);
                            foreach (TSM.Part prt in OtherPartList)
                            {
                                if (IsBrace(prt) && brace.Identifier.ID == prt.Identifier.ID)
                                {
                                    check = true;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex) { }

            return check;
        }

        public bool IsGpOtherPart(BoltGroup blt, TSM.Part GPlate)
        {
            bool check = false;
            ArrayList boltaarr = blt.OtherPartsToBolt;
            foreach (TSM.Part prt in boltaarr)
            {
                if (prt.Identifier.ID == GPlate.Identifier.ID)
                    check = true;
            }

            return check;
        }

        public bool IsInList(List<TSM.Beam> myBraceList, TSM.Beam brace)
        {
            bool check = false;
            if (myBraceList.Count > 0)
            {
                foreach (TSM.Beam bem in myBraceList)
                {
                    if (bem.Identifier.ID == brace.Identifier.ID)
                    {
                        check = true;
                        break;
                    }
                    else if (IsEqualPoints(bem.StartPoint, brace.StartPoint) && IsEqualPoints(bem.EndPoint, brace.EndPoint))
                    {
                        check = true;
                        break;
                    }

                    else if (IsEqualPoints(bem.StartPoint, brace.EndPoint) && IsEqualPoints(bem.EndPoint, brace.StartPoint))
                    {
                        check = true;
                        break;
                    }
                }

            }

            return check;

        }

        public TSM.Part GetMP(TSM.Part part)
        {
            return part.GetAssembly().GetMainPart() as TSM.Part;
        }
        #endregion

        #region EdgeList(Part) Methods

        public Solid GetPartSolid(TSM.ModelObject mobj)
        {
            Solid sld = null;
            if (mobj is TSM.Part)
             sld = (mobj as TSM.Part).GetSolid();
            
            if (mobj is TSM.BoltGroup)
                sld = (mobj as TSM.BoltGroup).GetSolid();

            return sld;
        }

        public TSD.PointList GetVertexList(TSM.Solid tSolid)
        {
            var faceEnum = tSolid.GetFaceEnumerator();
            var vertexList = new TSD.PointList();
            while (faceEnum.MoveNext())
            {
                var face = faceEnum.Current as Face;
                if (face == null) continue;

                var loops = face.GetLoopEnumerator();
                while (loops.MoveNext())
                {
                    var lp = loops.Current as Loop;
                    if (lp == null) continue;

                    var vertices = lp.GetVertexEnumerator();
                    while (vertices.MoveNext())
                        vertexList.Add(vertices.Current as Point);
                }
            }
            return vertexList;
        }

        public PointList GetVertPointList(TSM.ModelObject modelObject)
        {
            PointList VertPList = new PointList();
            FaceEnumerator MyFaceEnum = (modelObject as TSM.Part).GetSolid().GetFaceEnumerator();
            while (MyFaceEnum.MoveNext())
            {
                Face MyFace = MyFaceEnum.Current as Face;
                if (MyFace != null)
                {
                    LoopEnumerator MyLoopEnum = MyFace.GetLoopEnumerator();
                    while (MyLoopEnum.MoveNext())
                    {
                        Loop MyLoop = MyLoopEnum.Current as Loop;
                        if (MyLoop != null)
                        {
                            VertexEnumerator MyVertexEnum = MyLoop.GetVertexEnumerator() as VertexEnumerator;
                            while (MyVertexEnum.MoveNext())
                            {
                                Point MyVertex = MyVertexEnum.Current as Point;
                                if (MyVertex != null)
                                {
                                    if (!VertPList.Contains(new Point(MyVertex.X, MyVertex.Y)))
                                        VertPList.Add(new Point(MyVertex.X, MyVertex.Y));
                                }
                            }
                        }
                    }
                }
            }

            return VertPList;
        }

        public PointList GetBeamEdgesPList(TSM.ModelObject mainBeam)
        {
            PointList VertPList = GetVertPointList(mainBeam);
            PointList EdgePList = new PointList();
            if (IsHorzObj(mainBeam))
            {
                EdgePList.Add(MinXY(VertPList, MinY(VertPList).Y));
                EdgePList.Add(MinXY(VertPList, MaxY(VertPList).Y));
                EdgePList.Add(MaxXY(VertPList, MaxY(VertPList).Y));
                EdgePList.Add(MaxXY(VertPList, MinY(VertPList).Y));
            }
            else
            {
                PointList RefPList = ConvertArrayListToPointList((mainBeam as TSM.Part).GetReferenceLine(false));
                if (!(IssameX(RefPList) && !IssameY(RefPList))) // not vert obj - i.e Skewed obj
                {
                    // Skewed Obj(Done for Skewed Stub)
                    PointList tempPList = GetAllEdgesPList(mainBeam);
                    //EdgePList.Add(MinX(tempPList));
                    //EdgePList.Add(MaxY(tempPList));
                    //EdgePList.Add(MaxX(tempPList));
                    //EdgePList.Add(MinY(tempPList));
                    Point centP = CenterPoint((mainBeam as TSM.Part).GetSolid().MinimumPoint, (mainBeam as TSM.Part).GetSolid().MaximumPoint);
                    EdgePList.Add(NPQuad3(centP, tempPList));
                    EdgePList.Add(NPQuad4(centP, tempPList));

                    EdgePList.Add(NPQuad1(centP, tempPList));
                    EdgePList.Add(NPQuad2(centP, tempPList));
                }
                else
                {
                    // Vert Obj
                    EdgePList.Add(MinYX(VertPList, MinX(VertPList).X));
                    EdgePList.Add(MaxYX(VertPList, MinX(VertPList).X));
                    EdgePList.Add(MaxYX(VertPList, MaxX(VertPList).X));
                    EdgePList.Add(MinYX(VertPList, MaxX(VertPList).X));
                }
            }

            return EdgePList;
        }

        public PointList GetSlopBeamEdgesPList(TSM.Part mainBeam)
        {
            PointList EdgePList = new PointList();
            try
            {
                Point Minp = mainBeam.GetSolid().MinimumPoint;
                Point Maxp = mainBeam.GetSolid().MaximumPoint;
                Point CentP = CenterPoint(Minp, Maxp);
                PointList TempLst = ConvertArrayListToPointList(mainBeam.GetCenterLine(false));
                CentP = new Point(CentP.X, TempLst[0].Y);
                PointList VertPList = GetVertPointList(mainBeam);

                PointList TempList = new PointList();

                foreach (Point pt in VertPList)
                {
                    if (IsEqual(pt.X, Minp.X))
                        TempList.Add(pt);

                    if (IsEqual(pt.X, Maxp.X))
                        TempList.Add(pt);

                    if (IsEqual(pt.Y, Minp.Y))
                        TempList.Add(pt);

                    if (IsEqual(pt.Y, Maxp.Y))
                        TempList.Add(pt);
                }

                if (!IsHorzObj(mainBeam)) // For Vertical Object
                {
                    PointList TopList = new PointList();
                    PointList BottomList = new PointList();
                    foreach (Point pt in TempList)
                    {
                        if (IsEqualOrGreater(pt.Y, CentP.Y))
                            TopList.Add(pt);
                        else
                            BottomList.Add(pt);
                    }

                    if (BottomList.Count > 0)
                    {
                        EdgePList.Add(MinX(BottomList));
                        EdgePList.Add(MaxX(BottomList));
                    }
                    if (TopList.Count > 0)
                    {
                        EdgePList.Add(MinX(TopList));
                        EdgePList.Add(MaxX(TopList));
                    }

                }
                else
                {
                    PointList LeftList = new PointList();
                    PointList RightList = new PointList();

                    foreach (Point pt in TempList)
                    {
                        if (pt.X > CentP.X)
                            RightList.Add(pt);
                        else
                            LeftList.Add(pt);
                    }

                    if (RightList.Count > 1)
                    {
                        Point p1 = MinY(LeftList);
                        Point p11 = MinX(LeftList);
                        if (!IsEqualPoints(p1, p11))
                        {
                            if (p11.Y < TempLst[0].Y)
                                p1 = p11;
                        }
                        EdgePList.Add(p1);
                        EdgePList.Add(MaxY(LeftList));
                    }

                    if (RightList.Count > 1)
                    {
                        Point p4 = MinY(RightList);
                        Point p44 = MaxX(RightList);
                        if (!IsEqualPoints(p4, p44))
                        {
                            if (p44.Y < TempLst[0].Y)
                                p4 = p44;
                            EdgePList.Add(MaxY(RightList));
                            EdgePList.Add(p4);
                        }

                    }




                 }


                bool IsSamePoint = false;
                for (int i = 0; i < EdgePList.Count; i++)
                {
                    for (int j = 0; j < EdgePList.Count; j++)
                    {
                        if (i != j)
                        {
                            if (IsEqualPoints(EdgePList[i], EdgePList[j]))
                                IsSamePoint = true;

                        }
                    }
                }

                if (IsSamePoint || (EdgePList.Count != 4))
                    EdgePList = GetSlopBeamEdgesPListByCenter(mainBeam);
            }

            catch (Exception ex)
            { }
            return EdgePList;
        }

        public PointList GetSlopBeamEdgesPListByCenter1(TSM.Part mainBeam)
        {
            PointList EdgePList = new PointList();
            try
            {
                Point Minp = mainBeam.GetSolid().MinimumPoint;
                Point Maxp = mainBeam.GetSolid().MaximumPoint;
                Point CentP = CenterPoint(Minp, Maxp);
                PointList TempLst = ConvertArrayListToPointList(mainBeam.GetCenterLine(false));
                if (IsHorzObj(mainBeam))
                    CentP = new Point(CentP.X, TempLst[0].Y);
                else
                    CentP = new Point(TempLst[0].X, CentP.Y);


                PointList VertPList = GetVertPointList(mainBeam);

                PointList TempList = new PointList();

                PointList TopPList = new PointList();
                PointList BottPList = new PointList();
                foreach (Point pt in VertPList)
                {

                    if (IsGreater(pt.Y, CentP.Y))
                        TopPList.Add(pt);
                    else
                        BottPList.Add(pt);


                }

                if (!IsHorzObj(mainBeam)) // For Vertical Object
                {
                    //    PointList TopList = new PointList();
                    //    PointList BottomList = new PointList();
                    //    foreach (Point pt in TempList)
                    //    {
                    //        if (pt.Y > CentP.Y)
                    //            TopList.Add(pt);
                    //        else
                    //            BottomList.Add(pt);
                    //    }

                    //    EdgePList.Add(MinX(BottomList));
                    //    EdgePList.Add(MinX(TopList));
                    //    EdgePList.Add(MaxX(TopList));
                    //    EdgePList.Add(MaxX(BottomList));

                    EdgePList.Add(MinX(BottPList));
                    EdgePList.Add(MinX(TopPList));
                    EdgePList.Add(MaxX(TopPList));
                    EdgePList.Add(MaxX(BottPList));
                }
                else
                {
                    //PointList LeftList = new PointList();
                    //PointList RightList = new PointList();

                    //foreach (Point pt in TempList)
                    //{
                    //    if (pt.X > CentP.X)
                    //        RightList.Add(pt);
                    //    else
                    //        LeftList.Add(pt);
                    //}

                    EdgePList.Add(MinX(BottPList));
                    EdgePList.Add(MinX(TopPList));
                    EdgePList.Add(MaxX(TopPList));
                    EdgePList.Add(MaxX(BottPList));

                }
            }

            catch (Exception ex)
            { }
            return EdgePList;
        }

        public PointList GetSlopBeamEdgesPListByCenter(TSM.Part mainBeam)
        {
            PointList EdgePList = new PointList();
            try
            {
                Point Minp = mainBeam.GetSolid().MinimumPoint;
                Point Maxp = mainBeam.GetSolid().MaximumPoint;
                Point CentP = CenterPoint(Minp, Maxp);
                PointList TempLst = ConvertArrayListToPointList(mainBeam.GetCenterLine(false));
                if (IsHorzObj(mainBeam))
                    CentP = new Point(CentP.X, TempLst[0].Y);
                else
                    CentP = new Point(TempLst[0].X, CentP.Y);


                PointList VertPList = GetVertPointList(mainBeam);

                PointList TempList = new PointList();

                PointList TopPList = new PointList();
                PointList BottPList = new PointList();
                foreach (Point pt in VertPList)
                {

                    if (IsEqualOrGreater(pt.Y, CentP.Y))
                        TopPList.Add(pt);
                    else
                        BottPList.Add(pt);

                }
                if (BottPList.Count > 0 && TopPList.Count > 0)
                {
                    if (!IsHorzObj(mainBeam)) // For Vertical Object
                    {
                        //    PointList TopList = new PointList();
                        //    PointList BottomList = new PointList();
                        //    foreach (Point pt in TempList)
                        //    {
                        //        if (pt.Y > CentP.Y)
                        //            TopList.Add(pt);
                        //        else
                        //            BottomList.Add(pt);
                        //    }

                        //    EdgePList.Add(MinX(BottomList));
                        //    EdgePList.Add(MinX(TopList));
                        //    EdgePList.Add(MaxX(TopList));
                        //    EdgePList.Add(MaxX(BottomList));

                        EdgePList.Add(MinX(BottPList));
                        EdgePList.Add(MinX(TopPList));
                        EdgePList.Add(MaxX(TopPList));
                        EdgePList.Add(MaxX(BottPList));

                    }
                    else
                    {
                        //PointList LeftList = new PointList();
                        //PointList RightList = new PointList();

                        //foreach (Point pt in TempList)
                        //{
                        //    if (pt.X > CentP.X)
                        //        RightList.Add(pt);
                        //    else
                        //        LeftList.Add(pt);
                        //}
                        EdgePList.Add(MinX(BottPList));
                        EdgePList.Add(MinX(TopPList));
                        EdgePList.Add(MaxX(TopPList));
                        EdgePList.Add(MaxX(BottPList));

                    }
                }
                else
                    EdgePList = GetSlopBeamEdgesPList(mainBeam);
            }

            catch (Exception ex)
            { }
            return EdgePList;

        }

        public PointList GetAllEdgesPList(TSM.ModelObject mainBeam)
        {
            PointList VertPList = GetVertPointList(mainBeam);
            PointList AEdgePList = new PointList();

            AEdgePList.Add(MinXY(VertPList, MinY(VertPList).Y));
            AEdgePList.Add(MinXY(VertPList, MaxY(VertPList).Y));
            AEdgePList.Add(MaxXY(VertPList, MaxY(VertPList).Y));
            AEdgePList.Add(MaxXY(VertPList, MinY(VertPList).Y));

            AEdgePList.Add(MinYX(VertPList, MinX(VertPList).X));
            AEdgePList.Add(MaxYX(VertPList, MinX(VertPList).X));
            AEdgePList.Add(MaxYX(VertPList, MaxX(VertPList).X));
            AEdgePList.Add(MinYX(VertPList, MaxX(VertPList).X));

            return AEdgePList;
        }

        public PartPoints GetSlopBeamEdgesPListByCenterC(TSM.Part mainBeam)
        {
            PartPoints Points = new PartPoints(); 

            PointList EdgePList = new PointList();
            try
            {
                Point Minp = mainBeam.GetSolid().MinimumPoint;
                Point Maxp = mainBeam.GetSolid().MaximumPoint;
                Point CentP = CenterPoint(Minp, Maxp);
                PointList TempLst = ConvertArrayListToPointList(mainBeam.GetCenterLine(false));
                if (IsHorzObj(mainBeam))
                    CentP = new Point(CentP.X, TempLst[0].Y);
                else
                    CentP = new Point(TempLst[0].X, CentP.Y);


                PointList VertPList = GetVertPointList(mainBeam);

                PointList TempList = new PointList();

                PointList TopPList = new PointList();
                PointList BottPList = new PointList();
                foreach (Point pt in VertPList)
                {

                    if (IsEqualOrGreater(pt.Y, CentP.Y))
                        TopPList.Add(pt);
                    else
                        BottPList.Add(pt);

                }
                if (BottPList.Count > 0 && TopPList.Count > 0)
                {
                    if (!IsHorzObj(mainBeam)) // For Vertical Object
                    {
                        Points.P1 = MinX(TopPList);
                        Points.P2 = MinX(BottPList);
                        Points.P3 = MaxX(BottPList);
                        Points.P4 = MaxX(TopPList);
                        Points.CentP = CenterPoint(Points.P2, Points.P4);
                    }
                    else
                    {
                        Points.P1 = MinX(TopPList);
                        Points.P2 = MinX(BottPList);
                        Points.P3 = MaxX(BottPList);
                        Points.P4 = MaxX(TopPList);
                        Points.CentP = CenterPoint(Points.P2, Points.P4);
                    }
                }
                else
                {
                    EdgePList = GetSlopBeamEdgesPList(mainBeam);

                    Points.P1 = EdgePList[1];
                    Points.P2 = EdgePList[0];
                    Points.P3 = EdgePList[3];
                    Points.P4 = EdgePList[2];
                    Points.CentP = CenterPoint(Points.P2, Points.P4);
                }
            }

            catch (Exception ex)
            { }
            return Points;

        }

        #endregion

        #region  Min / Max Point in PointList Methods

        public Point MaxY(TSD.PointList ptList)
        {
            int j = 0;
            for (int i = 1; i < ptList.Count; i++)
            {
                if (ptList[j].Y < ptList[i].Y)
                    j = i;


            }
            return ptList[j];
        }

        public Point MinY(TSD.PointList ptList)
        {
            int j = 0;
            for (int i = 1; i < ptList.Count; i++)
            {
                if (ptList[j].Y > ptList[i].Y)
                    j = i;
            }
            return ptList[j];
        }

        public Point MinX(TSD.PointList ptList)
        {
            int j = 0;
            for (int i = 1; i < ptList.Count; i++)
            {
                if (ptList[j].X > ptList[i].X)
                    j = i;

            }
            return ptList[j];
        }

        public Point MaxX(TSD.PointList ptList)
        {
            int j = 0;
            for (int i = 1; i < ptList.Count; i++)
            {
                if (ptList[j].X < ptList[i].X)
                    j = i;

            }
            return ptList[j];
        }

        public Point MaxXY(TSD.PointList ptList, double Y)
        {
            int j = 0;
            double lstval = -999999;
            for (int i = 0; i < ptList.Count; i++)
            {
                if (IsEqual(ptList[i].Y, Y))
                {
                    if (lstval == -999999)
                    {
                        lstval = ptList[i].X;
                        j = i;
                    }
                    else if (lstval < ptList[i].X)
                    {
                        lstval = ptList[i].X;
                        j = i;
                    }
                }
            }

            return ptList[j];
        }

        public Point MinXY(TSD.PointList ptList, double Y)
        {
            int j = 0;
            double lstval = 999999999;
            for (int i = 0; i < ptList.Count; i++)
            {
                if (IsEqual(ptList[i].Y, Y))
                {
                    if (lstval == 999999999)
                    {
                        lstval = ptList[i].X;
                        j = i;
                    }
                    else if (lstval > ptList[i].X)
                    {
                        lstval = ptList[i].X;
                        j = i;
                    }
                }
            }

            return ptList[j];
        }

        public Point MaxYX(TSD.PointList ptList, double X)
        {
            int j = 0;
            double lstval = -9999999999;
            for (int i = 0; i < ptList.Count; i++)
            {
                if (IsEqual(ptList[i].X, X))
                {
                    if (lstval == -9999999999)
                    {
                        lstval = ptList[i].Y;
                        j = i;
                    }
                    else if (lstval < ptList[i].Y)
                    {
                        lstval = ptList[i].Y;
                        j = i;
                    }
                }
            }

            return ptList[j];
        }

        public Point MinYX(TSD.PointList ptList, double X)
        {
            int j = 0;
            double lstval = 999999999;
            for (int i = 0; i < ptList.Count; i++)
            {
                if (IsEqual(ptList[i].X, X))
                {
                    if (lstval == 999999999)
                    {
                        lstval = ptList[i].Y;
                        j = i;
                    }
                    else if (lstval > ptList[i].Y)
                    {
                        lstval = ptList[i].Y;
                        j = i;
                    }
                }
            }

            return ptList[j];
        }

        public Point SecMaxY(TSD.PointList ptList, double Y)
        {
            int j = 0;
            double lstval = -999999;
            for (int i = 0; i < ptList.Count; i++)
            {
                if (!IsEqual(ptList[i].Y, Y))
                {
                    if (lstval == -999999)
                    {
                        lstval = ptList[i].Y;
                        j = i;
                    }
                    else if (lstval < ptList[i].Y)
                    {
                        lstval = ptList[i].Y;
                        j = i;
                    }
                }
            }

            return ptList[j];
        }

        public Point SecMinY(TSD.PointList ptList, double Y)
        {
            int j = 0;
            double lstval = 999999;
            for (int i = 0; i < ptList.Count; i++)
            {
                if (!IsEqual(ptList[i].Y, Y))
                {
                    if (lstval == 999999)
                    {
                        lstval = ptList[i].Y;
                        j = i;
                    }
                    else if (lstval > ptList[i].Y)
                    {
                        lstval = ptList[i].Y;
                        j = i;
                    }
                }
            }

            return ptList[j];
        }

        public Point SecMaxX(TSD.PointList ptList, double X)
        {
            int j = 0;
            double lstval = -999999;
            for (int i = 0; i < ptList.Count; i++)
            {
                if (!IsEqual(ptList[i].X, X))
                {
                    if (lstval == -999999)
                    {
                        lstval = ptList[i].X;
                        j = i;
                    }
                    else if (lstval < ptList[i].X)
                    {
                        lstval = ptList[i].X;
                        j = i;
                    }
                }
            }

            return ptList[j];
        }

        public Point SecMinX(TSD.PointList ptList, double X)
        {
            int j = 0;
            double lstval = 999999;
            for (int i = 0; i < ptList.Count; i++)
            {
                if (!IsEqual(ptList[i].X, X))
                {
                    if (lstval == 999999)
                    {
                        lstval = ptList[i].X;
                        j = i;
                    }
                    else if (lstval > ptList[i].X)
                    {
                        lstval = ptList[i].X;
                        j = i;
                    }
                }
            }

            return ptList[j];
        }



        #endregion

        public List<TSD.PointList> CombBoltList(List<TSM.BoltGroup> NewBoltArrList1, double ConstDist)
        {
            List<TSD.PointList> pointlist = new List<TSD.PointList>();
            TSD.PointList Blist = new TSD.PointList();
            List<int> PointIndex = new List<int>();
            bool check = false;
            bool LastCheck = false;
            for (int i = 0; i < NewBoltArrList1.Count; i++)
            {
                TSD.PointList blist = ConvertArrayListToPointList(NewBoltArrList1[i].BoltPositions);

                double CBAMinY = Math.Round(NewBoltArrList1[i].GetSolid().MinimumPoint.Y);
                double CBAMaxY = Math.Round(NewBoltArrList1[i].GetSolid().MaximumPoint.Y);

                double CBAMinX = Math.Round(NewBoltArrList1[i].GetSolid().MinimumPoint.X);
                double CBAMaxX = Math.Round(NewBoltArrList1[i].GetSolid().MaximumPoint.X);
                if (!PointIndex.Contains(i))
                {
                    if (!LastCheck)
                    {
                        PointIndex.Add(i);
                        Blist.AddRange(blist);
                    }
                }

                check = false;

                for (int k = 1 + i; k < NewBoltArrList1.Count; k++)
                {
                    if (!PointIndex.Contains(k))
                    {
                        TSD.PointList blist1 = ConvertArrayListToPointList(NewBoltArrList1[k].BoltPositions);
                        double EBAMinY = Math.Round(NewBoltArrList1[k].GetSolid().MinimumPoint.Y);
                        double EBAMaxY = Math.Round(NewBoltArrList1[k].GetSolid().MaximumPoint.Y);

                        double EBAMinX = Math.Round(NewBoltArrList1[k].GetSolid().MinimumPoint.X);
                        double EBAMaxX = Math.Round(NewBoltArrList1[k].GetSolid().MaximumPoint.X);

                        if (CBAMinY == EBAMinY && CBAMaxY == EBAMaxY)
                        {
                            double Dist = 0;

                            Dist = RemoveMinusValue(EBAMinX - CBAMaxX);
                            if (Dist <= ConstDist)
                            {
                                check = true;
                                PointIndex.Add(k);
                                Blist.AddRange(blist1);
                            }
                        }

                        else if (CBAMinX == EBAMinX && CBAMaxX == EBAMaxX)
                        {
                            double Dist = 0;
                            Dist = RemoveMinusValue(EBAMinY - CBAMinY);
                            if (Dist <= ConstDist)
                            {
                                check = true;
                                PointIndex.Add(k);
                                Blist.AddRange(blist1);
                            }
                        }
                    }
                }

                if (!check && !LastCheck)
                {
                    TSD.PointList plist = new TSD.PointList();
                    plist.AddRange(Blist);
                    pointlist.Add(plist);
                    Blist.Clear();
                }
                if (LastCheck && !check)
                {
                    TSD.PointList plist = new TSD.PointList();
                    plist.AddRange(Blist);
                    pointlist.Add(plist);

                    if (!PointIndex.Contains(i))
                        pointlist.Add(blist);

                    Blist.Clear();
                    LastCheck = false;
                }

                else if (LastCheck && check)
                    Blist.AddRange(blist);

                else if (check && !LastCheck)
                    LastCheck = true;
            }

            return pointlist;
        }

        public List<TSM.BoltGroup> BoltSortList(List<TSM.BoltGroup> FilteredBoltArr)
        {
            List<TSM.BoltGroup> FilteredBoltArr1 = new List<TSM.BoltGroup>();
            TSM.BoltGroup ba = null;
            double BoltMinx1 = 0;
            int count = FilteredBoltArr.Count;
            for (int i = 0; i < count; i++)
            {
                for (int j = 0; j < FilteredBoltArr.Count; j++)
                {
                    TSM.BoltGroup bArray = FilteredBoltArr[j];
                    double BoltMinY = bArray.GetSolid().MaximumPoint.X;

                    if (j == 0)
                    {
                        BoltMinx1 = BoltMinY;
                        ba = bArray;
                    }
                    if (BoltMinY < BoltMinx1)
                    {
                        BoltMinx1 = BoltMinY;
                        ba = bArray;
                    }
                }
                FilteredBoltArr1.Add(ba);
                FilteredBoltArr.Remove(ba);
            }

            return FilteredBoltArr1;
        }

        public double getRoundedValofMultiple(double dval, double dMmultipleOf)
        {
            double dRoundedVal = 0;
            double dLowerRoundedVal = 0;

            dLowerRoundedVal = getLowerRoundedValofMultiple(dval, dMmultipleOf);

            if (dval < (dLowerRoundedVal + (dMmultipleOf / 2)))
                dRoundedVal = dLowerRoundedVal;
            else
                dRoundedVal = dLowerRoundedVal + dMmultipleOf;

            return dRoundedVal;
        }

        public double getLowerRoundedValofMultiple(double dval, double dMmultipleOf)
        {
            double dRoundedVal = 0;

            if ((dval % dMmultipleOf) == 0)
                dRoundedVal = dval;

            else
            {
                int ival1 = (int)(dval / dMmultipleOf);
                dRoundedVal = (ival1 * dMmultipleOf);
            }

            return dRoundedVal;
        }

        public double getHigherRoundedValofMultiple(double dval, double dMmultipleOf)
        {
            double dRoundedVal = 0;

            dRoundedVal = getLowerRoundedValofMultiple(dval, dMmultipleOf);
            dRoundedVal += dMmultipleOf;

            return dRoundedVal;
        }

        public bool IssameX(PointList bptl)
        {
            bool IsX1 = true;
            for (int i = 0; i < bptl.Count; i++)
            {
                if (i > 0)
                {
                    if (!IsEqual(bptl[i].X, bptl[i - 1].X))
                        IsX1 = false;
                }
            }

            return IsX1;
        }

        public bool IssameY(PointList bptl)
        {
            bool IsY1 = true;
            for (int i = 0; i < bptl.Count; i++)
            {
                if (i > 0)
                {
                    if (!IsEqual(bptl[i].Y, bptl[i - 1].Y))
                        IsY1 = false;
                }
            }

            return IsY1;
        }

        public bool IssameZ(PointList bptl)
        {
            bool IsZ1 = true;
            for (int i = 0; i < bptl.Count; i++)
            {
                if (i > 0)
                {
                    if (!IsEqual(bptl[i].Z, bptl[i - 1].Z))
                        IsZ1 = false;
                }
            }

            return IsZ1;
        }

        public bool IsSingleLineBolt(BoltGroup bolt)
        {
            bool check = false;
            try
            {
                double DistX = 0;
                double DistY = 0;

                if (bolt is BoltArray)
                {
                    DistX = (bolt as BoltArray).GetBoltDistX(0);
                    DistY = (bolt as BoltArray).GetBoltDistY(0);
                }
                else if (bolt is BoltXYList)
                {
                    DistX = (bolt as BoltXYList).GetBoltDistX(0);
                    DistY = (bolt as BoltXYList).GetBoltDistY(0);
                }
                else
                {
                    MessageBox.Show("Bolt type is Bolt Circle Please Check!!!");
                }


                if (DistX != 0 && DistY != 0)
                    check = false;
                else if (DistX == 0 && DistY == 0)
                    check = false;
                else
                    check = true;
            }
            catch (Exception ex)
            { }
            return check;
        }

        public bool IsDiagonalPoints(PointList bptl)
        {
            bool chck = false;

            if (!IssameX(bptl) && !IssameY(bptl))
            {
                Point P1 = new Point(MinXY(bptl, MinY(bptl).Y));
                Point P4 = new Point(MaxXY(bptl, MinY(bptl).Y));
                Point P2 = new Point(MinXY(bptl, MaxY(bptl).Y));
                Point P3 = new Point(MaxXY(bptl, MaxY(bptl).Y));

                if ((!IsEqual(P1.Y, P4.Y) && !IsEqual(P3.Y, P2.Y)) || (!IsEqual(P1.X, P2.X) && !IsEqual(P3.X, P4.X)))
                    chck = true;
            }

            return chck;
        }

        public bool IsDiagonalBolt(TSM.BoltGroup bolt)
        {
            bool chck = false;

            PointList bptl = Com.GetBoltPoints(bolt);

            if (bptl.Count > 1)
                chck = IsDiagonalPoints(bptl);

            return chck;
        }

        public bool IsDiagonalBeam(Beam bem)
        {
            bool chck = false;

            if (!IsEqual(bem.StartPoint.X, bem.EndPoint.X) && !IsEqual(bem.StartPoint.Y, bem.EndPoint.Y))
                chck = true;

            return chck;
        }

        public bool IsPointinList(PointList ptlist, Point ChkPoint)
        {
            bool check = false;
            foreach (Point p in ptlist)
            {
                if (IsEqualPoints(p, ChkPoint))
                    check = true;
            }

            return check;
        }

        public bool IsPointinList(List<Point> ptlist, Point ChkPoint)
        {
            bool check = false;
            if ((from p in ptlist where IsEqualPoints(p, ChkPoint) select p).Count() > 0)
                check = true;

            return check;
        }

        public bool IsBoltInList1(BoltGroup BoltGroup, List<int> IdList)
        {
            bool check = false;
            if (IdList.Count > 0)
            {
                foreach (int id in IdList)
                {
                    Tekla.Structures.Model.ModelObject mobj = MyModel.SelectModelObject(new Identifier(id));
                    ModelObjectEnumerator boltenum = (mobj as TSM.Part).GetBolts();
                    if (boltenum.GetSize() > 0)
                    {
                        foreach (BoltGroup bolt in boltenum)
                        {
                            if (bolt.Identifier.ID == BoltGroup.Identifier.ID)
                                check = true;
                        }
                    }
                }
            }

            return check;
        }

        public bool IsBoltInList(BoltGroup BoltGroup, List<int> IdList)
        {
            bool check = false;
            try
            {
                if (IdList.Count > 0)
                {
                    foreach (int id in IdList)
                    {
                        Tekla.Structures.Model.ModelObject mobj = MyModel.SelectModelObject(new Identifier(id));

                        ModelObjectEnumerator boltenum = (mobj as TSM.Part).GetBolts();
                        if (boltenum.GetSize() > 0)
                        {
                            foreach (BoltGroup bolt in boltenum)
                            {
                                if (bolt.Identifier.ID == BoltGroup.Identifier.ID)
                                    check = true;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            { }

            return check;
        }

        public TSM.Part GetBoltPart(BoltGroup BoltGroup, TSM.Part mainBeam)
        {
            TSM.Part ConnPart = null;
            try
            {
                List<int> SecPartIdlist = new List<int>();
                ArrayList SecEnum = mainBeam.GetAssembly().GetSecondaries();
                foreach (TSM.Part part in SecEnum)
                    SecPartIdlist.Add(part.Identifier.ID);

                List<TSM.Part> partList = GetBoltConnectdPart(BoltGroup);
                foreach (TSM.Part part in partList)
                {
                    if (SecPartIdlist.Contains(part.Identifier.ID))
                    {
                        ConnPart = part;
                        break;
                    }
                }

            }
            catch (Exception ex)
            { }

            return ConnPart;
        }

        public List<TSM.Part> GetBoltConnectdPart(BoltGroup BoltGroup)
        {
            List<TSM.Part> ConnPartList = new List<TSM.Part>();
            ConnPartList.Add(BoltGroup.PartToBeBolted);
            ConnPartList.Add(BoltGroup.PartToBoltTo);

            ArrayList OtherList = BoltGroup.OtherPartsToBolt;
            foreach (TSM.Part Opart in OtherList)
            {
                ConnPartList.Add(Opart);
            }

            return ConnPartList;
        }

        public PointList RemoveSamePointsInList(PointList Ptlist1)
        {
            PointList temp = new PointList();

            foreach (Point p in Ptlist1)
            {
                if (!IsPointinList(temp, p))
                {
                    temp.Add(p);
                }
            }

            return temp;
        }

        public TSM.ModelObject GetBoltPart(BoltGroup BoltGroup, List<int> IdList)
        {
            TSM.ModelObject mobj1 = null;
            if (IdList.Count > 0)
            {
                foreach (int id in IdList)
                {
                    TSM.ModelObject mobj = MyModel.SelectModelObject(new Identifier(id));
                    ModelObjectEnumerator boltenum = (mobj as TSM.Part).GetBolts();
                    if (boltenum.GetSize() > 0)
                    {
                        foreach (BoltGroup bolt in boltenum)
                        {
                            if (bolt.Identifier.ID == BoltGroup.Identifier.ID)
                                mobj1 = mobj;
                        }
                    }
                }
            }

            return mobj1;
        }

        #region Identifier Methods

        public int GetViewID(TSD.View view)
        {
            DrawingHandler drawingHandler = new DrawingHandler();
            Type drawingType = view.GetType();
            System.Reflection.PropertyInfo propertyInfo = drawingType.GetProperty("Identifier", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic);
            object value = propertyInfo.GetValue(view, null);
            string ID = value.ToString();
            int a = Convert.ToInt32(ID);
            return a;
        }

        public int GetViewID(TSD.ViewBase view)
        {
            DrawingHandler drawingHandler = new DrawingHandler();
            Type drawingType = view.GetType();
            System.Reflection.PropertyInfo propertyInfo = drawingType.GetProperty("Identifier", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic);
            object value = propertyInfo.GetValue(view, null);
            string ID = value.ToString();
            int a = Convert.ToInt32(ID);
            return a;
        }

        public int GetModelIdDr(Drawing CurrentDrawing)
        {
            Identifier identi = null;
            int ID = 0;
            Type drawingType = CurrentDrawing.GetType();
            System.Reflection.PropertyInfo propertyInfo = drawingType.GetProperty("ModelObjectIdentifier", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic);
            object ident = propertyInfo.GetValue(CurrentDrawing, null);
            if (ident != null)
                identi = ident as Identifier;


            if (identi.ID > 0)
            {
                if (CurrentDrawing is SinglePartDrawing)
                    ID = identi.ID;
                else
                {
                    Assembly assm = MyModel.SelectModelObject(identi) as Assembly;
                    ID = assm.GetMainPart().Identifier.ID;
                }
            }

            return ID;
        }
        #endregion

        //public bool IsRDExist(RadiusDimension RdDim, List<RadiusDimension> RDList)
        //{
        //    bool check = false;
        //    foreach (RadiusDimension RDExist in RDList)
        //    {
        //        //AABB aabb = new AABB(new Point(Math.Round(RdDim.ArcPoint1.X), Math.Round(RdDim.ArcPoint1.Y)), new Point(Math.Round(RdDim.ArcPoint3.X), Math.Round(RdDim.ArcPoint3.Y)));
        //        //if (aabb.IsInside(new Point(Math.Round(RDExist.ArcPoint1.X), Math.Round(RDExist.ArcPoint1.Y))) || aabb.IsInside(new Point(Math.Round(RDExist.ArcPoint2.X), Math.Round(RDExist.ArcPoint2.Y))) || aabb.IsInside(new Point(Math.Round(RDExist.ArcPoint3.X), Math.Round(RDExist.ArcPoint3.Y))))
        //        //{
        //        //    check = true;
        //        //    break;
        //        //}


        //        if (IsEqualPoints(RdDim.ArcPoint1, RDExist.ArcPoint1) || IsEqualPoints(RdDim.ArcPoint2, RDExist.ArcPoint2) || IsEqualPoints(RdDim.ArcPoint3, RDExist.ArcPoint3))
        //        {
        //            check = true;
        //            break;
        //        }
        //    }

        //    return check;
        //}

        public bool IsRDExist(RadiusDimension RdDim, List<RadiusDimension> RDList, Point refP)
        {
            bool check = false;
            foreach (RadiusDimension RDExist in RDList)
            {
                AABB aabb = new AABB(new Point(Math.Round(RDExist.ArcPoint1.X), Math.Round(RDExist.ArcPoint1.Y)), new Point(Math.Round(RDExist.ArcPoint3.X), Math.Round(RDExist.ArcPoint3.Y)));
                AABB aabb1 = new AABB(new Point(Math.Round(RdDim.ArcPoint1.X), Math.Round(RdDim.ArcPoint1.Y)), new Point(Math.Round(RdDim.ArcPoint3.X), Math.Round(RdDim.ArcPoint3.Y)));
                AABB AB = new AABB(new Point(Math.Round(RdDim.ArcPoint2.X), Math.Round(RdDim.ArcPoint2.Y)), new Point(Math.Round(refP.X), Math.Round(refP.Y)));
                //if (aabb.IsInside(new Point(Math.Round(RDExist.ArcPoint1.X), Math.Round(RDExist.ArcPoint1.Y))) || aabb.IsInside(new Point(Math.Round(RDExist.ArcPoint2.X), Math.Round(RDExist.ArcPoint2.Y))) || aabb.IsInside(new Point(Math.Round(RDExist.ArcPoint3.X), Math.Round(RDExist.ArcPoint3.Y))))
                //{
                //    check = true;
                //    break;
                //}
                Tekla.Structures.Geometry3d.Line MyLine = new Tekla.Structures.Geometry3d.Line(RdDim.ArcPoint2, refP);
                Tekla.Structures.Geometry3d.Line MyLine1 = new Tekla.Structures.Geometry3d.Line(RDExist.ArcPoint2, refP);
                Vector v1 = MyLine.Direction;
                Vector v2 = MyLine1.Direction;


                if (IsEqualPoints(RdDim.ArcPoint1, RDExist.ArcPoint1) || IsEqualPoints(RdDim.ArcPoint2, RDExist.ArcPoint2) || IsEqualPoints(RdDim.ArcPoint3, RDExist.ArcPoint3))
                {
                    check = true;
                    break;
                }
                else if (IsEqualPoints(v1, v2))
                {
                    check = true;
                    break;
                }
                else if (AB.IsInside(RdDim.ArcPoint2))
                {
                    check = true;
                    break;
                }
                else if (aabb.IsInside(refP))
                {
                    check = true;
                    break;
                }

            }

            return check;
        }

        #region Check Names

        public string GetName(TSM.ModelObject modelObject)
        {
            string name = "";

            modelObject.GetUserProperty("NOTES0", ref name);
            if (name == "" || (!PNameList.Contains(name) && name != ""))
            {
                modelObject.GetReportProperty("comment", ref name);
                if (name == "" || (!PNameList.Contains(name) && name != ""))
                {
                    modelObject.GetReportProperty("USERDEFINED.USER_FIELD_4", ref name);
                    if (name == "" || (!PNameList.Contains(name) && name != ""))
                    {
                        if (modelObject is TSM.Part)
                            name = (modelObject as TSM.Part).Name;
                    }
                }
            }

            return name.ToUpper();
        }

        public string ToTitleCase(string title)
        {
            string RetTitle = "";

            char[] Sep = new char[] { ' ' };
            foreach (string str in title.Split(Sep).ToList())
            {
                string st = str.ToCharArray()[0].ToString().ToUpper();
                if (string.IsNullOrEmpty(RetTitle))
                    RetTitle += (st + str.Substring(1, str.Length - 1).ToLower());
                else
                    RetTitle += (" " + st + str.Substring(1, str.Length - 1).ToLower());
            }
            //TextInfo textInfo = new CultureInfo("en-US", false).TextInfo;

            //string RetTitle = textInfo.ToTitleCase(title);

            return RetTitle;
        }

        #region BEAMS/ PANEL
        public bool IsBeam(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "BEAM")
                return true;
            else
                return false;
        }

        public bool IsBeam_Grid(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "BEAM_GRID")
                return true;
            else
                return false;
        }

        public bool IsBeam_Mom(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "BEAM_MOM")
                return true;
            else
                return false;
        }

        public bool IsBeam_Braced(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "BEAM_BRACED")
                return true;
            else
                return false;
        }

        public bool IsBeam_Drag_W(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "BEAM_DRAG_W")
                return true;
            else
                return false;
        }

        public bool IsBeam_Drag_B(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "BEAM_DRAG_B")
                return true;
            else
                return false;
        }

        public bool IsBeam_Rolled(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "BEAM_ROLLED")
                return true;
            else
                return false;
        }

        public bool IsSlopingBeam(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "SLOPING BEAM")
                return true;
            else
                return false;
        }

        public bool IsSkewedBeam(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "SKEWED BEAM")
                return true;
            else
                return false;
        }

        public bool IsPanel(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "PANELASS")
                return true;
            else
                return false;
        }
        #endregion

        #region COLUMNS/POSTS
        public bool IsColumn(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "COLUMN")
                return true;
            else
                return false;
        }

        public bool IsColumn_Mom(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "COLUMN_MOM")
                return true;
            else
                return false;
        }

        public bool IsColumn_Braced(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "COLUMN_BRACED")
                return true;
            else
                return false;
        }

        public bool IsPost(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "POST")
                return true;
            else
                return false;
        }
        #endregion

        #region BOXES
        public bool IsBox_Column(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "BOX_COLUMN")
                return true;
            else
                return false;
        }

        public bool IsBox_Girder(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "BOX_GIRDER")
                return true;
            else
                return false;
        }

        public bool IsBox_Beam(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "BOX_BEAM")
                return true;
            else
                return false;
        }

        public bool IsBox_Column_Shaft(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "BOX_COLUMN_SHAFT")
                return true;
            else
                return false;
        }

        public bool IsBox_Girder_Shaft(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "BOX_GIRDER_SHAFT")
                return true;
            else
                return false;
        }

        public bool IsBox_Beam_Shaft(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "BOX_BEAM_SHAFT")
                return true;
            else
                return false;
        }
        #endregion

        #region BUILT-UP SECTIONS
        public bool IsBuiltUp_Beam(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "BUILT-UP_BEAM")
                return true;
            else
                return false;
        }

        public bool IsBuiltUp_Column(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "BUILT-UP_COLUMN")
                return true;
            else
                return false;
        }

        public bool IsBuiltUp_Plate_Girder(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "BUILT-UP_PLATE_GIRDER")
                return true;
            else
                return false;
        }

        public bool IsBuiltUp_Girder_Shaft(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "BUILT-UP_GIRDER_SHAFT")
                return true;
            else
                return false;
        }

        public bool IsBuiltUp_Column_Shaft(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "BUILT-UP_COLUMN_SHAFT")
                return true;
            else
                return false;
        }

        public bool IsBuiltUp_Beam_Shaft(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "BUILT-UP_BEAM_SHAFT")
                return true;
            else
                return false;
        }
        #endregion

        #region BRACES
        public bool IsBrace(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (IsHorzBrace(modelObject) || IsVerticalBrace(modelObject) || name.Contains("BRACE"))
                return true;
            else
                return false;
        }

        public bool IsVerticalBrace(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "VERTICAL BRACE" || name == "VERT. BRACE" || name == "VB" || name == "VERTICAL_BRACE")
                return true;
            else
                return false;
        }

        public bool IsHorzBrace(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "HORIZONTAL BRACE" || name == "HORZ. BRACE" || name == "HB" || name == "HORIZONTAL_BRACE")
                return true;
            else
                return false;
        }

        public bool IsPLBrace(TSM.ModelObject modelObject)
        {
            if (IsBrace(modelObject) && GetProType(modelObject as TSM.Part) == "B")
                return true;
            else
                return false;

        }
        #endregion

        public bool IsGussetPlate(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name.Contains("GUSSET PLATE") || name.Contains("GUSSET_PLATE"))
                return true;
            else
                return false;
        }

        public bool IsXGussetPlate(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name.Contains("X-GUSSET PLATE"))
                return true;
            else
                return false;
        }

        #region GIRT/PURLIN
        public bool IsGirt(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "GIRT")
                return true;
            else
                return false;
        }

        public bool IsPurlin(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "PURLIN")
                return true;
            else
                return false;
        }
        #endregion

        #region HANDRAIL/STAIR HANDRAIL/WALL RAIL & SPARTS
        public bool IsHandrail(Tekla.Structures.Model.ModelObject modelObject)
        {
            bool check = false;

            if (modelObject is TSM.Part)
            {
                TSM.Part bem = modelObject as TSM.Part;
                Identifier mainID = bem.GetAssembly().GetMainPart().Identifier;
                MainHandrail = new Model().SelectModelObject(mainID) as TSM.Part;
                if (MainHandrail != null)
                {
                    string name = GetName(MainHandrail);
                    if (name == "HANDRAIL" || name == "HAND_RAIL")
                        check = true;
                    else
                        check = false;
                }
            }

            return check;
        }

        public bool IsHandrailName(Tekla.Structures.Model.ModelObject modelObject)
        {
            bool check = false;

            if (modelObject is TSM.Part)
            {
                TSM.Part bem = modelObject as TSM.Part;
                if (bem != null)
                {
                    string name = GetName(bem);
                    if (name == "HANDRAIL" || name == "HAND_RAIL")
                        check = true;
                    else
                        check = false;
                }
            }

            return check;
        }

        public bool IsStairHandrail(Tekla.Structures.Model.ModelObject modelObject)
        {
            string name = GetName(MainHandrail);
            if (name == "STAIR HANDRAIL" || name == "STAIR_HANDRAIL")
                return true;
            else
                return false;
        }

        public bool IsWallRail(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "WALL RAIL" || name == "WALL_RAIL")
                return true;
            else
                return false;
        }

        public bool IsToePlate(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "TOE PLATE" || name == "TOE_PLATE")
                return true;
            else
                return false;
        }
        #endregion

        #region STAIR/STRINGER & SPARTS
        public bool IsStairs(Tekla.Structures.Model.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "STAIR")
                return true;
            else
                return false;
        }

        public bool IsStringer(Tekla.Structures.Model.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "STRINGER")
                return true;
            else
                return false;
        }

        public bool IsTread(Tekla.Structures.Model.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "TREAD")
                return true;
            else
                return false;
        }
        #endregion

        #region TRUSS's & SPARTS
        public bool IsTruss(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "TRUSS")
                return true;
            else
                return false;
        }

        public bool IsTopChord(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "TOP CHORD")
                return true;
            else
                return false;
        }

        public bool IsBottomChord(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "BOTTOM CHORD")
                return true;
            else
                return false;
        }

        public bool IsVerticalChord(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "VERTICAL CHORD")
                return true;
            else
                return false;
        }

        public bool IsDiagonaBrace(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "DIAGONAL BRACE")
                return true;
            else
                return false;
        }
        #endregion

        public bool IsEmbedPlate(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "EMBED PLATE")
                return true;
            else
                return false;
        }

        public bool IsAnchorBolt(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "ANCHOR BOLT")
                return true;
            else
                return false;
        }

        public bool IsSagRod(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "SAG ROD")
                return true;
            else
                return false;
        }


        public bool IsEndPlate(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "END PLATE" || name == "END_PLATE")
                return true;
            else
                return false;
        }

        public bool IsWebPlate(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "WEB PLATE" || name == "WEB_PLATE")
                return true;
            else
                return false;
        }

        public bool IsFlangePlate(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "FLANGE PLATE" || name == "FLANGE_PLATE")
                return true;
            else
                return false;
        }

        public bool IsFlangePlateUP(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name.Contains("FLANGE PLATE UP"))
                return true;
            else
                return false;
        }

        public bool IsXFlangePlate(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name.Contains("X-FLANGE PLATE"))
                return true;
            else
                return false;
        }

        public bool IsFillerPlate(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "FILLER PLATE")
                return true;
            else
                return false;
        }

        public bool IsBasePlate(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "BASE PLATE" || name == "BASE_PLATE")
                return true;
            else
                return false;
        }

        public bool IsCapPlate(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "CAP PLATE" || name == "CAP_PLATE")
                return true;
            else
                return false;
        }

        public bool IsLevelingPlate(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name.Contains("LEVELING PLATE"))
                return true;
            else
                return false;
        }

        public bool IsPlateWasher(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "PLATE WASHER" || name == "PLATE_WASHER")
                return true;
            else
                return false;
        }

        public bool IsPlate(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name.ToUpper().Contains("PLATE"))
                return true;
            else
                return false;
        }

        public bool IsShearPlate(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "SHEAR PLATE" || name == "SHEAR_PLATE")
                return true;
            else
                return false;
        }

        public bool IsLiftingLug(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "LIFTING LUG")
                return true;
            else
                return false;
        }

        public bool IsShearKey(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "SHEAR KEY" || name == "SHEAR_KEY")
                return true;
            else
                return false;
        }

        public bool IsStiffener(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "STIFFENER")
                return true;
            else
                return false;
        }

        public bool IsReinforcementPlate(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "REINFORCEMENT PLATE" || name == "REINF. PLATE")
                return true;
            else
                return false;
        }

        public bool IsStub(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "STUB")
                return true;
            else
                return false;
        }

        public bool IsColStub(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "COLUMN_STUB")
                return true;
            else
                return false;
        }

        public bool IsAngle(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "ANGLE")
                return true;
            else
                return false;
        }

        public bool IsRail(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "RAIL")
                return true;
            else
                return false;
        }

        public bool IsBentPlate(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "BENT PLATE")
                return true;
            else
                return false;
        }

        public bool IsSlabBentPlate(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "SLAB BENT PLATE")
                return true;
            else
                return false;
        }

        public bool IsTonguePlate(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "TONGUE PLATE")
                return true;
            else
                return false;
        }

        public bool IsClosurePlate(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "CLOSURE PLATE" || name == "CLOSURE_PLATE")
                return true;
            else
                return false;
        }

        public bool IsGrating(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "GRATING")
                return true;
            else
                return false;
        }

        public bool IsCheckeredPlate(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "CHECKERED PLATE")
                return true;
            else
                return false;
        }

        public bool IsHook(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "HOOK")
                return true;
            else
                return false;
        }

        public bool IsBackUpBar(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "BACKUP-BAR" || name == "BACK-UP BAR")
                return true;
            else
                return false;
        }

        public bool IsFireProofing(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "FIRE PROOFING" || name == "FIREPROOFING")
                return true;
            else
                return false;
        }

        public bool IsSurfaceT(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name.ToUpper().Contains("SURFACE"))
                return true;
            else
                return false;
        }

        public bool IsOutrigger(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "OUTRIGGER")
                return true;
            else
                return false;
        }

        public bool IsSpacerPlate(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "SPACER PLATE")
                return true;
            else
                return false;
        }

        public bool IsShimPlate(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "SHIM PLATE")
                return true;
            else
                return false;
        }

        public bool IsWedgeLock(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "WEDGE LOCK")
                return true;
            else
                return false;
        }

        public bool IsLadderCage(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name.Contains("LADDER CAGE"))
                return true;
            else
                return false;
        }

        public bool IsLadderPlate(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name.Contains("LADDER PLATE"))
                return true;
            else
                return false;
        }

        public bool IsCompFLPlate(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "COMP FLANGE PLATE" || name == "COMP PLATE")
                return true;
            else
                return false;
        }

        public bool IsRod(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "ROD")
                return true;
            else
                return false;
        }

        public bool IsRingPlate(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "RING PLATE")
                return true;
            else
                return false;
        }

        public bool IsDoublerPlate(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name.ToUpper().Contains("DOUBLER PLATE"))
                return true;
            else
                return false;
        }

        public bool IsBar(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "BAR")
                return true;
            else
                return false;
        }

        #region Haunch Objects
        public bool IsHaunchPlate(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "HAUNCH PLATE" || name == "HAUNCH_PLATE")
                return true;
            else
                return false;
        }

        public bool IsHaunchFlangePlate(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "HAUNCH FLANGE PLATE" || name == "HAUNCH_FLANGE_PLATE")
                return true;
            else
                return false;
        }

        public bool IsHaunchWebPlate(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "HAUNCH WEB PLATE" || name == "HAUNCH_WEB_PLATE")
                return true;
            else
                return false;
        }

        public bool IsHaunchProfile(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "HAUNCH PROFILE" || name == "HAUNCH_PROFILE")
                return true;
            else
                return false;
        }
        #endregion

        #region PEB Objects
        public bool IsPEBGirt(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "PEBGIRT")
                return true;
            else
                return false;
        }

        public bool IsPEBPurlin(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "PEBPURLIN")
                return true;
            else
                return false;
        }

        public bool IsPEBbeam(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "PEBBEAM")
                return true;
            else
                return false;
        }

        public bool IsPEBcolumn(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name == "PEBCOLUMN")
                return true;
            else
                return false;
        }
        #endregion

        #region BOLTS/HOLES
        public bool IsShopBolt(TSM.ModelObject modelObject)
        {
            string name = "";
            BoltGroup BoltG = (modelObject as BoltGroup);
            modelObject.GetUserProperty("BOLT_COMMENT", ref name);

            if ((name.ToUpper().Contains("SHOP BOLT")) && BoltG.Bolt == true)
                return true;
            else
                return false;
        }

        public bool IsShipBolt(TSM.ModelObject modelObject)
        {
            string name = "";
            BoltGroup BoltG = (modelObject as BoltGroup);
            modelObject.GetUserProperty("BOLT_COMMENT", ref name);

            if ((name.ToUpper().Contains("SHIPPING_BOLT")) && BoltG.Bolt == true)
                return true;
            else
                return false;
        }

        public bool IsGalvHole(TSM.ModelObject modelObject)
        {
            string name = "";
            BoltGroup BoltG = (modelObject as BoltGroup);
            modelObject.GetUserProperty("BOLT_COMMENT", ref name);

            if ((name.ToUpper().Contains("GALV HOLE") || name.ToUpper().Contains("GALV")) && BoltG.Bolt == false)
                return true;
            else
                return false;
        }

        public bool IsSafetyHole(TSM.ModelObject modelObject)
        {
            string name = "";
            BoltGroup BoltG = (modelObject as BoltGroup);
            modelObject.GetUserProperty("BOLT_COMMENT", ref name);

            if ((name.ToUpper().Contains("SAFETY HOLE")) && BoltG.Bolt == false)
                return true;
            else
                return false;
        }
        #endregion

        public bool IsPrepCut(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name.ToUpper().Contains("PREP"))
                return true;
            else
                return false;
        }

        public bool IsMCut(TSM.ModelObject modelObject)
        {
            string name = GetName(modelObject);
            if (name.ToUpper().Contains("M CUT"))
                return true;
            else
                return false;
        }

        #endregion

        public bool IsHorzObj(TSM.ModelObject obj)
        {
            bool check = false;
           
            Solid sld = GetPartSolid(obj);
            double Height = sld.MaximumPoint.Y - sld.MinimumPoint.Y;
            double Width = sld.MaximumPoint.X - sld.MinimumPoint.X;
           

            if (!IsSkewedPart(obj))  //Diagonal Part Discarded
            {
                if (IsEqualOrGreater(Width, Height))
                    check = true;
            }

            return check;
        }

        public bool IsHorzObjN(TSM.ModelObject obj)
        {
            bool check = false;
            PointList RefList = new PointList();
            Solid sld = GetPartSolid(obj);
            double Height = sld.MaximumPoint.Y - sld.MinimumPoint.Y;
            double Width = sld.MaximumPoint.X - sld.MinimumPoint.X;
            if (obj is TSM.Part)
                RefList = ConvertArrayListToPointList((obj as TSM.Part).GetReferenceLine(false));

            if (!IsSkewedPart(obj))  //Diagonal Part Discarded
            {
                if (IsEqualOrGreater(Width, Height))
                    check = true;
            }

            return check;
        }

        public CoordinateSystem GetPartBoltCord(TSM.Part prt)
        {
            CoordinateSystem crd = new CoordinateSystem();
            ModelObjectEnumerator Benum = prt.GetBolts();
            while (Benum.MoveNext())
            {
                if (Benum.Current is BoltGroup)
                    crd = (Benum.Current).GetCoordinateSystem();
            }
            return crd;
        }

        public Point FarestPointInList(PointList plist, Point refp)
        {
            Point NPoint = null;
            double D1 = -999999900009999999;
            int disti = -1;
            for (int i = 0; i < plist.Count; i++)
            {
                double dist = Distance.PointToPoint(new Point(plist[i].X, plist[i].Y), new Point(refp.X, refp.Y));
                disti = (int)dist;
                if (disti != 0)
                {
                    if (D1 < dist)
                    {
                        D1 = dist;
                        NPoint = plist[i];
                    }
                }

            }
            return NPoint;
        }

        public double GetDimValue1(StraightDimension stdim)
        {
            double dimVal = 0;
            Type Dim = stdim.GetType();
            System.Reflection.PropertyInfo propertyInfo = Dim.GetProperty("UnFormattedMark", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic);
            object dis = propertyInfo.GetValue(stdim, null);

            dimVal = ConvertFeetInchtoMM(dis as string);

            return dimVal;
        }

        public double GetDimValue(StraightDimensionSet stdim)
        {
            double dimVal = 0;
            try
            {
                Type Dim = stdim.GetType();
                System.Reflection.PropertyInfo propertyInfo = Dim.GetProperty("UnFormattedMark", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic);
                object dis = propertyInfo.GetValue(stdim, null);

                dimVal = ConvertFeetInchtoMM(dis as string);
            }
            catch (Exception ex)
            { }

            return dimVal;
        }

        #region Point/Line Methods

        public TSD.Line GetExtendedLine(TSD.View CurrentView, TSD.Line line, double offset)
        {
            TSD.Line Newline = null;
            Point pt1 = line.StartPoint;
            Point pt2 = line.EndPoint;

            if (pt1.Y == pt2.Y) //horizontal line
            {
                Point ptt1 = new Point();
                Point ptt2 = new Point();

                if (pt1.X < pt2.X)
                {
                    ptt1 = new Point(pt1.X - offset, pt1.Y);
                    ptt2 = new Point(pt2.X + offset, pt2.Y);
                }
                else if (pt1.X > pt2.X)
                {
                    ptt1 = new Point(pt1.X + offset, pt1.Y);
                    ptt2 = new Point(pt2.X - offset, pt2.Y);
                }

                Newline = new TSD.Line(CurrentView, ptt1, ptt2);
                Newline.Attributes.Line.Color = DrawingColors.Red;
            }
            else if (pt1.X == pt2.X) //vertical line
            {
                Point ptt1 = new Point();
                Point ptt2 = new Point();

                if (pt1.Y > pt2.Y)
                {
                    ptt1 = new Point(pt1.X, pt1.Y + offset);
                    ptt2 = new Point(pt2.X, pt2.Y - offset);
                }
                else if (pt1.Y < pt2.Y)
                {
                    ptt1 = new Point(pt1.X, pt1.Y - offset);
                    ptt2 = new Point(pt2.X, pt2.Y + offset);
                }

                Newline = new TSD.Line(CurrentView, ptt1, ptt2);
                Newline.Attributes.Line.Color = DrawingColors.Red;
            }
            else
            {

                PointList ptList = new PointList();
                ptList.Add(pt1);
                ptList.Add(pt2);

                if (!IssameX(ptList) && !IssameY(ptList))
                {
                    //Point 1 Extention
                    Point tempA = new Point(pt1.X + offset, pt1.Y, pt1.Z);
                    AngleDimension angDimA = new AngleDimension(CurrentView, pt1, pt2, tempA, 10);
                    //angDimA.Insert();

                    double acuteLA = Math.Round(angDimA.GetAngle(), 2);

                    Point ThirdPointA = new Point();
                    if (pt1.Y < pt2.Y)
                        ThirdPointA = GetThirdPoint(pt1, tempA, (180 + acuteLA)); //slope1:p1.y<p2.y
                    else if (pt1.Y > pt2.Y)
                        ThirdPointA = GetThirdPoint(pt1, tempA, -(180 + acuteLA));//slope2:p1.y>p2.y


                    //Point 2 Extention
                    Point tempB = new Point(pt2.X + offset, pt2.Y, pt2.Z);
                    AngleDimension angDimB = new AngleDimension(CurrentView, pt2, pt1, tempB, 10);
                    //angDimB.Insert();

                    double acuteLB = Math.Round(angDimB.GetAngle(), 2);

                    Point ThirdPointB = new Point();
                    if (pt1.Y > pt2.Y)
                        ThirdPointB = GetThirdPoint(pt2, tempB, (180 + acuteLB)); //slope1:p1.y<p2.y
                    else if (pt1.Y < pt2.Y)
                        ThirdPointB = GetThirdPoint(pt2, tempB, -(180 + acuteLB)); //slope2:p1.y>p2.y

                    //Line Between Two New Points
                    Newline = new TSD.Line(CurrentView, ThirdPointA, ThirdPointB);
                    Newline.Attributes.Line.Color = DrawingColors.Red;
                }


            }
            return Newline;
        }

        public bool IsSamePoints(TSD.PointList CurrDimPoints, TSD.PointList ExistDimPoints)
        {
            bool check = false;
            if (CurrDimPoints.Count == ExistDimPoints.Count)
            {
                for (int i = 0; i < CurrDimPoints.Count; i++)
                {
                    check = false;
                    for (int j = 0; j < ExistDimPoints.Count; j++)
                    {

                        Point p1 = new Point(Math.Round(CurrDimPoints[i].X), Math.Round(CurrDimPoints[i].Y));
                        Point p2 = new Point(Math.Round(ExistDimPoints[j].X), Math.Round(ExistDimPoints[j].Y));
                        if (IsEqualPoints(p1, p2))
                        {
                            check = true;
                            break;
                        }
                    }
                    if (!check)
                        break;

                }
            }

            return check;
        }

        public bool IsSamePointList(TSD.PointList CurrDimPoints, TSD.PointList ExistDimPoints)
        {
            bool check = false;
            if (CurrDimPoints.Count <= ExistDimPoints.Count)
            {
                for (int i = 0; i < CurrDimPoints.Count; i++)
                {
                    check = false;
                    for (int j = 0; j < ExistDimPoints.Count; j++)
                    {

                        Point p1 = new Point(CurrDimPoints[i].X, CurrDimPoints[i].Y);
                        Point p2 = new Point(ExistDimPoints[j].X, ExistDimPoints[j].Y);
                        if (IsEqualPoints(p1, p2))
                        {
                            check = true;
                            break;
                        }
                    }
                    if (!check)
                        break;
                }
            }

            return check;
        }

        public bool IsEqualPoints(Point P1, Point P2)
        {

            if (IsEqual(P1.X, P2.X) && IsEqual(P1.Y, P2.Y))
                return true;
            else
                return false;

        }

        /*-----------------------------------------------------------------------------*/

        public bool IsParallelLines(Point Line1p1, Point Line1p2, Point Line2p1, Point Line2p2)
        {
            bool check = false;
            Tekla.Structures.Geometry3d.Line line1 = new Tekla.Structures.Geometry3d.Line(Line1p1, Line1p2);
            Tekla.Structures.Geometry3d.Line line2 = new Tekla.Structures.Geometry3d.Line(Line2p1, Line2p2);
            //dc.DrawLine(currentView, BraceRefp, BoltCentP);
            //dc.DrawLine(currentView, BeamS, BeamE);
            if (Parallel.LineToLine(line1, line2))
                check = true;

            return check;

        }

        public bool IsPointLieOnLine(Point line1, Point line2, Point refp)
        {
            Tekla.Structures.Geometry3d.LineSegment l = new Tekla.Structures.Geometry3d.LineSegment(line1, line2);
            Vector lineVect = l.GetDirectionVector();
            if ((Math.Round(line1.X) == Math.Round(refp.X)) && (Math.Round(line1.Y) == Math.Round(refp.Y)))
                return true;
            else
            {
                Tekla.Structures.Geometry3d.LineSegment refline = new Tekla.Structures.Geometry3d.LineSegment(line1, refp);
                Vector reflineVect = refline.GetDirectionVector();

                //dc.DrawLine(currentView, line1, line2);
                //dc.DrawLine(currentView, line1, refp);

                if ((Math.Round(lineVect.X, 2) == Math.Round(reflineVect.X, 2)) && (Math.Round(lineVect.Y, 2) == Math.Round(reflineVect.Y, 2)))
                    return true;
                else
                    return false;
            }


        }

        public bool IsPointLieOnLine(Tekla.Structures.Geometry3d.LineSegment l, Point refp)
        {
            Vector lineVect = l.GetDirectionVector();
            if ((Math.Round(l.Point1.X) == Math.Round(refp.X)) && (Math.Round(l.Point1.Y) == Math.Round(refp.Y)))
                return true;
            else
            {
                Tekla.Structures.Geometry3d.LineSegment refline = new Tekla.Structures.Geometry3d.LineSegment(l.Point1, refp);
                Vector reflineVect = refline.GetDirectionVector();

                //dc.DrawLine(currentView, line1, line2);
                //dc.DrawLine(currentView, line1, refp);

                if ((Math.Round(lineVect.X, 2) == Math.Round(reflineVect.X, 2)) && (Math.Round(lineVect.Y, 2) == Math.Round(reflineVect.Y, 2)))
                    return true;
                else
                    return false;
            }
        }

        public void DrawLine(TSD.View CurrentView, Point p1, Point p2)
        {
            try
            {
                TSD.Line line = new TSD.Line(CurrentView as ViewBase, new Point(p1.X, p1.Y), new Point(p2.X, p2.Y));
                line.Attributes.Line.Color = DrawingColors.Red;
                line.Attributes.Line.Type = LineTypes.DashDot;
                line.Attributes.Arrowhead.Height = 100.0;
                line.Attributes.Arrowhead.ArrowPosition = ArrowheadPositions.None;
                line.Insert();
            }
            catch (Exception ex) { }
        }

        public void DrawCircle(TSD.View CurrentView, Point refp, double radius1)
        {
            try
            {
                TSD.Circle circle1 = new TSD.Circle(CurrentView as ViewBase, new Point(refp.X, refp.Y), radius1);
                circle1.Attributes.Line.Color = DrawingColors.Red;
                circle1.Attributes.Line.Type = LineTypes.DashDot;
                circle1.Insert();
            }
            catch (Exception ex) { }
        }

        #endregion

        #region  Vector/Direction Methods

        public Vector ChangeVector(Vector vect)
        {
            Vector Vect2 = new Vector();
            if (Math.Round(vect.X) < 0)
                Vect2.X = RemoveMinusValueVect(vect.X);
            else
                Vect2.X = -vect.X;

            if (Math.Round(vect.Y) < 0)
                Vect2.Y = RemoveMinusValueVect(vect.Y);
            else
                Vect2.Y = -vect.Y;

            return Vect2;
        }

        public bool IsSameVector(Vector V1, Vector V2)
        {
            if ((Math.Round(V1.X) == Math.Round(V2.X)) || (Math.Round(V1.Y) == Math.Round(V2.Y)))
                return true;
            else
                return false;
        }

        /*-----------------------------------------------------------------------------*/

        public int UpDown_Dim(Point centerPoint, PointList pt)
        {
            int check = 1, u = 0, d = 0;
            double dist1 = 0, dist2 = 0;
            foreach (Point p in pt)
            {
                if (p.Y > centerPoint.Y)
                {
                    u++;
                    if (u == 1)
                        dist1 = Tekla.Structures.Geometry3d.Distance.PointToPoint(centerPoint, p);

                    if (dist1 > Tekla.Structures.Geometry3d.Distance.PointToPoint(centerPoint, p))
                        dist1 = Tekla.Structures.Geometry3d.Distance.PointToPoint(centerPoint, p);
                }

                if (p.Y < centerPoint.Y)
                {
                    d++;
                    if (d == 1)
                        dist2 = Tekla.Structures.Geometry3d.Distance.PointToPoint(centerPoint, p);

                    if (dist2 > Tekla.Structures.Geometry3d.Distance.PointToPoint(centerPoint, p))
                        dist2 = Tekla.Structures.Geometry3d.Distance.PointToPoint(centerPoint, p);
                }
            }
            if (u > d)
                return check = 1;
            else if (d > u)
                return check = 2;
            else if (u == d)
            {
                if (dist1 > dist2)
                    check = 1;
                else if (dist2 > dist1)
                    check = 2;
            }
            return check;
        }

        public int LeftRight_Dim(Point centerPoint, PointList pt)
        {
            int check = 1, l = 0, r = 0;
            double dist1 = 0, dist2 = 0;
            foreach (Point p in pt)
            {
                if (p.X < centerPoint.X)
                {
                    l++;
                    if (l == 1)
                        dist1 = Tekla.Structures.Geometry3d.Distance.PointToPoint(centerPoint, p);

                    if (dist1 > Tekla.Structures.Geometry3d.Distance.PointToPoint(centerPoint, p))
                        dist1 = Tekla.Structures.Geometry3d.Distance.PointToPoint(centerPoint, p);
                }
                if (p.X > centerPoint.X)
                {
                    r++;
                    if (r == 1)
                        dist2 = Tekla.Structures.Geometry3d.Distance.PointToPoint(centerPoint, p);

                    if (dist2 > Tekla.Structures.Geometry3d.Distance.PointToPoint(centerPoint, p))
                        dist2 = Tekla.Structures.Geometry3d.Distance.PointToPoint(centerPoint, p);
                }
            }
            if (l > r)
                return check = 1;
            else if (r > l)
                return check = 2;
            else if (l == r)
            {
                if (dist1 > dist2)
                    check = 1;
                else if (dist2 > dist1)
                    check = 2;
            }
            return check;


        }

        public int UpDown_Dim(Point centerPoint, Point p)
        {
            int res = 0;

            if (p.Y > centerPoint.Y)
            {
                res = 1;  // UP 
            }
            if (p.Y < centerPoint.Y)
            {
                res = 2;  // DOWN 
            }
            if (Math.Round(p.Y, 2) == Math.Round(centerPoint.Y, 2))
                res = 0;

            return res;
        }

        public int LeftRight_Dim(Point centerPoint, Point p)
        {
            int res = 0;

            if (p.X < centerPoint.X)
            {
                res = 1;  // LEFT 
            }
            if (p.X > centerPoint.X)
            {
                res = 2;  // RIGHT 
            }
            if (Math.Round(p.X, 2) == Math.Round(centerPoint.X, 2))
                res = 0;

            return res;
        }

        #endregion

        #region IsEqual Methods

        public bool IsEqual(double d1, double d2)
        {
            bool check = false;
            int dd1 = Convert.ToInt32(d1);
            int dd2 = Convert.ToInt32(d2);
            if (dd1 == dd2)
                check = true;
            else
            {
                //int k = Convert.ToInt32(RemoveMinusValue(d1 - d2));
                //if (k <= 1)
                double k = Convert.ToDouble(RemoveMinusValue(d1 - d2)); //updated by Uttari on 09-13-2016 for Stiffener Pick Point error..Need to verify with all posibilities.
                if (Math.Round(k, 1) <= 0.5)
                    check = true;
            }

            return check;
        }

        public bool IsGreater(double d1, double d2)
        {
            if (Math.Round(d1, 4) > Math.Round(d2, 4))
                return true;
            else
                return false;
        }

        public bool IsLess(double d1, double d2)
        {
            if (Math.Round(d1, 4) < Math.Round(d2, 4))
                return true;
            else
                return false;
        }

        public bool IsEqualOrGreater(double d1, double d2)
        {
            if (IsEqual(d1, d2) || IsGreater(d1, d2))
                return true;
            else
                return false;
        }

        public bool IsEqualOrLess(double d1, double d2)
        {
            if (IsEqual(d1, d2) || IsLess(d1, d2))
                return true;
            else
                return false;
        }

        #endregion

        public TSD.StraightDimensionSet.StraightDimensionSetAttributes GetStDimAttr(TSD.StraightDimensionSet stdim)
        {
            StraightDimensionSet.StraightDimensionSetAttributes dimattr = null;
            try
            {
                Type Dim = stdim.GetType();
                System.Reflection.PropertyInfo propertyInfo = Dim.GetProperty("DimensionSetAttributes", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic);
                object dis = propertyInfo.GetValue(stdim, null);
                if (dis != null && dis is DimensionSetBaseAttributes)
                    dimattr = dis as StraightDimensionSet.StraightDimensionSetAttributes;
            }
            catch (Exception ex)
            { }

            return dimattr;
        }

        public TSD.StraightDimension.StraightDimensionAttributes GetStDimAttr1(TSD.StraightDimension stdim)
        {
            StraightDimension.StraightDimensionAttributes dimattr = null;
            try
            {
                Type Dim = stdim.GetType();
                System.Reflection.PropertyInfo propertyInfo = Dim.GetProperty("DimensionSetAttributes", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic);
                object dis = propertyInfo.GetValue(stdim, null);
                if (dis != null && dis is AttributesBase)
                    dimattr = dis as StraightDimension.StraightDimensionAttributes;
            }
            catch (Exception ex)
            { }

            return dimattr;
        }


        public bool IsSameBoltX(BoltGroup bolt1, BoltGroup bolt2)
        {
            bool check = true;
            PointList PtList1 = ConvertArrayListToPointList(bolt1.BoltPositions);
            PointList PtList2 = ConvertArrayListToPointList(bolt2.BoltPositions);

            if (bolt2.BoltPositions.Count > bolt1.BoltPositions.Count)
            {
                PtList1 = ConvertArrayListToPointList(bolt2.BoltPositions);
                PtList2 = ConvertArrayListToPointList(bolt1.BoltPositions);
            }

            for (int i = 0; i < PtList2.Count; i++)
            {
                bool chk = false;
                foreach (Point pt in PtList1)
                {
                    if (IsEqual(pt.Y, PtList2[i].Y))
                    {
                        chk = true;
                        break;
                    }
                }
                if (!chk)
                {
                    check = false;
                    break;
                }
            }

            return check;
        }

        #region CheckSideView Methods

        public bool IsPlateSideView(TSM.Part bem)
        {

            if (bem.Identifier.ID == 902179)
            { }

            double Thickness = 0;
            double width = 0, width1 = 0, width2 = 0;
            double height = 0, height1 = 0, height2 = 0;
            string StubProfileTyp = "";
            bool check = false;
            PointList ptlist = new PointList();

            bem.GetReportProperty("PROFILE.WIDTH", ref width);
            bem.GetReportProperty("PROFILE.HEIGHT", ref height);
            bem.GetReportProperty("PROFILE_TYPE", ref StubProfileTyp);

            if (StubProfileTyp == "I" || StubProfileTyp == "U" || StubProfileTyp == "T")
                bem.GetReportProperty("PROFILE.FLANGE_THICKNESS", ref Thickness);
            else if (StubProfileTyp == "RO" || StubProfileTyp == "M")
                bem.GetReportProperty("PROFILE.PLATE_THICKNESS", ref Thickness);
            else if (StubProfileTyp == "L")
                bem.GetReportProperty("PROFILE.FLANGE_THICKNESS_1", ref Thickness);
            else if (StubProfileTyp == "B")
                bem.GetReportProperty("PROFILE.WIDTH", ref Thickness);

            if (Thickness == 0)
            {
                if (width == 0)
                    width = bem.GetSolid().MaximumPoint.X - bem.GetSolid().MinimumPoint.X;
                if (height == 0)
                    height = bem.GetSolid().MaximumPoint.Y - bem.GetSolid().MinimumPoint.Y;

                if (IsEqualOrLess(width, height))
                    Thickness = width;
                else
                    Thickness = height;
            }

            //if (width > height && height > 0)
            //    width = height;

            if (bem is PolyBeam)
            {
                PolyBeam bemP = bem as PolyBeam;
                bem.GetReportProperty("PROFILE.DIAMETER", ref width);
                if (width == 0)
                    width = 13;

                if (IsSkewedPart(bem))
                    ptlist = GetSlopBeamEdgesPList(bem);
                else
                    ptlist = GetBeamEdgesPList(bem);

                //width1 = ptlist[3].X - ptlist[0].X;
                //height1 = ptlist[1].Y - ptlist[0].Y;

                //width1 = MaxX(ptlist).X - MinX(ptlist).X;
                //height1 = MaxY(ptlist).Y - MinY(ptlist).Y;

                width1 = ptlist[2].X - ptlist[1].X;
                width2 = ptlist[3].X - ptlist[0].X;

                height1 = ptlist[1].Y - ptlist[0].Y;
                height2 = ptlist[2].Y - ptlist[3].Y;

                double ApprHW = width1 / 10;
                double SmallestVal = height1;
                if (height1 > width1)
                {
                    ApprHW = height1 / 10;
                    SmallestVal = width1;
                    if (ApprHW > 200 && SmallestVal > 150)
                        ApprHW = 0;
                }

                if ((IsEqual(width1, Thickness) || IsEqual(height1, Thickness) || IsEqual(width2, Thickness) || IsEqual(height2, Thickness)) || SmallestVal <= ApprHW)
                    check = true;
            }
            else
            {
                //width1 = bem.GetSolid().MaximumPoint.X - bem.GetSolid().MinimumPoint.X;
                //height1 = bem.GetSolid().MaximumPoint.Y - bem.GetSolid().MinimumPoint.Y;


                if (IsSkewedPart(bem))
                    ptlist = GetSlopBeamEdgesPList(bem);
                else
                    ptlist = GetBeamEdgesPList(bem);

                //width1 = ptlist[3].X - ptlist[0].X;
                //height1 = ptlist[1].Y - ptlist[0].Y;

                //width1 = MaxX(ptlist).X - MinX(ptlist).X;
                //height1 = MaxY(ptlist).Y - MinY(ptlist).Y;

                width1 = ptlist[2].X - ptlist[1].X;
                width2 = ptlist[3].X - ptlist[0].X;

                height1 = ptlist[1].Y - ptlist[0].Y;
                height2 = ptlist[2].Y - ptlist[3].Y;


                //if (IsEqual(width1, width) || IsEqual(height1, width))
                //    check = true;
                if (IsEqual(width1, Thickness) || IsEqual(height1, Thickness) || IsEqual(width2, Thickness) || IsEqual(height2, Thickness))
                    check = true;

            }

            return check;
        }

        public bool IsPlateSideView1(TSM.Part bem)
        {
            double width = 0, width1 = 0, width2 = 0;
            double height = 0, height1 = 0, height2 = 0;
            double Thickness = 0;
            string StubProfileTyp = "";
            bem.GetReportProperty("PROFILE.WIDTH", ref width);
            bem.GetReportProperty("PROFILE.HEIGHT", ref height);
            bem.GetReportProperty("PROFILE_TYPE", ref StubProfileTyp);

            if (StubProfileTyp == "I" || StubProfileTyp == "U" || StubProfileTyp == "T")
                bem.GetReportProperty("PROFILE.FLANGE_THICKNESS", ref Thickness);
            else if (StubProfileTyp == "RO" || StubProfileTyp == "M")
                bem.GetReportProperty("PROFILE.PLATE_THICKNESS", ref Thickness);
            else if (StubProfileTyp == "L")
                bem.GetReportProperty("PROFILE.FLANGE_THICKNESS_1", ref Thickness);
            else if (StubProfileTyp == "B")
                bem.GetReportProperty("PROFILE.WIDTH", ref Thickness);

            if (bem is PolyBeam)
            {
                PolyBeam bemP = bem as PolyBeam;
                bem.GetReportProperty("PROFILE.DIAMETER", ref width);
                if (width == 0)
                    width = 13;
            }

            if (Thickness == 0)
            {
                if (width == 0)
                    width = bem.GetSolid().MaximumPoint.X - bem.GetSolid().MinimumPoint.X;
                if (height == 0)
                    height = bem.GetSolid().MaximumPoint.Y - bem.GetSolid().MinimumPoint.Y;

                if (IsEqualOrLess(width, height))
                    Thickness = width;
                else
                    Thickness = height;
            }

            //if (width > height && height > 0)
            //    width = height;

            PointList ptlist = new PointList();

            if (IsSkewedPart(bem))
                ptlist = GetSlopBeamEdgesPList(bem);
            else
                ptlist = GetBeamEdgesPList(bem);

            //double width1 = ptlist[3].X - ptlist[0].X;
            //double height1 = ptlist[1].Y - ptlist[0].Y;

            //width1 = MaxX(ptlist).X - MinX(ptlist).X;
            //height1 = MaxY(ptlist).Y - MinY(ptlist).Y;

            width1 = ptlist[2].X - ptlist[1].X;
            width2 = ptlist[3].X - ptlist[0].X;

            height1 = ptlist[1].Y - ptlist[0].Y;
            height2 = ptlist[2].Y - ptlist[3].Y;

            double ApprHW = width1 / 10;
            double SmallestVal = height1;
            if (height1 > width1)
            {
                ApprHW = height1 / 10;
                SmallestVal = width1;
                if (ApprHW > 200 && SmallestVal > 150)
                    ApprHW = 0;
            }

            //if (IsGussetPlate(bem))
            //{
            //    if ((IsEqual(width1, width) || IsEqual(height1, width)))
            //        return true;
            //    else
            //        return false;
            //}

            //if ((IsEqual(width1, width) || IsEqual(height1, width)) || SmallestVal <= ApprHW)
            if ((IsEqual(width1, Thickness) || IsEqual(height1, Thickness) || IsEqual(width2, Thickness) || IsEqual(height2, Thickness)) || SmallestVal <= ApprHW)
                return true;
            else
                return false;
        }

        public bool IsStubSideView(TSM.Part bem)
        {
            bool check = false;
            double width = 0, width1 = 0, width2 = 0;
            double height = 0, height1 = 0, height2 = 0;
            double Thickness = 0;
            string StubProfileTyp = "";
            bem.GetReportProperty("PROFILE.WIDTH", ref width);
            bem.GetReportProperty("PROFILE.HEIGHT", ref height);
            bem.GetReportProperty("PROFILE_TYPE", ref StubProfileTyp);

            if (StubProfileTyp == "I" || StubProfileTyp == "U" || StubProfileTyp == "T")
                bem.GetReportProperty("PROFILE.FLANGE_THICKNESS", ref Thickness);
            else if (StubProfileTyp == "RO" || StubProfileTyp == "M")
                bem.GetReportProperty("PROFILE.PLATE_THICKNESS", ref Thickness);
            else if (StubProfileTyp == "L")
                bem.GetReportProperty("PROFILE.FLANGE_THICKNESS_1", ref Thickness);
            else if (StubProfileTyp == "B")
                bem.GetReportProperty("PROFILE.WIDTH", ref Thickness);

            if (bem is PolyBeam)
            {
                PolyBeam bemP = bem as PolyBeam;
                bem.GetReportProperty("PROFILE.DIAMETER", ref width);
                if (width == 0)
                    width = 13;
            }

            PointList ptlist = GetBeamEdgesPList(bem);

            //double width1 = ptlist[3].X - ptlist[0].X;
            //double height1 = ptlist[1].Y - ptlist[0].Y;

            //width1 = MaxX(ptlist).X - MinX(ptlist).X;
            //height1 = MaxY(ptlist).Y - MinY(ptlist).Y;

            width1 = ptlist[2].X - ptlist[1].X;
            width2 = ptlist[3].X - ptlist[0].X;

            height1 = ptlist[1].Y - ptlist[0].Y;
            height2 = ptlist[2].Y - ptlist[3].Y;

            if (!IsHorzObj(bem))
            {
                PointList RefPList = ConvertArrayListToPointList((bem as TSM.Part).GetReferenceLine(false));

                if (!(!IssameX(RefPList) && !IssameY(RefPList))) // not vert obj - i.e Skewed obj
                {
                    width1 = dist.PointToPoint(ptlist[2], ptlist[1]);
                    width2 = dist.PointToPoint(ptlist[3], ptlist[0]);

                    height1 = dist.PointToPoint(ptlist[1], ptlist[0]);
                    height2 = dist.PointToPoint(ptlist[2], ptlist[3]);

                    if (IsEqual(width1, width) || IsEqual(width2, width) || IsEqual(width1, height) || IsEqual(width2, height)/* || IsEqual(width1, Thickness)*/)
                        check = true;
                    if (!check)
                    {
                        if (IsEqual(height1, height) || IsEqual(height2, height) || IsEqual(height1, width) || IsEqual(height2, width) /* || IsEqual(height1, Thickness)*/)
                            check = true;
                    }
                }
                else
                {
                    //vert obj
                    if (IsEqual(height1, height) || IsEqual(height2, height) /* || IsEqual(height1, Thickness)*/)
                        check = true;
                }
            }
            else
            {
                if (IsEqual(width1, width) || IsEqual(width2, width) /* || IsEqual(width1, Thickness)*/)
                    check = true;
            }

            return check;
        }

        public bool IsPlateSideViewN(TSM.Part bem)
        {

            if (bem.Identifier.ID == 1497966)
            { }

            double Thickness = 0;
            double width = 0, width1 = 0, width2 = 0;
            double height = 0, height1 = 0, height2 = 0;
            string StubProfileTyp = "";
            bool check = false;
            PointList ptlist = new PointList();

            bem.GetReportProperty("PROFILE.WIDTH", ref width);
            bem.GetReportProperty("PROFILE.HEIGHT", ref height);
            bem.GetReportProperty("PROFILE_TYPE", ref StubProfileTyp);

            if (StubProfileTyp == "I" || StubProfileTyp == "U" || StubProfileTyp == "T")
                bem.GetReportProperty("PROFILE.FLANGE_THICKNESS", ref Thickness);
            else if (StubProfileTyp == "RO" || StubProfileTyp == "M")
                bem.GetReportProperty("PROFILE.PLATE_THICKNESS", ref Thickness);
            else if (StubProfileTyp == "L")
                bem.GetReportProperty("PROFILE.FLANGE_THICKNESS_1", ref Thickness);
            else if (StubProfileTyp == "B")
                bem.GetReportProperty("PROFILE.WIDTH", ref Thickness);

            if (Thickness == 0)
            {
                if (width == 0)
                    width = bem.GetSolid().MaximumPoint.X - bem.GetSolid().MinimumPoint.X;
                if (height == 0)
                    height = bem.GetSolid().MaximumPoint.Y - bem.GetSolid().MinimumPoint.Y;

                if (IsEqualOrLess(width, height))
                    Thickness = width;
                else
                    Thickness = height;
            }

            //if (width > height && height > 0)
            //    width = height;

            if (bem is PolyBeam)
            {
                PolyBeam bemP = bem as PolyBeam;
                bem.GetReportProperty("PROFILE.DIAMETER", ref width);
                if (width == 0)
                    width = 13;

                if (IsSkewedPart(bem))
                    ptlist = GetSlopBeamEdgesPList(bem);
                else
                    ptlist = GetBeamEdgesPList(bem);

                //width1 = ptlist[3].X - ptlist[0].X;
                //height1 = ptlist[1].Y - ptlist[0].Y;

                //width1 = MaxX(ptlist).X - MinX(ptlist).X;
                //height1 = MaxY(ptlist).Y - MinY(ptlist).Y;

                width1 = ptlist[2].X - ptlist[1].X;
                width2 = ptlist[3].X - ptlist[0].X;

                height1 = ptlist[1].Y - ptlist[0].Y;
                height2 = ptlist[2].Y - ptlist[3].Y;

                double ApprHW = width1 / 10;
                double SmallestVal = height1;
                if (height1 > width1)
                {
                    ApprHW = height1 / 10;
                    SmallestVal = width1;
                    if (ApprHW > 200 && SmallestVal > 150)
                        ApprHW = 0;
                }

                if ((IsEqual(width1, Thickness) || IsEqual(height1, Thickness) || IsEqual(width2, Thickness) || IsEqual(height2, Thickness)) || SmallestVal <= ApprHW)
                    check = true;
            }
            else
            {
                //width1 = bem.GetSolid().MaximumPoint.X - bem.GetSolid().MinimumPoint.X;
                //height1 = bem.GetSolid().MaximumPoint.Y - bem.GetSolid().MinimumPoint.Y;


                if (IsSkewedPart(bem))
                    ptlist = GetSlopBeamEdgesPListByCenter(bem);
                else
                    ptlist = GetEdgesPList(bem);

                //width1 = ptlist[3].X - ptlist[0].X;
                //height1 = ptlist[1].Y - ptlist[0].Y;

                //width1 = MaxX(ptlist).X - MinX(ptlist).X;
                //height1 = MaxY(ptlist).Y - MinY(ptlist).Y;

                width1 = Math.Abs(ptlist[2].X - ptlist[1].X);
                width2 = Math.Abs(ptlist[3].X - ptlist[0].X);

                height1 = Math.Abs(ptlist[1].Y - ptlist[0].Y);
                height2 = Math.Abs(ptlist[2].Y - ptlist[3].Y);


                //if (IsEqual(width1, width) || IsEqual(height1, width))
                //    check = true;
                if (IsEqual(width1, Thickness) || IsEqual(height1, Thickness) || IsEqual(width2, Thickness) || IsEqual(height2, Thickness))
                    check = true;

            }

            return check;
        }

        private PointList GetEdgesPList(TSM.Part part)
        {
            PartPoints Points = Com.GetPartPoints(part);
            PointList PtList = new PointList();
            PtList.Add(Points.P1);
            PtList.Add(Points.P2);
            PtList.Add(Points.P3);
            PtList.Add(Points.P4);

            return PtList;
        }

        #endregion

        public PointList GetExactPointsByList(TSD.View CurrentView, PointList PtList, Vector Vect, StraightDimensionSet.StraightDimensionSetAttributes StDimAttr)
        {
            Vector vect2 = ChangeVector(Vect);
            PointList RetPointList = new PointList();
            StraightDimensionSet BoltDH = InsertDim(CurrentView, PtList, vect2, 100, StDimAttr);  // Angle Main Bolt Dim
            if (BoltDH != null)
            {
                RetPointList = DimPointList(BoltDH);
                BoltDH.Delete();
            }
            else
            {
                if ((vect2.X > 0 && vect2.Y == 0))
                    RetPointList.Add(MaxX(PtList));
                else if ((vect2.X < 0 && vect2.Y == 0))
                    RetPointList.Add(MinX(PtList));
                else if ((vect2.Y > 0 && vect2.X == 0))
                    RetPointList.Add(MaxY(PtList));
                else if ((vect2.Y < 0 && vect2.X == 0))
                    RetPointList.Add(MinY(PtList));
            }

            return RetPointList;
        }

        #region Coordinate System Methods

        public Point GetThirdPoint(Point a, Point b, double angle)
        {
            double dx = 0;
            double dy = 0;
            Point p = new Point();
            if (b.X > a.X)
            {
                dx = b.X - a.X;
                dy = b.Y - a.Y;
                p = a;
            }
            else
            {
                dx = a.X - b.X;
                dy = a.Y - b.Y;
                p = a;
            }
            var lengthAB = Math.Sqrt(Math.Pow(dx, 2) + Math.Pow(dy, 2));
            var angleAB = Math.Atan(dy / dx);
            Point c = new Point();
            c.X = lengthAB * Math.Cos(Math.Abs(angleAB) + angle * Math.PI / 180) + p.X;
            c.Y = lengthAB * Math.Sin(Math.Abs(angleAB) + angle * Math.PI / 180) + p.Y;
            c.Z = a.Z;
            if (Math.Round(b.X, 3) < 0)
                c = new Point(-c.X, c.Y, c.Z);

            return c;
        }

        public CoordinateSystem GetCoordSys(TSD.View CurrentView, Point p1, Point p2)
        {
            CoordinateSystem myCoordSys = new CoordinateSystem();
            LineSegment lsX = null, lsY = null;
            Point Origin = null, trdPoint = null;
            //double angL = 0;
            Vector AxisX = null, AxisY = null;

            //if (IsEqual(p1.X, p2.X) || IsEqual(p1.Y, p2.Y))
            //    angL = 90;

            if (p1.X <= p2.X)
                lsX = new LineSegment(p1, p2);
            else if (p2.X < p1.X)
                lsX = new LineSegment(p2, p1);

            AxisX = lsX.GetDirectionVector();
            //dc.DrawLine(currentView, lsX.Point1, lsX.Point2);

            //setPlane(lsX.Point1, lsX.Point2);
            if (IsEqual(p1.X, p2.X) || IsEqual(p1.Y, p2.Y))
                trdPoint = GetThirdPoint(lsX.Point1, lsX.Point2, 90);
            else
                trdPoint = GetPerpendicularPoint(CurrentView, lsX.Point1, lsX.Point2);

            //myModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(tplane);

            Origin = lsX.Point1;

            lsY = new LineSegment(Origin, trdPoint);
            //dc.DrawLine(currentView, Origin, trdPoint);
            AxisY = lsY.GetDirectionVector();

            if (IsEqualPoints(AxisX, AxisY))
            {
                trdPoint = GetThirdPoint(lsX.Point1, lsX.Point2, 90);
                lsY = new LineSegment(Origin, trdPoint);
                //dc.DrawLine(currentView, Origin, trdPoint);
                AxisY = lsY.GetDirectionVector();
            }
            myCoordSys = new CoordinateSystem(Origin, AxisX, AxisY);

            return myCoordSys;
        }

        public Point GetPerpendicularPoint(TSD.View CurrentView, Point a, Point b)
        {
            Point p1 = null, p2 = null, p3 = null;

            if (a.X < b.X)
            {
                p1 = a;
                p2 = b;
            }
            else
            {
                p1 = b;
                p2 = a;
            }

            if (IsEqualOrLess(p1.Y, p2.Y))
                p3 = new Point(p2.X, p1.Y);
            else
                p3 = new Point(p1.X, p2.Y);

            AngleDimension AD = InsertAngelDim(CurrentView, p1, p2, p3, 50);
            AD.Insert();

            Point prepPt = GetThirdPoint(p1, p3, (90 + AD.GetAngle()));
            AD.Delete();

            return prepPt;
        }

        #endregion

        public bool IsPartBolt(BoltGroup bolts, TSM.Part mainbeam)
        {
            List<BoltGroup> boltslt = GetBoltArrlist(true, mainbeam);

            bool check = false;
            foreach (BoltGroup bolt in boltslt)
            {
                if (bolt.Identifier.ID == bolts.Identifier.ID)
                {
                    check = true;
                    break;
                }
            }

            return check;


        }

        public TSM.Part GetSlottedPart(BoltGroup bolts)
        {
            TSM.Part SlPart = null;

            var orderedParts = PartsBoltedInOrder(bolts);

            if (bolts.Hole1 && orderedParts.Count > 0)
            {
                SlPart = orderedParts[0];

            }

            if (bolts.Hole2 && orderedParts.Count > 1)
            {
                SlPart = orderedParts[1];
            }

            if (bolts.Hole3 && orderedParts.Count > 2)
            {
                SlPart = orderedParts[2];
            }

            if (bolts.Hole4 && orderedParts.Count > 3)
            {
                SlPart = orderedParts[3];
            }

            if (bolts.Hole5 && orderedParts.Count > 4)
            {
                SlPart = orderedParts[4];
            }

            return SlPart;
        }

        public bool IsSlottedPart(BoltGroup bolts, TSM.Part MainPart)
        {
            bool check = false;

            var orderedParts = PartsBoltedInOrder(bolts);

            if (bolts.Hole1 && orderedParts.Count > 0)
            {
                if (orderedParts[0].Identifier.ID == MainPart.Identifier.ID)
                    check = true;
            }

            if (bolts.Hole2 && orderedParts.Count > 1)
            {
                if (orderedParts[1].Identifier.ID == MainPart.Identifier.ID)
                    check = true;
            }

            if (bolts.Hole3 && orderedParts.Count > 2)
            {
                if (orderedParts[2].Identifier.ID == MainPart.Identifier.ID)
                    check = true;
            }

            if (bolts.Hole4 && orderedParts.Count > 3)
            {
                if (orderedParts[3].Identifier.ID == MainPart.Identifier.ID)
                    check = true;
            }

            if (bolts.Hole5 && orderedParts.Count > 4)
            {
                if (orderedParts[4].Identifier.ID == MainPart.Identifier.ID)
                    check = true;
            }

            return check;
        }

        public List<TSM.Part> PartsBoltedInOrder(BoltGroup bolts)
        {
            var parts = new List<TSM.Part>();

            if (bolts != null)
            {
                var boltPositions = bolts.BoltPositions;
                var startPoint = boltPositions[0] as Point;

                if (startPoint != null)
                {
                    CoordinateSystem boltCs = bolts.GetCoordinateSystem();
                    Vector boltAxisZ = 0.5 * bolts.CutLength * Vector.Cross(boltCs.AxisY, boltCs.AxisX).GetNormal();
                    Point endPoint = startPoint + boltAxisZ;
                    Point startSegment = startPoint - boltAxisZ;
                    LineSegment boltAxis = new LineSegment(startSegment, endPoint);

                    List<TSM.Part> partsBolted = GetBoltedParts(bolts);

                    var distances = new SortedDictionary<double, TSM.Part>();

                    foreach (var item in partsBolted)
                    {
                        Solid solid = item.GetSolid();
                        ArrayList points = solid.Intersect(boltAxis);

                        int count = (points.Count + 1) / 2;
                        for (int i = 0; i < count; i++)
                        {
                            double distanceToBoltHead = Distance.PointToPoint((Point)points[2 * i], startPoint);

                            Vector pointToPoint = new Vector((Point)points[2 * i] - startPoint);

                            if (Vector.Dot(boltAxisZ.GetNormal(), pointToPoint.GetNormal()) == -1)
                                distanceToBoltHead = -distanceToBoltHead;

                            if (!distances.ContainsKey(distanceToBoltHead))
                                distances.Add(distanceToBoltHead, item);

                        }
                    }

                    if (distances.Count > 1)
                    {
                        parts = distances.Values.ToList();
                    }
                }
            }

            return parts;
        }

        public List<TSM.Part> GetBoltedParts(BoltGroup bolts)
        {
            var parts = new List<TSM.Part>();

            if (bolts != null)
            {
                if (bolts.PartToBoltTo != null)
                {
                    parts.Add(bolts.PartToBoltTo);
                }

                if (bolts.PartToBeBolted != null)
                {
                    parts.Add(bolts.PartToBeBolted);
                }

                parts.AddRange(bolts.GetOtherPartsToBolt().Cast<TSM.Part>().Where(item => item != null));
            }

            return parts;
        }

        public bool IsMainPart(TSM.Part part)
        {
            if (part.GetAssembly().GetMainPart().Identifier.ID == part.Identifier.ID)
                return true;
            else
                return false;

        }

        public TSM.Part GetPartBolted(BoltGroup bolts, TSM.Part MainBeam)
        {
            TSM.Part parts = null;

            if (bolts != null)
            {
                if (bolts.PartToBoltTo != null && MainBeam.Identifier.ID != bolts.PartToBoltTo.Identifier.ID)
                {
                    if (!IsMainPart(bolts.PartToBoltTo))
                        parts = bolts.PartToBoltTo;
                }

                if (parts == null && bolts.PartToBeBolted != null && MainBeam.Identifier.ID != bolts.PartToBeBolted.Identifier.ID)
                {
                    if (!IsMainPart(bolts.PartToBeBolted))
                        parts = bolts.PartToBeBolted;
                }
            }

            return parts;
        }

        public TSM.Part GetPartBoltedMisc(BoltGroup bolts, TSM.Part MainBeam)
        {
            TSM.Part parts = null;

            if (bolts != null)
            {
                if (bolts.PartToBoltTo != null && MainBeam.Identifier.ID != bolts.PartToBoltTo.Identifier.ID)
                {

                    parts = bolts.PartToBoltTo;
                }

                if (parts == null && bolts.PartToBeBolted != null && MainBeam.Identifier.ID != bolts.PartToBeBolted.Identifier.ID)
                {

                    parts = bolts.PartToBeBolted;
                }
            }

            return parts;
        }


        public Point GetCentLinePoint(TSM.Part prt)
        {
            PointList pttemp = ConvertArrayListToPointList(prt.GetCenterLine(false));
            return pttemp[0];

        }

        public void InvisiblePart(TSD.Part part)
        {

            Type[] typ = new Type[] { typeof(TSD.Mark) };
            DrawingObjectEnumerator MarkObj = part.GetRelatedObjects(typ);
            foreach (Mark mark in MarkObj)
            {
                mark.Delete();
            }

            part.Attributes.FaceHatch.FactorType = 0;
            part.Attributes.VisibleLines.Color = DrawingColors.Invisible;
            part.Attributes.VisibleLines.Type = LineTypes.UndefinedLine;
            part.Attributes.VisibleLines.Color = DrawingColors.Invisible;
            part.Attributes.VisibleLines.Type = LineTypes.UndefinedLine;
            part.Attributes.HiddenLines.Color = DrawingColors.Invisible;
            part.Attributes.HiddenLines.Type = LineTypes.UndefinedLine;
            part.Attributes.ReferenceLine.Color = DrawingColors.Invisible;
            part.Attributes.ReferenceLine.Type = LineTypes.UndefinedLine;
            part.Modify();
        }

        public void InvisibleBolt(TSD.Bolt bolt)
        {
            Type[] typ = new Type[] { typeof(TSD.Mark) };
            DrawingObjectEnumerator MarkObj = bolt.GetRelatedObjects(typ);
            foreach (Mark mark in MarkObj)
            {
                mark.Delete();
            }
            bolt.Attributes.SymbolContainsAxis = false;
            bolt.Attributes.SymbolContainsHole = false;
            bolt.Modify();
        }

        public bool IsSkewedPart(TSM.ModelObject mobj)
        {
            bool isskewed = false;
            if (mobj is TSM.Part)
            {
                CoordinateSystem PCord = mobj.GetCoordinateSystem();
                PointList CentList = ConvertArrayListToPointList((mobj as TSM.Part).GetCenterLine(false));
                string name = "";
                if (mobj is Beam && !IssameX(CentList) && !IssameY(CentList))
                    isskewed = true;
                else if ((IsDiagonalVector(PCord.AxisX) || IsDiagonalVector(PCord.AxisY)) && (!IssameX(CentList) && !IssameY(CentList)))
                    isskewed = true;
                else
                    isskewed = false;

                if (isskewed)
                {
                    if (IsShearPlate(mobj))
                    {
                        mobj.GetUserProperty("NOTES1", ref name);
                        if (name == "")
                            mobj.SetUserProperty("NOTES1", " SKEWED");
                        else
                        {
                            if (!name.Contains("SKEWED"))
                                name = name + " SKEWED";
                        }

                    }
                }
            }
            return isskewed;
        }

        #region Cut Part Dim

        public List<string> CutPartDim(Beam mainbeam, TSD.View CurrentView, double DistLx, StraightDimensionSet.StraightDimensionSetAttributes StandardAttr, List<double> AxisList, List<int> idlist)
        {
            List<string> DimList = new List<string>();
            bool IsRightDim = false;
            bool IsLeftDim = false;
            bool IsTopDim = false;
            bool IsBottomDim = false;
            int placingUD = 0;
            int placingLR = 0;

            PointList pointList = new PointList();
            PointList VList = new PointList();
            try
            {
                Point pt1 = new Point(mainbeam.GetSolid().MinimumPoint.X, mainbeam.GetSolid().MinimumPoint.Y);
                Point pt2 = new Point(mainbeam.GetSolid().MinimumPoint.X, mainbeam.GetSolid().MaximumPoint.Y);
                Point pt3 = new Point(mainbeam.GetSolid().MaximumPoint.X, mainbeam.GetSolid().MaximumPoint.Y);
                Point pt4 = new Point(mainbeam.GetSolid().MaximumPoint.X, mainbeam.GetSolid().MinimumPoint.Y);
                ModelObjectEnumerator BoolEnum = mainbeam.GetChildren();

                PointList VertexPList = GetVertPointList(mainbeam);
                while (BoolEnum.MoveNext())
                {

                    if (BoolEnum.Current is CutPlane)
                    {
                        CutPlane cutplane = BoolEnum.Current as CutPlane;
                        Point XPoint = new Point(cutplane.Plane.AxisX);
                        Point YPoint = new Point(cutplane.Plane.AxisY);
                    }
                    if (BoolEnum.Current is Fitting)
                    {
                        Fitting fitting = BoolEnum.Current as Fitting;

                        CoordinateSystem cord = fitting.GetCoordinateSystem();
                        Point Origin = new Point(fitting.Plane.Origin);
                        Point XPoint = new Point(fitting.Plane.AxisX);
                        Point YPoint = new Point(fitting.Plane.AxisY);
                    }
                    if (BoolEnum.Current is BooleanPart)
                    {
                        pointList.Clear();
                        VList.Clear();
                        BooleanPart cutpart = BoolEnum.Current as BooleanPart;

                        Tekla.Structures.Model.Part optpart = cutpart.OperativePart as Tekla.Structures.Model.Part;

                        if (IsCirOrSqPenetration(optpart, CurrentView, mainbeam) == -1)
                        {
                            if (!IsBoolPartHole(optpart))
                            {
                                if (idlist.Contains(optpart.Identifier.ID))
                                {
                                    if (optpart is Beam)
                                    {
                                        Beam cp = optpart as Beam;
                                        Point min = new Point(cp.GetSolid().MinimumPoint.X, cp.GetSolid().MinimumPoint.Y);
                                        Point max = new Point(cp.GetSolid().MaximumPoint.X, cp.GetSolid().MaximumPoint.Y);
                                        Point newmin = new Point(cp.GetSolid().MinimumPoint.X, cp.GetSolid().MaximumPoint.Y);
                                        Point newmax = new Point(cp.GetSolid().MaximumPoint.X, cp.GetSolid().MinimumPoint.Y);

                                        pointList.Add(newmin);
                                        pointList.Add(newmax);
                                        pointList.Add(min);
                                        pointList.Add(max);
                                    }
                                    else if (optpart is ContourPlate)
                                    {
                                        ContourPlate cp = optpart as ContourPlate;
                                        pointList.AddRange(ContPList(cp));
                                    }

                                    PointList centerLine = ConvertArrayListToPointList(mainbeam.GetCenterLine(false));
                                    Point center1 = FindCenterPoint(centerLine);

                                    placingUD = UpDown_Dim(center1, pointList);
                                    placingLR = LeftRight_Dim(center1, pointList);

                                    VList.Clear();


                                    VList.AddRange(pointList);      // All contourpoints

                                    for (int i = 0; i < VList.Count; i++)
                                    {
                                        if (VList[i].X < pt1.X)
                                            VList[i].X = pt1.X;
                                        else if (VList[i].X > pt3.X)
                                            VList[i].X = pt3.X;

                                        if (VList[i].Y < pt1.Y)
                                            VList[i].Y = pt1.Y;
                                        else if (VList[i].Y > pt3.Y)
                                            VList[i].Y = pt3.Y;

                                    }

                                    if (!IssameX(VList) && !IssameY(VList))  //Only FrontView Cut [Discarding Top & Bottom View Cut]
                                    {
                                        int betweencount = 0;
                                        bool IsNotch = false;
                                        for (int i = 0; i < VList.Count; i++)
                                        {
                                            if (Math.Round(VList[i].X) == Math.Round(pt1.X) || Math.Round(VList[i].Y) == Math.Round(pt1.Y) || Math.Round(VList[i].X) == Math.Round(pt3.X) || Math.Round(VList[i].Y) == Math.Round(pt3.Y))
                                                betweencount++;
                                        }
                                        if (betweencount == 1)
                                            IsNotch = true;

                                        Vector VectTB = new Vector(0, 1, 0);
                                        Vector VectLR = new Vector(-1, 0, 0);
                                        if (placingUD == 2)
                                            VectTB = new Vector(0, -1, 0);

                                        if (placingLR == 2)
                                            VectLR = new Vector(1, 0, 0);

                                        double dist = DistLx;
                                        if (IsNotch)
                                            dist = DistLx + (DistLx / 2);

                                        PointList ptlst = new PointList();

                                        if (IsBrace(mainbeam) && GetProType(mainbeam) == "M")
                                            ptlst.AddRange(VList);
                                        else
                                        {
                                            foreach (Point p in VList)
                                            {
                                                if (IsPointinList(VertexPList, p))
                                                    ptlst.Add(p);
                                            }
                                        }

                                        if (ptlst.Count > 0)
                                        {
                                            StraightDimensionSet xDimension = InsertDim(CurrentView, ptlst, VectTB, DistLx, StandardAttr);
                                            if (xDimension != null)
                                            {
                                                if (VectTB.Y > 0)
                                                {
                                                    xDimension.Distance = ResBoxDistY(xDimension, AxisList[2]) + dist;
                                                    IsTopDim = true;
                                                }
                                                else
                                                {
                                                    xDimension.Distance = ResBoxDistY(xDimension, AxisList[0]) + dist;
                                                    IsBottomDim = true;
                                                }
                                                xDimension.Modify();
                                            }

                                            if (IsBrace(mainbeam) && GetProType(mainbeam) == "M")
                                            {
                                                if (VectLR.X > 0)
                                                {
                                                    ptlst.Add(pt3);
                                                    ptlst.Add(pt4);
                                                }
                                                else
                                                {
                                                    ptlst.Add(pt1);
                                                    ptlst.Add(pt2);
                                                }
                                            }


                                            PointList VList1 = SortPointListByMinY(ptlst);

                                            if (VList1[0].Y < centerLine[0].Y)
                                                VList1 = SortPointListByMaxY(ptlst);

                                            StraightDimensionSet xDimension1 = InsertDim(CurrentView, VList1, VectLR, DistLx, StandardAttr);
                                            if (xDimension1 != null)
                                            {

                                                if (VectLR.X > 0)
                                                {
                                                    xDimension1.Distance = ResBoxDistX(xDimension1, AxisList[3]) + dist;
                                                    IsRightDim = true;
                                                }
                                                else
                                                {
                                                    xDimension1.Distance = ResBoxDistX(xDimension1, AxisList[1]) + dist;
                                                    IsLeftDim = true;
                                                }

                                                xDimension1.Modify();
                                            }
                                        }
                                    }



                                }
                            }
                        }

                    }
                }

                if (IsBottomDim)
                    DimList.Add("Bottom");
                if (IsLeftDim)
                    DimList.Add("Left");
                if (IsTopDim)
                    DimList.Add("Top");
                if (IsRightDim)
                    DimList.Add("Right");

            }
            catch (Exception ex) { }
            return DimList;


        }

        public bool IsBoolPartHole(TSM.Part opPart)
        {
            bool check = false;
            try
            {
                if (opPart is ContourPlate)
                {
                    int i = 0;
                    ContourPlate contPlate = opPart as ContourPlate;
                    if (contPlate.Contour.ContourPoints.Count == 4)
                    {
                        foreach (ContourPoint p in contPlate.Contour.ContourPoints)
                        {
                            if (p.Chamfer.Type == Chamfer.ChamferTypeEnum.CHAMFER_ARC_POINT)
                                i++;

                        }

                        if (i >= 2)
                            check = true;
                    }

                }
            }
            catch (Exception ex)
            { }

            return check;
        }

        public double ResBoxDistY(StraightDimensionSet xpsV, double TopY)
        {
            PointList BoltPointL = DimPointList(xpsV);
            double dist = RemoveMinusValue((TopY - BoltPointL[0].Y));
            return dist;
        }

        public double ResBoxDistX(StraightDimensionSet xpsV, double TopX)
        {
            PointList BoltPointL = DimPointList(xpsV);
            double dist = RemoveMinusValue((TopX - BoltPointL[0].X));
            return dist;
        }

        public string GetProType(TSM.Part part)
        {
            string protype = "";

            part.GetReportProperty("PROFILE_TYPE", ref protype);

            return protype;

        }

        #endregion

        #region AABB

        public AABB GetAABB(TSM.Part part)
        {
            Point Minp = new Point(part.GetSolid().MinimumPoint.X, part.GetSolid().MinimumPoint.Y);
            Point Maxp = new Point(part.GetSolid().MaximumPoint.X, part.GetSolid().MaximumPoint.Y);
            AABB aabb = new AABB(Minp, Maxp);

            return aabb;
        }

        public bool IsInsideAABB(AABB aab1, PointList RefPList)
        {
            bool check = true;

            if (RefPList.Count > 0)
            {
                foreach (Point p in RefPList)
                {
                    if (!aab1.IsInside(new Point(p.X, p.Y)))
                    {
                        check = false;
                        break;
                    }
                }
            }
            else
                check = false;

            return check;
        }

        #endregion

        public int GetLegDir(TSM.Part angle1) // For Bottom Check = 1 and For Top  Check = 0 For Left Check = 2 and For Right Check =3
        {
            int check = 0;
            try
            {
                if (IsHorzObj(angle1)) // Horizontal Angle
                {
                    double maxy = angle1.GetSolid().MaximumPoint.Y;
                    double miny = angle1.GetSolid().MinimumPoint.Y;
                    double centy = (maxy - miny) / 2;
                    double CentY = angle1.GetSolid().MinimumPoint.Y + centy;
                    PointList AngEdgList = GetVertexList(angle1.GetSolid());
                    PointList TopPlist = new PointList();
                    PointList BottPlist = new PointList();
                    foreach (Point P in AngEdgList)
                    {
                        if (P.Y > CentY)
                            TopPlist.Add(P);
                        else
                            BottPlist.Add(P);
                    }

                    if (BottPlist.Count > TopPlist.Count)
                        check = 1;
                }
                else // Vertical Angle
                {
                    double maxx = angle1.GetSolid().MaximumPoint.X;
                    double minx = angle1.GetSolid().MinimumPoint.X;
                    double centx = (maxx - minx) / 2;
                    double CentX = angle1.GetSolid().MinimumPoint.X + centx;
                    PointList AngEdgList = GetVertexList(angle1.GetSolid());
                    PointList LeftPlist = new PointList();
                    PointList RightPlist = new PointList();
                    foreach (Point P in AngEdgList)
                    {
                        if (P.X < CentX)
                            LeftPlist.Add(P);
                        else
                            RightPlist.Add(P);
                    }

                    if (LeftPlist.Count > RightPlist.Count) // Left
                        check = 2;
                    else
                        check = 3;
                }
            }
            catch (Exception ex)
            { }

            return check;
        }

        public PointList GetHolePList(TSM.Part prt)
        {
            PointList ptlist = new PointList();
            try
            {
                ModelObjectEnumerator BoolEnum = prt.GetBooleans();

                foreach (BooleanPart boolPart in BoolEnum)
                {
                    TSM.Part opPart = boolPart.OperativePart;

                    if (opPart is ContourPlate)
                    {
                        int i = 0;
                        ContourPlate contPlate = opPart as ContourPlate;
                        if (contPlate.Contour.ContourPoints.Count == 4)
                        {
                            foreach (ContourPoint p in contPlate.Contour.ContourPoints)
                            {
                                if (p.Chamfer.Type == Chamfer.ChamferTypeEnum.CHAMFER_ARC_POINT)
                                    i++;

                            }

                            if (i > 2)
                            {
                                PointList temPlist = ContPList(contPlate);
                                Point CentP = CenterPoint(MinX(temPlist), MaxX(temPlist));
                                ptlist.Add(CentP);
                            }

                        }

                    }
                }
            }
            catch (Exception ex)
            { }

            return ptlist;
        }

        public PointList GetBoltPoints(BoltGroup bolts)
        {
            return ConvertArrayListToPointList(bolts.BoltPositions);
        }

        public AngleDimension InsertAngelDim(TSD.View CurrentView, Point P1, Point P2, Point P3, double Dist, AngleDimensionAttributes attr)
        {
            AngleDimension myAngle = null;
            try
            {
                DrawingHandler dh = new DrawingHandler();
                Drawing CurrentDrawing = dh.GetActiveDrawing();
                if (!IsEqual(P1.X, P2.X) && !IsEqual(P1.Y, P2.Y))
                {
                    myAngle = new AngleDimension(CurrentView, P1, P2, P3, Dist, attr);
                    // myAngle.Attributes.Text.Font.Height = (myAngle.Attributes.Text.Font.Height) / 1.5;
                    myAngle.Insert();
                    CurrentDrawing.CommitChanges();
                }

            }
            catch (Exception ex) { }

            return myAngle;
        }

        public AngleDimension InsertAngelDim(TSD.View CurrentView, Point P1, Point P2, Point P3, double Dist)
        {
            AngleDimension myAngle = null;
            try
            {
                DrawingHandler dh = new DrawingHandler();
                Drawing CurrentDrawing = dh.GetActiveDrawing();
                if (!IsEqual(P1.X, P2.X) && !IsEqual(P1.Y, P2.Y))
                    myAngle = new AngleDimension(CurrentView, P1, P2, P3, Dist);
                CurrentDrawing.CommitChanges();
            }
            catch (Exception ex) { }

            return myAngle;
        }

        public PointList GetBraceRefPoints(Beam Brace)
        {
            PointList bref1 = new PointList();
            bref1.Add(Brace.StartPoint);
            bref1.Add(Brace.EndPoint);

            return bref1;
        }

        public int GetDimID(TSD.StraightDimensionSet stdim)
        {
            DrawingHandler drawingHandler = new DrawingHandler();
            Type drawingType = stdim.GetType();
            System.Reflection.PropertyInfo propertyInfo = drawingType.GetProperty("Identifier", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic);
            object value = propertyInfo.GetValue(stdim, null);
            string ID = value.ToString();
            int a = Convert.ToInt32(ID);
            return a;
        }

        public int GetDimID(TSD.StraightDimension stdim)
        {
            DrawingHandler drawingHandler = new DrawingHandler();
            Type drawingType = stdim.GetType();
            System.Reflection.PropertyInfo propertyInfo = drawingType.GetProperty("Identifier", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic);
            object value = propertyInfo.GetValue(stdim, null);
            string ID = value.ToString();
            int a = Convert.ToInt32(ID);
            return a;
        }

        public int GetDimID(TSD.DimensionSetBase stdim)
        {
            DrawingHandler drawingHandler = new DrawingHandler();
            Type drawingType = stdim.GetType();
            System.Reflection.PropertyInfo propertyInfo = drawingType.GetProperty("Identifier", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic);
            object value = propertyInfo.GetValue(stdim, null);
            string ID = value.ToString();
            int a = Convert.ToInt32(ID);
            return a;
        }

        public int GetDimID(TSD.DimensionBase stdim)
        {
            DrawingHandler drawingHandler = new DrawingHandler();
            Type drawingType = stdim.GetType();
            System.Reflection.PropertyInfo propertyInfo = drawingType.GetProperty("Identifier", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic);
            object value = propertyInfo.GetValue(stdim, null);
            string ID = value.ToString();
            int a = Convert.ToInt32(ID);
            return a;
        }

        public double MinusValue(double val)
        {
            double FinalVal = 0;
            if (val < 0)
            {
                FinalVal = val * (-1);
            }
            else
                FinalVal = val;

            return FinalVal;
        }

        #region Macro Functions

        public void DeleteMac()
        {
            try
            {
                string macName = "DeleteMac";
                string MacroPath = string.Empty;
                Tekla.Structures.TeklaStructuresSettings.GetAdvancedOption("XS_MACRO_DIRECTORY", ref MacroPath);
                if (MacroPath.IndexOf(';') > 0) { MacroPath = MacroPath.Remove(MacroPath.IndexOf(';')); }

                string path = MacroPath.Replace("\\\\", "\\");
                if (!Directory.Exists(path))
                    Directory.CreateDirectory(path);
                string script = "namespace Tekla.Technology.Akit.UserScript" +
                                "{" +
                                    "public class Script" +
                                    "{" +
                                        "public static void Run(Tekla.Technology.Akit.IScript akit)" +
                                        "{" +
                                            @"akit.Callback(""acmd_delete_selected_dr"", """", ""View_10 window_1"");" +
                                        "}}}";
                File.WriteAllText(Path.Combine(MacroPath, macName), script);
                TSMO.Operation.RunMacro("..\\" + macName);
            }
            catch (Exception) { }
        }

        public void CreateDualDim()
        {
            try
            {
                // DualDim();
                DrawingHandler dh = new DrawingHandler();

                if (dh.GetConnectionStatus())
                {
                    ArrayList arrlst = new ArrayList();
                    Drawing CurrentDrawing = dh.GetActiveDrawing();
                    DrawingObjectEnumerator ViewEnum = CurrentDrawing.GetSheet().GetAllViews();

                    foreach (TSD.View CurrentView in ViewEnum)
                    {
                        Type[] ty = new Type[] { typeof(TSD.StraightDimension) };

                        DrawingObjectEnumerator DimEnum = CurrentView.GetAllObjects(ty);

                        foreach (StraightDimension stdim in DimEnum)
                        {
                            ContainerElement ce = stdim.Attributes.MiddleLowerTag;
                            string str = ce.GetUnformattedString();
                            str = str.Replace("{", "");
                            str = str.Replace("}", "");
                            str = str.Replace("\n", "");
                            str = str.Replace(" ", "");

                            //if(str!= ""  && str!="{\n}\n" && str!= "{\nKEEP}\n" && str!= "{\n W10X112 }\n")
                            if (str == "")
                            {
                                if (stdim.Attributes.DimensionValuePrefix.Count == 0)
                                    arrlst.Add(stdim);
                            }
                        }
                    }

                    dh.GetDrawingObjectSelector().SelectObjects(arrlst, false);
                    ApplyDualDim("DIMENSION");
                    dh.GetDrawingObjectSelector().UnselectObjects(arrlst);
                    dh.GetDrawingObjectSelector().UnselectAllObjects();

                }
            }
            catch (Exception) { }
        }

        public void ApplyDualDim(string MiddleLowerTxt)
        {
            try
            {
                string Name = "meraNam";//Temporary file name.
                string MacrosPath = string.Empty;//would store Path to script
                Tekla.Structures.TeklaStructuresSettings.GetAdvancedOption("XS_MACRO_DIRECTORY", ref MacrosPath);//Find out where is actual macro directory.
                if (MacrosPath.IndexOf(';') > 0) { MacrosPath = MacrosPath.Remove(MacrosPath.IndexOf(';')); }

                string path = MacrosPath.Replace("\\\\", "\\");
                if (!Directory.Exists(path))
                    Directory.CreateDirectory(path);

                //Create a script as string
                string script2 = "namespace Tekla.Technology.Akit.UserScript" +
                                    "{" +
                                    " public class Script" +
                                        "{" +
                                            " public static void Run(Tekla.Technology.Akit.IScript akit)" +
                                            " {" +
                                                //   \"" + BTextH1 + " \"
                                                @"akit.Callback(""acmd_display_attr_dialog"", ""dim_dial"", ""main_frame"");" +
                                                @" akit.PushButton(""dim_on_off"", ""dim_dial"");" +
                                                @" akit.TabChange(""dim_dial"", ""tabWndDimAttrib"", ""tabMarks"");" +
                                                @" akit.TabChange(""dim_dial"", ""tabWndDimAttrib"", ""tabTags"");" +
                                                @" akit.ValueChange(""dim_dial"", ""chkButMiddleLowerTagEnable"", ""1"");" +
                                                "akit.ValueChange(\"dim_dial\", \"txtFldMiddleLowerTag\", \" " + MiddleLowerTxt + " \" ); " +
                                                @" akit.PushButton(""dim_modify"", ""dim_dial"");" +
                                                @" akit.PushButton(""dim_ok"", ""dim_dial"");" +

                                            "}}}";


                if (!IsAllControlsChecked())
                {
                    script2 = "namespace Tekla.Technology.Akit.UserScript" +
                                        "{" +
                                        " public class Script" +
                                            "{" +
                                                " public static void Run(Tekla.Technology.Akit.IScript akit)" +
                                                " {" +

                                                    @"akit.Callback(""acmd_display_attr_dialog"", ""dim_dial"", ""main_frame"");" +

                                                    @" akit.TabChange(""dim_dial"", ""tabWndDimAttrib"", ""tabMarks"");" +
                                                    @" akit.TabChange(""dim_dial"", ""tabWndDimAttrib"", ""tabTags"");" +
                                                    @" akit.ValueChange(""dim_dial"", ""chkButMiddleLowerTagEnable"", ""1"");" +
                                                    "akit.ValueChange(\"dim_dial\", \"txtFldMiddleLowerTag\", \" " + MiddleLowerTxt + " \" ); " +
                                                    @" akit.PushButton(""dim_modify"", ""dim_dial"");" +
                                                    @" akit.PushButton(""dim_ok"", ""dim_dial"");" +

                                                "}}}";
                }

                //Save to file
                File.WriteAllText(Path.Combine(MacrosPath, Name), script2);
                //Run it at Tekla Structures application
                TSMO.Operation.RunMacro("..\\" + Name);
            }
            catch (Exception ex) { }

        }

        public void HideDimValue()
        {
            try
            {
                DrawingHandler dh = new DrawingHandler();
                string Name = "HideDimValue";//Temporary file name.
                string MacrosPath = string.Empty;//would store Path to script
                Tekla.Structures.TeklaStructuresSettings.GetAdvancedOption("XS_MACRO_DIRECTORY", ref MacrosPath);//Find out where is actual macro directory.
                if (MacrosPath.IndexOf(';') > 0) { MacrosPath = MacrosPath.Remove(MacrosPath.IndexOf(';')); }

                string path = MacrosPath.Replace("\\\\", "\\");
                if (!Directory.Exists(path))
                    Directory.CreateDirectory(path);

                //Create a script as string
                string script2 = "namespace Tekla.Technology.Akit.UserScript" +
                                    "{" +
                                    " public class Script" +
                                        "{" +
                                            " public static void Run(Tekla.Technology.Akit.IScript akit)" +
                                            " {" +

                                                @"akit.Callback(""acmd_display_attr_dialog"", ""dim_dial"", ""main_frame"");" +
                                                @" akit.PushButton(""dim_on_off"", ""dim_dial"");" +
                                                @" akit.ValueChange(""dim_dial"", ""chkButShowDimension"", ""1"");" +
                                                @" akit.ValueChange(""dim_dial"", ""chkButMiddleLowerTagEnable"", ""1"");" +
                                                @" akit.ValueChange(""dim_dial"", ""optMnuShowDimension"", ""1"");" +
                                                @"  akit.ValueChange(""dim_dial"", ""txtFldMiddleLowerTag"", """");" +
                                                @" akit.PushButton(""dim_modify"", ""dim_dial"");" +
                                                @" akit.PushButton(""dim_ok"", ""dim_dial"");" +

                                            "}}}";


                if (!IsAllControlsChecked())
                {
                    script2 = "namespace Tekla.Technology.Akit.UserScript" +
                                        "{" +
                                        " public class Script" +
                                            "{" +
                                                " public static void Run(Tekla.Technology.Akit.IScript akit)" +
                                                " {" +

                                                @"akit.Callback(""acmd_display_attr_dialog"", ""dim_dial"", ""main_frame"");" +
                                                @" akit.ValueChange(""dim_dial"", ""chkButShowDimension"", ""1"");" +
                                                @" akit.ValueChange(""dim_dial"", ""chkButMiddleLowerTagEnable"", ""1"");" +
                                                @" akit.ValueChange(""dim_dial"", ""optMnuShowDimension"", ""1"");" +
                                                @"  akit.ValueChange(""dim_dial"", ""txtFldMiddleLowerTag"", """");" +
                                                @" akit.PushButton(""dim_modify"", ""dim_dial"");" +
                                                @" akit.PushButton(""dim_ok"", ""dim_dial"");" +

                                                "}}}";
                }

                //Save to file
                File.WriteAllText(Path.Combine(MacrosPath, Name), script2);
                //Run it at Tekla Structures application
                Tekla.Structures.Model.Operations.Operation.RunMacro("..\\" + Name);
            }
            catch (Exception) { }
        }

        private bool IsAllControlsChecked()
        {
            bool check = true;
            try
            {
                string file = MyModel.GetInfo().ModelPath + "\\" + "options.ini";
                FileInfo fi = new FileInfo(file);
                if (fi.Exists)
                {
                    string TextNew = File.ReadAllText(file);
                    string defaultText = "XS_DIALOG_ENABLE_STATE=FALSE";
                    string defaultText1 = "XS_DIALOG_ENABLE_STATE=TRUE";
                    string[] alltext = File.ReadAllLines(fi.FullName);

                    foreach (string line in alltext)
                    {
                        if (line.Contains(defaultText))
                        {
                            check = false;
                            break;
                        }

                        else if (line.Contains(defaultText1))
                        {
                            check = true;
                            break;
                        }

                    }
                }



            }
            catch (Exception ex)
            { }
            return check;
        }

        public void FireProofMac()
        {
            try
            {
                string macName = "FireProf";
                string MacroPath = string.Empty;
                Tekla.Structures.TeklaStructuresSettings.GetAdvancedOption("XS_MACRO_DIRECTORY", ref MacroPath);
                if (MacroPath.IndexOf(';') > 0) { MacroPath = MacroPath.Remove(MacroPath.IndexOf(';')); }

                string path = MacroPath.Replace("\\\\", "\\");
                if (!Directory.Exists(path))
                    Directory.CreateDirectory(path);
                string script = "namespace Tekla.Technology.Akit.UserScript" +
                                "{" +
                                    "public class Script" +
                                    "{" +
                                        "public static void Run(Tekla.Technology.Akit.IScript akit)" +
                                        "{" +
                                            @"akit.Callback(""acmd_display_attr_dialog"", ""adraw_dial"", ""main_frame"");" +
                                            @"akit.PushButton(""gr_adraw_on_off"", ""adraw_dial"");" +
                                            @"akit.PushButton(""gr_adraw_np_filter"", ""adraw_dial"");" +
                                            @" akit.PushButton(""NewButton"", ""diaAssemblyDrawingNPObjectGroupDialogInstance"");" +
                                            @"akit.PushButton(""pushbutton_5154"", ""diaAssemblyDrawingNPObjectGroupDialogInstance"");" +
                                            @"akit.TableSelect(""diaAssemblyDrawingNPObjectGroupDialogInstance"", ""RuleTable"", 1);" +
                                            @"akit.TableValueChange(""diaAssemblyDrawingNPObjectGroupDialogInstance"", ""RuleTable"", ""CheckBox"", ""1"");" +
                                            @"akit.TableSelect(""diaAssemblyDrawingNPObjectGroupDialogInstance"", ""RuleTable"", 1);" +
                                            @"akit.TableValueChange(""diaAssemblyDrawingNPObjectGroupDialogInstance"", ""RuleTable"", ""Property"", ""albl_Name"");" +
                                            @"akit.TableValueChange(""diaAssemblyDrawingNPObjectGroupDialogInstance"", ""RuleTable"", ""Condition"", ""albl_Contains"");" +
                                            @"akit.TableValueChange(""diaAssemblyDrawingNPObjectGroupDialogInstance"", ""RuleTable"", ""Value"", ""FIREPROOF"");" +
                                            @"akit.TableValueChange(""diaAssemblyDrawingNPObjectGroupDialogInstance"", ""RuleTable"", ""AndOr"", """");" +
                                            @"akit.PushButton(""dia_pa_apply"", ""diaAssemblyDrawingNPObjectGroupDialogInstance"");" +
                                            @"akit.PushButton(""dia_pa_ok"", ""diaAssemblyDrawingNPObjectGroupDialogInstance"");" +
                                            @"akit.ValueChange(""adraw_dial"", ""gr_adraw_np_filter_en"", ""1"");" +
                                            @"akit.PushButton(""gr_adraw_modify"", ""adraw_dial"");" +
                                            @"akit.PushButton(""gr_adraw_ok"", ""adraw_dial"");" +
                                        "}}}";
                File.WriteAllText(Path.Combine(MacroPath, macName), script);
                TSMO.Operation.RunMacro("..\\" + macName);
            }
            catch (Exception) { }
        }

        public void CombineDim()
        {
            try
            {
                string Name = "CombineDim";//Temporary file name.
                string MacrosPath = string.Empty;//would store Path to script
                Tekla.Structures.TeklaStructuresSettings.GetAdvancedOption("XS_MACRO_DIRECTORY", ref MacrosPath);//Find out where is actual macro directory.
                if (MacrosPath.IndexOf(';') > 0) { MacrosPath = MacrosPath.Remove(MacrosPath.IndexOf(';')); }

                string path = MacrosPath.Replace("\\\\", "\\");
                if (!Directory.Exists(path))
                    Directory.CreateDirectory(path);


                //Create a script as string
                string script2 = "namespace Tekla.Technology.Akit.UserScript" +
                                 "{" +
                                 " public class Script" +
                                     "{" +
                                         " public static void Run(Tekla.Technology.Akit.IScript akit)" +
                                         " {" +
                                             @"akit.Callback(""acmd_combine_dims"", """", ""View_10 window_1"");" +

                                         "}}}";


                //Save to file
                File.WriteAllText(Path.Combine(MacrosPath, Name), script2);
                //Run it at Tekla Structures application
                Tekla.Structures.Model.Operations.Operation.RunMacro("..\\" + Name);
            }
            catch (Exception) { }
        }

        public void PlaceMark()
        {
            try
            {
                string Name = "PlaceMark";//Temporary file name.
                string MacrosPath = string.Empty;//would store Path to script
                Tekla.Structures.TeklaStructuresSettings.GetAdvancedOption("XS_MACRO_DIRECTORY", ref MacrosPath);//Find out where is actual macro directory.
                if (MacrosPath.IndexOf(';') > 0) { MacrosPath = MacrosPath.Remove(MacrosPath.IndexOf(';')); }

                string path = MacrosPath.Replace("\\\\", "\\");
                if (!Directory.Exists(path))
                    Directory.CreateDirectory(path);


                //Create a script as string
                string script2 = "namespace Tekla.Technology.Akit.UserScript" +
                                 "{" +
                                 " public class Script" +
                                     "{" +
                                         " public static void Run(Tekla.Technology.Akit.IScript akit)" +
                                         " {" +
                                             @"akit.Callback(""acmdReFreeplaceSelected"", """", ""View_10 window_1"");" +

                                         "}}}";


                //Save to file
                File.WriteAllText(Path.Combine(MacrosPath, Name), script2);
                //Run it at Tekla Structures application
                Tekla.Structures.Model.Operations.Operation.RunMacro("..\\" + Name);
            }
            catch (Exception) { }
        }

        public void ModifyMarkPlace(TSD.View CView)
        {
            TSD.DrawingHandler dh = new TSD.DrawingHandler();
            TSD.DrawingObjectEnumerator DimList = CView.GetAllObjects(typeof(TSD.MarkBase));
            List<TSD.MarkBase> AllMark = Com.EnumtoArrayD(DimList).OfType<TSD.MarkBase>().ToList();
            dh.GetDrawingObjectSelector().SelectObjects(new ArrayList(AllMark), false);
            PlaceMark();
            dh.GetDrawingObjectSelector().UnselectAllObjects();
        }


        public void SetMiddleTag(string Text)
        {
            try
            {
                string Name = "SetMiddleTag";//Temporary file name.
                string MacrosPath = string.Empty;//would store Path to script
                Tekla.Structures.TeklaStructuresSettings.GetAdvancedOption("XS_MACRO_DIRECTORY", ref MacrosPath);//Find out where is actual macro directory.
                if (MacrosPath.IndexOf(';') > 0) { MacrosPath = MacrosPath.Remove(MacrosPath.IndexOf(';')); }

                string path = MacrosPath.Replace("\\\\", "\\");
                if (!Directory.Exists(path))
                    Directory.CreateDirectory(path);


                //Create a script as string
                string script2 = "namespace Tekla.Technology.Akit.UserScript" +
                                 "{" +
                                 " public class Script" +
                                     "{" +
                                         " public static void Run(Tekla.Technology.Akit.IScript akit)" +
                                         " {" +

                                              @"akit.Callback(""acmd_display_selected_drawing_object_dialog"", """",""View_10 window_1"");" +
                                               @" akit.TabChange(""dim_dial"", ""tabWndDimAttrib"", ""tabTags""); " +
                                                @"akit.ValueChange(""dim_dial"", ""txtFldMiddleLowerTag"", """ + Text + @"""); " +
                                               @" akit.PushButton(""dim_modify"", ""dim_dial""); " +
                                               @" akit.PushButton(""dim_ok"", ""dim_dial""); " +

                "}}}";


                //Save to file
                File.WriteAllText(Path.Combine(MacrosPath, Name), script2);
                //Run it at Tekla Structures application
                Tekla.Structures.Model.Operations.Operation.RunMacro("..\\" + Name);
            }
            catch (Exception) { }
        }

        public bool RotateView(TSD.View CView, double Degree)
        {
            bool check = false;
            try
            {
                DrawingHandler dh = new DrawingHandler();
                dh.GetDrawingObjectSelector().SelectObject(CView);
                string Name = "RotateViewAb";//Temporary file name.
                string MacrosPath = string.Empty;//would store Path to script
                Tekla.Structures.TeklaStructuresSettings.GetAdvancedOption("XS_MACRO_DIRECTORY", ref MacrosPath);//Find out where is actual macro directory.
                if (MacrosPath.IndexOf(';') > 0) { MacrosPath = MacrosPath.Remove(MacrosPath.IndexOf(';')); }

                string path = MacrosPath.Replace("\\\\", "\\");
                if (!Directory.Exists(path))
                    Directory.CreateDirectory(path);

                //Create a script as string
                string script2 = "namespace Tekla.Technology.Akit.UserScript" +
                                 "{" +
                                 " public class Script" +
                                     "{" +
                                         " public static void Run(Tekla.Technology.Akit.IScript akit)" +
                                         " {" +

                                                "akit.Callback(\"acmd_display_rotate_view_dialog\", \"\", \"View_10 window_1\"); " +
                                                "akit.ValueChange(\"gr_rotate_view\", \"gr_rotate_view_angle\", \"" + Degree + "\");" +
                                                "akit.PushButton(\"gr_rotate_view_rotate\", \"gr_rotate_view\");" +
                                                "akit.PushButton(\"gr_rotate_view_cancel\", \"gr_rotate_view\");" +


                                         "}}}";


                //Save to file
                File.WriteAllText(Path.Combine(MacrosPath, Name), script2);
                //Run it at Tekla Structures application
                Tekla.Structures.Model.Operations.Operation.RunMacro("..\\" + Name);

                dh.GetDrawingObjectSelector().UnselectAllObjects();

                check = true;
            }
            catch (Exception ex)
            { }
            return check;
        }

        public void NeighbourpartOFF()
        {
            //string script = "namespace Tekla.Technology.Akit.UserScript" +
            //                   "{" +
            //                       "public class Script" +
            //                       "{" +
            //                           "public static void Run(Tekla.Technology.Akit.IScript akit)" +
            //                           "{" +
            //                               @" akit.Callback(""acmd_display_selected_drawing_object_dialog"", """", ""View_10 window_1"");" +
            //@"akit.PushButton( ""gr_adraw_npart"", ""adraw_dial"");" +
            //@"akit.ValueChange(""adnp_dial"", ""gr_dnp_collect_by"", ""0"");" +
            //@"akit.ValueChange(""adnp_dial"", ""gr_dnp_which"", ""1"");" +
            //@"akit.PushButton( ""dnp_modify"", ""adnp_dial"");" +
            //@"akit.PushButton( ""dnp_ok"", ""adnp_dial"");" +
            //@"akit.PushButton( ""gr_adraw_ok"", ""adraw_dial"");" +
            //                           "}}}";

            string script = "namespace Tekla.Technology.Akit.UserScript" +
                               "{" +
                                   "public class Script" +
                                   "{" +
                                       "public static void Run(Tekla.Technology.Akit.IScript akit)" +
                                       "{" +
            @"akit.Callback(""acmd_display_selected_drawing_object_dialog"", """", ""main_frame"");" +
            @"akit.PushButton(""gr_wdraw_on_off"", ""wdraw_dial"");" +
            @"akit.PushButton(""gr_wdraw_npart"", ""wdraw_dial"");" +
            @"akit.ValueChange(""wdnp_dial"", ""gr_dnp_collect_by"", ""0"");" +
            @"akit.ValueChange(""wdnp_dial"", ""gr_dnp_which"", ""1"");" +
            @"akit.ValueChange(""wdnp_dial"", ""gr_dnp_take_skew"", ""0"");" +
            @"akit.ValueChange(""wdnp_dial"", ""optBoltVisibility"", ""0"");" +
            @"akit.PushButton(""dnp_modify"", ""wdnp_dial"");" +
            @"akit.PushButton(""dnp_apply"", ""wdnp_dial"");" +
            @"akit.PushButton(""dnp_ok"", ""wdnp_dial"");" +
            @"akit.ValueChange(""wdraw_dial"", ""gr_wdraw_npart_en"", ""1"");" +
            @"akit.PushButton(""gr_wdraw_apply"", ""wdraw_dial"");" +
            @"akit.PushButton(""gr_wdraw_ok"", ""wdraw_dial"");" +
            @"akit.TabChange(""adnp_dial"", ""Container_443"", ""Container_446"");" +
            @"akit.ValueChange(""adnp_dial"", ""gr_dnp_cl_main_beam"", ""0"");" +
            @"akit.ValueChange(""adnp_dial"", ""gr_dnp_cl_second_beam"", ""0"");" +
            @"akit.ValueChange(""adnp_dial"", ""gr_dnp_rl_main_beam"", ""0"");" +
            @"akit.ValueChange(""adnp_dial"", ""gr_dnp_rl_second_beam"", ""0"");" +
            @"akit.TabChange(""adnp_dial"", ""Container_443"", ""Container_275"");" +
            @"akit.ValueChange(""adnp_dial"", ""gr_dnp_colour"", ""152"");" +
            @"akit.ValueChange(""adnp_dial"", ""gr_dnp_linetype"", ""0"");" +
            @"akit.ValueChange(""adnp_dial"", ""gr_dnp_hidden_colour"", ""152"");" +
            @"akit.ValueChange(""adnp_dial"", ""gr_dnp_hidden_linetype"", ""0"");" +
            @"akit.ValueChange(""adnp_dial"", ""gr_dnp_reference_colour"", ""152"");" +
            @"akit.ValueChange(""adnp_dial"", ""gr_dnp_reference_linetype"", ""0"");" +
            @"akit.ValueChange(""adnp_dial"", ""gr_dnp_bolt_colour"", ""152"");" +
            @"akit.PushButton(""dnp_modify"", ""adnp_dial"");" +
            @"akit.PushButton(""dnp_apply"", ""adnp_dial"");" +
            @"akit.PushButton(""dnp_ok"", ""adnp_dial"");" +
            @"akit.ValueChange(""adraw_dial"", ""gr_adraw_npart_en"", ""1"");" +
            @"akit.PushButton(""gr_adraw_modify"", ""adraw_dial"");" +
            @"akit.PushButton(""gr_adraw_apply"", ""adraw_dial"");" +
            @"akit.PushButton(""gr_adraw_ok"", ""adraw_dial"");" +
            "}}}";

            RunMacro(script);
        }

        public void NeighbourpartON()
        {
            //string script = "namespace Tekla.Technology.Akit.UserScript" +
            //                   "{" +
            //                       "public class Script" +
            //                       "{" +
            //                           "public static void Run(Tekla.Technology.Akit.IScript akit)" +
            //                           "{" +
            //@"akit.Callback(""acmd_display_selected_drawing_object_dialog"", """", ""View_10 window_1"");" +
            //@"akit.PushButton( ""gr_adraw_npart"", ""adraw_dial"");" +
            //@"akit.ValueChange(""adnp_dial"", ""gr_dnp_collect_by"", ""4"");" +
            //@"akit.ValueChange(""adnp_dial"", ""gr_dnp_which"", ""3"");" +
            //@"akit.PushButton( ""dnp_modify"", ""adnp_dial"");" +
            //@"akit.PushButton( ""dnp_ok"", ""adnp_dial"");" +
            //@"akit.PushButton( ""gr_adraw_ok"", ""adraw_dial"");" +
            //                           "}}}";

            string script = "namespace Tekla.Technology.Akit.UserScript" +
                               "{" +
                                   "public class Script" +
                                   "{" +
                                       "public static void Run(Tekla.Technology.Akit.IScript akit)" +
                                       "{" +
            @"akit.Callback(""acmd_display_selected_drawing_object_dialog"", """", ""main_frame"");" +
            @"akit.PushButton(""gr_wdraw_on_off"", ""wdraw_dial"");" +
            @"akit.PushButton(""gr_wdraw_npart"", ""wdraw_dial"");" +
            @"akit.ValueChange(""wdnp_dial"", ""gr_dnp_collect_by"", ""4"");" +
            @"akit.ValueChange(""wdnp_dial"", ""gr_dnp_which"", ""3"");" +
            @"akit.ValueChange(""wdnp_dial"", ""gr_dnp_take_skew"", ""1"");" +
            @"akit.ValueChange(""wdnp_dial"", ""optBoltVisibility"", ""1"");" +
            @"akit.PushButton(""dnp_modify"", ""wdnp_dial"");" +
            @"akit.PushButton(""dnp_apply"", ""wdnp_dial"");" +
            @"akit.PushButton(""dnp_ok"", ""wdnp_dial"");" +
            @"akit.ValueChange(""wdraw_dial"", ""gr_wdraw_npart_en"", ""1"");" +
            @"akit.PushButton(""gr_wdraw_apply"", ""wdraw_dial"");" +
            @"akit.PushButton(""gr_wdraw_ok"", ""wdraw_dial"");" +
            @"akit.TabChange(""adnp_dial"", ""Container_443"", ""Container_446"");" +
            @"akit.ValueChange(""adnp_dial"", ""gr_dnp_rl_main_beam"", ""1"");" +
            @"akit.ValueChange(""adnp_dial"", ""gr_dnp_cl_main_beam"", ""1"");" +
            @"akit.ValueChange(""adnp_dial"", ""gr_dnp_cl_second_beam"", ""1"");" +
            @"akit.ValueChange(""adnp_dial"", ""gr_dnp_rl_second_beam"", ""1"");" +
            @"akit.TabChange(""adnp_dial"", ""Container_443"", ""Container_275"");" +
            @"akit.ValueChange(""adnp_dial"", ""gr_dnp_linetype"", ""3"");" +
            @"akit.ValueChange(""adnp_dial"", ""gr_dnp_hidden_linetype"", ""4"");" +
            @"akit.ValueChange(""adnp_dial"", ""gr_dnp_reference_linetype"", ""3"");" +
            @"akit.ValueChange(""adnp_dial"", ""gr_dnp_colour"", ""160"");" +
            @"akit.ValueChange(""adnp_dial"", ""gr_dnp_hidden_colour"", ""160"");" +
            @"akit.ValueChange(""adnp_dial"", ""gr_dnp_reference_colour"", ""160"");" +
            @"akit.ValueChange(""adnp_dial"", ""gr_dnp_bolt_colour"", ""153"");" +
            @"akit.PushButton(""dnp_modify"", ""adnp_dial"");" +
            @"akit.PushButton(""dnp_apply"", ""adnp_dial"");" +
            @"akit.PushButton(""dnp_ok"", ""adnp_dial"");" +
            @"akit.ValueChange(""adraw_dial"", ""gr_adraw_npart_en"", ""1"");" +
            @"akit.PushButton(""gr_adraw_modify"", ""adraw_dial"");" +
            @"akit.PushButton(""gr_adraw_apply"", ""adraw_dial"");" +
            @"akit.PushButton(""gr_adraw_ok"", ""adraw_dial"");" +
            "}}}";

            RunMacro(script);
        }

        #region old
        //public void NeighbourpartOFF()
        //{
        //    //string script = "namespace Tekla.Technology.Akit.UserScript" +
        //    //                   "{" +
        //    //                       "public class Script" +
        //    //                       "{" +
        //    //                           "public static void Run(Tekla.Technology.Akit.IScript akit)" +
        //    //                           "{" +
        //    //                               @" akit.Callback(""acmd_display_selected_drawing_object_dialog"", """", ""View_10 window_1"");" +
        //    //@"akit.PushButton( ""gr_adraw_npart"", ""adraw_dial"");" +
        //    //@"akit.ValueChange(""adnp_dial"", ""gr_dnp_collect_by"", ""0"");" +
        //    //@"akit.ValueChange(""adnp_dial"", ""gr_dnp_which"", ""1"");" +
        //    //@"akit.PushButton( ""dnp_modify"", ""adnp_dial"");" +
        //    //@"akit.PushButton( ""dnp_ok"", ""adnp_dial"");" +
        //    //@"akit.PushButton( ""gr_adraw_ok"", ""adraw_dial"");" +
        //    //                           "}}}";

        //    string script = "namespace Tekla.Technology.Akit.UserScript" +
        //                       "{" +
        //                           "public class Script" +
        //                           "{" +
        //                               "public static void Run(Tekla.Technology.Akit.IScript akit)" +
        //                               "{" +
        //    @"akit.Callback(""acmd_display_selected_drawing_object_dialog"", """", ""main_frame"");" +
        //    @"akit.PushButton(""gr_adraw_on_off"", ""adraw_dial"");" +
        //    @"akit.PushButton(""gr_adraw_npart"", ""adraw_dial"");" +
        //    @"akit.ValueChange(""adnp_dial"", ""gr_dnp_collect_by"", ""0"");" +
        //    @"akit.ValueChange(""adnp_dial"", ""gr_dnp_which"", ""1"");" +
        //    @"akit.ValueChange(""adnp_dial"", ""gr_dnp_take_skew"", ""0"");" +
        //    @"akit.ValueChange(""adnp_dial"", ""optBoltVisibility"", ""0"");" +
        //    @"akit.TabChange(""adnp_dial"", ""Container_443"", ""Container_446"");" +
        //    @"akit.ValueChange(""adnp_dial"", ""gr_dnp_cl_main_beam"", ""0"");" +
        //    @"akit.ValueChange(""adnp_dial"", ""gr_dnp_cl_second_beam"", ""0"");" +
        //    @"akit.ValueChange(""adnp_dial"", ""gr_dnp_rl_main_beam"", ""0"");" +
        //    @"akit.ValueChange(""adnp_dial"", ""gr_dnp_rl_second_beam"", ""0"");" +
        //    @"akit.TabChange(""adnp_dial"", ""Container_443"", ""Container_275"");" +
        //    @"akit.ValueChange(""adnp_dial"", ""gr_dnp_colour"", ""152"");" +
        //    @"akit.ValueChange(""adnp_dial"", ""gr_dnp_linetype"", ""0"");" +
        //    @"akit.ValueChange(""adnp_dial"", ""gr_dnp_hidden_colour"", ""152"");" +
        //    @"akit.ValueChange(""adnp_dial"", ""gr_dnp_hidden_linetype"", ""0"");" +
        //    @"akit.ValueChange(""adnp_dial"", ""gr_dnp_reference_colour"", ""152"");" +
        //    @"akit.ValueChange(""adnp_dial"", ""gr_dnp_reference_linetype"", ""0"");" +
        //    @"akit.ValueChange(""adnp_dial"", ""gr_dnp_bolt_colour"", ""152"");" +
        //    @"akit.PushButton(""dnp_modify"", ""adnp_dial"");" +
        //    @"akit.PushButton(""dnp_apply"", ""adnp_dial"");" +
        //    @"akit.PushButton(""dnp_ok"", ""adnp_dial"");" +
        //    @"akit.ValueChange(""adraw_dial"", ""gr_adraw_npart_en"", ""1"");" +
        //    @"akit.PushButton(""gr_adraw_modify"", ""adraw_dial"");" +
        //    @"akit.PushButton(""gr_adraw_apply"", ""adraw_dial"");" +
        //    @"akit.PushButton(""gr_adraw_ok"", ""adraw_dial"");" +
        //    "}}}";

        //    RunMacro(script);
        //}

        //public void NeighbourpartON()
        //{
        //    //string script = "namespace Tekla.Technology.Akit.UserScript" +
        //    //                   "{" +
        //    //                       "public class Script" +
        //    //                       "{" +
        //    //                           "public static void Run(Tekla.Technology.Akit.IScript akit)" +
        //    //                           "{" +
        //    //@"akit.Callback(""acmd_display_selected_drawing_object_dialog"", """", ""View_10 window_1"");" +
        //    //@"akit.PushButton( ""gr_adraw_npart"", ""adraw_dial"");" +
        //    //@"akit.ValueChange(""adnp_dial"", ""gr_dnp_collect_by"", ""4"");" +
        //    //@"akit.ValueChange(""adnp_dial"", ""gr_dnp_which"", ""3"");" +
        //    //@"akit.PushButton( ""dnp_modify"", ""adnp_dial"");" +
        //    //@"akit.PushButton( ""dnp_ok"", ""adnp_dial"");" +
        //    //@"akit.PushButton( ""gr_adraw_ok"", ""adraw_dial"");" +
        //    //                           "}}}";

        //    string script = "namespace Tekla.Technology.Akit.UserScript" +
        //                       "{" +
        //                           "public class Script" +
        //                           "{" +
        //                               "public static void Run(Tekla.Technology.Akit.IScript akit)" +
        //                               "{" +
        //    @"akit.Callback(""acmd_display_selected_drawing_object_dialog"", """", ""main_frame"");" +
        //    @"akit.PushButton(""gr_adraw_on_off"", ""adraw_dial"");" +
        //    @"akit.PushButton(""gr_adraw_npart"", ""adraw_dial"");" +
        //    @"akit.ValueChange(""adnp_dial"", ""gr_dnp_collect_by"", ""4"");" +
        //    @"akit.ValueChange(""adnp_dial"", ""gr_dnp_take_skew"", ""1"");" +
        //    @"akit.ValueChange(""adnp_dial"", ""optBoltVisibility"", ""1"");" +
        //    @"akit.ValueChange(""adnp_dial"", ""gr_dnp_which"", ""3"");" +
        //    @"akit.TabChange(""adnp_dial"", ""Container_443"", ""Container_446"");" +
        //    @"akit.ValueChange(""adnp_dial"", ""gr_dnp_rl_main_beam"", ""1"");" +
        //    @"akit.ValueChange(""adnp_dial"", ""gr_dnp_cl_main_beam"", ""1"");" +
        //    @"akit.ValueChange(""adnp_dial"", ""gr_dnp_cl_second_beam"", ""1"");" +
        //    @"akit.ValueChange(""adnp_dial"", ""gr_dnp_rl_second_beam"", ""1"");" +
        //    @"akit.TabChange(""adnp_dial"", ""Container_443"", ""Container_275"");" +
        //    @"akit.ValueChange(""adnp_dial"", ""gr_dnp_linetype"", ""3"");" +
        //    @"akit.ValueChange(""adnp_dial"", ""gr_dnp_hidden_linetype"", ""4"");" +
        //    @"akit.ValueChange(""adnp_dial"", ""gr_dnp_reference_linetype"", ""3"");" +
        //    @"akit.ValueChange(""adnp_dial"", ""gr_dnp_colour"", ""160"");" +
        //    @"akit.ValueChange(""adnp_dial"", ""gr_dnp_hidden_colour"", ""160"");" +
        //    @"akit.ValueChange(""adnp_dial"", ""gr_dnp_reference_colour"", ""160"");" +
        //    @"akit.ValueChange(""adnp_dial"", ""gr_dnp_bolt_colour"", ""153"");" +
        //    @"akit.PushButton(""dnp_modify"", ""adnp_dial"");" +
        //    @"akit.PushButton(""dnp_apply"", ""adnp_dial"");" +
        //    @"akit.PushButton(""dnp_ok"", ""adnp_dial"");" +
        //    @"akit.ValueChange(""adraw_dial"", ""gr_adraw_npart_en"", ""1"");" +
        //    @"akit.PushButton(""gr_adraw_modify"", ""adraw_dial"");" +
        //    @"akit.PushButton(""gr_adraw_apply"", ""adraw_dial"");" +
        //    @"akit.PushButton(""gr_adraw_ok"", ""adraw_dial"");" +
        //    "}}}";

        //    RunMacro(script);
        //}
        #endregion

        public void RunMacro(string TempStr)
        {
            string Name = "RotatePartAb";//Temporary file name.
            string MacrosPath = string.Empty;//would store Path to script
            Tekla.Structures.TeklaStructuresSettings.GetAdvancedOption("XS_MACRO_DIRECTORY", ref MacrosPath);//Find out where is actual macro directory.
            if (MacrosPath.IndexOf(';') > 0) { MacrosPath = MacrosPath.Remove(MacrosPath.IndexOf(';')); }

            //Save to file
            File.WriteAllText(Path.Combine(MacrosPath, Name), TempStr);
            //Run it at Tekla Structures application
            Tekla.Structures.Model.Operations.Operation.RunMacro("..\\" + Name);
        }

        #endregion

        #region Insert New Tekla Mark
        public void CreateMark(string Clientname, int mergemark, double PTextH, double BTextH)
        {
            bool Env = false; double PTextH1, BTextH1;
            TeklaStructuresSettings.GetAdvancedOption("XS_IMPERIAL", ref Env);
            if (Env)
            {
                PTextH1 = (PTextH * 0.039);
                BTextH1 = (BTextH * 0.039);
            }
            else
            {
                PTextH1 = PTextH;
                BTextH1 = BTextH;
            }

            int mergemark1 = mergemark;
            DeleteMark();
            if (!Clientname.ToUpper().Contains("USSL"))
                ApplyMarkSetting(mergemark1, PTextH1, BTextH1);
            // DualDim();
            ArrayList arrlst = new ArrayList();
            DrawingHandler dh = new DrawingHandler();
            if (dh.GetConnectionStatus())
            {
                Drawing CurrentDrawing = dh.GetActiveDrawing();
                DrawingObjectEnumerator ViewEnum = CurrentDrawing.GetSheet().GetViews();
                while (ViewEnum.MoveNext())
                {
                    Tekla.Structures.Drawing.View CurrentView = ViewEnum.Current as TSD.View;
                    arrlst = new ArrayList();
                    if (CurrentView != null)
                    {
                        if (Clientname == "Corey-Mexico-MET" && CurrentView.Name == "ISO VIEW")
                        {
                            DeleteMark(CurrentView);
                        }
                        else
                        {
                            Type[] ty = new Type[] { typeof(TSD.Part), typeof(TSD.Bolt) };

                            DrawingObjectEnumerator DimEnum = CurrentView.GetAllObjects(ty);
                            foreach (TSD.DrawingObject stPart in DimEnum)
                            {
                                arrlst.Add(stPart);
                            }
                            dh.GetDrawingObjectSelector().SelectObjects(arrlst, false);
                            InsertMark();
                            dh.GetDrawingObjectSelector().UnselectObjects(arrlst);
                            //foreach (TSD.DrawingObject stPart in DimEnum)
                            //{
                            //    dh.GetDrawingObjectSelector().SelectObject(stPart);
                            //    InsertMark();
                            //    dh.GetDrawingObjectSelector().UnselectObject(stPart);
                            //}
                        }
                    }
                }
            }
        }

        private void DeleteMark()
        {
            // DualDim();
            ArrayList arrlst = new ArrayList();
            DrawingHandler dh = new DrawingHandler();
            if (dh.GetConnectionStatus())
            {
                Drawing CurrentDrawing = dh.GetActiveDrawing();
                DrawingObjectEnumerator ViewEnum = CurrentDrawing.GetSheet().GetViews();
                int viewcount = ViewEnum.GetSize();
                while (ViewEnum.MoveNext())
                {
                    Tekla.Structures.Drawing.View CurrentView = ViewEnum.Current as TSD.View;
                    if (CurrentView != null)
                    {
                        Type[] ty = new Type[] { typeof(TSD.Mark) };
                        DrawingObjectEnumerator DimEnum = CurrentView.GetAllObjects(ty);
                        foreach (TSD.Mark stMark in DimEnum)
                        {
                            arrlst.Add(stMark);
                        }
                    }
                }

                dh.GetDrawingObjectSelector().SelectObjects(arrlst, false);
                ApplyDeleteMarks();
            }
        }

        private void DeleteMark(TSD.View CurrentView)
        {
            ArrayList arrlst = new ArrayList();
            DrawingHandler dh = new DrawingHandler();
            Type[] ty = new Type[] { typeof(TSD.Mark) };

            if (CurrentView != null)
            {
                DrawingObjectEnumerator DimEnum = CurrentView.GetAllObjects(ty);

                foreach (TSD.Mark stMark in DimEnum)
                {
                    arrlst.Add(stMark);
                }

                dh.GetDrawingObjectSelector().SelectObjects(arrlst, false);
                ApplyDeleteMarks();
            }
        }

        private void ApplyDeleteMarks()
        {
            string Name = "DeleteMarksAb";//Temporary file name.
            string MacrosPath = string.Empty;//would store Path to script
            Tekla.Structures.TeklaStructuresSettings.GetAdvancedOption("XS_MACRO_DIRECTORY", ref MacrosPath);//Find out where is actual macro directory.
            if (MacrosPath.IndexOf(';') > 0) { MacrosPath = MacrosPath.Remove(MacrosPath.IndexOf(';')); }
            string path = MacrosPath.Replace("\\\\", "\\");
            if (!Directory.Exists(path))
                Directory.CreateDirectory(path);



            //Create a script as string
            string script2 = "namespace Tekla.Technology.Akit.UserScript" +
                             "{" +
                             " public class Script" +
                                 "{" +
                                     " public static void Run(Tekla.Technology.Akit.IScript akit)" +
                                     " {" +

                                          @"akit.ValueChange(""main_frame"", ""gr_sel_mark"", ""0"");" +
                                          @"akit.ValueChange(""main_frame"", ""gr_sel_mark"", ""1"");" +
                                          @"akit.Callback(""acmd_delete_selected_dr"", """", ""main_frame"");" +
                                          @"akit.ValueChange(""main_frame"", ""gr_sel_all"", ""1"");" +

                                     "}}}";


            //Save to file



            File.WriteAllText(Path.Combine(MacrosPath, Name), script2);
            //Run it at Tekla Structures application
            Tekla.Structures.Model.Operations.Operation.RunMacro("..\\" + Name);
        }

        private void ApplyMarkSetting(int mergemark1, double PTextH1, double BTextH1)
        {
            bool Env = false;
            double MinMargin, SMargin;
            TeklaStructuresSettings.GetAdvancedOption("XS_IMPERIAL", ref Env);
            if (Env)
            {
                SMargin = 0.25; MinMargin = 0.75;
            }
            else
            {
                SMargin = 6.35; MinMargin = 19.05;
            }

            string Name = "MarkSettingAb";//Temporary file name.
            string MacrosPath = string.Empty;//would store Path to script
            Tekla.Structures.TeklaStructuresSettings.GetAdvancedOption("XS_MACRO_DIRECTORY", ref MacrosPath);//Find out where is actual macro directory.
            if (MacrosPath.IndexOf(';') > 0) { MacrosPath = MacrosPath.Remove(MacrosPath.IndexOf(';')); }


            string path = MacrosPath.Replace("\\\\", "\\");
            if (!Directory.Exists(path))
                Directory.CreateDirectory(path);

            //Create a script as string
            string script2 = "namespace Tekla.Technology.Akit.UserScript" +
                             "{" +
                             " public class Script" +
                                 "{" +
                                     " public static void Run(Tekla.Technology.Akit.IScript akit)" +
                                     " {" +

                                        "akit.Callback(\"acmd_display_attr_dialog\", \"adraw_dial\", \"main_frame\");" +
                                        "akit.PushButton(\"gr_adraw_pmark\", \"adraw_dial\");" +
                                        "akit.ValueChange(\"adpm_dial\", \"gr_mark_tab_page_option\", \"1\");" +
                                        "akit.TableSelect(\"adpm_dial\", \"gr_mark_selected_elements\", 1, 2, 3, 4, 5, 6, 7);" +
                                        "akit.ValueChange(\"adpm_dial\", \"height\", \"" + PTextH1 + " \");" +
                                        "akit.TabChange(\"adpm_dial\", \"Container_251\", \"gr_mark_general_tab\");" +
                                        "akit.ValueChange(\"adpm_dial\", \"apm_merge_marks\", \"" + mergemark1 + "\");" +
                                        "akit.PushButton(\"gr_apm_place\", \"adpm_dial\");" +
                                        "akit.ValueChange(\"adppl_dial\", \"mark_freepl_margin\", \"" + SMargin + "\");" +
                                        "akit.ValueChange(\"adppl_dial\", \"mark_freepl_min\", \"" + MinMargin + "\");" +
                                        "akit.ValueChange(\"adppl_dial\", \"mk_quart_1\", \"1\");" +
                                        "akit.ValueChange(\"adppl_dial\", \"mk_quart_2\", \"2\");" +
                                        "akit.ValueChange(\"adppl_dial\", \"mk_quart_3\", \"4\");" +
                                        "akit.ValueChange(\"adppl_dial\", \"mk_quart_4\", \"8\");" +
                                        "akit.PushButton(\"mkpl_modify\", \"adppl_dial\");" +
                                        "akit.PushButton(\"mkpl_apply\", \"adppl_dial\");" +
                                        "akit.PushButton(\"mkpl_ok\", \"adppl_dial\");" +
                                        "akit.PushButton(\"apm_modify\", \"adpm_dial\");" +
                                        "akit.PushButton(\"apm_apply\", \"adpm_dial\");" +
                                        "akit.PushButton(\"apm_ok\", \"adpm_dial\");" +

                                        "akit.PushButton(\"gr_adraw_smark\", \"adraw_dial\");" +
                                        "akit.TableSelect(\"adsm_dial\", \"gr_mark_selected_elements\", 1, 2, 3, 4, 5, 6, 7);" +
                                        "akit.ValueChange(\"adsm_dial\", \"height\", \"" + BTextH1 + " \");" +
                                        "akit.TabChange(\"adsm_dial\", \"Container_239\", \"gr_mark_general_tab\");" +
                                        "akit.PushButton(\"gr_dsm_place\", \"adsm_dial\");" +
                                        "akit.ValueChange(\"adspl_dial\", \"mark_freepl_margin\", \"" + SMargin + "\");" +
                                        "akit.ValueChange(\"adspl_dial\", \"mark_freepl_min\", \"" + MinMargin + "\");" +
                                        "akit.ValueChange(\"adspl_dial\", \"mk_quart_1\", \"1\");" +
                                        "akit.ValueChange(\"adspl_dial\", \"mk_quart_2\", \"2\");" +
                                        "akit.ValueChange(\"adspl_dial\", \"mk_quart_3\", \"4\");" +
                                        "akit.ValueChange(\"adspl_dial\", \"mk_quart_4\", \"8\");" +
                                        "akit.PushButton(\"mkpl_modify\", \"adspl_dial\");" +
                                        "akit.PushButton(\"mkpl_apply\", \"adspl_dial\");" +
                                        "akit.PushButton(\"mkpl_ok\", \"adspl_dial\");" +
                                        "akit.PushButton(\"dsm_modify\", \"adsm_dial\");" +
                                        "akit.PushButton(\"dsm_apply\", \"adsm_dial\");" +
                                        "akit.PushButton(\"dsm_ok\", \"adsm_dial\");" +

                                        "akit.PushButton(\"gr_adraw_ok\", \"adraw_dial\");" +

                                     "}}}";

            //Save to file
            File.WriteAllText(Path.Combine(MacrosPath, Name), script2);
            //Run it at Tekla Structures application
            Tekla.Structures.Model.Operations.Operation.RunMacro("..\\" + Name);
        }

        private void InsertMark()
        {
            string Name = "InserMarkAb";//Temporary file name.
            string MacrosPath = string.Empty;//would store Path to script
            Tekla.Structures.TeklaStructuresSettings.GetAdvancedOption("XS_MACRO_DIRECTORY", ref MacrosPath);//Find out where is actual macro directory.
            if (MacrosPath.IndexOf(';') > 0) { MacrosPath = MacrosPath.Remove(MacrosPath.IndexOf(';')); }

            string path = MacrosPath.Replace("\\\\", "\\");
            if (!Directory.Exists(path))
                Directory.CreateDirectory(path);


            //Create a script as string
            string script2 = "namespace Tekla.Technology.Akit.UserScript" +
                             "{" +
                             " public class Script" +
                                 "{" +
                                     " public static void Run(Tekla.Technology.Akit.IScript akit)" +
                                     " {" +

                                         @"akit.Callback(""acmd_create_marks_selected"", """", ""View_10 window_1"");" +

                                     "}}}";


            //Save to file
            File.WriteAllText(Path.Combine(MacrosPath, Name), script2);
            //Run it at Tekla Structures application
            Tekla.Structures.Model.Operations.Operation.RunMacro("..\\" + Name);


        }
        #endregion

        public List<TSD.DrawingObject> GetCurrentViewObject(TSD.View CurrView, Type[] type)
        {
            List<TSD.DrawingObject> RetObjList = new List<DrawingObject>();
            try
            {
                DrawingObjectEnumerator DobjEnum = CurrView.GetAllObjects(type);

                foreach (TSD.DrawingObject Dobj in DobjEnum) RetObjList.Add(Dobj);

            }
            catch (Exception ex)
            { }

            return RetObjList;

        }

        public bool IsPLInsideAABB(AABB aab1, PointList RefPList)
        {
            bool check = false;

            foreach (Point p in RefPList)
            {
                if (aab1.IsInside(new Point(p.X, p.Y)))
                    check = true;
                else
                    check = false;

            }


            return check;

        }

        public bool IsSideBolt(TSM.ModelObject Mobj, BoltGroup boltG)
        {
            bool check = true;
            try
            {
                string BraceProType = "";
                Mobj.GetReportProperty("PROFILE_TYPE", ref BraceProType);
                double AngWidth = 15;

                Point p1 = new Point((Mobj as TSM.Part).GetSolid().MinimumPoint.X, (Mobj as TSM.Part).GetSolid().MinimumPoint.Y);
                Point p2 = new Point((Mobj as TSM.Part).GetSolid().MinimumPoint.X, (Mobj as TSM.Part).GetSolid().MaximumPoint.Y);
                Point p3 = new Point((Mobj as TSM.Part).GetSolid().MaximumPoint.X, (Mobj as TSM.Part).GetSolid().MaximumPoint.Y);
                Point p4 = new Point((Mobj as TSM.Part).GetSolid().MaximumPoint.X, (Mobj as TSM.Part).GetSolid().MinimumPoint.Y);

                if (BraceProType == "I" || BraceProType == "U" || BraceProType == "T")
                    Mobj.GetReportProperty("PROFILE.FLANGE_THICKNESS", ref AngWidth);
                else if (BraceProType == "RO" || BraceProType == "M" || BraceProType == "B")
                    Mobj.GetReportProperty("PROFILE.PLATE_THICKNESS", ref AngWidth);
                else if (BraceProType == "L")
                    Mobj.GetReportProperty("PROFILE.FLANGE_THICKNESS_1", ref AngWidth);
                else
                    Mobj.GetReportProperty("PROFILE.FLANGE_THICKNESS", ref AngWidth);

                double minby = p1.Y + AngWidth;
                double maxby = p2.Y - AngWidth;
                double minbx = p1.X + AngWidth;
                double maxbx = p3.X - AngWidth;
                PointList bList = ConvertArrayListToPointList(boltG.BoltPositions);
                if (bList.Count > 0)
                {
                    Point bcent = null;

                    if (bList.Count == 1)
                        bcent = bList[0];
                    else
                        bcent = CenterPoint(new Point(MinX(bList).X, MinY(bList).Y), new Point(MaxX(bList).X, MaxY(bList).Y));


                    if (IsHorzObj(Mobj))
                    {
                        if (bcent.Y > minby && bcent.Y < maxby)
                            check = false;
                    }
                    else
                    {
                        if (bcent.X > minbx && bcent.X < maxbx)
                            check = false;
                    }
                }
            }
            catch (Exception) { }
            return check;
        }

        public string GetXmlNodeValue(string file, string AttrName)
        {
            string Value = null;
            try
            {
                XmlDocument doc = new XmlDocument();
                doc.Load(file);
                XmlNode xnod = doc.DocumentElement;
                foreach (XmlNode node in doc.DocumentElement.ChildNodes)
                {
                    if (node.Name == AttrName || node.Name.Contains(AttrName))
                        Value = node.InnerText;
                }

            }
            catch (Exception ex) { }

            return Value;
        }

        public bool IsLeftSide(TSM.Part bem1, TSM.Part Mbem)
        {
            Point pp1 = new Point(bem1.GetSolid().MinimumPoint.X, bem1.GetSolid().MinimumPoint.Y);
            Point centMP = CenterPoint(Mbem.GetSolid().MinimumPoint, Mbem.GetSolid().MaximumPoint);
            if (IsEqualOrLess(pp1.X, Mbem.GetSolid().MinimumPoint.X) || IsEqualOrLess(pp1.X, centMP.X))
                return true;
            else
                return false;
        }

        public bool IsRightSide(TSM.Part bem1, TSM.Part Mbem)
        {
            Point pp3 = new Point(bem1.GetSolid().MaximumPoint.X, bem1.GetSolid().MaximumPoint.Y);
            Point centMP = CenterPoint(Mbem.GetSolid().MinimumPoint, Mbem.GetSolid().MaximumPoint);
            if (IsEqualOrGreater(pp3.X, Mbem.GetSolid().MaximumPoint.X) || IsEqualOrGreater(pp3.X, centMP.X))
                return true;
            else
                return false;
        }

        public PointList GetBoolHoleList(TSM.Part bem1)
        {
            AABB aab = GetAABB(bem1);
            PointList PtHoleList = new PointList();
            ModelObjectEnumerator MoEnum = bem1.GetBooleans();
            int chamcount = 0;

            while (MoEnum.MoveNext())
            {
                if (MoEnum.Current is BooleanPart)
                {
                    TSM.Part bpart = (MoEnum.Current as BooleanPart).OperativePart;
                    PointList Refp = ConvertArrayListToPointList(bpart.GetReferenceLine(false));
                    if (bpart is ContourPlate)
                    {
                        foreach (TSM.ContourPoint pts in (bpart as ContourPlate).Contour.ContourPoints)
                        {
                            if (pts.Chamfer.Type != TSM.Chamfer.ChamferTypeEnum.CHAMFER_ARC_POINT)
                                chamcount++;
                        }
                    }
                    if (bpart is PolyBeam)
                    {
                        foreach (TSM.ContourPoint pts in (bpart as PolyBeam).Contour.ContourPoints)
                        {
                            if (pts.Chamfer.Type != TSM.Chamfer.ChamferTypeEnum.CHAMFER_ARC_POINT)
                                chamcount++;
                        }
                    }

                    if (IsInsideAABB(aab, Refp) && chamcount >= 2)
                    {
                        PtHoleList.Add(CenterPoint(MinXY(Refp, MinY(Refp).Y), MaxXY(Refp, MaxY(Refp).Y)));
                        //break;
                    }

                }

            }

            return PtHoleList;

        }

        public bool IsDiagonalVector(Vector vect)
        {
            vect = vect.GetNormal();
            vect = new Vector(Math.Round(vect.X, 4), Math.Round(vect.Y, 4), Math.Round(vect.Z, 4));

            if (vect.X != 0 && vect.Y != 0)
                return true;
            else
                return false;
        }

        public Point GetCenterPointByPart(TSM.Part part)
        {
            return CenterPoint(part.GetSolid().MinimumPoint, part.GetSolid().MaximumPoint);
        }

        public void ViewLayoutModify()
        {
            string Name = "ViewLayoutModify";//Temporary file name.
            string MacrosPath = string.Empty;//would store Path to script
            Tekla.Structures.TeklaStructuresSettings.GetAdvancedOption("XS_MACRO_DIRECTORY", ref MacrosPath);//Find out where is actual macro directory.
            if (MacrosPath.IndexOf(';') > 0) { MacrosPath = MacrosPath.Remove(MacrosPath.IndexOf(';')); }

            string path = MacrosPath.Replace("\\\\", "\\");
            if (!Directory.Exists(path))
                Directory.CreateDirectory(path);

            //Create a script as string
            string script2 = "namespace Tekla.Technology.Akit.UserScript" +
                             "{" +
                             " public class Script" +
                                 "{" +
                                     " public static void Run(Tekla.Technology.Akit.IScript akit)" +
                                     " {" +
                                            @"akit.Callback(""acmd_display_selected_drawing_object_dialog"", """", ""main_frame"");" +
                                            @"akit.PushButton(""gr_adraw_layout"", ""adraw_dial"");" +
                                            @"akit.PushButton(""dl_modify"", ""adl_dial"");" +
                                            @"akit.PushButton(""dl_apply"", ""adl_dial"");" +
                                            @"akit.PushButton(""dl_ok"", ""adl_dial"");" +
                                            @"akit.PushButton(""gr_adraw_apply"", ""adraw_dial"");" +
                                            @"akit.PushButton(""gr_adraw_ok"", ""adraw_dial"");" +

                                     "}}}";


            //Save to file
            File.WriteAllText(Path.Combine(MacrosPath, Name), script2);
            //Run it at Tekla Structures application
            Tekla.Structures.Model.Operations.Operation.RunMacro("..\\" + Name);
        }

        public void SetLayoutSheetSizeChange(string Layout, string TLayout)
        {
            string Name = "SetLayout";//Temporary file name.
            string MacrosPath = string.Empty;//would store Path to script
            Tekla.Structures.TeklaStructuresSettings.GetAdvancedOption("XS_MACRO_DIRECTORY", ref MacrosPath);//Find out where is actual macro directory.
            if (MacrosPath.IndexOf(';') > 0) { MacrosPath = MacrosPath.Remove(MacrosPath.IndexOf(';')); }

            string path = MacrosPath.Replace("\\\\", "\\");
            if (!Directory.Exists(path))
                Directory.CreateDirectory(path);

            //Create a script as string
            string script2 = "namespace Tekla.Technology.Akit.UserScript" +
                             "{" +
                             " public class Script" +
                                 "{" +
                                     " public static void Run(Tekla.Technology.Akit.IScript akit)" +
                                     " {" +
                                            "akit.Callback(\"acmd_display_selected_drawing_object_dialog\", \"\", \"main_frame\");" +
                                            "akit.PushButton(\"gr_adraw_layout\", \"adraw_dial\");" +

                                            "akit.PushButton(\"dl_on_off\", \"adl_dial\");" +
                                            "akit.ValueChange(\"adl_dial\", \"gr_layout\", \"" + Layout + "\");" +
                                            "akit.ValueChange(\"adl_dial\", \"gr_dl_sheet\", \"" + TLayout + "\");" +
                                            "akit.ValueChange(\"adl_dial\", \"gr_dl_size_en\", \"1\");" +
                                            "akit.PushButton(\"dl_modify\", \"adl_dial\");" +
                                            "akit.PushButton(\"dl_apply\", \"adl_dial\");" +
                                            "akit.PushButton(\"dl_ok\", \"adl_dial\");" +
                                            "akit.PushButton(\"gr_adraw_apply\", \"adraw_dial\");" +
                                            "akit.PushButton(\"gr_adraw_ok\", \"adraw_dial\");" +

                                     "}}}";


            //Save to file
            File.WriteAllText(Path.Combine(MacrosPath, Name), script2);
            //Run it at Tekla Structures application
            Tekla.Structures.Model.Operations.Operation.RunMacro("..\\" + Name);
        }

        //Common conti
        public PointList GetExtBoltList(TSM.ModelObject Brace1)
        {
            PointList ExtBList = new PointList();
            //PointList FBList1 = new PointList();
            List<int> FBList = new List<int>();
            //FBList.AddRange(conti.TFBlist);
            //FBList.AddRange(conti.BFBlist);
            PointList FBList1 = new PointList();

            FBList1.AddRange(GetBoltPlist(false, Brace1));

            if (FBList1.Count == 0 || (!(dist.PointToPoint(new Point(MinX(FBList1).X, 0), new Point((Brace1 as TSM.Part).GetSolid().MinimumPoint.X, 0)) <= 152.4) || !(dist.PointToPoint(new Point(MaxX(FBList1).X, 0), new Point((Brace1 as TSM.Part).GetSolid().MaximumPoint.X, 0)) <= 152.4)))   //if MP(Brace) bolts not present
            {
                ArrayList secList = (Brace1 as TSM.Part).GetAssembly().GetSecondaries();
                if (secList.Count > 0)
                {
                    foreach (TSM.Part spart in secList)
                    {
                        FBList1.AddRange(GetBoltPlist(false, spart));
                    }
                }
            }
            //foreach (int id in FBList1)
            //{
            //    TSM.ModelObject mobj = new Model().SelectModelObject(new Identifier(id));
            //    BoltGroup BGrp = mobj as BoltGroup;
            //    FBList1.AddRange(ConvertArrayListToPointList(BGrp.BoltPositions));
            //}

            if (FBList1.Count > 0)
            {
                if (dist.PointToPoint(new Point(MinX(FBList1).X, 0), new Point((Brace1 as TSM.Part).GetSolid().MinimumPoint.X, 0)) <= 152.4 || IsEqualOrLess(MinX(FBList1).X, (Brace1 as TSM.Part).GetSolid().MinimumPoint.X))
                {
                    ExtBList.Add(MinYX(FBList1, MinX(FBList1).X));
                    ExtBList.Add(MaxYX(FBList1, MinX(FBList1).X));
                }
                if (dist.PointToPoint(new Point(MaxX(FBList1).X, 0), new Point((Brace1 as TSM.Part).GetSolid().MaximumPoint.X, 0)) <= 152.4 || IsEqualOrGreater(MaxX(FBList1).X, (Brace1 as TSM.Part).GetSolid().MaximumPoint.X))
                {
                    ExtBList.Add(MinYX(FBList1, MaxX(FBList1).X));
                    ExtBList.Add(MaxYX(FBList1, MaxX(FBList1).X));
                }

            }

            return ExtBList;

        }

        //For Brace cs new method
        public PointList GetExtBoltList1(TSM.ModelObject Brace1, string ExtremeBolt)
        {
            PointList ExtBList = new PointList();
            //PointList FBList1 = new PointList();
            List<int> FBList = new List<int>();
            //FBList.AddRange(conti.TFBlist);
            //FBList.AddRange(conti.BFBlist);
            PointList FBList1 = new PointList();

            FBList1.AddRange(GetBoltPlist(false, Brace1));

            if (FBList1.Count == 0 || (!(dist.PointToPoint(new Point(MinX(FBList1).X, 0), new Point((Brace1 as TSM.Part).GetSolid().MinimumPoint.X, 0)) <= 152.4) || !(dist.PointToPoint(new Point(MaxX(FBList1).X, 0), new Point((Brace1 as TSM.Part).GetSolid().MaximumPoint.X, 0)) <= 152.4)))   //if MP(Brace) bolts not present
            {
                ArrayList secList = (Brace1 as TSM.Part).GetAssembly().GetSecondaries();
                if (secList.Count > 0)
                {
                    foreach (TSM.Part spart in secList)
                    {
                        FBList1.AddRange(GetBoltPlist(false, spart));
                    }
                }
            }
            else
            {
                if (ExtremeBolt == "2")
                {
                    ArrayList secList = (Brace1 as TSM.Part).GetAssembly().GetSecondaries();
                    if (secList.Count > 0)
                    {
                        foreach (TSM.Part spart in secList)
                        {
                            FBList1.AddRange(GetBoltPlist(false, spart));
                        }
                    }
                }
            }
            //foreach (int id in FBList1)
            //{
            //    TSM.ModelObject mobj = new Model().SelectModelObject(new Identifier(id));
            //    BoltGroup BGrp = mobj as BoltGroup;
            //    FBList1.AddRange(ConvertArrayListToPointList(BGrp.BoltPositions));
            //}

            if (FBList1.Count > 0)
            {
                if (dist.PointToPoint(new Point(MinX(FBList1).X, 0), new Point((Brace1 as TSM.Part).GetSolid().MinimumPoint.X, 0)) <= 152.4 || IsEqualOrLess(MinX(FBList1).X, (Brace1 as TSM.Part).GetSolid().MinimumPoint.X))
                {
                    ExtBList.Add(MinYX(FBList1, MinX(FBList1).X));
                    ExtBList.Add(MaxYX(FBList1, MinX(FBList1).X));
                }
                if (dist.PointToPoint(new Point(MaxX(FBList1).X, 0), new Point((Brace1 as TSM.Part).GetSolid().MaximumPoint.X, 0)) <= 152.4 || IsEqualOrGreater(MaxX(FBList1).X, (Brace1 as TSM.Part).GetSolid().MaximumPoint.X))
                {
                    ExtBList.Add(MinYX(FBList1, MaxX(FBList1).X));
                    ExtBList.Add(MaxYX(FBList1, MaxX(FBList1).X));
                }

            }

            return ExtBList;

        }

        public void Arrowcheck(int ind, Text text)
        {
            if (ind == 1)
                text.Attributes.ArrowHead.Head = ArrowheadTypes.FilledArrow;
            else if (ind == 2)
                text.Attributes.ArrowHead.Head = ArrowheadTypes.LineArrow;
            else if (ind == 3)
                text.Attributes.ArrowHead.Head = ArrowheadTypes.CircleArrow;
            else if (ind == 15)
                text.Attributes.ArrowHead.Head = ArrowheadTypes.FilledCircleArrow;
            else
            {
                if (ind == 4 || ind == 0)
                    ind = 16;
                else if (ind == 5)
                    ind = 17;
                else if (ind == 6)
                    ind = 18;
                else if (ind == 7)
                    ind = 19;
                else if (ind == 8)
                    ind = 20;
                else if (ind == 9)
                    ind = 21;
                else if (ind == 10)
                    ind = 22;
                else if (ind == 11)
                    ind = 23;
                else if (ind == 12)
                    ind = 24;
                else if (ind == 13)
                    ind = 32;
                else if (ind == 14)
                    ind = 48;
                else if (ind == 15)
                    ind = 49;
                else if (ind == 16)
                    ind = 50;
                else if (ind == 17)
                    ind = 101;
                else if (ind == 18)
                    ind = 102;
                else if (ind == 19)
                    ind = 110;
                else if (ind == 20)
                    ind = 200;

                Type head = text.Attributes.ArrowHead.GetType();
                System.Reflection.PropertyInfo propertyInfo = head.GetProperty("Head", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.Public);
                var value = propertyInfo.GetValue(text.Attributes.ArrowHead, null);
                if (value != null)
                {
                    propertyInfo.SetValue(text.Attributes.ArrowHead, ind);
                }
            }
        }

        #region Bolt Size For Mark
        public string[,] BoltSlotSizeInch = {
                                               { "0.5"  , "0", "0.125" , "0.125" , "0.6875"},  // 1/2       //  Bolt Dia   Tolerance(STDHolesize)   OVSHoleSize   SSLHoleSize  LSLHoleSize
                                               { "0.625", "0", "0.1875", "0.1875", "0.875" },  // 5/8       //  0.5         0                       0.125         0.125        0.6875
                                               { "0.75" , "0", "0.1875", "0.1875", "1.0625"},  // 3/4
                                               { "0.875", "0", "0.1875", "0.1875", "1.25"  },  // 7/8
                                               { "1"    , "0", "0.25"  , "0.25"  , "1.4375"},  // 1
                                               { "1.125", "0", "0.3125", "0.3125", "1.625" },  // 1 1/8
                                               { "1.25" , "0", "0.3125", "0.3125", "1.8125"},  // 1 1/4
                                               { "1.5"  , "0", "0.3125", "0.3125", "2.1875"},  // 1 1/2
                                               { "1.75" , "0", "0.3125", "0.3125", "2.5625"}   // 1 3/4
                                                            };
        public string[,] BoltSlotSizeImpMetric = {
                                               { "12.7" , "0", "3.175" , "3.175" , "17.4625"},  // 1/2
                                               { "15.88", "0", "4.7625", "4.7625", "22.225" },  // 5/8
                                               { "19.05", "0", "4.7625", "4.7625", "26.9875"},  // 3/4
                                               { "22.23", "0", "4.7625", "4.7625", "31.75"  },  // 7/8
                                               { "25.4" , "0", "6.35"  , "6.35"  , "36.5125"},  // 1
                                               { "28.58", "0", "7.9375", "7.9375", "41.275" },  // 1 1/8
                                               { "31.75" , "0", "7.9375", "7.9375", "46.0375"},  // 1 1/4
                                               { "34.92" , "0", "7.9375", "7.9375", "50.0000"},  // 1 3/8  // 50.0000 check
                                               { "38.1"  , "0", "7.9375", "7.9375", "55.5625"},  // 1 1/2
                                               { "44.45" , "0", "7.9375", "7.9375", "65.0875"},  // 1 3/4

                                               { "0.5" , "0", "3.175" , "3.175" , "17.4625"},  // 1/2
                                               { "0.625", "0", "4.7625", "4.7625", "22.225" },  // 5/8
                                               { "0.75", "0", "4.7625", "4.7625", "26.9875"},  // 3/4
                                               { "0.875", "0", "4.7625", "4.7625", "31.75"  },  // 7/8
                                               { "1" , "0", "6.35"  , "6.35"  , "36.5125"},  // 1
                                               { "1.125", "0", "7.9375", "7.9375", "41.275" },  // 1 1/8
                                               { "1.25" , "0", "7.9375", "7.9375", "46.0375"},  // 1 1/4
                                               { "1.5"  , "0", "7.9375", "7.9375", "55.5625"},  // 1 1/2
                                               { "1.75" , "0", "7.9375", "7.9375", "65.0875"}   // 1 3/4
                                                            };
        public string[,] BoltSlotSizeMetric = {// To be updated this data
                                               { "6" , "0", "3 ", "3" , "12"},  // M6  // Pl check
                                               { "8" , "0", "3" , "3" , "13"},  // M8
                                               { "10", "0", "3" , "3" , "15"},  // M10
                                               { "12", "0", "3" , "3" , "17"},  // M12
                                               { "14", "0", "5" , "5" , "20"},  // M14
                                               { "16", "0", "5" , "5" , "22"},  // M16
                                               { "20", "0", "5" , "5" , "27"},  // M20
                                               { "22", "0", "5" , "5" , "32"},  // M22
                                               { "24", "0", "5" , "5" , "32"},  // M24
                                               { "27", "0", "6" , "6" , "37"},  // M27
                                               { "30", "0", "8" , "8" , "41"},  // M30
                                               { "32", "0", "8" , "8" , "46"},  // M30
                                               { "36", "0", "8" , "8" , "65"}   // M36
                                                            };
        public string CheckBoltSlotSize(double BoltSize, BoltGroup.BoltHoleTypeEnum bhtype, double SlottedHoleX, double SlottedHoleY)
        {
            string UserText = "";
            string[,] strbolt = BoltSlotSizeImpMetric;
            int r = strbolt.GetUpperBound(0);
            int c = strbolt.GetUpperBound(1);
            for (int i = 0; i <= strbolt.GetUpperBound(0); i++)
            {
                double BSizeIM = Math.Round(Convert.ToDouble(strbolt[i, 0]), 2);
                if (BSizeIM == Math.Round(BoltSize, 2))
                {
                    for (int j = 1; j <= strbolt.GetUpperBound(1); j++)
                    {
                        double BSlotIM = Math.Round(Convert.ToDouble(strbolt[i, j]), 2);
                        if ((BSlotIM == Math.Round(SlottedHoleX, 2) || BSlotIM == Math.Round(SlottedHoleY, 2)) && bhtype == BoltGroup.BoltHoleTypeEnum.HOLE_TYPE_SLOTTED && SlottedHoleX == 0 && SlottedHoleY == 0)
                            UserText = "(STD)";
                        else if ((BSlotIM == Math.Round(SlottedHoleX, 2) || BSlotIM == Math.Round(SlottedHoleY, 2)) && bhtype == BoltGroup.BoltHoleTypeEnum.HOLE_TYPE_OVERSIZED && SlottedHoleX == 0 && SlottedHoleY == 0)
                            UserText = "(STD)";
                        else if ((BSlotIM == Math.Round(SlottedHoleX, 2) || BSlotIM == Math.Round(SlottedHoleY, 2)) && bhtype == BoltGroup.BoltHoleTypeEnum.HOLE_TYPE_OVERSIZED && (SlottedHoleX != 0 || SlottedHoleY != 0))
                            UserText = "(OVS)";
                        else if ((BSlotIM == Math.Round(SlottedHoleX, 2) || BSlotIM == Math.Round(SlottedHoleY, 2)) && bhtype == BoltGroup.BoltHoleTypeEnum.HOLE_TYPE_SLOTTED && (SlottedHoleX != 0 || SlottedHoleY != 0))
                        {
                            if (j == 3)
                                UserText = "(SSL)";
                            else if (j == 4)
                                UserText = "(LSL)";
                        }
                        double cv = Math.Round(SlottedHoleY, 2);
                    }
                }
            }

            return UserText;
        }

        #endregion

        public Dictionary<CoordinateSystem, PointList> GetBoltPlistFUP(TSD.View CurrView, bool IsGalvaOn, TSM.ModelObject Mobj)
        {
            Dictionary<CoordinateSystem, PointList> DList = new Dictionary<CoordinateSystem, PointList>();

            try
            {
                ModelObjectEnumerator Benum = (Mobj as TSM.Part).GetBolts();
                List<BoltGroup> BGList = new List<BoltGroup>();
                foreach (BoltGroup bolt in Benum)
                {
                    if (bolt.BoltPositions.Count > 0)
                    {
                        if ((!IsGalvaOn && IsGalvHole(bolt)) || IsShopBolt(bolt) || IsShipBolt(bolt)) { }
                        else
                            BGList.Add(bolt);
                    }
                }
                int loopnum = BGList.Count;
                for (int i = 0; i < loopnum; i++)
                {
                    CoordinateSystem mCord = BGList[0].GetCoordinateSystem();
                    Tekla.Structures.Geometry3d.Line l0 = new Tekla.Structures.Geometry3d.Line(BGList[0].GetSolid().MinimumPoint, BGList[0].GetSolid().MaximumPoint);
                    //DrawLine(CurrView, BGList[0].GetSolid().MinimumPoint, BGList[0].GetSolid().MaximumPoint);
                    PointList BList = new PointList();
                    for (int j = 0; j < BGList.Count; j++)
                    {
                        CoordinateSystem sCord = BGList[j].GetCoordinateSystem();
                        Tekla.Structures.Geometry3d.Line l1 = new Tekla.Structures.Geometry3d.Line(BGList[j].GetSolid().MinimumPoint, BGList[j].GetSolid().MaximumPoint);
                        // DrawLine(CurrView, BGList[j].GetSolid().MinimumPoint, BGList[j].GetSolid().MaximumPoint);
                        if ((mCord.AxisX == sCord.AxisX && mCord.AxisY == sCord.AxisY) || (l0.Direction == l1.Direction))
                        {
                            BList.AddRange(ConvertArrayListToPointList(BGList[j].BoltPositions));
                            BGList.Remove(BGList[j]);
                        }
                    }
                    if (BList.Count > 0)
                        DList.Add(mCord, BList);

                }

                //foreach(var temp in DList)
                //{
                //   PointList tList= temp.Key;
                //   CoordinateSystem cd = temp.Value;
                //}
                //OR
                //foreach(KeyValuePair<CoordinateSystem,PointList> item in DList)
                //{
                //    CoordinateSystem cord= item.Key;
                //    PointList pList = item.Value;
                //}

            }
            catch (Exception ex)
            { }

            return DList;
        }

        public List<BoltGroup> GetBoltArrlist(bool IsGalvaOn, TSM.ModelObject Mobj)
        {
            List<BoltGroup> blst = new List<BoltGroup>();
            ModelObjectEnumerator Benum = (Mobj as TSM.Part).GetBolts();

            foreach (BoltGroup bolt in Benum)
            {
                if ((!IsGalvaOn && IsGalvHole(bolt)) || IsShipBolt(bolt))
                { }
                else
                    blst.Add(bolt);
            }

            return blst;
        }

        public PointList GetBoltPlist(bool IsGalvaOn, TSM.ModelObject Mobj)
        {
            PointList ptList = new PointList();
            try
            {
                ModelObjectEnumerator Benum = (Mobj as TSM.Part).GetBolts();

                foreach (BoltGroup bolt in Benum)
                {
                    if (bolt.BoltPositions.Count > 0)
                    {
                        if ((!IsGalvaOn && IsGalvHole(bolt)) || IsShipBolt(bolt))
                        { }
                        else
                            ptList.AddRange(ConvertArrayListToPointList(bolt.BoltPositions));
                    }
                }
            }
            catch (Exception ex)
            { }

            return ptList;
        }

        public bool IsEqualQuad(Vector v1, Vector v2)
        {
            bool check = false;
            try
            {
                if ((v1.X > 0 && v1.Y == 0) && (v2.X > 0 && v2.Y == 0)) { check = true; }
                else if ((v1.X < 0 && v1.Y == 0) && (v2.X < 0 && v2.Y == 0)) { check = true; }
                else if ((v1.X == 0 && v1.Y > 0) && (v2.X == 0 && v2.Y > 0)) { check = true; }
                else if ((v1.X == 0 && v1.Y < 0) && (v2.X == 0 && v2.Y < 0)) { check = true; }
                else if ((v1.X > 0 && v1.Y > 0) && (v2.X > 0 && v2.Y > 0)) { check = true; }
                else if ((v1.X < 0 && v1.Y > 0) && (v2.X < 0 && v2.Y > 0)) { check = true; }
                else if ((v1.X < 0 && v1.Y < 0) && (v2.X < 0 && v2.Y < 0)) { check = true; }
                else if ((v1.X > 0 && v1.Y < 0) && (v2.X > 0 && v2.Y < 0)) { check = true; }

            }
            catch (Exception) { }
            return check;
        }

        public int GetCageDir(TSM.ModelObject mobj) //Left=1 / Top=2 / Right=3 / Bottom=4
        {
            int dir = 0;
            try
            {
                if (!(mobj is TSM.Beam) && !IsPlateSideView(mobj as TSM.Part))
                {
                    Point CentP = CenterPoint((mobj as TSM.Part).GetSolid().MinimumPoint, (mobj as TSM.Part).GetSolid().MaximumPoint);

                    List<ContourPoint> CPList = new List<ContourPoint>();
                    if (mobj is PolyBeam)
                    {
                        foreach (ContourPoint cpt in (mobj as PolyBeam).Contour.ContourPoints)
                            CPList.Add(cpt);
                    }
                    else if (mobj is ContourPlate)
                    {
                        foreach (ContourPoint cpt in (mobj as ContourPlate).Contour.ContourPoints)
                            CPList.Add(cpt);
                    }

                    if (IsHorzObj(mobj)) //Dir-> T/B
                    {
                        foreach (ContourPoint cpt in CPList)
                        {
                            if ((cpt.Chamfer.Type == Chamfer.ChamferTypeEnum.CHAMFER_ARC_POINT || (cpt.Chamfer.Type == Chamfer.ChamferTypeEnum.CHAMFER_ROUNDING && cpt.Chamfer.X > 100)) && IsEqualOrGreater(cpt.Y, CentP.Y))
                                dir = 2; //Top
                            else if ((cpt.Chamfer.Type == Chamfer.ChamferTypeEnum.CHAMFER_ARC_POINT || (cpt.Chamfer.Type == Chamfer.ChamferTypeEnum.CHAMFER_ROUNDING && cpt.Chamfer.X > 100)) && IsLess(cpt.Y, CentP.Y))
                                dir = 4; //Bottom
                        }
                    }
                    else //Dir-> L/R
                    {
                        foreach (ContourPoint cpt in CPList)
                        {
                            if ((cpt.Chamfer.Type == Chamfer.ChamferTypeEnum.CHAMFER_ARC_POINT || (cpt.Chamfer.Type == Chamfer.ChamferTypeEnum.CHAMFER_ROUNDING && cpt.Chamfer.X > 100)) && IsEqualOrLess(cpt.X, CentP.X))
                                dir = 1; //Left
                            else if ((cpt.Chamfer.Type == Chamfer.ChamferTypeEnum.CHAMFER_ARC_POINT || (cpt.Chamfer.Type == Chamfer.ChamferTypeEnum.CHAMFER_ROUNDING && cpt.Chamfer.X > 100)) && IsGreater(cpt.X, CentP.X))
                                dir = 3; //Right
                        }
                    }
                }
            }
            catch (Exception) { }

            return dir;
        }

        public List<TSM.Part> GetConnWPart(TSM.Part spart)
        {
            List<TSM.Part> ConnWPList = new List<TSM.Part>();
            List<int> IdlIst = new List<int>();
            try
            {
                TSM.Part MPart = GetMP(spart);
                ModelObjectEnumerator WEnum = spart.GetWelds();
                foreach (TSM.BaseWeld weld in WEnum)
                {
                    if (weld.MainObject.Identifier.ID != MPart.Identifier.ID && weld.SecondaryObject.Identifier.ID != MPart.Identifier.ID)
                    {
                        if (weld.MainObject.Identifier.ID != spart.Identifier.ID && !IdlIst.Contains(weld.MainObject.Identifier.ID))
                        {
                            ConnWPList.Add(weld.MainObject as TSM.Part);
                            IdlIst.Add(weld.MainObject.Identifier.ID);
                        }
                        else if (weld.SecondaryObject.Identifier.ID != spart.Identifier.ID && !IdlIst.Contains(weld.SecondaryObject.Identifier.ID))
                        {
                            ConnWPList.Add(weld.SecondaryObject as TSM.Part);
                            IdlIst.Add(weld.SecondaryObject.Identifier.ID);
                        }
                    }

                }
            }
            catch (Exception) { }
            return ConnWPList;
        }

        public bool IsConnectedPart(TSM.Part spart, TSM.Part MPart)
        {
            bool check = false;
            try
            {
                TSM.Part MPart1 = GetMP(spart);
                if (MPart1.Identifier.ID == MPart.Identifier.ID)
                    check = true;
                else
                    check = false;
            }
            catch (Exception) { }
            return check;
        }


        public List<int> GetRexBoxPartList(TSD.View cView, List<int> ContiPartList)
        {
            List<int> NewContiPartList = new List<int>();

            List<int> ContiPartListTemp = new List<int>();
            ContiPartListTemp.AddRange(ContiPartList);

            if (cView.Name == "Top View1")
            {
                foreach (int id in ContiPartListTemp)
                {
                    TSM.ModelObject mbj = MyModel.SelectModelObject(new Identifier(id));
                    if (mbj is TSM.Part)
                    {
                        Point pt01 = new Point((mbj as TSM.Part).GetSolid().MinimumPoint);
                        Point pt11 = new Point((mbj as TSM.Part).GetSolid().MaximumPoint);
                        LineSegment ls = new LineSegment(pt01, pt11);
                        if ((cView.RestrictionBox.IsInside(pt01) && cView.RestrictionBox.IsInside(pt11)) || cView.RestrictionBox.IsInside(ls))
                            NewContiPartList.Add(id);
                    }
                }
            }
            else
            {
                //For Temp : Rainer Square
                NewContiPartList = new List<int>();
                NewContiPartList.AddRange(ContiPartListTemp);
            }
            return NewContiPartList;
        }

        public TSM.Part GetConnWPartHandrail(TSM.Part spart, TSM.Part MPart)
        {
            TSM.Part ConnWPList = null;
            List<int> IdlIst = new List<int>();
            try
            {
                // TSM.Part MPart = GetMP(spart);
                ModelObjectEnumerator WEnum = spart.GetWelds();

                foreach (TSM.BaseWeld weld in WEnum)
                {
                    // if (weld.MainObject.Identifier.ID != MPart.Identifier.ID && weld.SecondaryObject.Identifier.ID != MPart.Identifier.ID)
                    // {
                    if (weld.MainObject.Identifier.ID != spart.Identifier.ID && !IdlIst.Contains(weld.MainObject.Identifier.ID))
                    {
                        ConnWPList = weld.MainObject as TSM.Part;
                    }
                    else if (weld.SecondaryObject.Identifier.ID != spart.Identifier.ID && !IdlIst.Contains(weld.SecondaryObject.Identifier.ID))
                    {
                        ConnWPList = weld.SecondaryObject as TSM.Part;
                    }
                    // }

                }
                if (IsEqual(spart.GetSolid().MaximumPoint.X, MPart.GetSolid().MinimumPoint.X) || IsEqual(spart.GetSolid().MinimumPoint.X, MPart.GetSolid().MaximumPoint.X))
                {
                    ConnWPList = MPart;
                }
            }
            catch (Exception) { }
            return ConnWPList;
        }

        public List<TSM.Part> GetPenetrationCutList(TSM.Part MBeam)
        {
            List<TSM.Part> PenCList = new List<TSM.Part>();
            Point minB = new Point(MBeam.GetSolid().MinimumPoint.X, MBeam.GetSolid().MinimumPoint.Y);
            Point maxB = new Point(MBeam.GetSolid().MaximumPoint.X, MBeam.GetSolid().MaximumPoint.Y);

            ModelObjectEnumerator BoolEnum = MBeam.GetBooleans();
            while (BoolEnum.MoveNext())
            {
                if (BoolEnum.Current is BooleanPart)
                {
                    BooleanPart bPart = BoolEnum.Current as BooleanPart;
                    TSM.Part optpart = bPart.OperativePart as TSM.Part;
                    PointList contPList = ContPList(optpart);
                    Point p11 = new Point(optpart.GetSolid().MinimumPoint.X, optpart.GetSolid().MinimumPoint.Y);
                    Point p33 = new Point(optpart.GetSolid().MaximumPoint.X, optpart.GetSolid().MaximumPoint.Y);

                    if (IsEqualOrLess(p11.X, minB.X) || IsEqualOrGreater(p33.X, maxB.X)) { }
                    else
                    {
                        if (!IssameX(contPList) && !IssameY(contPList))
                        {
                            if (IsInsideAABB(GetAABB(MBeam), contPList))
                                PenCList.Add(optpart);
                        }
                    }
                }
            }
            return PenCList;
        }

        public List<int> GetPenReinfAngList(Point PenCutPt, List<int> RefPList, List<int> AngList)
        {
            List<int> PenReinfList = new List<int>();

            List<int> PLAngList = new List<int>();
            PLAngList.AddRange(RefPList);
            PLAngList.AddRange(AngList);

            foreach (int id in PLAngList)
            {
                TSM.Part Refin = (MyModel.SelectModelObject(new Identifier(id))) as TSM.Part;
                if (IsHorzObj(Refin) && IsGreater(PenCutPt.X, Refin.GetSolid().MinimumPoint.X) && IsLess(PenCutPt.X, Refin.GetSolid().MaximumPoint.X))
                    PenReinfList.Add(id);
            }

            return PenReinfList;
        }

        public List<int> GetPenStiffList(TSM.Part PenRefin, List<int> StiffList)
        {
            List<int> PenStiffList = new List<int>();
            foreach (int id in StiffList)
            {
                TSM.Part Stiff = (MyModel.SelectModelObject(new Identifier(id))) as TSM.Part;
                if (!IsHorzObj(Stiff) && IsGreater(Stiff.GetSolid().MinimumPoint.X, PenRefin.GetSolid().MinimumPoint.X) && IsLess(Stiff.GetSolid().MaximumPoint.X, PenRefin.GetSolid().MaximumPoint.X))
                    PenStiffList.Add(id);
            }

            return PenStiffList;
        }

        public int IsCirOrSqPenetration(TSM.Part PenCut, TSD.View curView)
        {
            int PenTyp = -1;
            if (curView.Name == "Front View")
            {
                int chafcount = 0;
                double chamfval = 0;
                bool IsArcChamf = false;
                TSD.PointList chfList = ContPList(PenCut);
                if (chfList.Count > 0)
                {
                    if (PenCut is PolyBeam)
                    {
                        foreach (ContourPoint cp in (PenCut as PolyBeam).Contour.ContourPoints)
                        {
                            if (cp.Chamfer.Type == TSM.Chamfer.ChamferTypeEnum.CHAMFER_ROUNDING)
                            {
                                chafcount++;
                                chamfval = cp.Chamfer.X;
                            }
                            else if (cp.Chamfer.Type == TSM.Chamfer.ChamferTypeEnum.CHAMFER_ARC_POINT)
                            {
                                chafcount++;
                                IsArcChamf = true;
                            }
                        }
                    }
                    else if (PenCut is ContourPlate)
                    {
                        foreach (ContourPoint cp in (PenCut as ContourPlate).Contour.ContourPoints)
                        {
                            if (cp.Chamfer.Type == TSM.Chamfer.ChamferTypeEnum.CHAMFER_ROUNDING)
                            {
                                chafcount++;
                                chamfval = cp.Chamfer.X;
                            }
                            else if (cp.Chamfer.Type == TSM.Chamfer.ChamferTypeEnum.CHAMFER_ARC_POINT)
                            {
                                chafcount++;
                                IsArcChamf = true;
                            }
                        }
                    }

                    double wid = MaxX(chfList).X - MinX(chfList).X;
                    double ht = MaxY(chfList).Y - MinY(chfList).Y;
                    double halfwid = (wid / 2);
                    if (chafcount == 4 && chfList.Count == 4 && IsEqual(wid, ht) && IsEqual(chamfval, halfwid))
                        PenTyp = 0;         //Circle Penetration
                    else if (chafcount >= 2 && IsArcChamf)
                        PenTyp = 0;         //Circle Penetration
                    else if (chfList.Count <= 4 && (IsEqual(wid, ht) || !IsEqual(wid, ht)))
                        PenTyp = 1;         //Sq OR Rect Penetration
                }
            }
            return PenTyp;
        }

        public int IsCirOrSqPenetration(TSM.Part PenCut, TSD.View curView, Beam mainbeam)
        {
            int PenTyp = -1;
            if (curView.Name == "Front View")
            {
                Point pt1 = new Point(mainbeam.GetSolid().MinimumPoint.X, mainbeam.GetSolid().MinimumPoint.Y);
                Point pt3 = new Point(mainbeam.GetSolid().MaximumPoint.X, mainbeam.GetSolid().MaximumPoint.Y);


                int chafcount = 0;
                double chamfval = 0;
                bool IsArcChamf = false;
                TSD.PointList chfList = ContPList(PenCut);
                if (chfList.Count > 0)
                {
                    if (PenCut is PolyBeam)
                    {
                        foreach (ContourPoint cp in (PenCut as PolyBeam).Contour.ContourPoints)
                        {
                            if (cp.Chamfer.Type == TSM.Chamfer.ChamferTypeEnum.CHAMFER_ROUNDING)
                            {
                                chafcount++;
                                chamfval = cp.Chamfer.X;
                            }
                            else if (cp.Chamfer.Type == TSM.Chamfer.ChamferTypeEnum.CHAMFER_ARC_POINT)
                            {
                                chafcount++;
                                IsArcChamf = true;
                            }
                        }
                    }
                    else if (PenCut is ContourPlate)
                    {
                        foreach (ContourPoint cp in (PenCut as ContourPlate).Contour.ContourPoints)
                        {
                            if (cp.Chamfer.Type == TSM.Chamfer.ChamferTypeEnum.CHAMFER_ROUNDING)
                            {
                                chafcount++;
                                chamfval = cp.Chamfer.X;
                            }
                            else if (cp.Chamfer.Type == TSM.Chamfer.ChamferTypeEnum.CHAMFER_ARC_POINT)
                            {
                                chafcount++;
                                IsArcChamf = true;
                            }
                        }
                    }

                    Point p1 = new Point(PenCut.GetSolid().MinimumPoint.X, PenCut.GetSolid().MinimumPoint.Y);
                    Point p3 = new Point(PenCut.GetSolid().MaximumPoint.X, PenCut.GetSolid().MaximumPoint.Y);


                    if (IsEqualOrLess(p1.X, pt1.X) || IsEqualOrGreater(p3.X, pt3.X))
                    { }
                    else
                    {
                        double wid = MaxX(chfList).X - MinX(chfList).X;
                        double ht = MaxY(chfList).Y - MinY(chfList).Y;
                        double halfwid = (wid / 2);
                        if (chafcount == 4 && chfList.Count == 4 && IsEqual(wid, ht) && IsEqual(chamfval, halfwid))
                            PenTyp = 0;         //Circle Penetration
                        else if (chafcount >= 2 && IsArcChamf)
                            PenTyp = 0;         //Circle Penetration
                        else if (chfList.Count <= 4 && (IsEqual(wid, ht) || !IsEqual(wid, ht)))
                            PenTyp = 1;         //Sq OR Rect Penetration

                    }
                }
            }
            return PenTyp;
        }

        // for Tekla 2017i please make sure about Compiling application

        public DrawingHatchColor HatchColorCheck(int ind)
        {
            DrawingHatchColor drColor = new DrawingHatchColor();

            if (ind == 0)
                drColor = DrawingHatchColor.Invisible;
            if (ind == 1)
                drColor = DrawingHatchColor.Black;
            if (ind == 2)
                drColor = DrawingHatchColor.NewLine1;
            if (ind == 3)
                drColor = DrawingHatchColor.NewLine2;
            if (ind == 4)
                drColor = DrawingHatchColor.NewLine3;
            if (ind == 5)
                drColor = DrawingHatchColor.NewLine4;
            if (ind == 6)
                drColor = DrawingHatchColor.NewLine5;
            if (ind == 7)
                drColor = DrawingHatchColor.NewLine6;
            if (ind == 8)
                drColor = DrawingHatchColor.Red;
            if (ind == 9)
                drColor = DrawingHatchColor.Green;
            if (ind == 10)
                drColor = DrawingHatchColor.Blue;
            if (ind == 11)
                drColor = DrawingHatchColor.Cyan;
            if (ind == 12)
                drColor = DrawingHatchColor.Yellow;
            if (ind == 13)
                drColor = DrawingHatchColor.Magenta;

            return drColor;
        }



        public PointList GetSurfTBoltPList(SurfaceTreatment surfT, List<BoltGroup> FBoltPt)
        {
            PointList cpList = ConvertArrayListToPointList(surfT.Polygon.ContourPoints);
            Point minx1 = new Point(MinX(cpList).X, MinY(cpList).Y);
            Point maxx1 = new Point(MaxX(cpList).X, MaxY(cpList).Y);
            AABB sab = new AABB(new Point(minx1.X, minx1.Y), new Point(maxx1.X, maxx1.Y));

            PointList SurfBoltPList = new PointList();
            foreach (BoltGroup Bgrp in FBoltPt)
            {
                PointList bList = ConvertArrayListToPointList(Bgrp.BoltPositions);
                foreach (Point p in bList)
                {
                    if (sab.IsInside(new Point(p.X, p.Y)))
                        SurfBoltPList.Add(p);
                }
            }
            return SurfBoltPList;
        }

        public bool IsBoltInsideSurfT(SurfaceTreatment surfT, PointList BoltPt)
        {
            PointList cpList = ConvertArrayListToPointList(surfT.Polygon.ContourPoints);
            Point minx1 = new Point(MinX(cpList).X, MinY(cpList).Y);
            Point maxx1 = new Point(MaxX(cpList).X, MaxY(cpList).Y);
            AABB sab = new AABB(new Point(minx1.X, minx1.Y), new Point(maxx1.X, maxx1.Y));

            bool chk = false;
            foreach (Point p in BoltPt)
            {

                if (sab.IsInside(new Point(p.X, p.Y)))
                    chk = true;
                else
                {
                    chk = false;
                    break;
                }
            }
            return chk;
        }

        public SurfaceTreatment GetSurfT(List<int> SurfTList, PointList BoltPt)
        {
            SurfaceTreatment surf1 = null;
            foreach (int id in SurfTList)
            {
                TSM.ModelObject mobj = MyModel.SelectModelObject(new Identifier(id)) as TSM.ModelObject;
                if (mobj is SurfaceTreatment)
                {
                    SurfaceTreatment surf = mobj as SurfaceTreatment;
                    PointList cpList = ConvertArrayListToPointList(surf.Polygon.ContourPoints);
                    AABB sab = new AABB(MinXY(cpList, MinY(cpList).Y), MaxXY(cpList, MaxY(cpList).Y));
                    if (IsInsideAABB(sab, BoltPt))
                    {
                        surf1 = surf;
                        break;
                    }
                }
            }
            return surf1;
        }


        public PointList ChangePints(BoltGroup bolt, ViewBase ViewB, Vector Vect)
        {
            StraightDimensionSet.StraightDimensionSetAttributes DimAtrr = new StraightDimensionSet.StraightDimensionSetAttributes("standard");

            PointList RetList = Com.PointToPointList(bolt.BoltPositions.OfType<Point>().ToList());
            Vector NewVect = Com.ChangeVector(Vect);
            StraightDimensionSet st = Com.InsertDim(ViewB, RetList, NewVect, 100, DimAtrr);
            if (st != null)
            {
                TSD.PointList NewPoints = Com.GetDimPoints(st);
                if (NewPoints.Count != RetList.Count)
                    RetList = NewPoints;

                st.Delete();
            }
            else
            {
                Point SingelPoint = null;
                if (Vect.X > 0)
                    SingelPoint = Com.MinP(RetList, "X");
                else if (Vect.X < 0)
                    SingelPoint = Com.MaxP(RetList, "X");
                if (Vect.Y > 0)
                    SingelPoint = Com.MinP(RetList, "Y");
                if (Vect.Y < 0)
                    SingelPoint = Com.MaxP(RetList, "Y");

                if (SingelPoint != null)
                {
                    RetList = new PointList();
                    RetList.Add(SingelPoint);
                }

            }
            return RetList;
        }

        public PointList ChangePints(PointList RetList, ViewBase ViewB, Vector Vect)
        {
            StraightDimensionSet.StraightDimensionSetAttributes DimAtrr = new StraightDimensionSet.StraightDimensionSetAttributes("standard");
            Vector NewVect = Com.ChangeVector(Vect);
            StraightDimensionSet st = Com.InsertDim(ViewB, RetList, NewVect, 100, DimAtrr);
            if (st != null)
            {
                TSD.PointList NewPoints = Com.GetDimPoints(st);
                if (NewPoints.Count != RetList.Count)
                    RetList = NewPoints;

                st.Delete();
            }
            else
            {
                Point SingelPoint = null;
                if (Vect.X > 0)
                    SingelPoint = Com.MinP(RetList, "X");
                else if (Vect.X < 0)
                    SingelPoint = Com.MaxP(RetList, "X");
                if (Vect.Y > 0)
                    SingelPoint = Com.MinP(RetList, "Y");
                if (Vect.Y < 0)
                    SingelPoint = Com.MaxP(RetList, "Y");

                if (SingelPoint != null)
                {
                    RetList = new PointList();
                    RetList.Add(SingelPoint);
                }

            }
            return RetList;
        }

        public List<int> GetKnockOffDim(TSD.View CView, Beam MainBeam, PartPoints Points, BoltGroup LeftBolt, BoltGroup RightBolt)
        {
            List<int> Ids = new List<int>();
            try
            {
                Point StartP = new Point(MainBeam.StartPoint.X, MainBeam.StartPoint.Y);
                Point EndP = new Point(MainBeam.EndPoint.X, MainBeam.EndPoint.Y);
                Point P1 = new Point(Points.P1.X, Points.P1.Y);
                Point P2 = new Point(Points.P2.X, Points.P2.Y);
                Point P3 = new Point(Points.P3.X, Points.P3.Y);
                Point P4 = new Point(Points.P4.X, Points.P4.Y);
                Point PBoltL1 = null;
                Point PBoltR1 = null;
                Point PBoltL2 = null;
                Point PBoltR2 = null;

                if (LeftBolt != null)
                {
                    PointList TempList = Com.GetBoltPoints(LeftBolt);
                    PBoltL1 = Com.MinPofX(TempList, "Y", Com.MinP(TempList, "X").X);
                    PBoltL1 = new Point(PBoltL1.X, PBoltL1.Y);

                    PBoltL2 = Com.MaxPofX(TempList, "Y", Com.MinP(TempList, "X").X);
                    PBoltL2 = new Point(PBoltL2.X, PBoltL2.Y);
                }

                if (RightBolt != null)
                {
                    PointList TempList = Com.GetBoltPoints(RightBolt);
                    PBoltR1 = Com.MinPofX(TempList, "Y", Com.MaxP(TempList, "X").X);
                    PBoltR1 = new Point(PBoltR1.X, PBoltR1.Y);

                    PBoltR2 = Com.MaxPofX(TempList, "Y", Com.MaxP(TempList, "X").X);
                    PBoltR2 = new Point(PBoltR2.X, PBoltR2.Y);
                }

                DrawingObjectEnumerator DimList = CView.GetAllObjects(typeof(TSD.DimensionBase));
                List<TSD.DimensionBase> AllDim = Com.EnumtoArrayD(DimList).OfType<TSD.DimensionBase>().ToList();
                List<TSD.StraightDimension> AllStDim = AllDim.OfType<TSD.StraightDimension>().Where(x => x.UpDirection.Y > 0 || x.UpDirection.Y < 0).ToList();

                TSD.StraightDimension LeftDim = (from d in AllStDim where IsEqualPoints1(d.StartPoint, StartP) && IsEqualPts(d.EndPoint, P1, P2) select d).FirstOrDefault();

                if (LeftDim == null && PBoltL1 != null)
                    LeftDim = (from d in AllStDim where IsEqualPoints1(d.StartPoint, StartP) && IsEqualPts(d.EndPoint, P1, P2, PBoltL1, PBoltL2) select d).FirstOrDefault();

                TSD.StraightDimension RightDim = (from d in AllStDim where IsEqualPoints1(d.EndPoint, EndP) && IsEqualPts(d.StartPoint, P3, P4) select d).FirstOrDefault();

                if (RightDim == null && PBoltR1 != null)
                    RightDim = (from d in AllStDim where IsEqualPoints1(d.EndPoint, EndP) && IsEqualPts(d.StartPoint, P3, P4, PBoltR1, PBoltR2) select d).FirstOrDefault();

                if (LeftDim != null && RightDim != null)
                {
                    TSD.StraightDimension MidDim = (from d in AllStDim where IsSameVector(d.UpDirection, LeftDim.UpDirection) && Com.IsEqual(d.StartPoint.X, LeftDim.EndPoint.X) && Com.IsEqual(d.EndPoint.X, RightDim.StartPoint.X) select d).FirstOrDefault();

                    if (MidDim != null)
                    {
                        Ids.Add(GetDimID(MidDim));
                        Ids.Add(GetDimID(LeftDim));
                        Ids.Add(GetDimID(RightDim));
                    }
                }
            }
            catch (Exception ex)
            { }

            return Ids;
        }


        public List<int> GetKnockOffDim(TSD.View CView, Beam MainBeam, PartPoints Points, BoltGroup LeftBolt, BoltGroup RightBolt, out List<TSD.StraightDimension> KnockDim)
        {
            List<int> Ids = new List<int>();
            List<TSD.StraightDimension> KnockStDim = new List<StraightDimension>();
            try
            {
                Point StartP = new Point(MainBeam.StartPoint.X, MainBeam.StartPoint.Y);
                Point EndP = new Point(MainBeam.EndPoint.X, MainBeam.EndPoint.Y);
                Point P1 = new Point(Points.P1.X, Points.P1.Y);
                Point P2 = new Point(Points.P2.X, Points.P2.Y);
                Point P3 = new Point(Points.P3.X, Points.P3.Y);
                Point P4 = new Point(Points.P4.X, Points.P4.Y);
                Point PBoltL1 = null;
                Point PBoltR1 = null;
                Point PBoltL2 = null;
                Point PBoltR2 = null;
                Point PBoltR11 = null;
                Point PBoltR22 = null;

                if (LeftBolt != null)
                {
                    PointList TempList = Com.GetBoltPoints(LeftBolt);
                    PBoltL1 = Com.MinPofX(TempList, "Y", Com.MinP(TempList, "X").X);
                    PBoltL1 = new Point(PBoltL1.X, PBoltL1.Y);

                    PBoltL2 = Com.MaxPofX(TempList, "Y", Com.MinP(TempList, "X").X);
                    PBoltL2 = new Point(PBoltL2.X, PBoltL2.Y);
                }

                if (RightBolt != null)
                {
                    PointList TempList = Com.GetBoltPoints(RightBolt);
                    PBoltR1 = Com.MinPofX(TempList, "Y", Com.MinP(TempList, "X").X);
                    PBoltR1 = new Point(PBoltR1.X, PBoltR1.Y);

                    PBoltR11 = Com.MinPofX(TempList, "Y", Com.MaxP(TempList, "X").X);
                    PBoltR11 = new Point(PBoltR11.X, PBoltR11.Y);

                    PBoltR2 = Com.MaxPofX(TempList, "Y", Com.MinP(TempList, "X").X);
                    PBoltR2 = new Point(PBoltR2.X, PBoltR2.Y);

                    PBoltR22 = Com.MaxPofX(TempList, "Y", Com.MaxP(TempList, "X").X);
                    PBoltR22 = new Point(PBoltR22.X, PBoltR22.Y);
                }

                DrawingObjectEnumerator DimList = CView.GetAllObjects(typeof(TSD.DimensionBase));
                List<TSD.DimensionBase> AllDim = Com.EnumtoArrayD(DimList).OfType<TSD.DimensionBase>().ToList();
                List<TSD.StraightDimension> AllStDim = AllDim.OfType<TSD.StraightDimension>().Where(x => x.UpDirection.Y > 0 || x.UpDirection.Y < 0).ToList();


                TSD.StraightDimension LeftDim = (from d in AllStDim where IsEqualPoints1(d.StartPoint, StartP) && IsEqualPts(d.EndPoint, P1, P2) select d).FirstOrDefault();

                if (LeftDim == null && PBoltL1 != null)
                    LeftDim = (from d in AllStDim where IsEqualPoints1(d.StartPoint, StartP) && IsEqualPts(d.EndPoint, P1, P2, PBoltL1, PBoltL2) select d).FirstOrDefault();

                TSD.StraightDimension RightDim = (from d in AllStDim where IsEqualPoints1(d.EndPoint, EndP) && IsEqualPts(d.StartPoint, P3, P4) select d).FirstOrDefault();

                if (RightDim == null && PBoltR1 != null)
                    RightDim = (from d in AllStDim where IsEqualPoints1(d.EndPoint, EndP) && IsEqualPts(d.StartPoint, P3, P4, PBoltR1, PBoltR2, PBoltR11, PBoltR22) select d).FirstOrDefault();

                if (LeftDim != null && RightDim != null)
                {
                    TSD.StraightDimension MidDim = (from d in AllStDim where IsSameVector(d.UpDirection, LeftDim.UpDirection) && Com.IsEqual(d.StartPoint.X, LeftDim.EndPoint.X) && Com.IsEqual(d.EndPoint.X, RightDim.StartPoint.X) select d).FirstOrDefault();

                    if (MidDim != null)
                    {
                        Ids.Add(GetDimID(LeftDim));
                        Ids.Add(GetDimID(MidDim));
                        Ids.Add(GetDimID(RightDim));
                        KnockStDim.Add(LeftDim);
                        KnockStDim.Add(MidDim);
                        KnockStDim.Add(RightDim);
                    }
                }
            }
            catch (Exception ex)
            { }

            KnockDim = KnockStDim;
            return Ids;
        }

        public bool IsEqualPts(Point pt, Point Check1, Point Check2, Point Check3, Point Check4)
        {
            if (IsEqualPoints1(pt, Check1) || IsEqualPoints1(pt, Check2) || IsEqualPoints1(pt, Check3) || IsEqualPoints1(pt, Check4))
                return true;
            else
                return false;
        }

        public bool IsEqualPts(Point pt, Point Check1, Point Check2, Point Check3, Point Check4, Point Check5, Point Check6)
        {
            if (IsEqualPoints1(pt, Check1) || IsEqualPoints1(pt, Check2) || IsEqualPoints1(pt, Check3) || IsEqualPoints1(pt, Check4) || IsEqualPoints1(pt, Check5) || IsEqualPoints1(pt, Check6))
                return true;
            else
                return false;
        }

        public bool IsEqualPts(Point pt, Point Check1, Point Check2)
        {
            if (IsEqualPoints1(pt, Check1) || IsEqualPoints1(pt, Check2))
                return true;
            else
                return false;
        }

        public bool IsEqualPoints1(Point P1, Point P2)
        {
            //if (IsEqual(P1.X, P2.X) && IsEqual(P1.Y, P2.Y) && IsEqual(P1.Z, P2.Z)) return true;
            if (IsEqual1(P1.X, P2.X) && IsEqual1(P1.Y, P2.Y)) return true;
            else return false;
        }

        public bool IsEqual1(double d1, double d2)
        {
            bool check = false;
            int dd1 = Convert.ToInt32(d1);
            int dd2 = Convert.ToInt32(d2);
            if (dd1 == dd2)
                check = true;
            else
            {
                //int k = Convert.ToInt32(RemoveMinusValue(d1 - d2));
                //if (k <= 1)
                double k = Convert.ToDouble(RemoveMinusValue(d1 - d2)); //updated by Uttari on 09-13-2016 for Stiffener Pick Point error..Need to verify with all posibilities.
                if (Math.Round(k, 1) <= 3)
                    check = true;
            }

            return check;
        }


        public  PartPoints GetPartPointsSlop(TSM.Part part)
        {
            PointList PList = GetSlopBeamEdgesPList(part);
            PartPoints BPoints = new PartPoints();
            BPoints.P1 = PList[1];
            BPoints.P2 = PList[0];
            BPoints.P3 = PList[3];
            BPoints.P4 = PList[2];

            List<Point> points = part.GetCenterLine(false).OfType<Point>().ToList();
            BPoints.CentP = Com.CenterPoint1(points[0], points[1]);

           
            return BPoints;
        }

        public PointList GetRadialChampherPointList(ContourPoint pts, TSM.Part Cplate)
        {
            PointList PtList = new PointList();

            double DivVal = 0;
            if (pts.Chamfer.Type == Chamfer.ChamferTypeEnum.CHAMFER_ARC)
                DivVal = 1.5;
            if (pts.Chamfer.Type == Chamfer.ChamferTypeEnum.CHAMFER_ROUNDING)
                DivVal = 4.0;
            if (pts.Chamfer.Type == Chamfer.ChamferTypeEnum.CHAMFER_LINE_AND_ARC)
                DivVal = 1.0;


            Point Centp = Com.CenterPoint(Cplate);
            Point Ptc = new Point(pts.X, pts.Y);
            Point pt0 = new Point(Cplate.GetSolid().MinimumPoint.X, Cplate.GetSolid().MinimumPoint.Y);
            Point pt1 = new Point(Cplate.GetSolid().MaximumPoint.X, Cplate.GetSolid().MaximumPoint.Y);
            //Point centerCP = new Point(dc.CenterPoint(pt0, pt1));
            PointList VertPlist = GetVertPointList(Cplate);

            if (pts.Chamfer.X > 0 || pts.Chamfer.Y > 0)
            {
                double Xp = 0, Yp = 0;
                if ((pts.Chamfer.Type == Chamfer.ChamferTypeEnum.CHAMFER_ARC) || (pts.Chamfer.Type == Chamfer.ChamferTypeEnum.CHAMFER_ROUNDING))
                {
                    Xp = Math.Round(pts.Chamfer.X, 2);
                    Yp = Math.Round(pts.Chamfer.X, 2);
                }
                else
                {
                    Xp = Math.Round(pts.Chamfer.X, 2);
                    Yp = Math.Round(pts.Chamfer.Y, 2);
                }
                if (pts.Chamfer.Y == 0)
                    Yp = Math.Round(pts.Chamfer.X, 2);  // chamfer.Y=0 

                double Mpx = (Xp / DivVal) + (Xp / 25.4);
                double Mpy = (Yp / DivVal) + (Yp / 25.4);


                if ((Math.Round(Ptc.X) < Centp.X) && (Math.Round(Ptc.Y) > Centp.Y))    //LeftTop
                {
                    //Xp = Xp;
                    Yp = -Yp;
                    Mpy = -Mpy;
                }
                if ((Math.Round(Ptc.X) > Centp.X) && (Math.Round(Ptc.Y) < Centp.Y))	//RightBottom
                {
                    Xp = -Xp;
                    Mpx = -Mpx;
                    //Yp = Yp;
                }
                if ((Math.Round(Ptc.X) > Centp.X) && (Math.Round(Ptc.Y) > Centp.Y))	//RightTop
                {
                    Xp = -Xp;
                    Yp = -Yp;
                    Mpx = -Mpx;
                    Mpy = -Mpy;
                }
                if ((Math.Round(Ptc.X) < Centp.X) && (Math.Round(Ptc.Y) < Centp.Y))	//LeftBottom
                {
                    //Xp = Xp;
                    //Yp = Yp;
                }

                Point XPoint = new Point(Ptc.X + Xp, Ptc.Y);
                Point MidPoint = new Point(Ptc.X + Mpx, Ptc.Y + Mpy);
                Point YPoint = new Point(Ptc.X, Ptc.Y + Yp);

                // dc.DrawLine(currentView,XPoint, YPoint);

                if ((pts.Chamfer.Type == Chamfer.ChamferTypeEnum.CHAMFER_ARC) || (pts.Chamfer.Type == Chamfer.ChamferTypeEnum.CHAMFER_ROUNDING))
                { }
                else
                {
                    if (!IsPointinList(VertPlist, XPoint))
                        XPoint = new Point(Ptc.X + Yp, Ptc.Y);

                    if (!IsPointinList(VertPlist, XPoint))
                    {
                        if (Yp > 0)
                            Yp = (-Yp);
                        else
                            Yp = RemoveMinusValue(Yp);

                        XPoint = new Point(Ptc.X + Yp, Ptc.Y);
                    }

                    //dc.DrawLine(currentView, XPoint, YPoint);

                    if (!IsPointinList(VertPlist, YPoint))
                        YPoint = new Point(Ptc.X, Ptc.Y + Xp);

                    if (!IsPointinList(VertPlist, YPoint))
                    {
                        if (Xp > 0)
                            Xp = (-Xp);
                        else
                            Xp = RemoveMinusValue(Xp);

                        YPoint = new Point(Ptc.X, Ptc.Y + Xp);
                    }
                    //dc.DrawLine(currentView,XPoint,YPoint);
                }
                PtList.Add(XPoint);
                PtList.Add(MidPoint);
                PtList.Add(YPoint);
            }

            return PtList;
        }

    }

    public enum DrawingHatchColor
    {
        Special = 120,
        Gray30 = 130,
        Gray50 = 131,
        Gray70 = 132,
        Gray90 = 133,
        Invisible = 152,
        Black = 153,
        NewLine1 = 154,
        NewLine2 = 155,
        NewLine3 = 156,
        NewLine4 = 157,
        NewLine5 = 158,
        NewLine6 = 159,
        Red = 160,
        Green = 161,
        Blue = 162,
        Cyan = 163,
        Yellow = 164,
        Magenta = 165,
    }

    //add below line in options.ini file in model folder in case Assembly Drawing Property window is TreeView structure for old format
    //XS_USE_OLD_DRAWING_CREATION_SETTINGS=TRUE

}
