﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows.Forms;
using System.Xml.Linq;
using System.Xml.Serialization;
using Tekla.Structures.Dialog;
using Tekla.Structures.Geometry3d;
using Tekla.Structures.Model;
using Tekla.Structures.Solid;
using SD = System.Drawing;
using TSD = Tekla.Structures.Drawing;
using TSM = Tekla.Structures.Model;
using TSMO = Tekla.Structures.Model.Operations;
using TSG = Tekla.Structures.Geometry3d;
using TSDD = Tekla.Structures.Datatype;
using VirtueleDrawingAutomation;

namespace Auto_Detailing_Tool_Beam
{
    public static class Com
    {
        public static Model MyModel = new Model();

        public static Dictionary<string, string> CodeNames = new Dictionary<string, string>()
        {
            {"BBP1",  "Two Bent Plate Connection On Flange [Left And Right End Connection]" },
            {"BC2",  "Sloped Clip Angle With Cope [Left And Right End Connection]" },
            {"BCR1",  "Cope Reinforcement Plate With Top & Bottom Cope [Left And Right End Connection]" },
            {"BDP1",  "Doubler Plate Connection With Top & Bottom Cope [Left And Right End Connection]" },
            {"BEP2",  "Sloped End Plate [Left And Right End Connection]" },
            {"BEP3",  "End Plate Extended Beyond Top And Bottom Flange [Left And Right End Connection]" },
            {"BHP1",  "Beam With Haunch Plate [Left And Right End Connection]" },
            {"BS2",  "Skewed Shear Tab [Middle Connection]" },
            {"BSP2",  "Web & Flange Splice Plate Connection With Plates [Left And Right End Connection]" },
            {"BG2",  "Double Side Gusset Plate Connection For Angle Brace [Left And Right End Connection]" },
            {"BG3",  "Both Side Vertical Gusset Plate [Middle Connection-Wt Braces]" },
            {"BG5",  "Gusset Plate With Clip Angle Connection For Angle Profile [Left And Right End Connection]" },
            {"BG6",  "Vertical Gusset Plate With Shear Tab [Left And Right End Connection]" },
            {"BG7",  "Gusset Pate With Shear Plate Connection(Angle Profile) [Left And Right End Connection]" },
            {"BG8",  "Vertical Gusset Plate With Claw Angle W-Profile [Left And Right End Connection]" },
            {"BG9",  "Double Side Gusset Plate With Stiffner Connection [Middle Connection-Wt Braces]" },
            {"BG12",  "Horizontal Chevron Connection [Middle Connection-Angle Braces]" },
            {"BG13",  "Double Side Chevron Connection With Stiffener [Middle Connection-Wt Braces]" },
            {"BG17",  "Vertical Chevron Connection Angle Braces [Middle Connection]" },
            {"BG18",  "Vertical Chevron Connection Including Claw Angle W Profile [Middle Connection]" },
            {"BG19",  "Vertical Gusset Plate With Claw Angle W-Profile [Middle Connection]" },
            {"BG21",  "BRB Vertical Braced Connection Welded At The Middle Of The Beam" },
            {"BG22",  "BRB Vertical Brace Connection Bolted At The Middle Of The Beam With Staggered Bolts" },
            {"BSP3",  "Beam With Side Plate Narrow Connection [Left And Right End Connection]" },
            {"BSP4",  "Beam With Side Plate Connection[Left And Right End Connection]" }

        };

        public static List<string> MidCodes = new List<string>() { "BBP1", "BS2", "BG2", "BG3", "BG9", "BG12", "BG13", "BG17", "BG18", "BG19", "BG21", "BG22" };

        public static string CPath = @"C:\ProgramData\Tekla Structures\Auto Steel Detailing System\";

        #region XML Methods
        public static void CreateClass(string ClassName, IDictionary<string, Type> AttributeList)
        {
            string startupPath = System.IO.Directory.GetCurrentDirectory();
            string ClassFile = Path.Combine(startupPath, ClassName + ".cs");

            string AllText = "public class " + ClassName + " \n ";
            AllText += "{ \n ";
            for (int i = 0; i < AttributeList.Count; i++)
            {

                string AttrName = AttributeList.Keys.ToList()[i];
                string DataType = AttributeList.Values.ToList()[i].Name;

                string Variabe = "public string " + AttrName + " {get; set;} \n ";
                if (DataType == "Integer")
                    Variabe = "public int " + AttrName + " {get; set;} \n ";
                if (DataType == "Double")
                    Variabe = "public double " + AttrName + " {get; set;} \n ";
                if (DataType == "Distance")
                    Variabe = "public double " + AttrName + " {get; set;} \n ";
                if (DataType == "DistanceList")
                    Variabe = "public string " + AttrName + " {get; set;} \n ";
                if (DataType == "Boolean")
                    Variabe = "public bool " + AttrName + " {get; set;} \n ";

                AllText += Variabe;
            }

            AllText += "} \n ";

            File.WriteAllText(ClassFile, AllText);
        }

        public static void SaveCollFile(string AttrName, string ProjectName, ApplicationFormBase form)
        {
            if (!string.IsNullOrEmpty(AttrName))
            {
                string FilePath = Com.MyModel.GetInfo().ModelPath + @"\attributes\" + AttrName + ".Auto_Steel_Detailing_System." + form.Name + ".xml";
                form.SaveValues(FilePath);
                string CollPath = Com.CPath + @"Clients\" + ProjectName + @"\Attribute\XML\" + ProjectName + "_" + form.Name + "_Collection.xml";
                Com.XMLToCollection(CollPath, FilePath, AttrName, form.Name);
            }
        }

        public static void XMLToCollection(string CollFile, string XMlFile, string NodeName, string ConnName)
        {
            if (!File.Exists(CollFile))
                CreateEmptyXMLFile(CollFile, ConnName);

            XElement XDoc = XElement.Load(CollFile);
            XElement El = (from b in XDoc.Elements() where b.Name.LocalName == NodeName select b).FirstOrDefault();
            if (El == null)
            {
                XElement ElNew = TekXMlFileToElement(XMlFile, NodeName, false);
                XDoc.Add(ElNew);
                XDoc.Save(CollFile);
            }
            else
            {
                XElement ElNew = TekXMlFileToElement(XMlFile, NodeName, false);
                El.ReplaceWith(ElNew);
                XDoc.Save(CollFile);
            }
        }

        public static void CreateEmptyXMLFile(string XmlFile, string RootName)
        {
            XDocument xmlDoc = new XDocument(
               new XDeclaration("1.0", "utf-8", "yes"),
               new XComment("XML File for " + RootName));

            xmlDoc.Add(new XElement(RootName));
            xmlDoc.Save(XmlFile);

        }

        public static T TeklaXMLToClass<T>(string xmlFile)
        {
            Type type = typeof(T);
            XElement element = TekXMlFileToElement(xmlFile, type.Name, true);
            var serializer = new XmlSerializer(typeof(T));
            return (T)serializer.Deserialize(element.CreateReader());
        }

        public static XElement TekXMlFileToElement(string xmlFile, string ClassName, bool IsRemoveMM)
        {
            string AllText = File.ReadAllText(xmlFile);
            AllText = AllText.Replace("<?xml version=\"1.0\" encoding=\"utf-8\"?>", "");
            AllText = AllText.Replace("config", ClassName);
            if (IsRemoveMM)
            {
                AllText = AllText.Replace("<Millimeters>", "");
                AllText = AllText.Replace("</Millimeters>", "");
            }
            XElement element = XElement.Parse(AllText);

            return element;
        }

        public static T CollectionToXMLClass<T>(string CollFile, string NodeName)
        {

            Type type = typeof(T);
            XElement XDoc = XElement.Load(CollFile);
            XElement El = (from b in XDoc.Elements() where b.Name.LocalName == NodeName select b).FirstOrDefault();

            string ElText = El?.ToString();
            ElText = ElText?.Replace("<Millimeters>", "");
            ElText = ElText?.Replace("</Millimeters>", "");
            ElText = ElText?.Replace(NodeName, type.Name);
            XElement element = XElement.Parse(ElText);
            return ElemnetToClass<T>(element);

        }

        public static T ElemnetToClass<T>(XElement element)
        {
            var serializer = new XmlSerializer(typeof(T));
            return (T)serializer.Deserialize(element.CreateReader());
        }

        public static void CollectionToXML(string CollFile, string ConnName)
        {
            if (File.Exists(CollFile))
            {
                XElement XDoc = XElement.Load(CollFile);

                foreach (XElement el in XDoc.Elements())
                {
                    string XMLFile = MyModel.GetInfo().ModelPath + @"\attributes\" + el.Name.LocalName + ".Auto_Steel_Detailing_System." + ConnName + ".xml";
                    ElementToTekXMlFile(el, XMLFile, el.Name.LocalName);
                }
            }
        }

        public static void ElementToTekXMlFile(XElement element, string xmlFile, string ClassName)
        {
            string AllText = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n";
            AllText += element.ToString();

            AllText = AllText.Replace(ClassName, "config");
            File.WriteAllText(xmlFile, AllText);

        }

        public static XElement ToElement<T>(object obj)
        {
            using (var memoryStream = new MemoryStream())
            {
                using (TextWriter streamWriter = new StreamWriter(memoryStream))
                {
                    var xmlSerializer = new XmlSerializer(typeof(T));
                    xmlSerializer.Serialize(streamWriter, obj);
                    return XElement.Parse(Encoding.ASCII.GetString(memoryStream.ToArray()));
                }
            }
        }

        public static void CollectionToXMLSpecific(string CollFile, string ConnName, string AttributeName)
        {
            if (File.Exists(CollFile))
            {
                XElement XDoc = XElement.Load(CollFile);
                XElement el = (from b in XDoc.Elements() where b.Name.LocalName == AttributeName select b).FirstOrDefault();

                if (el != null)
                {
                    string XMLFile = MyModel.GetInfo().ModelPath + @"\attributes\" + AttributeName + ".Auto_Steel_Detailing_System." + ConnName + ".xml";
                    ElementToTekXMlFile(el, XMLFile, el.Name.LocalName);
                }

                el = (from b in XDoc.Elements() where b.Name.LocalName == "standard" select b).FirstOrDefault();

                if (el != null)
                {
                    string XMLFile = MyModel.GetInfo().ModelPath + @"\attributes\standard.Auto_Steel_Detailing_System." + ConnName + ".xml";
                    if (!File.Exists(XMLFile))
                        ElementToTekXMlFile(el, XMLFile, el.Name.LocalName);
                }

            }
        }

        public static void ColltoXMLFile(string CollFile, string FileName, string ProjectName, string AttributeName)
        {
            string CollPath = Com.CPath + ProjectName + @"\Collection Files\" + CollFile;
            Com.CollectionToXMLSpecific(CollPath, FileName, AttributeName);

        }

        public static T GetViewClass<T>(string CollFile, string PartName, string ViewName)
        {
            string ClassName = ViewName.Replace(" ", "") + "Class_" + PartName.Replace(" ", "");
            XElement XDoc = XElement.Load(CollFile);

            XElement El = (from b in XDoc.Elements() where b.Name.LocalName == ClassName select b).FirstOrDefault();
            var serializer = new XmlSerializer(typeof(T));
            return (T)serializer.Deserialize(El.CreateReader());
        }

        public static void CreateXMFile(string CollFile, string FileName, string ClientName)
        {
            string CollPaths = @"C:\ProgramData\Tekla Structures\Auto Steel Detailing System\Clients\" + ClientName + @"\Attribute\XML\";
            string CollPath = CollPaths + ClientName + "_" + CollFile;
            Com.CollectionToXML(CollPath, FileName);

        }

        public static void CreateClass(string ClassName, IDictionary<string, Type> AttributeList, Control ct)
        {
            string startupPath = System.IO.Directory.GetCurrentDirectory();
            string ClassFile = Path.Combine(startupPath, ClassName + ".cs");


            string ComBList = "";
            string CheckBoxList = "";
            string AllText = "public class " + ClassName + " \n ";
            AllText += "{ \n ";
            for (int i = 0; i < AttributeList.Count; i++)
            {

                string AttrName = AttributeList.Keys.ToList()[i];
                string DataType = AttributeList.Values.ToList()[i].Name;
                Control Cont = ct.Controls.Find(AttrName, true)[0];
                if (Cont != null && (Cont is ComboBox || Cont is Tekla.Structures.Dialog.UIControls.ImageListComboBox))
                    ComBList += "\"" + AttrName + "\" ,";


                if (Cont != null && (Cont is CheckBox))
                    CheckBoxList += "\"" + AttrName + "\" ,";

                string Variabe = "public string " + AttrName + " {get; set;} \n ";
                if (DataType == "Integer")
                    Variabe = "public int " + AttrName + " {get; set;} \n ";
                if (DataType == "Double")
                    Variabe = "public double " + AttrName + " {get; set;} \n ";
                if (DataType == "Distance")
                    Variabe = "public double " + AttrName + " {get; set;} \n ";
                if (DataType == "DistanceList")
                    Variabe = "public string " + AttrName + " {get; set;} \n ";
                if (DataType == "Boolean")
                    Variabe = "public bool " + AttrName + " {get; set;} \n ";

                AllText += Variabe;
            }

            AllText += "} \n ";



            AllText += "List<string> ComboBoxList =  new List<string>() { " + ComBList + "}; \n";
            AllText += "List<string> CheckBoxList =  new List<string>() { " + CheckBoxList + "};";

            File.WriteAllText(ClassFile, AllText);
        }

        #endregion

        #region General Methods

        public static ArrayList EnumtoArray(IEnumerator Enum)
        {
            ArrayList RetList = new ArrayList();
            while (Enum.MoveNext())
            {
                object B = Enum.Current;
                if (B != null) RetList.Add(B);

            }

            return RetList;

        }

        public static ArrayList EnumtoArrayD(IEnumerator Enum)
        {
            ArrayList RetList = new ArrayList();
            while (Enum.MoveNext())
            {
                TSD.DrawingObject B = null;
                try
                {
                    B = Enum.Current as TSD.DrawingObject;
                }
                catch (Exception ex)
                { }

                if (B != null) RetList.Add(B);

            }

            return RetList;

        }

        public static ArrayList EnumtoArrayDr(IEnumerator Enum)
        {
            ArrayList RetList = new ArrayList();
            while (Enum.MoveNext())
            {
                TSD.Drawing B = null;
                try
                {
                    B = Enum.Current as TSD.Drawing;
                }
                catch (Exception ex)
                { }

                if (B != null) RetList.Add(B);

            }

            return RetList;

        }

        public static ArrayList EnumtoArrayDr(IEnumerator Enum, int count, ProgressBar prog)
        {
            ArrayList RetList = new ArrayList();
            prog.Value = 0;
            prog.Maximum = count;
            while (Enum.MoveNext())
            {
                TSD.Drawing B = Enum.Current as TSD.Drawing;
                if (B != null) RetList.Add(B);

                if (prog.Value < prog.Maximum)
                {
                    prog.Value++;

                    int percent = (int)(((double)prog.Value / (double)prog.Maximum) * 100);
                    prog.Refresh();
                    prog.CreateGraphics().DrawString(percent.ToString() + "%",
                        new SD.Font("Calibri", (float)9.25, SD.FontStyle.Regular),
                        SD.Brushes.Black,
                        new SD.PointF(prog.Width / 2 - 10, prog.Height / 2 - 7));
                }
            }

            return RetList;

        }

        public static ArrayList EnumtoArray(IEnumerator Enum, int count, ProgressBar prog)
        {
            ArrayList RetList = new ArrayList();
            prog.Value = 0;
            prog.Maximum = count;
            while (Enum.MoveNext())
            {
                ModelObject B = Enum.Current as ModelObject;
                if (B != null) RetList.Add(B);

                if (prog.Value < prog.Maximum)
                {
                    prog.Value++;

                    int percent = (int)(((double)prog.Value / (double)prog.Maximum) * 100);
                    prog.Refresh();
                    prog.CreateGraphics().DrawString(percent.ToString() + "%",
                        new SD.Font("Calibri", (float)9.25, SD.FontStyle.Regular),
                        SD.Brushes.Black,
                        new SD.PointF(prog.Width / 2 - 10, prog.Height / 2 - 7));
                }
            }

            return RetList;

        }



        public static ArrayList EnumtoArray(IEnumerator Enum, int count, ProgressBar prog, string Message, Label lbResult)
        {
            ArrayList RetList = new ArrayList();
            prog.Value = 0;
            prog.Maximum = count;
            while (Enum.MoveNext())
            {
                ModelObject B = Enum.Current as ModelObject;
                if (B != null) RetList.Add(B);

                if (prog.Value < prog.Maximum)
                {

                    prog.Value++;
                    int percent = (int)(((double)prog.Value / (double)prog.Maximum) * 100);
                    prog.Refresh();
                    prog.CreateGraphics().DrawString(percent.ToString() + "%",
                        new SD.Font("Calibri", (float)9.25, SD.FontStyle.Regular),
                        SD.Brushes.Black,
                        new SD.PointF(prog.Width / 2 - 10, prog.Height / 2 - 7));

                    lbResult.Text = Message + " : Total - " + count.ToString() + " Remaining : " + (prog.Value - prog.Maximum);
                }
            }

            return RetList;

        }

        #endregion

        #region Set Plane Methods
        public static void SetPlaneGlobally()
        {
            MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane());
        }

        public static void SetPlane(CoordinateSystem cs)
        {
            MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane(cs));
        }

        public static void SetPlane(Point StartPoint, Point EndPoint)
        {
            MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane());

            double Xdif = EndPoint.X - StartPoint.X;
            double Ydif = EndPoint.Y - StartPoint.Y;
            double Zdif = EndPoint.Z - StartPoint.Z;
            MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane(StartPoint, new Vector(Xdif, Ydif, 0), new Vector(Xdif, Ydif, 0).Cross(new Vector(0, 0, -1))));

        }

        #endregion

        #region Center Point Methods
        public static Point CenterPoint(Point Sp, Point Ep)
        {
            double distance = (Tekla.Structures.Geometry3d.Distance.PointToPoint(Sp, Ep));
            double x = ((Ep.X - Sp.X) / distance) * (distance / 2) + Sp.X;
            double y = ((Ep.Y - Sp.Y) / distance) * (distance / 2) + Sp.Y;
            double z = ((Ep.Z - Sp.Z) / distance) * (distance / 2) + Sp.Z;

            Point CenterPoint = new Point();
            if (!double.IsNaN(x) && !double.IsNaN(y) && !double.IsNaN(z))
                CenterPoint = new Point(x, y, z);

            return CenterPoint;
        }

        public static Point CenterPoint1(Point StartP, Point EndP)
        {

            double X = StartP.X + (Math.Abs(EndP.X - StartP.X) / 2);
            double Y = StartP.Y + (Math.Abs(EndP.Y - StartP.Y) / 2);
            double Z = StartP.Z + (Math.Abs(EndP.Z - StartP.Z) / 2);

            return new Point(X, Y, Z);
        }

        public static Point CenterPoint(Part Mobj)
        {
            Point RetPoint = CenterPoint(Mobj.GetSolid().MinimumPoint, Mobj.GetSolid().MaximumPoint);
            return RetPoint;
        }

        public static Point CenterPoint(Solid Mobj)
        {
            Point RetPoint = CenterPoint(Mobj.MinimumPoint, Mobj.MaximumPoint);
            return RetPoint;
        }

        public static Point CenterPoint(BoltGroup Mobj)
        {
            Point RetPoint = CenterPoint(Mobj.GetSolid().MinimumPoint, Mobj.GetSolid().MaximumPoint);
            return RetPoint;
        }

        #endregion

        #region Comparing Method
        public static bool IsEqualGreater(double val1, double val2)
        {
            bool RetCheck = false;
            double ValDif = val1 - val2;
            double ValDifAb = Math.Abs(val1 - val2);

            if (ValDifAb <= 0.5 || ValDif > 0) RetCheck = true;

            return RetCheck;

        }

        public static bool IsEqualLess(double val1, double val2)
        {
            bool RetCheck = false;
            double ValDif = val2 - val1;
            double ValDifAb = Math.Abs(val1 - val2);

            if (ValDifAb <= 0.5 || ValDif > 0) RetCheck = true;

            return RetCheck;
        }

        public static bool IsEqual(double val1, double val2)
        {
            bool RetCheck = false;
            double ValDifAb = Math.Abs(val1 - val2);

            if (ValDifAb <= 0.5) RetCheck = true;

            return RetCheck;

        }

        public static bool IsEqualPoints(Point P1, Point P2)
        {
            //if (IsEqual(P1.X, P2.X) && IsEqual(P1.Y, P2.Y) && IsEqual(P1.Z, P2.Z)) return true;
            if (IsEqual(P1.X, P2.X) && IsEqual(P1.Y, P2.Y)) return true;
            else return false;
        }

        public static Point MinP(List<Point> PList, string XYZ)
        {
            string xyz = XYZ.ToUpper();
            Point RetP = (from p in PList orderby p.Z ascending select p).FirstOrDefault();
            if (xyz == "X") RetP = (from p in PList orderby p.X ascending select p).FirstOrDefault();
            else if (xyz == "Y") RetP = (from p in PList orderby p.Y ascending select p).FirstOrDefault();

            return RetP;
        }

        public static Point MaxP(List<Point> PList, string XYZ)
        {
            string xyz = XYZ.ToUpper();
            Point RetP = (from p in PList orderby p.Z descending select p).FirstOrDefault();
            if (xyz == "X") RetP = (from p in PList orderby p.X descending select p).FirstOrDefault();
            else if (xyz == "Y") RetP = (from p in PList orderby p.Y descending select p).FirstOrDefault();

            return RetP;
        }

        public static Point MinPofX(List<Point> PList, string XYZ, double X)
        {
            string xyz = XYZ.ToUpper();
            Point RetP = (from p in PList where IsEqual(p.X, X) orderby p.Z descending select p).FirstOrDefault();
            if (xyz == "X") RetP = (from p in PList where IsEqual(p.X, X) orderby p.X ascending select p).FirstOrDefault();
            else if (xyz == "Y") RetP = (from p in PList where IsEqual(p.X, X) orderby p.Y ascending select p).FirstOrDefault();

            return RetP;
        }

        public static Point MaxPofX(List<Point> PList, string XYZ, double X)
        {
            string xyz = XYZ.ToUpper();
            Point RetP = (from p in PList where IsEqual(p.X, X) orderby p.Z descending select p).FirstOrDefault();
            if (xyz == "X") RetP = (from p in PList where IsEqual(p.X, X) orderby p.X descending select p).FirstOrDefault();
            else if (xyz == "Y") RetP = (from p in PList where IsEqual(p.X, X) orderby p.Y descending select p).FirstOrDefault();

            return RetP;
        }

        public static Point MinPofY(List<Point> PList, string XYZ, double Y)
        {
            string xyz = XYZ.ToUpper();
            Point RetP = (from p in PList where IsEqual(p.Y, Y) orderby p.Z ascending select p).FirstOrDefault();
            if (xyz == "X") RetP = (from p in PList where IsEqual(p.Y, Y) orderby p.X ascending select p).FirstOrDefault();
            else if (xyz == "Y") RetP = (from p in PList where IsEqual(p.Y, Y) orderby p.Y ascending select p).FirstOrDefault();

            return RetP;
        }

        public static Point MaxPofY(List<Point> PList, string XYZ, double Y)
        {
            string xyz = XYZ.ToUpper();
            Point RetP = (from p in PList where IsEqual(p.Y, Y) orderby p.Z descending select p).FirstOrDefault();
            if (xyz == "X") RetP = (from p in PList where IsEqual(p.Y, Y) orderby p.X descending select p).FirstOrDefault();
            else if (xyz == "Y") RetP = (from p in PList where IsEqual(p.Y, Y) orderby p.Y descending select p).FirstOrDefault();

            return RetP;
        }

        public static Point MinPofZ(List<Point> PList, string XYZ, double Z)
        {
            string xyz = XYZ.ToUpper();
            Point RetP = (from p in PList where IsEqual(p.Z, Z) orderby p.Z ascending select p).FirstOrDefault();
            if (xyz == "X") RetP = (from p in PList where IsEqual(p.Z, Z) orderby p.X ascending select p).FirstOrDefault();
            else if (xyz == "Y") RetP = (from p in PList where IsEqual(p.Z, Z) orderby p.Y ascending select p).FirstOrDefault();

            return RetP;
        }

        public static Point MaxPofZ(List<Point> PList, string XYZ, double Z)
        {
            string xyz = XYZ.ToUpper();
            Point RetP = (from p in PList where IsEqual(p.Z, Z) orderby p.Z descending select p).FirstOrDefault();
            if (xyz == "X") RetP = (from p in PList where IsEqual(p.Z, Z) orderby p.X descending select p).FirstOrDefault();
            else if (xyz == "Y") RetP = (from p in PList where IsEqual(p.Z, Z) orderby p.Y descending select p).FirstOrDefault();

            return RetP;
        }


        #region Drawing PointList Methods

        public static Point MinP(TSD.PointList PList, string XYZ)
        {
            string xyz = XYZ.ToUpper();
            Point RetP = (from p in PList.OfType<Point>() orderby p.Z descending select p).FirstOrDefault();
            if (xyz == "X") RetP = (from p in PList.OfType<Point>() orderby p.X ascending select p).FirstOrDefault();
            else if (xyz == "Y") RetP = (from p in PList.OfType<Point>() orderby p.Y ascending select p).FirstOrDefault();

            return RetP;
        }

        public static Point MaxP(TSD.PointList PList, string XYZ)
        {
            string xyz = XYZ.ToUpper();
            Point RetP = (from p in PList.OfType<Point>() orderby p.Z descending select p).FirstOrDefault();
            if (xyz == "X") RetP = (from p in PList.OfType<Point>() orderby p.X descending select p).FirstOrDefault();
            else if (xyz == "Y") RetP = (from p in PList.OfType<Point>() orderby p.Y descending select p).FirstOrDefault();

            return RetP;
        }

        public static Point MinPofX(TSD.PointList PList, string XYZ, double X)
        {
            string xyz = XYZ.ToUpper();
            Point RetP = (from p in PList.OfType<Point>() where IsEqual(p.X, X) orderby p.Z descending select p).FirstOrDefault();
            if (xyz == "X") RetP = (from p in PList.OfType<Point>() where IsEqual(p.X, X) orderby p.X ascending select p).FirstOrDefault();
            else if (xyz == "Y") RetP = (from p in PList.OfType<Point>() where IsEqual(p.X, X) orderby p.Y ascending select p).FirstOrDefault();

            return RetP;
        }

        public static Point MaxPofX(TSD.PointList PList, string XYZ, double X)
        {
            string xyz = XYZ.ToUpper();
            Point RetP = (from p in PList.OfType<Point>() where IsEqual(p.X, X) orderby p.Z descending select p).FirstOrDefault();
            if (xyz == "X") RetP = (from p in PList.OfType<Point>() where IsEqual(p.X, X) orderby p.X descending select p).FirstOrDefault();
            else if (xyz == "Y") RetP = (from p in PList.OfType<Point>() where IsEqual(p.X, X) orderby p.Y descending select p).FirstOrDefault();

            return RetP;
        }

        public static Point MinPofY(TSD.PointList PList, string XYZ, double Y)
        {
            string xyz = XYZ.ToUpper();
            Point RetP = (from p in PList.OfType<Point>() where IsEqual(p.Y, Y) orderby p.Z descending select p).FirstOrDefault();
            if (xyz == "X") RetP = (from p in PList.OfType<Point>() where IsEqual(p.Y, Y) orderby p.X ascending select p).FirstOrDefault();
            else if (xyz == "Y") RetP = (from p in PList.OfType<Point>() where IsEqual(p.Y, Y) orderby p.Y ascending select p).FirstOrDefault();

            return RetP;
        }

        public static Point MaxPofY(TSD.PointList PList, string XYZ, double Y)
        {
            string xyz = XYZ.ToUpper();
            Point RetP = (from p in PList.OfType<Point>() where IsEqual(p.Y, Y) orderby p.Z descending select p).FirstOrDefault();
            if (xyz == "X") RetP = (from p in PList.OfType<Point>() where IsEqual(p.Y, Y) orderby p.X descending select p).FirstOrDefault();
            else if (xyz == "Y") RetP = (from p in PList.OfType<Point>() where IsEqual(p.Y, Y) orderby p.Y descending select p).FirstOrDefault();

            return RetP;
        }

        public static Point MinPofZ(TSD.PointList PList, string XYZ, double Z)
        {
            string xyz = XYZ.ToUpper();
            Point RetP = (from p in PList.OfType<Point>() where IsEqual(p.Z, Z) orderby p.Z descending select p).FirstOrDefault();
            if (xyz == "X") RetP = (from p in PList.OfType<Point>() where IsEqual(p.Z, Z) orderby p.X ascending select p).FirstOrDefault();
            else if (xyz == "Y") RetP = (from p in PList.OfType<Point>() where IsEqual(p.Z, Z) orderby p.Y ascending select p).FirstOrDefault();

            return RetP;
        }

        public static Point MaxPofZ(TSD.PointList PList, string XYZ, double Z)
        {
            string xyz = XYZ.ToUpper();
            Point RetP = (from p in PList.OfType<Point>() where IsEqual(p.Z, Z) orderby p.Z descending select p).FirstOrDefault();
            if (xyz == "X") RetP = (from p in PList.OfType<Point>() where IsEqual(p.Z, Z) orderby p.X descending select p).FirstOrDefault();
            else if (xyz == "Y") RetP = (from p in PList.OfType<Point>() where IsEqual(p.Z, Z) orderby p.Y descending select p).FirstOrDefault();

            return RetP;
        }

        public static Point GetPartPoint(TSM.Part part, int num)
        {
            if (num == 1)
                return new Point(part.GetSolid().MinimumPoint.X, part.GetSolid().MaximumPoint.Y); // P1
            if (num == 2)
                return new Point(part.GetSolid().MinimumPoint);  //P2
            if (num == 3)
                return new Point(part.GetSolid().MaximumPoint.X, part.GetSolid().MinimumPoint.Y); // P3
            else
                return new Point(part.GetSolid().MaximumPoint);  //P4


        }

        #endregion


        #endregion

        #region Part Properties Methods

        public static double GetDoubleProperty(Part part, string AttrName)
        {
            double Cal_V = 0;
            part.GetReportProperty(AttrName, ref Cal_V);
            return Cal_V;
        }

        public static int GetIntProperty(Part part, string AttrName)
        {
            int Cal_V = 0;
            part.GetReportProperty(AttrName, ref Cal_V);
            return Cal_V;
        }

        public static int GetIntProperty(TSM.Assembly part, string AttrName)
        {
            int Cal_V = 0;
            part.GetReportProperty(AttrName, ref Cal_V);
            return Cal_V;
        }

        public static string GetStringProperty(Part part, string AttrName)
        {
            string Ret_V = "";
            part.GetReportProperty(AttrName, ref Ret_V);
            return Ret_V;
        }

        public static double GetPartHeight(Part part)
        {
            return GetDoubleProperty(part, "PROFILE.HEIGHT");
        }

        public static double GetPartWidth(Part part)
        {
            return GetDoubleProperty(part, "PROFILE.WIDTH");
        }

        public static double GetPartFlangeThickness(Part part)
        {
            double FlangeThick = 0;

            string StubProfileTyp = GetPartProfileType(part);

            if (StubProfileTyp == "I" || StubProfileTyp == "U" || StubProfileTyp == "T")
                FlangeThick = GetDoubleProperty(part, "PROFILE.FLANGE_THICKNESS");
            else if (StubProfileTyp == "RO" || StubProfileTyp == "M")
                FlangeThick = GetDoubleProperty(part, "PROFILE.PLATE_THICKNESS");
            else if (StubProfileTyp == "L")
                FlangeThick = GetDoubleProperty(part, "PROFILE.FLANGE_THICKNESS_1");
            else if (StubProfileTyp == "B")
                FlangeThick = GetDoubleProperty(part, "PROFILE.WIDTH");

            return FlangeThick;
        }

        public static double GetPartWebThickness(Part part)
        {
            return GetDoubleProperty(part, "WEB_THICKNESS");
        }

        public static double GetPartNetWeight(Part part)
        {
            return GetDoubleProperty(part, "WEIGHT_NET");
        }

        public static double GetPartNetLength(Part part)
        {
            return GetDoubleProperty(part, "LENGTH_NET");
        }

        public static double GetPlateThickness(Part part)
        {
            return GetDoubleProperty(part, "PROFILE.PLATE_THICKNESS");
        }

        public static double GetPartDia(Part part)
        {
            return GetDoubleProperty(part, "PROFILE.DIAMETER");
        }

        public static string GetAssemblyPos(Part part)
        {
            return GetStringProperty(part, "ASSEMBLY_POS");
        }

        public static string GetPartPos(Part part)
        {
            return GetStringProperty(part, "PART_POS");
        }

        public static string GetPartProfileType(Part part)
        {
            return GetStringProperty(part, "PROFILE_TYPE");
        }

        public static string GetPartProfileStartName(Part part)
        {
            return GetStringProperty(part, "PROFILE.PROFILE_SUBGROUP");
        }

        public static double GetAssembLength(Part part)
        {
            double Cal_V = 0;
            part.GetAssembly().GetReportProperty("LENGTH", ref Cal_V);
            return Cal_V;

        }

        #endregion

        public static TSD.PointList PointToPointList(List<Point> Plist)
        {
            TSD.PointList RetList = new TSD.PointList();
            foreach (Point p in Plist)
            {
                RetList.Add(p);
            }

            return RetList;
        }

        public static TSD.PointList GetBoltPoints(TSM.BoltGroup bolt)
        {

            return PointToPointList(bolt.BoltPositions.OfType<Point>().ToList());
        }

        public static TSD.PointList GetBoltPoints(List<TSM.BoltGroup> bolts)
        {
            TSD.PointList Plist = new TSD.PointList();
            bolts.ForEach(x => Plist.AddRange(GetBoltPoints(x)));
            return Plist;
        }

        public static bool HasBolt(TSM.Part part)
        {
            if (EnumtoArray(part.GetBolts()).Count > 0)
                return true;
            else
                return false;
        }

        public static List<Point> GetVertxPoints(Part Part)
        {
            List<Point> RetPointList = new List<Point>();
            List<Face> FaceList = EnumtoArray(Part.GetSolid().GetFaceEnumerator()).OfType<Face>().ToList();
            foreach (Face face in FaceList)
            {
                List<Loop> LoopList = EnumtoArray(face.GetLoopEnumerator()).OfType<Loop>().ToList();
                foreach (Loop loop in LoopList)
                {
                    List<Point> PointList = EnumtoArray(loop.GetVertexEnumerator()).OfType<Point>().ToList();
                    RetPointList.AddRange(PointList);
                }
            }

            return RetPointList;
        }

        public static TSD.PointList GetVertxPointsD(Part Part)
        {
            TSD.PointList RetPointList = new TSD.PointList();
            List<Face> FaceList = EnumtoArray(Part.GetSolid().GetFaceEnumerator()).OfType<Face>().ToList();
            foreach (Face face in FaceList)
            {
                List<Loop> LoopList = EnumtoArray(face.GetLoopEnumerator()).OfType<Loop>().ToList();
                foreach (Loop loop in LoopList)
                {
                    TSD.PointList PointList = PointToPointList(EnumtoArray(loop.GetVertexEnumerator()).OfType<Point>().ToList());
                    RetPointList.AddRange(PointList);
                }
            }

            return RetPointList;
        }

        public static TSD.StraightDimensionSet ChangeDimPoints(PlacingClass DOC, TSD.StraightDimensionSet st, Vector Vect, double Dist)
        {
            TSD.StraightDimensionSet StNew = null;
            Vector NewVect = ChangeVector(Vect);
            TSD.PointList NewPoints = GetDimPoints(st);
            if (st.Attributes.DimensionType != TSD.DimensionSetBaseAttributes.DimensionTypes.USAbsolute2)
                NewPoints = OrderPointList(GetDimPoints(st), NewVect);

            st.Delete();
            StNew = new TSD.StraightDimensionSetHandler().CreateDimensionSet(st.GetView(), NewPoints, NewVect, Dist, st.Attributes);
            StNew.Distance = GetCalDist(DOC, StNew, NewVect, Dist);
            StNew.Modify();

            return StNew;
        }

        public static TSD.StraightDimensionSet ChangeDimPoints(TSD.StraightDimensionSet st, Vector Vect, double Dist)
        {
            TSD.StraightDimensionSet StNew = null;
            Vector NewVect = ChangeVector(Vect);
            TSD.PointList Points = GetDimPoints(st);
            if (st.Attributes.DimensionType != TSD.DimensionSetBaseAttributes.DimensionTypes.USAbsolute2)
                Points = OrderPointList(GetDimPoints(st), NewVect);

            st.Delete();
            StNew = new TSD.StraightDimensionSetHandler().CreateDimensionSet(st.GetView(), Points, NewVect, Dist, st.Attributes);

            TSD.PointList NewPoints = GetDimPoints(StNew);

            StNew.Distance = Dist;  //GetCalDist(NewPoints, Points, Dist);
            StNew.Modify();

            return StNew;
        }

        public static TSD.StraightDimensionSet ChangeDimPoints(PlacingClass DOC, TSD.StraightDimensionSet st, Vector Vect, double Dist, TSD.PointList Points)
        {
            st.Delete();
            Vector NewVect = Com.ChangeVector(Vect);
            st = new TSD.StraightDimensionSetHandler().CreateDimensionSet(st.GetView(), Points, NewVect, Dist, st.Attributes);

            TSD.StraightDimensionSet StNew = null;
            NewVect = Com.ChangeVector(NewVect);
            TSD.PointList NewPoints = OrderPointList(GetDimPoints(st), Vect);
            st.Delete();
            StNew = new TSD.StraightDimensionSetHandler().CreateDimensionSet(st.GetView(), NewPoints, Vect, Dist, st.Attributes);
            StNew.Distance = GetCalDist(DOC, StNew, Vect, Dist);
            StNew.Modify();

            return StNew;
        }

        public static double GetCalDist(TSD.PointList NewPoints, TSD.PointList Points, double Dist)
        {
            double RetDist = 0;

            if (!IsEqualPoints(NewPoints[0], Points[0]))
                RetDist = Dist + Distance.PointToPoint(NewPoints[0], Points[0]);
            else
                RetDist = Dist + Distance.PointToPoint(NewPoints[0], Points[1]);

            return RetDist;
        }

        public static double GetCalDist(PlacingClass DOC, TSD.StraightDimensionSet st, Vector Vect, double OldDist)
        {
            double Dist = 0;
            Point p = GetDimPoints(st)[0];
            if (Vect.X > 0)
                Dist = OldDist + (DOC.RightX - p.X);
            else if (Vect.X < 0)
                Dist = OldDist + (p.X - DOC.LeftX);
            else if (Vect.Y > 0)
                Dist = OldDist + (DOC.TopY - p.Y);
            else if (Vect.Y < 0)
                Dist = OldDist + (p.Y - DOC.BottomY);

            return Dist;
        }

        public static TSD.PointList GetDimPoints(TSD.StraightDimensionSet st)
        {
            TSD.PointList RetList = null;
            PropertyInfo pi = st.GetType().GetProperty("DimensionPoints", BindingFlags.NonPublic | BindingFlags.Instance);
            if (pi != null)
            {
                object obj = pi.GetValue(st);
                RetList = obj as TSD.PointList;
            }

            return RetList;
        }

        public static double GetCalDist1(List<Point> OldPoints, TSD.StraightDimensionSet st, Vector Vect, double OldDist)
        {
            double Dist = 0;
            Point p = GetDimPoints(st)[0];
            if (Vect.X > 0)
                Dist = OldDist + Math.Abs((MaxP(OldPoints, "X").X - p.X));
            else if (Vect.X < 0)
                Dist = OldDist + Math.Abs(p.X - MinP(OldPoints, "X").X);
            else if (Vect.Y > 0)
                Dist = OldDist + Math.Abs(p.Y - MaxP(OldPoints, "Y").X);
            else if (Vect.Y < 0)
                Dist = OldDist + Math.Abs(p.Y - MinP(OldPoints, "Y").X);

            return Dist;
        }

        public static TSD.PointList OrderPointList(TSD.PointList PtList, Vector Vect)
        {
            List<Point> OpList = PtList.ToArray().ToList();
            if (Vect.X > 0)
                OpList = (from p in OpList orderby p.X ascending select p).ToList();
            else if (Vect.X < 0)
                OpList = (from p in OpList orderby p.X descending select p).ToList();
            else if (Vect.Y > 0)
                OpList = (from p in OpList orderby p.Y ascending select p).ToList();
            else if (Vect.Y < 0)
                OpList = (from p in OpList orderby p.Y descending select p).ToList();


            return PointToPointList(OpList);
        }

        public static Vector ChangeVector(Vector Vect)
        {
            Vector RetVect = new Vector(0, 0, 0);

            if (Vect.X > 0)
                RetVect.X = Vect.X * (-1);
            if (Vect.X < 0)
                RetVect.X = Math.Abs(Vect.X);

            if (Vect.Y > 0)
                RetVect.Y = Vect.Y * (-1);
            if (Vect.Y < 0)
                RetVect.Y = Math.Abs(Vect.Y);

            if (Vect.Z > 0)
                RetVect.Z = Vect.Z * (-1);
            if (Vect.Z < 0)
                RetVect.Z = Math.Abs(Vect.Z);

            return RetVect;
        }

        public static void DeleteDim(TSD.View CView, bool KeepKnockOff, Beam MainBeam)
        {
            List<TSD.DimensionBase> DimList = Com.EnumtoArrayD(CView.GetAllObjects(typeof(TSD.DimensionBase))).OfType<TSD.DimensionBase>().ToList();
            foreach (TSD.DimensionBase dim in DimList)
            {
                dim.Select();
                if (!(dim is TSD.RadiusDimension))
                {
                    TSD.DimensionSetBase setdim = dim.GetDimensionSet();
                    if (KeepKnockOff && setdim != null && setdim is TSD.StraightDimensionSet && IsKnockOffDim(MainBeam, setdim as TSD.StraightDimensionSet)) { }
                    else
                        dim.Delete();
                }
                else
                    dim.Delete();
            }
        }

        public static void DeleteDim(TSD.View CView)
        {
            TSD.DrawingObjectEnumerator DimList = CView.GetAllObjects(typeof(TSD.DimensionBase));
            List<TSD.DimensionBase> AllDim = Com.EnumtoArrayD(DimList).OfType<TSD.DimensionBase>().ToList();
            AllDim.ForEach(x => x.Delete());

        }

        private static bool IsKnockOffDim(Beam MainBeam, TSD.StraightDimensionSet stdim)
        {
            bool IsKnockOff = false;
            if (stdim != null)
            {

                List<Point> PTList = GetDimPoints(stdim).OfType<Point>().ToList();
                if (PTList.Count == 4)
                {
                    if (IsContainsPoint(PTList, MainBeam.StartPoint) && IsContainsPoint(PTList, MainBeam.EndPoint))
                    {

                        bool IsLeftP = ((from p in PTList where p.X == MainBeam.GetSolid().MinimumPoint.X select p).Count() > 0);
                        bool IsRightP = ((from p in PTList where p.X == MainBeam.GetSolid().MaximumPoint.X select p).Count() > 0);
                        if (IsLeftP && IsRightP)
                            IsKnockOff = true;
                    }
                }
            }

            return IsKnockOff;
        }

        public static bool IsSameBoltX(BoltGroup bolt1, BoltGroup bolt2)
        {
            bool check = true;
            TSD.PointList PtList1 = PointToPointList(bolt1.BoltPositions.OfType<Point>().ToList());
            TSD.PointList PtList2 = PointToPointList(bolt2.BoltPositions.OfType<Point>().ToList());

            if (bolt2.BoltPositions.Count > bolt1.BoltPositions.Count)
            {
                PtList1 = PointToPointList(bolt2.BoltPositions.OfType<Point>().ToList());
                PtList2 = PointToPointList(bolt1.BoltPositions.OfType<Point>().ToList());
            }

            for (int i = 0; i < PtList2.Count; i++)
            {
                bool chk = false;
                foreach (Point pt in PtList1)
                {
                    if (IsEqual(pt.Y, PtList2[i].Y))
                    {
                        chk = true;
                        break;
                    }
                }
                if (!chk)
                {
                    check = false;
                    break;
                }
            }

            return check;
        }

        public static TSD.PointList GetNewDimPoints(TSD.ViewBase ViewB, TSD.PointList pointList, Vector Vect, TSD.StraightDimensionSet.StraightDimensionSetAttributes DimAttr)
        {
            TSD.PointList RetPlist = new TSD.PointList();
            try
            {
                Vector NewVect = Com.ChangeVector(Vect);
                TSD.StraightDimensionSet st = new TSD.StraightDimensionSetHandler().CreateDimensionSet(ViewB, pointList, NewVect, 100, DimAttr);

                if (st != null)
                {
                    RetPlist = Com.GetDimPoints(st);
                    st.Delete();
                }
            }
            catch (Exception ex)
            {
                RetPlist = pointList;
            }



            return RetPlist;
        }

        public static bool IsContainsPoint(List<Point> PTList, Point CheckP)
        {
            bool RetCheck = false;

            Point PointL = (from p in PTList where IsEqualPoints(CheckP, p) select p).FirstOrDefault();
            if (PointL != null)
                RetCheck = true;

            return RetCheck;
        }

        public static Vector GetDimVector(TSD.DimensionSetBase xpsV)
        {

            Vector dir = null;
            System.Reflection.PropertyInfo propertyInfo = xpsV.GetType().GetProperty("UpDirection", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic);
            object value = propertyInfo.GetValue(xpsV, null);
            if (value is Vector)
                dir = value as Vector;

            dir = dir.GetNormal();
            dir = new Vector(Math.Round(dir.X, 4), Math.Round(dir.Y, 4), Math.Round(dir.Z, 4));

            return dir;
        }

        public static string GetCollectionPath(string ProjectName)
        {
            return CPath + ProjectName + @"\Collection Files\";
        }

        public static bool IssameY(TSD.PointList bptl)
        {
            if ((from p in bptl.OfType<Point>() where !IsEqual(p.Y, bptl[0].Y) select p).Count() > 0)
                return false;
            else
                return true;
        }

        public static bool IssameY(List<Point> bptl)
        {
            if ((from p in bptl where !IsEqual(p.Y, bptl[0].Y) select p).Count() > 0)
                return false;
            else
                return true;
        }

        public static bool IssameX(TSD.PointList bptl)
        {
            if ((from p in bptl.OfType<Point>() where !IsEqual(p.X, bptl[0].X) select p).Count() > 0)
                return false;
            else
                return true;
        }

        public static bool IssameX(List<Point> bptl)
        {
            if ((from p in bptl where !IsEqual(p.X, bptl[0].X) select p).Count() > 0)
                return false;
            else
                return true;
        }

        #region  Vector/Direction Methods



        public static bool IsSameVector(Vector V1, Vector V2)
        {
            if ((Math.Round(V1.X) == Math.Round(V2.X)) || (Math.Round(V1.Y) == Math.Round(V2.Y)))
                return true;
            else
                return false;
        }

        /*-----------------------------------------------------------------------------*/

        public static int UpDown_Dim(Point centerPoint, TSD.PointList pt)
        {
            int check = 1, u = 0, d = 0;
            double dist1 = 0, dist2 = 0;
            foreach (Point p in pt)
            {
                if (p.Y > centerPoint.Y)
                {
                    u++;
                    if (u == 1)
                        dist1 = Tekla.Structures.Geometry3d.Distance.PointToPoint(centerPoint, p);

                    if (dist1 > Tekla.Structures.Geometry3d.Distance.PointToPoint(centerPoint, p))
                        dist1 = Tekla.Structures.Geometry3d.Distance.PointToPoint(centerPoint, p);
                }

                if (p.Y < centerPoint.Y)
                {
                    d++;
                    if (d == 1)
                        dist2 = Tekla.Structures.Geometry3d.Distance.PointToPoint(centerPoint, p);

                    if (dist2 > Tekla.Structures.Geometry3d.Distance.PointToPoint(centerPoint, p))
                        dist2 = Tekla.Structures.Geometry3d.Distance.PointToPoint(centerPoint, p);
                }
            }
            if (u > d)
                return check = 1;
            else if (d > u)
                return check = 2;
            else if (u == d)
            {
                if (dist1 > dist2)
                    check = 1;
                else if (dist2 > dist1)
                    check = 2;
            }
            return check;
        }

        public static int LeftRight_Dim(Point centerPoint, TSD.PointList pt)
        {
            int check = 1, l = 0, r = 0;
            double dist1 = 0, dist2 = 0;
            foreach (Point p in pt)
            {
                if (p.X < centerPoint.X)
                {
                    l++;
                    if (l == 1)
                        dist1 = Tekla.Structures.Geometry3d.Distance.PointToPoint(centerPoint, p);

                    if (dist1 > Tekla.Structures.Geometry3d.Distance.PointToPoint(centerPoint, p))
                        dist1 = Tekla.Structures.Geometry3d.Distance.PointToPoint(centerPoint, p);
                }
                if (p.X > centerPoint.X)
                {
                    r++;
                    if (r == 1)
                        dist2 = Tekla.Structures.Geometry3d.Distance.PointToPoint(centerPoint, p);

                    if (dist2 > Tekla.Structures.Geometry3d.Distance.PointToPoint(centerPoint, p))
                        dist2 = Tekla.Structures.Geometry3d.Distance.PointToPoint(centerPoint, p);
                }
            }
            if (l > r)
                return check = 1;
            else if (r > l)
                return check = 2;
            else if (l == r)
            {
                if (dist1 > dist2)
                    check = 1;
                else if (dist2 > dist1)
                    check = 2;
            }
            return check;


        }

        public static int UpDown_Dim(Point centerPoint, Point p)
        {
            int res = 0;

            if (p.Y > centerPoint.Y)
            {
                res = 1;  // UP 
            }
            if (p.Y < centerPoint.Y)
            {
                res = 2;  // DOWN 
            }
            if (Math.Round(p.Y, 2) == Math.Round(centerPoint.Y, 2))
                res = 0;

            return res;
        }

        public static int LeftRight_Dim(Point centerPoint, Point p)
        {
            int res = 0;

            if (p.X < centerPoint.X)
            {
                res = 1;  // LEFT 
            }
            if (p.X > centerPoint.X)
            {
                res = 2;  // RIGHT 
            }
            if (Math.Round(p.X, 2) == Math.Round(centerPoint.X, 2))
                res = 0;

            return res;
        }

        public static TSM.Part Dr2Model(TSD.Part PartD)
        {
            return MyModel.SelectModelObject(PartD.ModelIdentifier) as TSM.Part;
        }

        #endregion

        #region Cut Part Dim

        public static bool IsBoolPartHole(TSM.Part opPart)
        {
            bool check = false;
            try
            {
                if (opPart is ContourPlate)
                {
                    int i = 0;
                    ContourPlate contPlate = opPart as ContourPlate;
                    if (contPlate.Contour.ContourPoints.Count == 4)
                    {
                        foreach (ContourPoint p in contPlate.Contour.ContourPoints)
                        {
                            if (p.Chamfer.Type == Chamfer.ChamferTypeEnum.CHAMFER_ARC_POINT)
                                i++;

                        }

                        if (i >= 2)
                            check = true;
                    }

                }
            }
            catch (Exception ex)
            { }

            return check;
        }

        public static double ResBoxDistY(TSD.StraightDimensionSet xpsV, double TopY)
        {
            TSD.PointList BoltPointL = GetDimPoints(xpsV);
            double dist = Math.Abs((TopY - BoltPointL[0].Y));
            return dist;
        }

        public static double ResBoxDistX(TSD.StraightDimensionSet xpsV, double TopX)
        {
            TSD.PointList BoltPointL = GetDimPoints(xpsV);
            double dist = Math.Abs((TopX - BoltPointL[0].X));
            return dist;
        }

        public static string GetProType(TSM.Part part)
        {
            string protype = "";

            part.GetReportProperty("PROFILE_TYPE", ref protype);

            return protype;

        }

        public static int IsCirOrSqPenetration(TSM.Part PenCut, TSD.View curView, Beam mainbeam)
        {
            int PenTyp = -1;
            if (curView.Name == "Front View")
            {
                Point pt1 = new Point(mainbeam.GetSolid().MinimumPoint.X, mainbeam.GetSolid().MinimumPoint.Y);
                Point pt3 = new Point(mainbeam.GetSolid().MaximumPoint.X, mainbeam.GetSolid().MaximumPoint.Y);


                int chafcount = 0;
                double chamfval = 0;
                bool IsArcChamf = false;
                TSD.PointList chfList = ContPList(PenCut);
                if (chfList.Count > 0)
                {
                    if (PenCut is PolyBeam)
                    {
                        foreach (ContourPoint cp in (PenCut as PolyBeam).Contour.ContourPoints)
                        {
                            if (cp.Chamfer.Type == TSM.Chamfer.ChamferTypeEnum.CHAMFER_ROUNDING)
                            {
                                chafcount++;
                                chamfval = cp.Chamfer.X;
                            }
                            else if (cp.Chamfer.Type == TSM.Chamfer.ChamferTypeEnum.CHAMFER_ARC_POINT)
                            {
                                chafcount++;
                                IsArcChamf = true;
                            }
                        }
                    }
                    else if (PenCut is ContourPlate)
                    {
                        foreach (ContourPoint cp in (PenCut as ContourPlate).Contour.ContourPoints)
                        {
                            if (cp.Chamfer.Type == TSM.Chamfer.ChamferTypeEnum.CHAMFER_ROUNDING)
                            {
                                chafcount++;
                                chamfval = cp.Chamfer.X;
                            }
                            else if (cp.Chamfer.Type == TSM.Chamfer.ChamferTypeEnum.CHAMFER_ARC_POINT)
                            {
                                chafcount++;
                                IsArcChamf = true;
                            }
                        }
                    }

                    Point p1 = new Point(PenCut.GetSolid().MinimumPoint.X, PenCut.GetSolid().MinimumPoint.Y);
                    Point p3 = new Point(PenCut.GetSolid().MaximumPoint.X, PenCut.GetSolid().MaximumPoint.Y);


                    if (IsEqualLess(p1.X, pt1.X) || IsEqualGreater(p3.X, pt3.X))
                    { }
                    else
                    {
                        double wid = MaxP(chfList, "X").X - MinP(chfList, "X").X;
                        double ht = MinP(chfList, "Y").Y - MinP(chfList, "Y").Y;
                        double halfwid = (wid / 2);
                        if (chafcount == 4 && chfList.Count == 4 && IsEqual(wid, ht) && IsEqual(chamfval, halfwid))
                            PenTyp = 0;         //Circle Penetration
                        else if (chafcount >= 2 && IsArcChamf)
                            PenTyp = 0;         //Circle Penetration
                        else if (chfList.Count <= 4 && (IsEqual(wid, ht) || !IsEqual(wid, ht)))
                            PenTyp = 1;         //Sq OR Rect Penetration

                    }
                }
            }
            return PenTyp;
        }

        public static TSD.PointList ContPList(ArrayList ArrPtlist)
        {
            TSD.PointList pointList = new TSD.PointList();
            try
            {
                foreach (TSM.ContourPoint pts in ArrPtlist)
                {
                    pointList.Add(new Point(pts.X, pts.Y, pts.Z));
                }
            }
            catch (Exception ex)
            { }

            return pointList;
        }

        public static TSD.PointList ContPList(TSM.Part Cplate)
        {
            TSD.PointList pointList = new TSD.PointList();
            if (Cplate is Beam)
            {
                pointList.AddRange(GetAllEdgesPList(Cplate));
            }
            else if (Cplate is PolyBeam)
            {
                foreach (TSM.ContourPoint pts in (Cplate as PolyBeam).Contour.ContourPoints)
                {
                    pointList.Add(new Point(pts.X, pts.Y));
                }
            }
            else if (Cplate is ContourPlate)
            {
                foreach (TSM.ContourPoint pts in (Cplate as ContourPlate).Contour.ContourPoints)
                {
                    pointList.Add(new Point(pts.X, pts.Y));
                }
            }
            return pointList;
        }

        public static TSD.PointList GetAllEdgesPList(TSM.Part mainBeam)
        {
            TSD.PointList VertPList = GetVertxPointsD(mainBeam);
            TSD.PointList AEdgePList = new TSD.PointList();

            AEdgePList.Add(MinPofX(VertPList, "X", MinP(VertPList, "Y").Y));
            AEdgePList.Add(MinPofX(VertPList, "X", MaxP(VertPList, "Y").Y));
            AEdgePList.Add(MaxPofX(VertPList, "X", MaxP(VertPList, "Y").Y));

            AEdgePList.Add(MaxPofX(VertPList, "X", MinP(VertPList, "Y").Y));
            AEdgePList.Add(MinPofY(VertPList, "Y", MinP(VertPList, "X").X));

            AEdgePList.Add(MaxPofY(VertPList, "Y", MinP(VertPList, "X").X));
            AEdgePList.Add(MaxPofY(VertPList, "Y", MaxP(VertPList, "X").X));
            AEdgePList.Add(MinPofY(VertPList, "Y", MaxP(VertPList, "X").X));

            return AEdgePList;
        }

        public static Point FindCenterPoint(TSD.PointList pttList)
        {
            Point pa = new Point(pttList[0]);
            Point pb = new Point(pttList[pttList.Count - 1]);
            double distance = (Tekla.Structures.Geometry3d.Distance.PointToPoint(pa, pb));

            double x = ((pb.X - pa.X) / distance) * (distance / 2) + pa.X;
            double y = ((pb.Y - pa.Y) / distance) * (distance / 2) + pa.Y;
            double z = ((pb.Z - pa.Z) / distance) * (distance / 2) + pa.Z;

            Point CenterPoint = new Point();

            if (!double.IsNaN(x) && !double.IsNaN(y) && !double.IsNaN(z))
                CenterPoint = new Point(x, y, z);

            return CenterPoint;
        }

        public static TSD.StraightDimensionSet InsertDim(TSD.View Currentview, TSD.PointList ptList, Vector vect, double Distance, TSD.StraightDimensionSet.StraightDimensionSetAttributes Attributes)
        {
            TSD.StraightDimensionSet StDimension = null;
            try
            {

                TSD.DrawingHandler dh = new TSD.DrawingHandler();
                TSD.Drawing CurrentDrawing = dh.GetActiveDrawing();
                StDimension = new TSD.StraightDimensionSetHandler().CreateDimensionSet(Currentview, ptList, vect, Distance, Attributes);
                if (StDimension != null)
                {
                    StDimension.Attributes.Placing.Placing = TSD.DimensionSetBaseAttributes.Placings.Fixed;
                    StDimension.Distance = Distance;
                    StDimension.Modify();
                    CurrentDrawing.CommitChanges();

                }
            }
            catch (Exception ex)
            {
                StDimension = null;
            }

            return StDimension;
        }

        #endregion

        #region Sorting PointList

        public static TSD.PointList SortPointListByMinY(TSD.PointList ptList11)
        {
            return PointToPointList(ptList11.OfType<Point>().OrderBy(o => o.Y).ToList());
        }

        public static TSD.PointList SortPointListByMaxY(TSD.PointList ptList11)
        {
            List<Point> ptList = ptList11.OfType<Point>().OrderBy(o => o.Y).ToList();
            ptList.Reverse();
            TSD.PointList SortedList = PointToPointList(ptList);

            return SortedList;
        }

        public static TSD.PointList SortPointListByMinX(TSD.PointList ptList11)
        {
            return PointToPointList(ptList11.OfType<Point>().OrderBy(o => o.X).ToList());
        }

        public static TSD.PointList SortPointListByMaxX(TSD.PointList ptList11)
        {
            List<Point> ptList = ptList11.OfType<Point>().OrderBy(o => o.X).ToList();
            ptList.Reverse();
            TSD.PointList SortedList = PointToPointList(ptList);

            return SortedList;
        }

        #endregion

        public static void ThruSlotLeft(TSD.StraightDimensionSet xDim)
        {
            try
            {
                TSD.DrawingHandler dh = new TSD.DrawingHandler();
                ArrayList arrlst = new ArrayList();
                xDim.Select();
                arrlst.Add(xDim);
                dh.GetDrawingObjectSelector().SelectObjects(arrlst, true);

                string macName = "ThruSlotRight";
                string MacroPath = string.Empty;
                Tekla.Structures.TeklaStructuresSettings.GetAdvancedOption("XS_MACRO_DIRECTORY", ref MacroPath);
                if (MacroPath.IndexOf(';') > 0) { MacroPath = MacroPath.Remove(MacroPath.IndexOf(';')); }

                string path = MacroPath.Replace("\\\\", "\\");
                if (!Directory.Exists(path))
                    Directory.CreateDirectory(path);
                string script = "namespace Tekla.Technology.Akit.UserScript" +
                                "{" +
                                    "public class Script" +
                                    "{" +
                                        "public static void Run(Tekla.Technology.Akit.IScript akit)" +
                                        "{" +
                                            @"akit.Callback(""acmd_display_selected_drawing_object_dialog"", """", ""View_10 window_1"");" +
                                             @"akit.TabChange(""dim_dial"", ""tabWndDimAttrib"", ""tabTags"");" +
                                              @"akit.ValueChange(""dim_dial"", ""txtFldRightUpperTag"", ""THRU"");" +
                                               @"akit.ValueChange(""dim_dial"", ""txtFldRightLowerTag"", ""SLOT"");" +
                                               @"akit.PushButton(""dim_modify"", ""dim_dial"");" +
                                               @"akit.PushButton(""dim_ok"", ""dim_dial"");" +

                "}}}";
                File.WriteAllText(Path.Combine(MacroPath, macName), script);
                TSMO.Operation.RunMacro("..\\" + macName);


                dh.GetDrawingObjectSelector().UnselectObjects(arrlst);
                dh.GetDrawingObjectSelector().UnselectAllObjects();
            }
            catch (Exception) { }


        }

        public static void ThruSlotRight(TSD.StraightDimensionSet xDim)
        {
            try
            {

                TSD.DrawingHandler dh = new TSD.DrawingHandler();
                ArrayList arrlst = new ArrayList();
                xDim.Select();
                arrlst.Add(xDim);
                dh.GetDrawingObjectSelector().SelectObjects(arrlst, true);

                string macName = "ThruSlotRight";
                string MacroPath = string.Empty;
                Tekla.Structures.TeklaStructuresSettings.GetAdvancedOption("XS_MACRO_DIRECTORY", ref MacroPath);
                if (MacroPath.IndexOf(';') > 0) { MacroPath = MacroPath.Remove(MacroPath.IndexOf(';')); }

                string path = MacroPath.Replace("\\\\", "\\");
                if (!Directory.Exists(path))
                    Directory.CreateDirectory(path);
                string script = "namespace Tekla.Technology.Akit.UserScript" +
                                "{" +
                                    "public class Script" +
                                    "{" +
                                        "public static void Run(Tekla.Technology.Akit.IScript akit)" +
                                        "{" +
                                            @"akit.Callback(""acmd_display_selected_drawing_object_dialog"", """", ""View_10 window_1"");" +
                                             @"akit.TabChange(""dim_dial"", ""tabWndDimAttrib"", ""tabTags"");" +
                                              @"akit.ValueChange(""dim_dial"", ""txtFldLeftUpperTag"", ""THRU"");" +
                                               @"akit.ValueChange(""dim_dial"", ""txtFldLeftLowerTag"", ""SLOT"");" +
                                               @"akit.PushButton(""dim_modify"", ""dim_dial"");" +
                                               @"akit.PushButton(""dim_ok"", ""dim_dial"");" +

                "}}}";
                File.WriteAllText(Path.Combine(MacroPath, macName), script);
                TSMO.Operation.RunMacro("..\\" + macName);


                dh.GetDrawingObjectSelector().UnselectObjects(arrlst);
                dh.GetDrawingObjectSelector().UnselectAllObjects();
            }
            catch (Exception) { }
        }

        public static void SetLeftUpperDimText(TSD.StraightDimensionSet xDim, string UpperText)
        {
            try
            {
                TSD.DrawingHandler dh = new TSD.DrawingHandler();
                ArrayList arrlst = new ArrayList();
                xDim.Select();
                arrlst.Add(xDim);
                dh.GetDrawingObjectSelector().SelectObjects(arrlst, true);

                string macName = "ThruSlotRight";
                string MacroPath = string.Empty;
                Tekla.Structures.TeklaStructuresSettings.GetAdvancedOption("XS_MACRO_DIRECTORY", ref MacroPath);
                if (MacroPath.IndexOf(';') > 0) { MacroPath = MacroPath.Remove(MacroPath.IndexOf(';')); }

                string path = MacroPath.Replace("\\\\", "\\");
                if (!Directory.Exists(path))
                    Directory.CreateDirectory(path);
                string script = "namespace Tekla.Technology.Akit.UserScript" +
                                "{" +
                                    "public class Script" +
                                    "{" +
                                        "public static void Run(Tekla.Technology.Akit.IScript akit)" +
                                        "{" +
                                            @"akit.Callback(""acmd_display_selected_drawing_object_dialog"", """", ""View_10 window_1"");" +
                                             @"akit.TabChange(""dim_dial"", ""tabWndDimAttrib"", ""tabTags"");" +
                                              "akit.ValueChange(\"dim_dial\", \"txtFldLeftUpperTag\", \" " + UpperText + " \" ); " +
                                               @"akit.PushButton(""dim_modify"", ""dim_dial"");" +
                                               @"akit.PushButton(""dim_ok"", ""dim_dial"");" +

                "}}}";


                File.WriteAllText(Path.Combine(MacroPath, macName), script);
                TSMO.Operation.RunMacro("..\\" + macName);


                dh.GetDrawingObjectSelector().UnselectObjects(arrlst);
                dh.GetDrawingObjectSelector().UnselectAllObjects();
            }
            catch (Exception ex) { }


        }

        public static void SetLeftLowerDimText(TSD.StraightDimensionSet xDim, string LowerText)
        {
            try
            {
                TSD.DrawingHandler dh = new TSD.DrawingHandler();
                ArrayList arrlst = new ArrayList();
                xDim.Select();
                arrlst.Add(xDim);
                dh.GetDrawingObjectSelector().SelectObjects(arrlst, true);

                string macName = "ThruSlotRight";
                string MacroPath = string.Empty;
                Tekla.Structures.TeklaStructuresSettings.GetAdvancedOption("XS_MACRO_DIRECTORY", ref MacroPath);
                if (MacroPath.IndexOf(';') > 0) { MacroPath = MacroPath.Remove(MacroPath.IndexOf(';')); }

                string path = MacroPath.Replace("\\\\", "\\");
                if (!Directory.Exists(path))
                    Directory.CreateDirectory(path);
                string script = "namespace Tekla.Technology.Akit.UserScript" +
                                "{" +
                                    "public class Script" +
                                    "{" +
                                        "public static void Run(Tekla.Technology.Akit.IScript akit)" +
                                        "{" +
                                            @"akit.Callback(""acmd_display_selected_drawing_object_dialog"", """", ""View_10 window_1"");" +
                                             @"akit.TabChange(""dim_dial"", ""tabWndDimAttrib"", ""tabTags"");" +
                                              "akit.ValueChange(\"dim_dial\", \"txtFldLeftLowerTag\", \" " + LowerText + " \" ); " +
                                               @"akit.PushButton(""dim_modify"", ""dim_dial"");" +
                                               @"akit.PushButton(""dim_ok"", ""dim_dial"");" +

                "}}}";


                File.WriteAllText(Path.Combine(MacroPath, macName), script);
                TSMO.Operation.RunMacro("..\\" + macName);


                dh.GetDrawingObjectSelector().UnselectObjects(arrlst);
                dh.GetDrawingObjectSelector().UnselectAllObjects();
            }
            catch (Exception ex) { }


        }

        public static void SetRightUpperDimText(TSD.StraightDimensionSet xDim, string UpperText)
        {
            try
            {
                TSD.DrawingHandler dh = new TSD.DrawingHandler();
                ArrayList arrlst = new ArrayList();
                xDim.Select();
                arrlst.Add(xDim);
                dh.GetDrawingObjectSelector().SelectObjects(arrlst, true);

                string macName = "ThruSlotRight";
                string MacroPath = string.Empty;
                Tekla.Structures.TeklaStructuresSettings.GetAdvancedOption("XS_MACRO_DIRECTORY", ref MacroPath);
                if (MacroPath.IndexOf(';') > 0) { MacroPath = MacroPath.Remove(MacroPath.IndexOf(';')); }

                string path = MacroPath.Replace("\\\\", "\\");
                if (!Directory.Exists(path))
                    Directory.CreateDirectory(path);
                string script = "namespace Tekla.Technology.Akit.UserScript" +
                                "{" +
                                    "public class Script" +
                                    "{" +
                                        "public static void Run(Tekla.Technology.Akit.IScript akit)" +
                                        "{" +
                                            @"akit.Callback(""acmd_display_selected_drawing_object_dialog"", """", ""View_10 window_1"");" +
                                             @"akit.TabChange(""dim_dial"", ""tabWndDimAttrib"", ""tabTags"");" +
                                              "akit.ValueChange(\"dim_dial\", \"txtFldRightUpperTag\", \" " + UpperText + " \" ); " +

                                               @"akit.PushButton(""dim_modify"", ""dim_dial"");" +
                                               @"akit.PushButton(""dim_ok"", ""dim_dial"");" +

                "}}}";


                File.WriteAllText(Path.Combine(MacroPath, macName), script);
                TSMO.Operation.RunMacro("..\\" + macName);


                dh.GetDrawingObjectSelector().UnselectObjects(arrlst);
                dh.GetDrawingObjectSelector().UnselectAllObjects();
            }
            catch (Exception ex) { }


        }

        public static void SetRightLowerDimText(TSD.StraightDimensionSet xDim, string LowerText)
        {
            try
            {
                TSD.DrawingHandler dh = new TSD.DrawingHandler();
                ArrayList arrlst = new ArrayList();
                xDim.Select();
                arrlst.Add(xDim);
                dh.GetDrawingObjectSelector().SelectObjects(arrlst, true);

                string macName = "ThruSlotRight";
                string MacroPath = string.Empty;
                Tekla.Structures.TeklaStructuresSettings.GetAdvancedOption("XS_MACRO_DIRECTORY", ref MacroPath);
                if (MacroPath.IndexOf(';') > 0) { MacroPath = MacroPath.Remove(MacroPath.IndexOf(';')); }

                string path = MacroPath.Replace("\\\\", "\\");
                if (!Directory.Exists(path))
                    Directory.CreateDirectory(path);
                string script = "namespace Tekla.Technology.Akit.UserScript" +
                                "{" +
                                    "public class Script" +
                                    "{" +
                                        "public static void Run(Tekla.Technology.Akit.IScript akit)" +
                                        "{" +
                                            @"akit.Callback(""acmd_display_selected_drawing_object_dialog"", """", ""View_10 window_1"");" +
                                             @"akit.TabChange(""dim_dial"", ""tabWndDimAttrib"", ""tabTags"");" +
                                             "akit.ValueChange(\"dim_dial\", \"txtFldRightLowerTag\", \" " + LowerText + " \" ); " +

                                               @"akit.PushButton(""dim_modify"", ""dim_dial"");" +
                                               @"akit.PushButton(""dim_ok"", ""dim_dial"");" +

                "}}}";

                File.WriteAllText(Path.Combine(MacroPath, macName), script);
                TSMO.Operation.RunMacro("..\\" + macName);


                dh.GetDrawingObjectSelector().UnselectObjects(arrlst);
                dh.GetDrawingObjectSelector().UnselectAllObjects();
            }
            catch (Exception ex) { }


        }

        public static void SetMidDimText(TSD.StraightDimensionSet xDim, string MidText)
        {
            try
            {
                TSD.DrawingHandler dh = new TSD.DrawingHandler();
                ArrayList arrlst = new ArrayList();
                xDim.Select();
                arrlst.Add(xDim);
                dh.GetDrawingObjectSelector().SelectObjects(arrlst, true);

                string macName = "ThruSlotRight";
                string MacroPath = string.Empty;
                Tekla.Structures.TeklaStructuresSettings.GetAdvancedOption("XS_MACRO_DIRECTORY", ref MacroPath);
                if (MacroPath.IndexOf(';') > 0) { MacroPath = MacroPath.Remove(MacroPath.IndexOf(';')); }

                string path = MacroPath.Replace("\\\\", "\\");
                if (!Directory.Exists(path))
                    Directory.CreateDirectory(path);
                string script = "namespace Tekla.Technology.Akit.UserScript" +
                                "{" +
                                    "public class Script" +
                                    "{" +
                                        "public static void Run(Tekla.Technology.Akit.IScript akit)" +
                                        "{" +
                                            @"akit.Callback(""acmd_display_selected_drawing_object_dialog"", """", ""View_10 window_1"");" +
                                             @"akit.TabChange(""dim_dial"", ""tabWndDimAttrib"", ""tabTags"");" +
                                              "akit.ValueChange(\"dim_dial\", \"txtFldMiddleLowerTag\", \" " + MidText + " \" ); " +
                                               @"akit.PushButton(""dim_modify"", ""dim_dial"");" +
                                               @"akit.PushButton(""dim_ok"", ""dim_dial"");" +

                "}}}";


                File.WriteAllText(Path.Combine(MacroPath, macName), script);
                TSMO.Operation.RunMacro("..\\" + macName);


                dh.GetDrawingObjectSelector().UnselectObjects(arrlst);
                dh.GetDrawingObjectSelector().UnselectAllObjects();
            }
            catch (Exception ex) { }


        }

        public static void DeleteDim()
        {
            try
            {
                string macName = "DeleteDim";
                string MacroPath = string.Empty;
                Tekla.Structures.TeklaStructuresSettings.GetAdvancedOption("XS_MACRO_DIRECTORY", ref MacroPath);
                if (MacroPath.IndexOf(';') > 0) { MacroPath = MacroPath.Remove(MacroPath.IndexOf(';')); }

                string path = MacroPath.Replace("\\\\", "\\");
                if (!Directory.Exists(path))
                    Directory.CreateDirectory(path);
                string script = "namespace Tekla.Technology.Akit.UserScript" +
                                "{" +
                                    "public class Script" +
                                    "{" +
                                        "public static void Run(Tekla.Technology.Akit.IScript akit)" +
                                        "{" +
                                            @"akit.Callback(""acmd_delete_selected_dr"", """", ""View_10 window_1"");" +
                                        "}}}";
                File.WriteAllText(Path.Combine(MacroPath, macName), script);
                TSMO.Operation.RunMacro("..\\" + macName);
            }
            catch (Exception) { }
        }

        public static void InsertMark()
        {
            try
            {
                string macName = "InsertMark";
                string MacroPath = string.Empty;
                Tekla.Structures.TeklaStructuresSettings.GetAdvancedOption("XS_MACRO_DIRECTORY", ref MacroPath);
                if (MacroPath.IndexOf(';') > 0) { MacroPath = MacroPath.Remove(MacroPath.IndexOf(';')); }

                string path = MacroPath.Replace("\\\\", "\\");
                if (!Directory.Exists(path))
                    Directory.CreateDirectory(path);
                string script = "namespace Tekla.Technology.Akit.UserScript" +
                                "{" +
                                    "public class Script" +
                                    "{" +
                                        "public static void Run(Tekla.Technology.Akit.IScript akit)" +
                                        "{" +
                                            @"akit.Callback(""acmd_create_marks_selected"", """", ""View_10 window_1"");" +
                                        "}}}";
                File.WriteAllText(Path.Combine(MacroPath, macName), script);
                TSMO.Operation.RunMacro("..\\" + macName);
            }
            catch (Exception) { }
        }

        public static void ModifyMark(string AttrName)
        {
            try
            {
                string macName = "ModifyMark";
                string MacroPath = string.Empty;
                Tekla.Structures.TeklaStructuresSettings.GetAdvancedOption("XS_MACRO_DIRECTORY", ref MacroPath);
                if (MacroPath.IndexOf(';') > 0) { MacroPath = MacroPath.Remove(MacroPath.IndexOf(';')); }

                string path = MacroPath.Replace("\\\\", "\\");
                if (!Directory.Exists(path))
                    Directory.CreateDirectory(path);
                string script = "namespace Tekla.Technology.Akit.UserScript" +
                                "{" +
                                    "public class Script" +
                                    "{" +
                                        "public static void Run(Tekla.Technology.Akit.IScript akit)" +
                                        "{" +
                                            @"akit.Callback(""acmd_display_selected_drawing_object_dialog"", """", ""View_10 window_1"");" +
                                               @"akit.ValueChange(""smark_dial"", ""gr_smark_get_menu"", ""standard"");" +
                                                @"akit.ValueChange(""smark_dial"", ""gr_smark_get_menu"", """ + AttrName + @""");" +
                                                  @"akit.PushButton(""gr_smark_get"",  ""smark_dial"");" +
                                                  @"akit.PushButton(""smark_modify"",  ""smark_dial"");" +
                                                  @"akit.PushButton(""smark_ok"",  ""smark_dial"");" +

                                        "}}}";
                File.WriteAllText(Path.Combine(MacroPath, macName), script);
                TSMO.Operation.RunMacro("..\\" + macName);
            }
            catch (Exception) { }
        }

        public static LineSegment GetLineSegm(TSD.Bolt bolt)
        {
            LineSegment line = new LineSegment((MyModel.SelectModelObject(bolt.ModelIdentifier) as BoltGroup).GetSolid().MinimumPoint, (MyModel.SelectModelObject(bolt.ModelIdentifier) as BoltGroup).GetSolid().MaximumPoint);
            return line;
        }

        public static LineSegment GetLineSegm(TSD.Part part)
        {
            LineSegment line = new LineSegment((MyModel.SelectModelObject(part.ModelIdentifier) as TSM.Part).GetSolid().MinimumPoint, (MyModel.SelectModelObject(part.ModelIdentifier) as TSM.Part).GetSolid().MaximumPoint);
            return line;
        }

        public static AABB GetAABB(TSD.Bolt bolt)
        {
            AABB aabb = new AABB((MyModel.SelectModelObject(bolt.ModelIdentifier) as BoltGroup).GetSolid().MinimumPoint, (MyModel.SelectModelObject(bolt.ModelIdentifier) as BoltGroup).GetSolid().MaximumPoint);
            return aabb;
        }

        public static AABB GetAABB(TSM.Part part)
        {
            AABB aabb = new AABB(part.GetSolid().MinimumPoint, part.GetSolid().MaximumPoint);
            return aabb;
        }

        public static TSM.Part GetPartByID(int ID)
        {
            return MyModel.SelectModelObject(new Tekla.Structures.Identifier(ID)) as Part;
        }

        public static TSM.ModelObject GetObjectByID(int ID)
        {
            return MyModel.SelectModelObject(new Tekla.Structures.Identifier(ID));
        }

        public static List<TSM.Part> GetBoltParts(BoltGroup bolt)
        {
            List<TSM.Part> RetList = new List<Part>();

            if (bolt.PartToBeBolted != null)
                RetList.Add(bolt.PartToBeBolted);
            if (bolt.PartToBoltTo != null)
                RetList.Add(bolt.PartToBoltTo);
            if (bolt.OtherPartsToBolt.Count > 0)
                RetList.AddRange(bolt.OtherPartsToBolt.OfType<Part>().ToList());

            return RetList;

        }

        public static void DrawLine(TSD.View CView, Point P1, Point P2)
        {
            try
            {

                TSD.Line line = new TSD.Line(CView, P1, P2);
                line.Attributes.Line.Color = TSD.DrawingColors.Black;
                line.Attributes.Line.Type = TSD.LineTypes.SolidLine;
                line.Insert();
            }
            catch (Exception ex)
            { }
        }

        public static void DrawLineDotted(TSD.View CView, Point P1, Point P2)
        {
            try
            {
                TSD.Line line = new TSD.Line(CView, P1, P2);
                line.Attributes.Line.Color = TSD.DrawingColors.Red;
                line.Attributes.Line.Type = TSD.LineTypes.DashDot;
                line.Insert();
            }
            catch (Exception ex)
            { }
        }

        public static TSD.Line DrawLineDotted1(TSD.View CView, Point P1, Point P2)
        {
            TSD.Line line = null;

            try
            {
                line = new TSD.Line(CView, P1, P2);
                line.Attributes.Line.Color = TSD.DrawingColors.Red;
                line.Attributes.Line.Type = TSD.LineTypes.DashDot;
                line.Insert();
            }
            catch (Exception ex)
            { }

            return line;
        }

        public static TSD.StraightDimensionSet InsertDim(TSD.ViewBase ViewB, TSD.PointList ptList, Vector Vect, double dist, TSD.StraightDimensionSet.StraightDimensionSetAttributes DimAtr)
        {
            TSD.StraightDimensionSet st = null;
            try
            {
                st = new TSD.StraightDimensionSetHandler().CreateDimensionSet(ViewB, ptList, Vect, dist, DimAtr);
            }
            catch (Exception ex)
            { }

            return st;
        }

        public static Point GetIntersectionPoint(Point P1, Point P2, Point P3, Point P4)
        {
            Point RetP = null;
            try
            {
                TSG.Line line1 = new TSG.Line(P1, P2);
                TSG.Line line2 = new TSG.Line(P3, P4);
                LineSegment lg = Intersection.LineToLine(line1, line2);
                RetP = lg.Point1;


            }
            catch (Exception ex)
            { }

            return RetP;
        }

        public static Point GetIntersectionPointN(Point P1, Point P2, Point P3, Point P4)
        {
            Point RetP = null;
            try
            {
                TSG.Line line1 = new TSG.Line(P1, P2);
                TSG.Line line2 = new TSG.Line(P3, P4);
                LineSegment lg = Intersection.LineToLine(line1, line2);

                if (Com.IsEqual(lg.Point1.Y, P3.Y))
                    RetP = lg.Point1;
                else
                    RetP = lg.Point2;


            }
            catch (Exception ex)
            { }

            return RetP;
        }

        public static void SetBoltType(TSD.View CView)
        {

            TSD.DrawingObjectEnumerator DimList = CView.GetAllObjects(typeof(TSD.Bolt));
            List<TSD.Bolt> AllBolts = Com.EnumtoArrayD(DimList).OfType<TSD.Bolt>().ToList();

            foreach (TSD.Bolt bolt in AllBolts)
            {
                BoltGroup boltG = Com.GetObjectByID(bolt.ModelIdentifier.ID) as BoltGroup;
                if (boltG.BoltType == BoltGroup.BoltTypeEnum.BOLT_TYPE_WORKSHOP)
                {
                    bolt.Attributes.Representation = TSD.Bolt.Representation.ExactSolid;
                    bolt.Modify();
                }

            }
        }

        public static PartPoints GetPartPoints(TSM.Part part)
        {
            PartPoints BPoints = new PartPoints();
            BPoints.CentP = Com.CenterPoint1(part.GetSolid().MinimumPoint, part.GetSolid().MaximumPoint);
            BPoints.P1 = new Point(part.GetSolid().MinimumPoint.X, part.GetSolid().MaximumPoint.Y);
            BPoints.P2 = new Point(part.GetSolid().MinimumPoint.X, part.GetSolid().MinimumPoint.Y);
            BPoints.P3 = new Point(part.GetSolid().MaximumPoint.X, part.GetSolid().MinimumPoint.Y);
            BPoints.P4 = new Point(part.GetSolid().MaximumPoint.X, part.GetSolid().MaximumPoint.Y);


            return BPoints;
        }

        public static PartPoints GetPartPointsSlop(TSM.Part part)
        {

            PartPoints BPoints = new PartPoints();
            BPoints.CentP = Com.CenterPoint1(part.GetSolid().MinimumPoint, part.GetSolid().MaximumPoint);
            BPoints.P1 = new Point(part.GetSolid().MinimumPoint.X, part.GetSolid().MaximumPoint.Y);
            BPoints.P2 = new Point(part.GetSolid().MinimumPoint.X, part.GetSolid().MinimumPoint.Y);
            BPoints.P3 = new Point(part.GetSolid().MaximumPoint.X, part.GetSolid().MinimumPoint.Y);
            BPoints.P4 = new Point(part.GetSolid().MaximumPoint.X, part.GetSolid().MaximumPoint.Y);


            return BPoints;
        }

        public static bool IsContPlateSlop(ContourPlate CP)
        {
            TSD.PointList PtList = Com.ContPList(CP);
            Point MaxY = MaxP(PtList, "Y");

            Point MaxX = MaxP(PtList, "X");

            if ((from p in PtList.OfType<Point>() where !IsEqualPoints(p, MaxY) && IsEqual(p.Y, MaxY.Y) select p).Count() > 0)
                return false;
            else
                return true;
        }

        public static bool IsPlateSlop(ContourPlate CP)
        {
            TSD.PointList PtList = Com.ContPList(CP);
            Point MaxY = MaxP(PtList, "Y");

            Point MaxX = MaxP(PtList, "X");

            if ((from p in PtList.OfType<Point>() where !IsEqualPoints(p, MaxY) && IsEqual(p.Y, MaxY.Y) select p).Count() > 0 && (from p in PtList.OfType<Point>() where !IsEqualPoints(p, MaxX) && IsEqual(p.X, MaxX.X) select p).Count() > 0)
                return false;
            else
                return true;
        }

        public static bool IsPlateSlop(Beam CP)
        {
            TSD.PointList PtList = Com.GetVertxPointsD(CP);
            Point MaxY = MaxP(PtList, "Y");

            Point MaxX = MaxP(PtList, "X");

            if ((from p in PtList.OfType<Point>() where !IsEqualPoints(p, MaxY) && IsEqual(p.Y, MaxY.Y) select p).Count() > 0 && (from p in PtList.OfType<Point>() where !IsEqualPoints(p, MaxX) && IsEqual(p.X, MaxX.X) select p).Count() > 0)
                return false;
            else
                return true;
        }

        public static Point To2DPoint(Point P1)
        {
            return new Point(P1.X, P1.Y);
        }

        public static TSD.PointList GetPartBoltPoint(TSM.Part part)
        {
            TSD.PointList RetPList = new TSD.PointList();
            List<BoltGroup> Bolts = Com.EnumtoArray(part.GetBolts()).OfType<BoltGroup>().ToList();
            if (Bolts != null && Bolts.Count > 0)
            {
                Bolts.ForEach(x => RetPList.AddRange(Com.GetBoltPoints(x)));
            }

            return RetPList;
        }

        public static double ToMM(string Value)
        {
            double RetVal = 0;
            try
            {

                if (Value.Contains("\n"))
                    Value = Value.Replace("\n", "");

                if (Value.Contains("{"))
                    Value = Value.Replace("{", "");

                if (Value.Contains("}"))
                    Value = Value.Replace("}", "");

                if (Value.Contains("-"))
                    Value = Value.Replace("-", "");

                if (Value.Contains(@"0\"))
                    Value = Value.Replace(@"0\", "");

                if (Value.Contains(@"\"))
                    Value = Value.Replace(@"\", "\"");

                if (Value.Contains("'") || Value.Contains("\""))
                {

                    TSDD.Distance.CurrentUnitType = TSDD.Distance.UnitType.Inch;
                    TSDD.Distance.UseFractionalFormat = true;
                    if (!string.IsNullOrEmpty(Value))
                    {
                        TSDD.Distance dist = new TSDD.Distance();

                        if (TSDD.Distance.TryParse(Value, out dist))
                            RetVal = dist.Millimeters;
                    }
                }
            }
            catch (Exception ex)
            { }

            return RetVal;
        }

        public static void GroupDim(TSD.StraightDimensionSet xDim)
        {
            xDim.Select();
            xDim.Attributes.CombinedDimension.Format = TSD.DimensionSetBaseAttributes.CombineFormats.NumberOfItemsTimesLengthEqualsResult;
            xDim.Attributes.CombinedDimension.MinimumNumberToCombine = 2;
            xDim.Modify();
            xDim.Attributes.CombinedDimension.Format = TSD.DimensionSetBaseAttributes.CombineFormats.Off;
        }

        public static List<string> GetCommaSepList(string List)
        {
            List<string> ReturnList = new List<string>();
            if (List.Contains(","))
            {
                char[] Comma = new char[] { ',' };
                ReturnList = List.Split(Comma, StringSplitOptions.None).ToList();
            }
            else
                ReturnList.Add(List);


            return ReturnList;
        }

        public static string GetLeftEndCode(TSM.Part part)
        {
            string code = "";
            //part.GetUserProperty("CONN_CODE_END1", ref code);
            part.GetUserProperty("LEFT_END_CONN", ref code);
            return code;
        }

        public static string GetRightEndCode(TSM.Part part)
        {

            string code = "";
            //part.GetUserProperty("CONN_CODE_END2", ref code);
            part.GetUserProperty("RIGHT_END_CONN", ref code);
            return code;
        }

        public static List<string> GetMiddleCode(TSM.Part part)
        {
            List<string> codes = new List<string>();
            try
            {
                string code = "";
                part.GetUserProperty("NOTES5", ref code);
                if (!string.IsNullOrEmpty(code))
                {
                    codes = GetCommaSepList(code);
                }
            }
            catch (Exception ex)
            { }

            return codes;
        }

        public static void ClearCode(TSM.Part part)
        {
            part.Select();
            part.SetUserProperty("NOTES6", "");
            part.Modify();
        }

        public static bool IsCode(TSM.Part part)
        {
            part.Select();
            string code = "";
            part.GetUserProperty("NOTES6", ref code);
            if (code == "BAC101")
                return true;
            else
                return false;

        }

        public static void SetCode(TSM.Part part)
        {
            part.Select();
            part.SetUserProperty("NOTES6", "BAC101");
            part.Modify();
        }

        public static string GetNote5(TSM.Part part)
        {
            part.Select();
            string code = "";
            part.GetUserProperty("NOTES5", ref code);


            return code;
        }

        public static PartClass GetPartClass(TSM.Part part)
        {
            PartClass PC = null;

            if (part != null)
            {
                PC = new PartClass();
                PC.part = part;
                PC.Points = GetPartPoints(part);
                PC.BoltPList = GetPartBoltPoint(part);
            }

            return PC;

        }

        public static TSD.AngleDimension InsertAngleDim(TSD.View CView, Point RefPBrace, Point IntPoint, string Position, double Dist)
        {
            TSD.AngleDimension angDimA = null;
            try
            {
                Point WP = RefPBrace;
                Point Temp = new Point(WP.X, WP.Y + 100, WP.Z);
                if (Position == "Bottom")
                    Temp = new Point(WP.X, WP.Y - 100, WP.Z);

                angDimA = new TSD.AngleDimension(CView, WP, IntPoint, Temp, Dist);
                angDimA.Attributes.Placing.Placing = TSD.DimensionSetBaseAttributes.Placings.Fixed;
                angDimA.Insert();
            }
            catch (Exception ex)
            { }


            return angDimA;

        }

        public static bool IsBoltPart(BoltGroup bolt, TSM.Part part)
        {
            bool RetCheck = false;
            List<int> IdList = GetBoltParts(bolt).Select(x => x.Identifier.ID).ToList();

            if (IdList.Contains(part.Identifier.ID))
                RetCheck = true;


            return RetCheck;
        }

        public static bool CheckControls(string Code, Control ctr)
        {
            bool RetCheck = false;
            string fileR = @"E:\textR.txt";
            if (File.Exists(fileR))
            {

                AutoDimensioningTypes autoDimensioningTypes = AutoMethods.GetAutoDimentionTypeObj();
                PropertyInfo pr = (from p in autoDimensioningTypes.GetType().GetProperties() where p.Name.ToUpper() == Code.ToUpper() select p).FirstOrDefault();
                if (pr != null)
                {
                    List<string> Names = pr.PropertyType.GetProperties().Select(x => x.Name).Where(x => x.Contains("DimIDNo")).OrderBy(x => x).ToList();
                    List<CheckBox> ListControl = ctr.Controls.OfType<CheckBox>().ToList();
                    List<string> ListControlN = ListControl.Select(x => x.Name.Replace("chk", "")).ToList();

                    if (Names != null && Names.Count > 0)
                    {
                        List<string> NewLines = new List<string>();
                        List<string> ListExc = (from s in Names where !ListControlN.Contains(s) select s).ToList();
                        if (ListExc != null && ListExc.Count > 0)
                        {

                            NewLines.Add("// These Controls are not added in Form :");
                            NewLines.Add(" ");
                            NewLines.AddRange(ListExc);
                            RetCheck = true;
                        }

                        ListExc = (from s in ListControlN where !Names.Contains(s) select s).ToList();
                        if (ListExc != null && ListExc.Count > 0)
                        {
                            NewLines.Add(" ");
                            NewLines.Add("// These Codes are not added in available DLL :");
                            NewLines.Add(" ");
                            NewLines.AddRange(ListExc);
                            RetCheck = true;
                        }

                        File.WriteAllLines(fileR, NewLines);
                    }

                }
            }


            return RetCheck;
        }

        // Get Mid Codes from the Secondries
        public static List<string> GetMidCodes(Beam MainBeam)
        {
            List<string> RetList = new List<string>();

            SetPlaneGlobally();
            MainBeam.Select();
            SetPlane(MainBeam.StartPoint, MainBeam.EndPoint);
            MainBeam.Select();

            List<TSM.Part> SecParts = MainBeam.GetAssembly().GetSecondaries().OfType<TSM.Part>().OrderBy(x=> x.GetSolid().MinimumPoint.X).ToList();
            if (SecParts != null && SecParts.Count > 0)
            {
                foreach (TSM.Part part in SecParts)
                {
                    string str = GetNote5(part).ToUpper();
                    if (!string.IsNullOrEmpty(str) && !RetList.Contains(str) && MidCodes.Contains(str))
                        RetList.Add(str);
                }
            }

            SetPlaneGlobally();
            MainBeam.Select();
            return RetList;
        }

        public static bool IsViewObj(TSM.Part part, TSD.View CView)
        {
            bool RetCheck = false;
            bool RetCheckZ = false;
            bool RetCheckX = false;
            bool RetCheckY = false;

            double MinZ = CView.RestrictionBox.MinPoint.Z;
            double MaxZ = CView.RestrictionBox.MaxPoint.Z;

            double MinZP = part.GetSolid().MinimumPoint.Z;
            double MaxZP = part.GetSolid().MaximumPoint.Z;

            double MinX = CView.RestrictionBox.MinPoint.X;
            double MaxX = CView.RestrictionBox.MaxPoint.X;

            double MinXP = part.GetSolid().MinimumPoint.X;
            double MaxXP = part.GetSolid().MaximumPoint.X;

            double MinY = CView.RestrictionBox.MinPoint.Y;
            double MaxY = CView.RestrictionBox.MaxPoint.Y;

            double MinYP = part.GetSolid().MinimumPoint.Y;
            double MaxYP = part.GetSolid().MaximumPoint.Y;

            RetCheckZ = ((MinZP >= MinZ && MaxZP <= MaxZ) || ((MinZ >= MinZP && MinZ <= MaxZP) || (MaxZ >= MinZP && MaxZ <= MaxZP)));

            RetCheckX = ((MinXP >= MinX && MaxXP <= MaxX) || ((MinX >= MinXP && MinX <= MaxXP) || (MaxX >= MinXP && MaxX <= MaxXP)));

            RetCheckY = ((MinYP >= MinY && MaxYP <= MaxY) || ((MinY >= MinYP && MinY <= MaxYP) || (MaxY >= MinYP && MaxY <= MaxYP)));

            if (RetCheckZ && RetCheckX && RetCheckY)
                RetCheck = true;

            return RetCheck;

        }

        public static double GetXDist(TSM.Part part)
        {
           return  part.GetSolid().MaximumPoint.X - part.GetSolid().MinimumPoint.X;
        }

        public static double GetYDist(TSM.Part part)
        {
            return part.GetSolid().MaximumPoint.Y - part.GetSolid().MinimumPoint.Y;
        }

        public static List<PartClass> FilterStiff(List<TSM.Part> Stiffs)
        {
            List<PartClass> partClasses = new List<PartClass>();
            List<double> XVals = new List<double>();
            foreach (TSM.Part p in Stiffs)
            {
                PartClass PC = Com.GetPartClass(p);
                if (XVals.Where(x => Com.IsEqual(PC.Points.P1.X, x)).Count() == 0)
                {
                    partClasses.Add(PC);
                    XVals.Add(PC.Points.P1.X);
                }
            }


            return partClasses;
        }
    }
}
