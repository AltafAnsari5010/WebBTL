﻿using System;
using Tekla.Structures.Drawing;
using Tekla.Structures.Geometry3d;
using TSG =Tekla.Structures.Geometry3d;

namespace Auto_Detailing_Tool_Beam
{
    public static class PL
    {
        #region Dim Placing

        public static PlacingClass DimPlaceByTopY(StraightDimensionSet xpsV, PlacingClass PC)
        {
            //DimCheck(xpsV);
            try
            {
                if (xpsV != null)
                {
                    PointList BoltPointL = Com.GetDimPoints(xpsV);
                    double dist = Math.Abs(PC.TopY - BoltPointL[0].Y) + PC.DistTop;
                    xpsV.Distance = dist;
                    xpsV.Modify();

                    if (xpsV.Attributes.DimensionType == DimensionSetBaseAttributes.DimensionTypes.Absolute || xpsV.Attributes.DimensionType == DimensionSetBaseAttributes.DimensionTypes.RelativeAndAbsolute || xpsV.Attributes.DimensionType == DimensionSetBaseAttributes.DimensionTypes.AbsoluteWithShortRelatives || xpsV.Attributes.DimensionType == DimensionSetBaseAttributes.DimensionTypes.AbsoluteWithAllRelativesAbove)
                        PC.DistTop += (PC.DistInc * 2);
                    else
                        PC.DistTop += PC.DistInc;
                }
            }
            catch (Exception ex)
            {
                //cs.ErrorMsg(ex);
            }
            return PC;
        }

        public static PlacingClass DimPlaceByBottomY(StraightDimensionSet xpsV, PlacingClass PC)
        {
            // DimCheck(xpsV);
            try
            {
                if (xpsV != null)
                {
                    PointList BoltPointL = Com.GetDimPoints(xpsV);
                    double dist = Math.Abs((PC.BottomY - BoltPointL[0].Y)) + PC.DistBot;
                    xpsV.Distance = dist;
                    xpsV.Modify();

                    if (xpsV.Attributes.DimensionType == DimensionSetBaseAttributes.DimensionTypes.Absolute || xpsV.Attributes.DimensionType == DimensionSetBaseAttributes.DimensionTypes.RelativeAndAbsolute || xpsV.Attributes.DimensionType == DimensionSetBaseAttributes.DimensionTypes.AbsoluteWithShortRelatives || xpsV.Attributes.DimensionType == DimensionSetBaseAttributes.DimensionTypes.AbsoluteWithAllRelativesAbove)
                        PC.DistBot += (PC.DistInc * 2);
                    else
                        PC.DistBot += PC.DistInc;
                }
            }
            catch (Exception ex)
            {
                // cs.ErrorMsg(ex);
            }
            return PC;
        }

        public static PlacingClass DimPlaceByLeftX(StraightDimensionSet xpsV, PlacingClass PC)
        {
            // DimCheck(xpsV);
            try
            {
                if (xpsV != null)
                {
                    PointList BoltPointL = Com.GetDimPoints(xpsV);
                    double dist = Math.Abs((PC.LeftX - BoltPointL[0].X)) + PC.DistLeft;
                    xpsV.Distance = dist;
                    xpsV.Modify();

                    if (xpsV.Attributes.DimensionType == DimensionSetBaseAttributes.DimensionTypes.Absolute || xpsV.Attributes.DimensionType == DimensionSetBaseAttributes.DimensionTypes.RelativeAndAbsolute || xpsV.Attributes.DimensionType == DimensionSetBaseAttributes.DimensionTypes.AbsoluteWithShortRelatives || xpsV.Attributes.DimensionType == DimensionSetBaseAttributes.DimensionTypes.AbsoluteWithAllRelativesAbove)
                        PC.DistLeft += (PC.DistInc * 2);
                    else
                        PC.DistLeft += PC.DistInc;
                }
            }
            catch (Exception ex)
            {
                //cs.ErrorMsg(ex);
            }
            return PC;
        }

        public static PlacingClass DimPlaceByRightX(StraightDimensionSet xpsV, PlacingClass PC)
        {
            // DimCheck(xpsV);
            try
            {
                if (xpsV != null)
                {
                    PointList BoltPointL = Com.GetDimPoints(xpsV);
                    double dist = Math.Abs(PC.RightX - BoltPointL[0].X) + PC.DistRight;
                    xpsV.Distance = dist;
                    xpsV.Modify();

                    if (xpsV.Attributes.DimensionType == DimensionSetBaseAttributes.DimensionTypes.Absolute || xpsV.Attributes.DimensionType == DimensionSetBaseAttributes.DimensionTypes.RelativeAndAbsolute || xpsV.Attributes.DimensionType == DimensionSetBaseAttributes.DimensionTypes.AbsoluteWithShortRelatives || xpsV.Attributes.DimensionType == DimensionSetBaseAttributes.DimensionTypes.AbsoluteWithAllRelativesAbove)
                        PC.DistRight += (PC.DistInc * 2);
                    else
                        PC.DistRight += PC.DistInc;
                }
            }
            catch (Exception ex)
            {
                // cs.ErrorMsg(ex);
            }

            return PC;
        }

        public static double ResBoxDistLeft(StraightDimensionSet xpsV, PlacingClass PC)
        {
            PointList BoltPointL = Com.GetDimPoints(xpsV);
            double dist = Math.Abs((PC.LeftX - BoltPointL[0].X));
            return dist;
        }

        public static double ResBoxDistRight(StraightDimensionSet xpsV, PlacingClass PC)
        {
            PointList BoltPointL = Com.GetDimPoints(xpsV);
            double dist = PC.RightX - BoltPointL[0].X;
            return dist;
        }

        public static double ResBoxDistTop(StraightDimensionSet xpsV, PlacingClass PC)
        {
            PointList BoltPointL = Com.GetDimPoints(xpsV);
            double dist = Math.Abs((PC.TopY - BoltPointL[0].Y));
            return dist;
        }

        public static double ResBoxDistBottom(StraightDimensionSet xpsV, PlacingClass PC)
        {
            PointList BoltPointL = Com.GetDimPoints(xpsV);
            double dist = Math.Abs((PC.BottomY - BoltPointL[0].Y));
            return dist;
        }


        public static double DistLeftP(StraightDimensionSet xpsV, double Xval)
        {
            PointList BoltPointL = Com.GetDimPoints(xpsV);
            double dist = Math.Abs((Xval - BoltPointL[0].X));
            return dist;
        }

        public static double DistTopP(StraightDimensionSet xpsV, double Yval)
        {
            PointList BoltPointL = Com.GetDimPoints(xpsV);
            double dist = Math.Abs((Yval - BoltPointL[0].Y));
            return dist;
        }

        public static double DistBottP(StraightDimensionSet xpsV, double Yval)
        {
            PointList BoltPointL = Com.GetDimPoints(xpsV);
            double dist = Math.Abs((Yval - BoltPointL[0].Y));
            return dist;
        }

        public static double DistRightP(StraightDimensionSet xpsV, double Xval)
        {
            PointList BoltPointL = Com.GetDimPoints(xpsV);
            double dist = Xval - BoltPointL[0].X;
            return dist;
        }

        public static StraightDimensionSet DistPlaceLeftP(StraightDimensionSet xpsV, double Xval, double Dist)
        {
            xpsV.Distance = DistLeftP(xpsV, Xval) + Dist;
            xpsV.Modify();
            xpsV.GetDrawing().CommitChanges();
            return xpsV;
        }

        public static StraightDimensionSet DistPlaceRightP(StraightDimensionSet xpsV, double Xval, double Dist)
        {
            xpsV.Distance = DistRightP(xpsV, Xval) + Dist;
            xpsV.Modify();
            xpsV.GetDrawing().CommitChanges();
            return xpsV;
        }

        public static StraightDimensionSet DistPlaceTopP(StraightDimensionSet xpsV, double Yval, double Dist)
        {
            xpsV.Distance = DistTopP(xpsV, Yval) + Dist;
            xpsV.Modify();
            xpsV.GetDrawing().CommitChanges();
            return xpsV;
        }

        public static StraightDimensionSet DistPlaceBottP(StraightDimensionSet xpsV, double Yval, double Dist)
        {
            xpsV.Distance = DistTopP(xpsV, Yval) + Dist;
            xpsV.Modify();
            xpsV.GetDrawing().CommitChanges();
            return xpsV;
        }


        public static StraightDimensionSet DimPlacingDiag(StraightDimensionSet xpsV, TSG.Line YLine, double Dist)
        {
            try
            {
                PointList BoltPointL = Com.GetDimPoints(xpsV);
                TSG.Line YLine1 = new TSG.Line(BoltPointL[0], BoltPointL[1]);
                double dist = TSG.Distance.PointToLine(BoltPointL[0], YLine);
                //if (dist > 0)
                Dist = Dist + dist;

                xpsV.Distance = Dist;
                xpsV.Modify();
                xpsV.GetDrawing().CommitChanges();
            }
            catch (Exception ex)
            { }
            return xpsV;
        }

        #endregion
    }

    public class PlacingClass
    {
        public double DistTop = 100;
        public double DistBot = 100;

        public double DistLeft = 100;
        public double DistRight = 100;
        public double DistInc = 70;
        public double DistIncD = 100;
        public double DistD = 100;

        public double TopY { get; set; }
        public double BottomY { get; set; }

        public double LeftX { get; set; }
        public double RightX { get; set; }
    }
}
