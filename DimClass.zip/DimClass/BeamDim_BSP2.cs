﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Tekla.Structures;
using Tekla.Structures.Drawing;
using Tekla.Structures.Geometry3d;
using Tekla.Structures.Model;
using TSD = Tekla.Structures.Drawing;
using TSM = Tekla.Structures.Model;
using VirtueleDrawingAutomation;
using TSDD = Tekla.Structures.Datatype;
using TSG = Tekla.Structures.Geometry3d;

namespace Auto_Detailing_Tool_Beam
{
    public class BeamDim_BSP2
    {
        #region Global Variables
        DimCom dc = new DimCom();
        StraightDimensionSet.StraightDimensionSetAttributes StAtrr = new StraightDimensionSet.StraightDimensionSetAttributes("standard");
        StraightDimensionSet.StraightDimensionSetAttributes RdAtrr = new StraightDimensionSet.StraightDimensionSetAttributes("standard");

        public Beam MainBeam = null;
        VirtueleDrawingAutomation.Json.DrawingAttributeInfoJson.AttributeFiles dimAttrClass = null;
        List<TSD.StraightDimension> KnockDim = new List<StraightDimension>();
        BeamClass_BSP2 BC = null;

        VirtueleDrawingAutomation.Json.AutoDimensionTypesJson.BSP2Json DN = null;
        string Position = "Left";
        TSD.View CView = null;
        string ViewName = "";
        public Point BoltPS = null;

        #endregion

        public void ApplyDim(TSD.View CView, string ViewName, AutoDimensioningTypes autoDimensioningTypes, DrawingAttributeInfo drawingAttributeInfo, string Position)
        {
            try
            {
                Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane());
                //Set model everything to the view
                Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane(CView.DisplayCoordinateSystem));

                this.CView = CView;
                this.dimAttrClass = drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files;
                this.DN = autoDimensioningTypes.Bsp2;
                this.Position = Position;
                StAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.StandardDimension);
                RdAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.RunningDimension);
                this.MainBeam = (Com.MyModel.SelectModelObject(new Identifier((CView.GetDrawing() as AssemblyDrawing).AssemblyIdentifier.ID)) as TSM.Assembly).GetMainPart() as TSM.Beam;
                this.MainBeam.Select();
                string ProType = Com.GetProType(MainBeam);
                this.ViewName = ViewName;
                GetBeamClassClass(CView);

                if (Position == "Left")
                {
                    if (ViewName == "Front View")
                        ApplyDimTypeLeft(CView);
                    if (ViewName == "Top View" || ViewName == "Bottom View")
                        ApplyDimTypeLeftTV(CView);
                    else
                    if (ViewName == "Section View")
                        AppySectionDim();
                }

                else if (Position == "Right")
                {
                    if (ViewName == "Front View")
                        ApplyDimTypeRight(CView);
                    if (ViewName == "Top View" || ViewName == "Bottom View")
                        ApplyDimTypeRightTV(CView);
                    else
                    if (ViewName == "Section View")
                        AppySectionDim();
                }
            }
            catch (Exception ex)
            { }

            Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane());
        }

        #region Front View
        private void ApplyDimTypeLeft(TSD.View CView)
        {

            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(-1, 0, 0);
            TSD.PointList TempList = new PointList();

            if (BC.WP != null)
            {
                if (BC.WP.WebPlate != null)
                {
                    #region Left Dim
                    Vect = new Vector(-1, 0, 0);
                    TempList.AddRange(BC.WP.BoltB);
                    TempList.AddRange(BC.WP.BoltP);
                    TempList = dc.ChangePints(TempList, CView, Vect);



                    // Dim No 2.3
                    if (DN.DimIDNo2Dot3)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MaxP(TempList, "Y"));
                        pointList.Add(BC.WP.WebPlate.Points.P1);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceLeftP(xDim, BC.WP.WebPlate.Points.P1.X, (BC.PC.DistLeft / 2));
                            BC.PC.DistLeft += (BC.PC.DistInc / 2);
                        }
                    }


                    // Dim No 1
                    if (DN.DimIDNo1)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.Points.P1);
                        pointList.Add(Com.MaxP(TempList, "Y"));
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceLeftP(xDim, BC.WP.WebPlate.Points.P1.X, BC.PC.DistLeft);

                    }

                    // Dim No 2.2
                    if (DN.DimIDNo2Dot2)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MinP(TempList, "Y"));
                        pointList.Add(BC.WP.WebPlate.Points.P2);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceLeftP(xDim, BC.WP.WebPlate.Points.P1.X, BC.PC.DistLeft);

                    }

                    if (DN.DimIDNo1 || DN.DimIDNo2Dot2)
                        BC.PC.DistLeft += BC.PC.DistInc;

                    // Dim No 2
                    if (DN.DimIDNo2)
                    {
                        pointList = new PointList();
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByLeftX(xDim, BC.PC);

                    }

                    // Dim No 2.1
                    if (DN.DimIDNo2Dot1)
                    {
                        if (TempList.Count > 2)
                        {
                            pointList = new PointList();
                            pointList.AddRange(TempList);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                            if (xDim != null)
                            {
                                PL.DimPlaceByLeftX(xDim, BC.PC);
                                Com.GroupDim(xDim);
                            }
                        }

                    }


                    // Dim No 14 Elevation Dim
                    if (DN.DimIDNo14)
                    {


                        Vect = new Vector(-1, 0, 0);
                        StraightDimensionSet.StraightDimensionSetAttributes ElAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.ElevationDimension);
                        ElAtrr.DimensionType = DimensionSetBaseAttributes.DimensionTypes.Elevation;
                        ElAtrr.Arrowhead.Head = ArrowheadTypes.FilledArrow;
                        pointList = new PointList();

                        if (MainBeam.StartPoint.X > MainBeam.EndPoint.X)
                        {
                            pointList.Add(MainBeam.EndPoint);
                            pointList.Add(MainBeam.EndPoint);

                        }
                        else
                        {
                            pointList.Add(MainBeam.StartPoint);
                            pointList.Add(MainBeam.StartPoint);
                        }

                        BC.PC.DistLeft = BC.PC.DistLeft - (BC.Points.P1.X - pointList[0].X);
                        xDim = dc.InsertDimm(CView, pointList, Vect, (-BC.PC.DistLeft), ElAtrr);
                        if (xDim != null)
                        {
                            xDim.Distance = (-BC.PC.DistLeft);
                            xDim.Modify();
                        }
                        BC.PC.DistLeft += BC.PC.DistInc;

                    }

                    #endregion

                    #region Top Dim
                    Vect = new Vector(0, 1, 0);
                    TempList = new PointList();
                    TempList.AddRange(BC.WP.BoltB);
                    TempList.AddRange(BC.WP.BoltP);
                    TempList = dc.ChangePints(TempList, CView, Vect);

                    // Dim No 4.1
                    if (DN.DimIDNo4Dot1)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MinP(TempList, "X"));
                        pointList.Add(BC.WP.WebPlate.Points.P1);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);


                        pointList = new PointList();
                        pointList.Add(Com.MaxP(TempList, "X"));
                        pointList.Add(BC.WP.WebPlate.Points.P4);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);

                        BC.PC.DistTop += BC.PC.DistInc;

                    }


                    // Dim No 11.1
                    if (DN.DimIDNo11Dot1)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MinPofX(BC.WP.BoltB, "Y", Com.MinP(BC.WP.BoltB, "X").X));
                        pointList.Add(BC.Points.P1);
                        pointList.Add(Com.MinPofX(BC.WP.BoltP, "Y", Com.MaxP(BC.WP.BoltP, "X").X));
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);

                        BC.PC.DistTop += BC.PC.DistInc;

                    }

                    // Dim No 4
                    if (DN.DimIDNo4)
                    {
                        pointList = new PointList();
                        pointList.AddRange(dc.ChangePints(BC.WP.BoltP, CView, Vect));
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                    }

                    // Dim No 19
                    if (DN.DimIDNo19)
                    {
                        pointList = new PointList();
                        pointList.AddRange(dc.ChangePints(BC.WP.BoltB, CView, Vect));
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                    }

                    if (DN.DimIDNo4 || DN.DimIDNo19)
                        BC.PC.DistTop += BC.PC.DistInc;

                    // Dim No 11
                    if (DN.DimIDNo11)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MinPofX(BC.WP.BoltP, "Y", Com.MaxP(BC.WP.BoltP, "X").X));
                        pointList.Add(Com.MinPofX(BC.WP.BoltB, "Y", Com.MinP(BC.WP.BoltB, "X").X));
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                    }

                    TempList = dc.ChangePints(BC.WP.BoltP, CView, Vect);
                    // Dim No 4.2
                    if (DN.DimIDNo4Dot2 && TempList.Count > 2)
                    {

                        pointList = new PointList();
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                            Com.GroupDim(xDim);
                        }
                    }

                    if (DN.DimIDNo11 || (DN.DimIDNo4Dot2 && TempList.Count > 2))
                        BC.PC.DistTop += BC.PC.DistInc;

                    TempList = dc.ChangePints(BC.WP.BoltB, CView, Vect);

                    // Dim No 3
                    if (DN.DimIDNo3Dot1)
                    {

                        pointList = new PointList();
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                        {
                            PL.DimPlaceByTopY(xDim, BC.PC);
                            Com.GroupDim(xDim);
                        }

                        pointList = new PointList();
                        pointList.Add(BC.Points.P1);
                        pointList.Add(Com.MinP(TempList, "X"));
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                        if (xDim != null)
                            PL.DimPlaceByTopY(xDim, BC.PC);
                    }
                    else if (DN.DimIDNo3)
                    {
                        BC.PC.DistTop += BC.PC.DistInc;
                        pointList = new PointList();
                        pointList.Add(BC.Points.P1);
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                        if (xDim != null)
                            PL.DimPlaceByTopY(xDim, BC.PC);
                    }



                    #endregion
                }

                #region Filler and Web Plate Top And Bottom
                BC.PC.DistLeft = (BC.PC.DistInc / 2);
                Vect = new Vector(1, 0, 0);
                if (BC.WP.WebPlateT != null)
                {
                    // Dim No 15
                    if (DN.DimIDNo15)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.WP.WebPlateT.Points.P4);
                        pointList.Add(BC.WP.WebPlateT.Points.P3);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);

                    }
                }
                Vect = new Vector(-1, 0, 0);
                if (BC.WP.FillPlateT != null)
                {
                    // Dim No 15.1
                    if (DN.DimIDNo15Dot1)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.WP.FillPlateT.Points.P2);
                        pointList.Add(BC.WP.FillPlateT.Points.P1);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                            BC.PC.DistLeft += BC.PC.DistInc;
                    }
                }

                if (BC.WP.FillPlateT2 != null)
                {
                    // Dim No 15.2
                    if (DN.DimIDNo15Dot2)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.WP.FillPlateT2.Points.P2);
                        pointList.Add(BC.WP.FillPlateT2.Points.P1);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                            BC.PC.DistLeft += BC.PC.DistInc;
                    }
                }


                BC.PC.DistLeft = (BC.PC.DistInc / 2);
                Vect = new Vector(1, 0, 0);
                if (BC.WP.WebPlateB != null)
                {
                    // Dim No 15
                    if (DN.DimIDNo15)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.WP.WebPlateB.Points.P4);
                        pointList.Add(BC.WP.WebPlateB.Points.P3);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);

                    }
                }
                Vect = new Vector(-1, 0, 0);
                if (BC.WP.FillPlateB != null)
                {
                    // Dim No 15.1
                    if (DN.DimIDNo15Dot1)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.WP.FillPlateB.Points.P1);
                        pointList.Add(BC.WP.FillPlateB.Points.P2);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                            BC.PC.DistLeft += BC.PC.DistInc;
                    }
                }

                if (BC.WP.FillPlateB2 != null)
                {
                    // Dim No 15.1
                    if (DN.DimIDNo15Dot1)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.WP.FillPlateB2.Points.P1);
                        pointList.Add(BC.WP.FillPlateB2.Points.P2);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                            BC.PC.DistLeft += BC.PC.DistInc;
                    }
                }

                #endregion


            }



        }

        private void ApplyDimTypeRight(TSD.View CView)
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(1, 0, 0);
            TSD.PointList TempList = new PointList();

            if (BC.WP != null)
            {

                if (BC.WP.WebPlate != null)
                {

                    #region Left Dim
                    Vect = new Vector(1, 0, 0);
                    TempList.AddRange(BC.WP.BoltB);
                    TempList.AddRange(BC.WP.BoltP);
                    TempList = dc.ChangePints(TempList, CView, Vect);



                    // Dim No 2.3
                    if (DN.DimIDNo2Dot3)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MaxP(TempList, "Y"));
                        pointList.Add(BC.WP.WebPlate.Points.P4);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceRightP(xDim, BC.WP.WebPlate.Points.P4.X, (BC.PC.DistRight / 2));
                            BC.PC.DistRight += (BC.PC.DistInc / 2);
                        }
                    }


                    // Dim No 1
                    if (DN.DimIDNo1)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.Points.P4);
                        pointList.Add(Com.MaxP(TempList, "Y"));
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceRightP(xDim, BC.WP.WebPlate.Points.P4.X, BC.PC.DistRight);

                    }

                    // Dim No 2.2
                    if (DN.DimIDNo2Dot2)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MinP(TempList, "Y"));
                        pointList.Add(BC.WP.WebPlate.Points.P3);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceRightP(xDim, BC.WP.WebPlate.Points.P4.X, BC.PC.DistRight);

                    }

                    if (DN.DimIDNo1 || DN.DimIDNo2Dot2)
                        BC.PC.DistRight += BC.PC.DistInc;

                    // Dim No 2
                    if (DN.DimIDNo2)
                    {
                        pointList = new PointList();
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByRightX(xDim, BC.PC);

                    }

                    // Dim No 2.1
                    if (DN.DimIDNo2Dot1)
                    {
                        if (TempList.Count > 2)
                        {
                            pointList = new PointList();
                            pointList.AddRange(TempList);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                            if (xDim != null)
                            {
                                PL.DimPlaceByRightX(xDim, BC.PC);
                                Com.GroupDim(xDim);
                            }
                        }

                    }

                    #endregion

                    #region Top Dim
                    Vect = new Vector(0, 1, 0);
                    TempList = new PointList();
                    TempList.AddRange(BC.WP.BoltB);
                    TempList.AddRange(BC.WP.BoltP);
                    TempList = dc.ChangePints(TempList, CView, Vect);

                    // Dim No 4.1
                    if (DN.DimIDNo4Dot1)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MaxP(TempList, "X"));
                        pointList.Add(BC.WP.WebPlate.Points.P4);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);


                        pointList = new PointList();
                        pointList.Add(Com.MinP(TempList, "X"));
                        pointList.Add(BC.WP.WebPlate.Points.P1);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);

                        BC.PC.DistTop += BC.PC.DistInc;

                    }

                    // Dim No 11.1
                    if (DN.DimIDNo11Dot1)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MinPofX(BC.WP.BoltB, "Y", Com.MaxP(BC.WP.BoltB, "X").X));
                        pointList.Add(BC.Points.P4);
                        pointList.Add(Com.MinPofX(BC.WP.BoltP, "Y", Com.MinP(BC.WP.BoltP, "X").X));
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);

                        BC.PC.DistTop += BC.PC.DistInc;

                    }


                    // Dim No 4
                    if (DN.DimIDNo4)
                    {
                        pointList = new PointList();
                        pointList.AddRange(dc.ChangePints(BC.WP.BoltP, CView, Vect));
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                    }

                    // Dim No 19
                    if (DN.DimIDNo19)
                    {
                        pointList = new PointList();
                        pointList.AddRange(dc.ChangePints(BC.WP.BoltB, CView, Vect));
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                    }

                    if (DN.DimIDNo4 || DN.DimIDNo19)
                        BC.PC.DistTop += BC.PC.DistInc;

                    // Dim No 11
                    if (DN.DimIDNo11)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MinPofX(BC.WP.BoltP, "Y", Com.MinP(BC.WP.BoltP, "X").X));
                        pointList.Add(Com.MinPofX(BC.WP.BoltB, "Y", Com.MaxP(BC.WP.BoltB, "X").X));
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                    }

                    TempList = dc.ChangePints(BC.WP.BoltP, CView, Vect);
                    // Dim No 4.2
                    if (DN.DimIDNo4Dot2 && TempList.Count > 2)
                    {

                        pointList = new PointList();
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                            Com.GroupDim(xDim);
                        }
                    }

                    if (DN.DimIDNo11 || (DN.DimIDNo4Dot2 && TempList.Count > 2))
                        BC.PC.DistTop += BC.PC.DistInc;

                    TempList = dc.ChangePints(BC.WP.BoltB, CView, Vect);

                    // Dim No 3
                    if (DN.DimIDNo3Dot1)
                    {
                        pointList = new PointList();
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                        {
                            PL.DimPlaceByTopY(xDim, BC.PC);
                            Com.GroupDim(xDim);
                        }

                        pointList = new PointList();
                        pointList.Add(BC.Points.P1);
                        pointList.Add(Com.MinP(TempList, "X"));
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                        if (xDim != null)
                            PL.DimPlaceByTopY(xDim, BC.PC);
                    }
                    else if (DN.DimIDNo3)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MaxP(TempList, "X"));
                        pointList.Add(BC.Points.P4);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByTopY(xDim, BC.PC);

                        BC.PC.DistTop += (BC.PC.DistInc*2);
                        pointList = new PointList();
                        pointList.Add(BC.Points.P1);
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                        if (xDim != null)
                            PL.DimPlaceByTopY(xDim, BC.PC);
                    }



                    #endregion
                }

                #region Filler and Web Plate Top And Bottom
                BC.PC.DistRight = (BC.PC.DistInc / 2);
                Vect = new Vector(-1, 0, 0);
                if (BC.WP.WebPlateT != null)
                {
                    // Dim No 15
                    if (DN.DimIDNo15)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.WP.WebPlateT.Points.P1);
                        pointList.Add(BC.WP.WebPlateT.Points.P2);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);

                    }
                }

                Vect = new Vector(1, 0, 0);
                if (BC.WP.FillPlateT != null)
                {
                    // Dim No 15.1
                    if (DN.DimIDNo15Dot1)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.WP.FillPlateT.Points.P3);
                        pointList.Add(BC.WP.FillPlateT.Points.P4);

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                            BC.PC.DistRight += BC.PC.DistInc;
                    }
                }

                if (BC.WP.FillPlateT2 != null)
                {
                    // Dim No 15.1
                    if (DN.DimIDNo15Dot1)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.WP.FillPlateT2.Points.P3);
                        pointList.Add(BC.WP.FillPlateT2.Points.P4);

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                            BC.PC.DistRight += BC.PC.DistInc;
                    }
                }

                BC.PC.DistRight = (BC.PC.DistInc / 2);
                Vect = new Vector(-1, 0, 0);
                if (BC.WP.WebPlateB != null)
                {
                    // Dim No 15
                    if (DN.DimIDNo15)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.WP.WebPlateB.Points.P1);
                        pointList.Add(BC.WP.WebPlateB.Points.P2);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);

                    }
                }
                Vect = new Vector(1, 0, 0);
                if (BC.WP.FillPlateB != null)
                {
                    // Dim No 15.1
                    if (DN.DimIDNo15Dot1)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.WP.FillPlateB.Points.P4);
                        pointList.Add(BC.WP.FillPlateB.Points.P3);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                            BC.PC.DistRight += BC.PC.DistInc;
                    }
                }

                if (BC.WP.FillPlateB2 != null)
                {
                    // Dim No 15.1
                    if (DN.DimIDNo15Dot1)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.WP.FillPlateB2.Points.P4);
                        pointList.Add(BC.WP.FillPlateB2.Points.P3);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                            BC.PC.DistRight += BC.PC.DistInc;
                    }
                }

                #endregion


            }



        }

        #endregion

        #region Top View
        private void ApplyDimTypeLeftTV(TSD.View CView)
        {

            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(-1, 0, 0);
            TSD.PointList TempList = new PointList();



            if (BC.WP != null)
            {
                // Dim No 17
                if (DN.DimIDNo17)
                {
                    pointList = new PointList();

                    if (BC.WP.WebPlateT != null)
                        pointList.Add(BC.WP.WebPlateT.Points.P2);

                    if (BC.WP.WebPlateB != null)
                        pointList.Add(BC.WP.WebPlateB.Points.P1);

                    pointList.Add(new Point(BC.Points.P1.X, BC.Points.CentP.Y));
                    Point Px = pointList[0];

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, Px.X, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistLeft;
                    }

                }


                if (BC.WP.WebPlate != null)
                {

                    #region Left Dim
                    Vect = new Vector(-1, 0, 0);
                    TempList.AddRange(BC.WP.BoltB);
                    TempList.AddRange(BC.WP.BoltP);
                    TempList = dc.ChangePints(TempList, CView, Vect);

                    // Dim No 8.1
                    if (DN.DimIDNo8Dot1)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MaxP(TempList, "Y"));
                        pointList.Add(BC.WP.WebPlate.Points.P1);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceLeftP(xDim, BC.WP.WebPlate.Points.P1.X, (BC.PC.DistLeft));

                        }

                        pointList = new PointList();
                        pointList.Add(Com.MinP(TempList, "Y"));
                        pointList.Add(BC.WP.WebPlate.Points.P2);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceLeftP(xDim, BC.WP.WebPlate.Points.P1.X, (BC.PC.DistLeft));

                        }

                        BC.PC.DistLeft += (BC.PC.DistInc);
                    }

                    // Dim No 8
                    if (DN.DimIDNo8)
                    {
                        pointList = new PointList();
                        pointList.Add(new Point(BC.Points.P1.X, BC.Points.CentP.Y));
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByLeftX(xDim, BC.PC);

                    }

                    // Dim No 9
                    if (DN.DimIDNo9)
                    {
                        pointList = new PointList();
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByLeftX(xDim, BC.PC);

                    }

                    #endregion


                    #region Top Dim
                    Vect = new Vector(0, 1, 0);
                    TempList = new PointList();
                    TempList.AddRange(BC.WP.BoltB);
                    TempList.AddRange(BC.WP.BoltP);
                    TempList = dc.ChangePints(TempList, CView, Vect);

                    // Dim No 12.1
                    if (DN.DimIDNo12Dot1)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MinP(TempList, "X"));
                        pointList.Add(BC.WP.WebPlate.Points.P1);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);


                        pointList = new PointList();
                        pointList.Add(Com.MaxP(TempList, "X"));
                        pointList.Add(BC.WP.WebPlate.Points.P4);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);

                        BC.PC.DistTop += BC.PC.DistInc;

                    }

                    // Dim No 13.1
                    if (DN.DimIDNo13Dot1)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MinPofX(BC.WP.BoltB, "Y", Com.MinP(BC.WP.BoltB, "X").X));
                        pointList.Add(BC.Points.P1);
                        pointList.Add(Com.MinPofX(BC.WP.BoltP, "Y", Com.MaxP(BC.WP.BoltP, "X").X));
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);

                        BC.PC.DistTop += BC.PC.DistInc;

                    }

                    // Dim No 12
                    if (DN.DimIDNo12)
                    {
                        pointList = new PointList();
                        pointList.AddRange(dc.ChangePints(BC.WP.BoltP, CView, Vect));
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                    }

                    // Dim No 20
                    if (DN.DimIDNo20)
                    {
                        pointList = new PointList();
                        pointList.AddRange(dc.ChangePints(BC.WP.BoltB, CView, Vect));
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                    }

                    if (DN.DimIDNo12 || DN.DimIDNo20)
                        BC.PC.DistTop += BC.PC.DistInc;

                    // Dim No 13
                    if (DN.DimIDNo13)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MinPofX(BC.WP.BoltP, "Y", Com.MaxP(BC.WP.BoltP, "X").X));
                        pointList.Add(Com.MinPofX(BC.WP.BoltB, "Y", Com.MinP(BC.WP.BoltB, "X").X));
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                    }

                    TempList = dc.ChangePints(BC.WP.BoltP, CView, Vect);
                    // Dim No 12.2
                    if (DN.DimIDNo12Dot2 && TempList.Count > 2)
                    {
                        pointList = new PointList();
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                            Com.GroupDim(xDim);
                        }
                    }

                    if (DN.DimIDNo13 || (DN.DimIDNo12Dot2 && TempList.Count > 2))
                        BC.PC.DistTop += BC.PC.DistInc;

                    TempList = dc.ChangePints(BC.WP.BoltB, CView, Vect);

                    // Dim No 10
                    if (DN.DimIDNo10Dot1)
                    {
                        pointList = new PointList();
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                        {
                            PL.DimPlaceByTopY(xDim, BC.PC);
                            Com.GroupDim(xDim);
                        }

                        pointList = new PointList();
                        pointList.Add(BC.Points.P1);
                        pointList.Add(Com.MinP(TempList, "X"));
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                        if (xDim != null)
                            PL.DimPlaceByTopY(xDim, BC.PC);
                    }
                    else if (DN.DimIDNo10)
                    {
                        BC.PC.DistTop += BC.PC.DistInc;
                        pointList = new PointList();
                        pointList.Add(BC.Points.P1);
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                        if (xDim != null)
                            PL.DimPlaceByTopY(xDim, BC.PC);
                    }



                    #endregion

                    Vect = new Vector(0, -1, 0);
                    // Dim No 16, 16.1
                    if (DN.DimIDNo16 || DN.DimIDNo16Dot1)
                    {
                        pointList = new PointList();
                        if (DN.DimIDNo16Dot1)
                            pointList.Add(BC.WP.WebPlate.Points.P2);
                        pointList.Add(BC.Points.P2);
                        if (DN.DimIDNo16)
                            pointList.Add(BC.WP.WebPlate.Points.P3);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByBottomY(xDim, BC.PC);
                    }
                }
            }

        }

        private void ApplyDimTypeRightTV(TSD.View CView)
        {

            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(1, 0, 0);
            TSD.PointList TempList = new PointList();


            if (BC.WP != null)
            {
                // Dim No 17
                if (DN.DimIDNo17)
                {
                    pointList = new PointList();

                    if (BC.WP.WebPlateT != null)
                        pointList.Add(BC.WP.WebPlateT.Points.P3);

                    if (BC.WP.WebPlateB != null)
                        pointList.Add(BC.WP.WebPlateB.Points.P4);

                    pointList.Add(new Point(BC.Points.P4.X, BC.Points.CentP.Y));

                    Point Px = pointList[0];
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, Px.X, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistLeft;
                    }


                }


                if (BC.WP.WebPlate != null)
                {

                    #region Right Dim
                    Vect = new Vector(1, 0, 0);
                    TempList.AddRange(BC.WP.BoltB);
                    TempList.AddRange(BC.WP.BoltP);
                    TempList = dc.ChangePints(TempList, CView, Vect);



                    // Dim No 8.1
                    if (DN.DimIDNo8Dot1)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MaxP(TempList, "Y"));
                        pointList.Add(BC.WP.WebPlate.Points.P4);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceLeftP(xDim, BC.WP.WebPlate.Points.P4.X, BC.PC.DistRight);

                        }

                        pointList = new PointList();
                        pointList.Add(Com.MinP(TempList, "Y"));
                        pointList.Add(BC.WP.WebPlate.Points.P3);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceLeftP(xDim, BC.WP.WebPlate.Points.P4.X, BC.PC.DistRight);

                        }

                        BC.PC.DistRight += BC.PC.DistLeft;
                    }

                    // Dim No 8
                    if (DN.DimIDNo8)
                    {
                        pointList = new PointList();
                        pointList.Add(new Point(BC.Points.P4.X, BC.Points.CentP.Y));
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByRightX(xDim, BC.PC);

                    }

                    // Dim No 9
                    if (DN.DimIDNo9)
                    {
                        pointList = new PointList();
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByRightX(xDim, BC.PC);

                    }

                    #endregion


                    #region Top Dim
                    Vect = new Vector(0, 1, 0);
                    TempList = new PointList();
                    TempList.AddRange(BC.WP.BoltB);
                    TempList.AddRange(BC.WP.BoltP);
                    TempList = dc.ChangePints(TempList, CView, Vect);

                    // Dim No 12.1
                    if (DN.DimIDNo12Dot1)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MaxP(TempList, "X"));
                        pointList.Add(BC.WP.WebPlate.Points.P4);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);


                        pointList = new PointList();
                        pointList.Add(Com.MinP(TempList, "X"));
                        pointList.Add(BC.WP.WebPlate.Points.P1);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);

                        BC.PC.DistTop += BC.PC.DistInc;

                    }


                    // Dim No 13.1
                    if (DN.DimIDNo13Dot1)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MinPofX(BC.WP.BoltB, "Y", Com.MaxP(BC.WP.BoltB, "X").X));
                        pointList.Add(BC.Points.P4);
                        pointList.Add(Com.MinPofX(BC.WP.BoltP, "Y", Com.MinP(BC.WP.BoltP, "X").X));
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);

                        BC.PC.DistTop += BC.PC.DistInc;

                    }

                    // Dim No 12
                    if (DN.DimIDNo12)
                    {
                        pointList = new PointList();
                        pointList.AddRange(dc.ChangePints(BC.WP.BoltP, CView, Vect));
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);

                    }

                    // Dim No 20
                    if (DN.DimIDNo20)
                    {
                        pointList = new PointList();
                        pointList.AddRange(dc.ChangePints(BC.WP.BoltB, CView, Vect));
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);

                    }

                    if (DN.DimIDNo12 || DN.DimIDNo20)
                        BC.PC.DistTop += BC.PC.DistInc;


                    // Dim No 13
                    if (DN.DimIDNo13)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MinPofX(BC.WP.BoltP, "Y", Com.MinP(BC.WP.BoltP, "X").X));
                        pointList.Add(Com.MinPofX(BC.WP.BoltB, "Y", Com.MaxP(BC.WP.BoltB, "X").X));
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);

                    }

                    TempList = dc.ChangePints(BC.WP.BoltP, CView, Vect);
                    // Dim No 12.2
                    if (DN.DimIDNo12Dot2 && TempList.Count > 2)
                    {
                        pointList = new PointList();
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                            Com.GroupDim(xDim);
                        }
                    }

                    if (DN.DimIDNo13 || (DN.DimIDNo12Dot2 && TempList.Count > 2))
                        BC.PC.DistTop += BC.PC.DistInc;


                    TempList = dc.ChangePints(BC.WP.BoltB, CView, Vect);

                    // Dim No 10
                    if (DN.DimIDNo10Dot1)
                    {
                        pointList = new PointList();
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                        {
                            PL.DimPlaceByTopY(xDim, BC.PC);
                            Com.GroupDim(xDim);
                        }

                        pointList = new PointList();
                        pointList.Add(BC.Points.P1);
                        pointList.Add(Com.MinP(TempList, "X"));
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                        if (xDim != null)
                            PL.DimPlaceByTopY(xDim, BC.PC);
                    }
                    else if (DN.DimIDNo10)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MaxP(TempList, "X"));
                        pointList.Add(BC.Points.P4);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByTopY(xDim, BC.PC);

                        BC.PC.DistTop += BC.PC.DistInc;
                        pointList = new PointList();
                        pointList.Add(BC.Points.P1);
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                        if (xDim != null)
                            PL.DimPlaceByTopY(xDim, BC.PC);
                    }



                    #endregion

                    Vect = new Vector(0, -1, 0);
                    // Dim No 16, 16.1
                    if (DN.DimIDNo16 || DN.DimIDNo16Dot1)
                    {
                        pointList = new PointList();
                        if (DN.DimIDNo16Dot1)
                            pointList.Add(BC.WP.WebPlate.Points.P3);
                        pointList.Add(BC.Points.P3);
                        if (DN.DimIDNo16)
                            pointList.Add(BC.WP.WebPlate.Points.P2);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByBottomY(xDim, BC.PC);
                    }
                }
            }

        }
        #endregion

        private void AppySectionDim()
        {
            StraightDimensionSet xDim = null;
            PointList pointList = new PointList();
            Vector Vect = new Vector(0, 1, 0);
            PointList TempList = new PointList();

            if (BC.WPL != null)
            {
                Vect = new Vector(0, 1, 0);
                // Dim No 18.1
                if (BC.WPL.WebPlate != null && DN.DimIDNo18Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(BC.WPL.WebPlate.Points.P4);
                    pointList.Add(BC.WPL.WebPlate.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);
                }

                Vect = new Vector(0, -1, 0);

                // Dim No 18.2
                if (BC.WPL.FillPlate != null && DN.DimIDNo18Dot2)
                {
                    pointList = new PointList();
                    pointList.Add(BC.WPL.FillPlate.Points.P3);
                    pointList.Add(BC.WPL.FillPlate.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);
                }

                // Dim No 18
                if (BC.WPL.FillPlate2 != null && DN.DimIDNo18)
                {
                    pointList = new PointList();
                    pointList.Add(BC.WPL.FillPlate2.Points.P3);
                    pointList.Add(BC.WPL.FillPlate2.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);
                }
            }

            if (BC.WPR != null)
            {
                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistBot = BC.PC.DistInc;
                Vect = new Vector(0, 1, 0);
                // Dim No 18.1
                if (BC.WPR.WebPlate != null && DN.DimIDNo18Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(BC.WPR.WebPlate.Points.P1);
                    pointList.Add(BC.WPR.WebPlate.Points.P4);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);
                }

                Vect = new Vector(0, -1, 0);
                // Dim No 18.2
                if (BC.WPR.FillPlate != null && DN.DimIDNo18Dot2)
                {
                    pointList = new PointList();
                    pointList.Add(BC.WPR.FillPlate.Points.P2);
                    pointList.Add(BC.WPR.FillPlate.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);
                }

                // Dim No 18
                if (BC.WPR.FillPlate2 != null && DN.DimIDNo18)
                {
                    pointList = new PointList();
                    pointList.Add(BC.WPR.FillPlate2.Points.P2);
                    pointList.Add(BC.WPR.FillPlate2.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);
                }
            }


        }

        #region Get Data

        private void GetBeamClassClass(TSD.View CView)
        {
            if (ViewName == "Front View")
            {
                BC = new BeamClass_BSP2();
                BC.beam = MainBeam;
                BC.Points = Com.GetPartPoints(MainBeam);
                List<TSM.Part> PartListC = BC.beam.GetAssembly().GetSecondaries().OfType<TSM.Part>().ToList();

                GetWebPlateProperties(PartListC);


                PartListC.Add(MainBeam);

                TSM.Part LeftPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.X ascending select p).FirstOrDefault();
                TSM.Part RightPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.X descending select p).FirstOrDefault();
                TSM.Part TopPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.Y descending select p).FirstOrDefault();
                TSM.Part BottPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.Y ascending select p).FirstOrDefault();

                BC.PC = new PlacingClass();
                BC.PC.TopY = TopPart.GetSolid().MaximumPoint.Y;
                BC.PC.BottomY = BottPart.GetSolid().MinimumPoint.Y;


                BC.PC.LeftX = LeftPart.GetSolid().MinimumPoint.X;// Math.Round(CView.RestrictionBox.MinPoint.X);
                BC.PC.RightX = RightPart.GetSolid().MaximumPoint.X;

                double AvScale = 12;
                double AvDistInc = 100;
                double DistPerScale = AvDistInc / AvScale;
                double CScale = CView.Attributes.Scale;
                BC.PC.DistInc = CScale * DistPerScale;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;
            }
            else if (ViewName == "Top View" || ViewName == "Bottom View")
            {
                BC = new BeamClass_BSP2();
                BC.beam = MainBeam;
                BC.Points = Com.GetPartPoints(MainBeam);
                List<TSM.Part> PartListC = BC.beam.GetAssembly().GetSecondaries().OfType<TSM.Part>().ToList();

                double MaxZ = CView.RestrictionBox.MinPoint.Z;
                List<TSM.Part> PartList = (from p in PartListC where Com.IsViewObj(p, CView) select p).ToList();

                GetWebPlatePropertiesTV(PartList);

                PartListC.Add(MainBeam);

                TSM.Part LeftPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.X ascending select p).FirstOrDefault();
                TSM.Part RightPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.X descending select p).FirstOrDefault();
                TSM.Part TopPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.Y descending select p).FirstOrDefault();
                TSM.Part BottPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.Y ascending select p).FirstOrDefault();

                BC.PC = new PlacingClass();
                BC.PC.TopY = TopPart.GetSolid().MaximumPoint.Y;
                BC.PC.BottomY = BottPart.GetSolid().MinimumPoint.Y;


                BC.PC.LeftX = LeftPart.GetSolid().MinimumPoint.X;// Math.Round(CView.RestrictionBox.MinPoint.X);
                BC.PC.RightX = RightPart.GetSolid().MaximumPoint.X;

                double AvScale = 12;
                double AvDistInc = 100;
                double DistPerScale = AvDistInc / AvScale;
                double CScale = CView.Attributes.Scale;
                BC.PC.DistInc = CScale * DistPerScale;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;
            }
            else if (ViewName == "Section View")
            {
                BC = new BeamClass_BSP2();
                BC.beam = MainBeam;
                BC.Points = Com.GetPartPoints(MainBeam);
                List<TSM.Part> PartListC = BC.beam.GetAssembly().GetSecondaries().OfType<TSM.Part>().ToList();

                double MaxZ = CView.RestrictionBox.MinPoint.Z;
                List<TSM.Part> PartList = (from p in PartListC where Com.IsViewObj(p, CView) select p).ToList();
                Point CentP = Com.CenterPoint(MainBeam.StartPoint, MainBeam.EndPoint);

                BC.WPL = GetWebPlatePropertiesS(PartList, "Left");
                BC.WPR = GetWebPlatePropertiesS(PartList, "Right");

                PartListC.Add(MainBeam);
                List<Point> RefPoints = MainBeam.GetReferenceLine(false).OfType<Point>().ToList();
                PartList.Add(MainBeam);
                TSM.Part LeftPart = (from p in PartList orderby p.GetSolid().MinimumPoint.X ascending select p).FirstOrDefault();
                TSM.Part RightPart = (from p in PartList orderby p.GetSolid().MaximumPoint.X descending select p).FirstOrDefault();
                TSM.Part TopPart = (from p in PartList orderby p.GetSolid().MaximumPoint.Y descending select p).FirstOrDefault();
                TSM.Part BottPart = (from p in PartList orderby p.GetSolid().MinimumPoint.Y ascending select p).FirstOrDefault();

                BC.PC = new PlacingClass();
                BC.PC.TopY = TopPart.GetSolid().MaximumPoint.Y;
                BC.PC.BottomY = BottPart.GetSolid().MinimumPoint.Y;
                BC.PC.LeftX = LeftPart.GetSolid().MinimumPoint.X;// Math.Round(CView.RestrictionBox.MinPoint.X);
                BC.PC.RightX = RightPart.GetSolid().MaximumPoint.X;

                double AvScale = 12;
                double AvDistInc = 100;
                double DistPerScale = AvDistInc / AvScale;
                double CScale = CView.Attributes.Scale;
                BC.PC.DistInc = CScale * DistPerScale;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;
            }


        }

        private void GetWebPlateProperties(List<TSM.Part> PartListC)
        {

            TSM.Part WebPlate = null;
            TSM.Part WebPlateT = null;
            TSM.Part WebPlateB = null;
            TSM.Part FillPlateT = null;
            TSM.Part FillPlateT2 = null;
            TSM.Part FIllPlateB = null;
            TSM.Part FIllPlateB2 = null;

            Point CentP = Com.CenterPoint(BC.beam.StartPoint, BC.beam.EndPoint);
            double Lenght = (BC.beam.GetSolid().MaximumPoint.X - BC.beam.GetSolid().MinimumPoint.X) / 8;
            double MinX = BC.beam.GetSolid().MinimumPoint.X + Lenght;
            double MaxX = BC.beam.GetSolid().MaximumPoint.X - Lenght;

            if (Position == "Left")
            {
                WebPlate = (from p in PartListC where !dc.IsPlateSideViewN(p) && (p.GetSolid().MaximumPoint.X < CentP.X && p.GetSolid().MinimumPoint.X <= MinX) select p).FirstOrDefault();
                WebPlateT = (from p in PartListC where dc.IsPlateSideViewN(p) && (p.GetSolid().MaximumPoint.X < CentP.X && p.GetSolid().MinimumPoint.X <= MinX) && p.GetSolid().MaximumPoint.Y > BC.Points.P1.Y orderby p.GetSolid().MaximumPoint.Y descending select p).FirstOrDefault();

                if (WebPlateT != null)
                {
                    FillPlateT = (from p in PartListC where dc.IsPlateSideViewN(p) && (p.GetSolid().MaximumPoint.X < CentP.X && p.GetSolid().MinimumPoint.X <= MinX) && Com.CenterPoint(p).Y < Com.CenterPoint(WebPlateT).Y && p.Identifier.ID != WebPlateT.Identifier.ID && p.GetSolid().MaximumPoint.Y > BC.Points.P1.Y select p).FirstOrDefault();

                    if (FillPlateT != null)
                        FillPlateT2 = (from p in PartListC where dc.IsPlateSideViewN(p) && (p.GetSolid().MaximumPoint.X < CentP.X && p.GetSolid().MinimumPoint.X <= MinX) && Com.CenterPoint(p).Y < Com.CenterPoint(FillPlateT).Y && p.Identifier.ID != FillPlateT.Identifier.ID && p.GetSolid().MaximumPoint.Y > BC.Points.P1.Y select p).FirstOrDefault();

                }


                WebPlateB = (from p in PartListC where dc.IsPlateSideViewN(p) && (p.GetSolid().MaximumPoint.X < CentP.X && p.GetSolid().MinimumPoint.X <= MinX) && p.GetSolid().MinimumPoint.Y < BC.Points.P2.Y orderby p.GetSolid().MinimumPoint.Y ascending select p).FirstOrDefault();

                if (WebPlateB != null)
                {
                    FIllPlateB = (from p in PartListC where dc.IsPlateSideViewN(p) && (p.GetSolid().MaximumPoint.X < CentP.X && p.GetSolid().MinimumPoint.X <= MinX) && Com.CenterPoint(p).Y > Com.CenterPoint(WebPlateB).Y && p.Identifier.ID != WebPlateB.Identifier.ID && p.GetSolid().MinimumPoint.Y < BC.Points.P2.Y select p).FirstOrDefault();

                    if (FIllPlateB != null)
                        FIllPlateB2 = (from p in PartListC where dc.IsPlateSideViewN(p) && (p.GetSolid().MaximumPoint.X < CentP.X && p.GetSolid().MinimumPoint.X <= MinX) && Com.CenterPoint(p).Y > Com.CenterPoint(FIllPlateB).Y && p.Identifier.ID != FIllPlateB.Identifier.ID && p.GetSolid().MinimumPoint.Y < BC.Points.P2.Y select p).FirstOrDefault();

                }
            }
            else
            {
                WebPlate = (from p in PartListC where !dc.IsPlateSideViewN(p) && (p.GetSolid().MinimumPoint.X > CentP.X && p.GetSolid().MaximumPoint.X >= MaxX) select p).FirstOrDefault();
                WebPlateT = (from p in PartListC where dc.IsPlateSideViewN(p) && (p.GetSolid().MinimumPoint.X > CentP.X && p.GetSolid().MaximumPoint.X >= MaxX) && p.GetSolid().MaximumPoint.Y > BC.Points.P1.Y orderby p.GetSolid().MaximumPoint.Y descending select p).FirstOrDefault();

                if (WebPlateT != null)
                {
                    FillPlateT = (from p in PartListC where dc.IsPlateSideViewN(p) && (p.GetSolid().MinimumPoint.X > CentP.X && p.GetSolid().MaximumPoint.X >= MaxX) && Com.CenterPoint(p).Y < Com.CenterPoint(WebPlateT).Y && p.Identifier.ID != WebPlateT.Identifier.ID && p.GetSolid().MaximumPoint.Y > BC.Points.P1.Y select p).FirstOrDefault();

                    if (FillPlateT != null)
                        FillPlateT2 = (from p in PartListC where dc.IsPlateSideViewN(p) && (p.GetSolid().MinimumPoint.X > CentP.X && p.GetSolid().MaximumPoint.X >= MaxX) && Com.CenterPoint(p).Y < Com.CenterPoint(FillPlateT).Y && p.Identifier.ID != FillPlateT.Identifier.ID && p.GetSolid().MaximumPoint.Y > BC.Points.P1.Y select p).FirstOrDefault();
                }



                WebPlateB = (from p in PartListC where dc.IsPlateSideViewN(p) && (p.GetSolid().MinimumPoint.X > CentP.X && p.GetSolid().MaximumPoint.X >= MaxX) && p.GetSolid().MinimumPoint.Y < BC.Points.P2.Y orderby p.GetSolid().MinimumPoint.Y ascending select p).FirstOrDefault();

                if (WebPlateB != null)
                {
                    FIllPlateB = (from p in PartListC where dc.IsPlateSideViewN(p) && (p.GetSolid().MinimumPoint.X > CentP.X && p.GetSolid().MaximumPoint.X >= MaxX) && Com.CenterPoint(p).Y > Com.CenterPoint(WebPlateB).Y && p.Identifier.ID != WebPlateB.Identifier.ID && p.GetSolid().MinimumPoint.Y < BC.Points.P2.Y select p).FirstOrDefault();

                    if (FIllPlateB != null)
                        FIllPlateB2 = (from p in PartListC where dc.IsPlateSideViewN(p) && (p.GetSolid().MinimumPoint.X > CentP.X && p.GetSolid().MaximumPoint.X >= MaxX) && Com.CenterPoint(p).Y > Com.CenterPoint(FIllPlateB).Y && p.Identifier.ID != FIllPlateB.Identifier.ID && p.GetSolid().MinimumPoint.Y < BC.Points.P2.Y select p).FirstOrDefault();


                }
            }


            if (WebPlate != null)
            {
                BC.WP = new WebPlateClass();

                BC.WP.WebPlate = Com.GetPartClass(WebPlate);

                PointList BoltP = dc.GetBoltPlist(false, WebPlate);
                if (BoltP != null && BoltP.Count > 0)
                {
                    List<Point> PointP = null;
                    List<Point> PointB = null;

                    if (Position == "Left")
                    {
                        PointP = (from p in BoltP.OfType<Point>() where p.X < BC.Points.P1.X select p).ToList();
                        PointB = (from p in BoltP.OfType<Point>() where p.X > BC.Points.P1.X select p).ToList();
                    }
                    else
                    {
                        PointB = (from p in BoltP.OfType<Point>() where p.X < BC.Points.P4.X select p).ToList();
                        PointP = (from p in BoltP.OfType<Point>() where p.X > BC.Points.P4.X select p).ToList();
                    }

                    if (PointP != null)
                        BC.WP.BoltP = Com.PointToPointList(PointP);

                    if (PointB != null)
                        BC.WP.BoltB = Com.PointToPointList(PointB);

                }

            }


            if (WebPlateT != null)
            {
                if (BC.WP == null)
                    BC.WP = new WebPlateClass();
                BC.WP.WebPlateT = Com.GetPartClass(WebPlateT);
            }

            if (WebPlateB != null)
            {
                if (BC.WP == null)
                    BC.WP = new WebPlateClass();
                BC.WP.WebPlateB = Com.GetPartClass(WebPlateB);
            }

            if (FillPlateT != null)
            {
                if (BC.WP == null)
                    BC.WP = new WebPlateClass();
                BC.WP.FillPlateT = Com.GetPartClass(FillPlateT);
            }

            if (FIllPlateB != null)
            {
                if (BC.WP == null)
                    BC.WP = new WebPlateClass();
                BC.WP.FillPlateB = Com.GetPartClass(FIllPlateB);
            }

            if (FillPlateT2 != null)
            {
                if (BC.WP == null)
                    BC.WP = new WebPlateClass();
                BC.WP.FillPlateT2 = Com.GetPartClass(FillPlateT2);
            }

            if (FIllPlateB2 != null)
            {
                if (BC.WP == null)
                    BC.WP = new WebPlateClass();
                BC.WP.FillPlateB2 = Com.GetPartClass(FIllPlateB2);
            }


        }

        private void GetWebPlatePropertiesTV(List<TSM.Part> PartListC)
        {

            TSM.Part WebPlate = null;

            TSM.Part WebPlateT = null;
            TSM.Part WebPlateB = null;

            Point CentP = Com.CenterPoint(BC.beam.StartPoint, BC.beam.EndPoint);
            double Lenght = (BC.beam.GetSolid().MaximumPoint.X - BC.beam.GetSolid().MinimumPoint.X) / 8;
            double MinX = BC.beam.GetSolid().MinimumPoint.X + Lenght;
            double MaxX = BC.beam.GetSolid().MaximumPoint.X - Lenght;

            List<TSM.Part> EndParts = null;

            if (Position == "Left")
            {
                WebPlate = (from p in PartListC where !dc.IsPlateSideViewN(p) && (p.GetSolid().MaximumPoint.X < CentP.X && p.GetSolid().MinimumPoint.X <= MinX) orderby Com.GetXDist(p) descending select p).FirstOrDefault();
                WebPlateT = (from p in PartListC where dc.IsPlateSideViewN(p) && (p.GetSolid().MaximumPoint.X < CentP.X && p.GetSolid().MinimumPoint.X <= MinX) && Com.CenterPoint(p).Y > BC.Points.CentP.Y orderby Com.CenterPoint(p).Y descending select p).FirstOrDefault();
                WebPlateB = (from p in PartListC where dc.IsPlateSideViewN(p) && (p.GetSolid().MaximumPoint.X < CentP.X && p.GetSolid().MinimumPoint.X <= MinX) && Com.CenterPoint(p).Y < BC.Points.CentP.Y orderby Com.CenterPoint(p).Y ascending select p).FirstOrDefault();

                EndParts = (from p in PartListC where !dc.IsPlateSideViewN(p) && (p.GetSolid().MaximumPoint.X < CentP.X && p.GetSolid().MinimumPoint.X <= MinX) select p).ToList();
            }
            else
            {
                WebPlate = (from p in PartListC where !dc.IsPlateSideViewN(p) && (p.GetSolid().MinimumPoint.X > CentP.X && p.GetSolid().MaximumPoint.X >= MaxX) orderby Com.GetXDist(p) descending select p).FirstOrDefault();
                WebPlateT = (from p in PartListC where dc.IsPlateSideViewN(p) && (p.GetSolid().MinimumPoint.X > CentP.X && p.GetSolid().MaximumPoint.X >= MaxX) && Com.CenterPoint(p).Y > BC.Points.CentP.Y orderby Com.CenterPoint(p).Y descending select p).FirstOrDefault();
                WebPlateB = (from p in PartListC where dc.IsPlateSideViewN(p) && (p.GetSolid().MinimumPoint.X > CentP.X && p.GetSolid().MaximumPoint.X >= MaxX) && Com.CenterPoint(p).Y < BC.Points.CentP.Y orderby Com.CenterPoint(p).Y ascending select p).FirstOrDefault();

                EndParts = (from p in PartListC where !dc.IsPlateSideViewN(p) && (p.GetSolid().MinimumPoint.X > CentP.X && p.GetSolid().MaximumPoint.X >= MaxX) select p).ToList();


            }


            if (WebPlate != null)
            {


                BC.WP = new WebPlateClass();

                BC.WP.WebPlate = Com.GetPartClass(WebPlate);

                PointList BoltP = dc.GetBoltPlist(false, WebPlate);

                if (BoltP != null && BoltP.Count > 0)
                {
                    if (EndParts != null && EndParts.Count > 0)
                    {
                        foreach (TSM.Part part in EndParts)
                        {
                            BoltP.AddRange(dc.GetBoltPlist(false, part));
                        }
                    }

                    List<Point> PointP = null;
                    List<Point> PointB = null;

                    if (Position == "Left")
                    {
                        PointP = (from p in BoltP.OfType<Point>() where p.X < BC.Points.P1.X select p).ToList();
                        PointB = (from p in BoltP.OfType<Point>() where p.X > BC.Points.P1.X select p).ToList();
                    }
                    else
                    {
                        PointB = (from p in BoltP.OfType<Point>() where p.X < BC.Points.P4.X select p).ToList();
                        PointP = (from p in BoltP.OfType<Point>() where p.X > BC.Points.P4.X select p).ToList();
                    }

                    if (PointP != null)
                        BC.WP.BoltP = Com.PointToPointList(PointP);

                    if (PointB != null)
                        BC.WP.BoltB = Com.PointToPointList(PointB);

                }


            }

            if (WebPlateT != null)
            {
                if (BC.WP == null)
                    BC.WP = new WebPlateClass();
                BC.WP.WebPlateT = Com.GetPartClass(WebPlateT);
            }

            if (WebPlateB != null)
            {
                if (BC.WP == null)
                    BC.WP = new WebPlateClass();
                BC.WP.WebPlateB = Com.GetPartClass(WebPlateB);
            }


        }

        private WebPlateClassS GetWebPlatePropertiesS(List<TSM.Part> PartListC, string PosV)
        {
            WebPlateClassS WPS = null;
            TSM.Part WebPlate = null;
            TSM.Part FillPlate = null;
            TSM.Part FillPlate2 = null;

            Point CentP = Com.CenterPoint(BC.beam.StartPoint, BC.beam.EndPoint);
            double Lenght = (BC.beam.GetSolid().MaximumPoint.X - BC.beam.GetSolid().MinimumPoint.X) / 8;
            double MinX = BC.beam.GetSolid().MinimumPoint.X + Lenght;
            double MaxX = BC.beam.GetSolid().MaximumPoint.X - Lenght;

            PartListC = (from p in PartListC where Com.CenterPoint(p).Y < BC.Points.P1.Y && Com.CenterPoint(p).Y > BC.Points.P2.Y select p).ToList();

            if (PartListC != null)
            {
                List<TSM.Part> Parts = (from p in PartListC where Com.CenterPoint(p).X > BC.Points.CentP.X select p).ToList();

                if (PosV == "Left")
                {
                    Parts = (from p1 in PartListC where Com.CenterPoint(p1).X < BC.Points.CentP.X select p1).ToList();

                    WebPlate = (from p in Parts where dc.IsPlateSideViewN(p) orderby p.GetSolid().MinimumPoint.X ascending select p).FirstOrDefault();

                    if (WebPlate != null)
                        FillPlate = (from p in Parts where dc.IsPlateSideViewN(p) && Com.CenterPoint(p).X > Com.CenterPoint(WebPlate).X && p.Identifier.ID != WebPlate.Identifier.ID orderby p.GetSolid().MinimumPoint.X ascending select p).FirstOrDefault();

                    if (FillPlate != null)
                        FillPlate2 = (from p in Parts where dc.IsPlateSideViewN(p) && Com.CenterPoint(p).X > Com.CenterPoint(FillPlate).X && p.Identifier.ID != FillPlate.Identifier.ID orderby p.GetSolid().MinimumPoint.X ascending select p).FirstOrDefault();

                }
                else
                {
                    WebPlate = (from p in Parts where dc.IsPlateSideViewN(p) orderby p.GetSolid().MaximumPoint.X descending select p).FirstOrDefault();

                    if (WebPlate != null)
                        FillPlate = (from p in Parts where dc.IsPlateSideViewN(p) && Com.CenterPoint(p).X < Com.CenterPoint(WebPlate).X && p.Identifier.ID != WebPlate.Identifier.ID orderby p.GetSolid().MaximumPoint.X descending select p).FirstOrDefault();

                    if (FillPlate != null)
                        FillPlate2 = (from p in Parts where dc.IsPlateSideViewN(p) && Com.CenterPoint(p).X < Com.CenterPoint(FillPlate).X && p.Identifier.ID != FillPlate.Identifier.ID orderby p.GetSolid().MaximumPoint.X descending select p).FirstOrDefault();
                }


                if (WebPlate != null)
                {
                    WPS = new WebPlateClassS();
                    WPS.WebPlate = Com.GetPartClass(WebPlate);

                    if (FillPlate != null)
                        WPS.FillPlate = Com.GetPartClass(FillPlate);

                    if (FillPlate2 != null)
                        WPS.FillPlate2 = Com.GetPartClass(FillPlate2);

                }
            }

            return WPS;

        }

        #endregion

        #region Helping Methods
        private double GetPartWidth(TSM.Part part)
        {
            return (part.GetSolid().MaximumPoint.X - part.GetSolid().MinimumPoint.X);
        }



        #endregion

        private class WebPlateClass
        {
            public PartClass WebPlate { get; set; }
            public PartClass WebPlateT { get; set; }
            public PartClass FillPlateT { get; set; }
            public PartClass FillPlateT2 { get; set; }
            public PartClass WebPlateB { get; set; }
            public PartClass FillPlateB { get; set; }
            public PartClass FillPlateB2 { get; set; }
            public PointList BoltP { get; set; }
            public PointList BoltB { get; set; }

        }

        private class WebPlateClassS
        {
            public PartClass WebPlate { get; set; }
            public PartClass FillPlate { get; set; }
            public PartClass FillPlate2 { get; set; }

        }

        private class BeamClass_BSP2
        {
            public Beam beam { get; set; }
            public WebPlateClass WP { get; set; }
            public WebPlateClassS WPL { get; set; }
            public WebPlateClassS WPR { get; set; }
            public PartPoints Points { get; set; }
            public PlacingClass PC { get; set; }
        }
    }

}
