﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Tekla.Structures;
using Tekla.Structures.Drawing;
using Tekla.Structures.Geometry3d;
using Tekla.Structures.Model;
using TSD = Tekla.Structures.Drawing;
using TSM = Tekla.Structures.Model;
using VirtueleDrawingAutomation;
using TSDD = Tekla.Structures.Datatype;
using TSG = Tekla.Structures.Geometry3d;
using System.IO;
using System.Reflection;

namespace Auto_Detailing_Tool_Beam
{
    public class BeamDim
    {
        #region Global Variables
        AutoDimensioningTypes autoDimensioningTypes = AutoMethods.GetAutoDimentionTypeObj();
        DrawingAttributeInfo drawingAttributeInfo = AutoMethods.GetAutoDimentionAttribute();
        string LeftCode = "";
        string RightCode = "";
        List<string> MidCodes = new List<string>();
        TSM.Beam MainBeam = null;
        DimCom dc = new DimCom();

        BeamDim_BG8 BD_BG8 = new BeamDim_BG8();
        BeamDim_BG18 BD_BG18 = new BeamDim_BG18();
        BeamDim_BG5 BD_BG5 = new BeamDim_BG5();
        BeamDim_BG17 BD_BG17 = new BeamDim_BG17();
        BeamDim_BG6 BD_BG6 = new BeamDim_BG6();
        BeamDim_BG3 BD_BG3 = new BeamDim_BG3();
        BeamDim_BG7 BD_BG7 = new BeamDim_BG7();
        BeamDim_BG22 BD_BG22 = new BeamDim_BG22();
        BeamDim_BSP3 BD_BSP3 = new BeamDim_BSP3();
        BeamDim_BSP4 BD_BSP4 = new BeamDim_BSP4();
        BeamDim_BG21 BD_BG21 = new BeamDim_BG21();
        BeamDim_BEP3 BD_BEP3 = new BeamDim_BEP3();
        BeamDim_BEP2 BD_BEP2 = new BeamDim_BEP2();
        BeamDim_BHP1 BD_BHP1 = new BeamDim_BHP1();
        BeamDim_BSP2 BD_BSP2 = new BeamDim_BSP2();
        BeamDim_BDP1 BD_BDP1 = new BeamDim_BDP1();
        BeamDim_BG19 BD_BG19 = new BeamDim_BG19();
        BeamDim_BG9 BD_BG9 = new BeamDim_BG9();
        BeamDim_BG2 BD_BG2 = new BeamDim_BG2();
        BeamDim_BG13 BD_BG13 = new BeamDim_BG13();
        BeamDim_BG12 BD_BG12 = new BeamDim_BG12();
        BeamDim_BCR1 BD_BCR1 = new BeamDim_BCR1();
        BeamDim_BC2 BD_BC2 = new BeamDim_BC2();
        BeamDim_BS2 BD_BS2 = new BeamDim_BS2();
        BeamDim_BBP1 BD_BBP1 = new BeamDim_BBP1();

        string ViewName = "";
        TSD.View TopView = null;
        TSD.View BottomView = null;
        TSD.View FrontView = null;
        List<TSD.View> SectViews = null;
        List<TSD.View> DetViews = null;

        #endregion

        public void ProceedDrawing(TSD.Drawing Dr, bool IsDeleteDim)
        {
            if (Dr != null)
            {
                MainBeam = (Com.MyModel.SelectModelObject(new Identifier((Dr as AssemblyDrawing).AssemblyIdentifier.ID)) as TSM.Assembly).GetMainPart() as TSM.Beam;
                //ClearRecord();
                LeftCode = Com.GetLeftEndCode(MainBeam);
                RightCode = Com.GetRightEndCode(MainBeam);
                MidCodes = Com.GetMidCodes(MainBeam);
                if (!string.IsNullOrEmpty(LeftCode) || !string.IsNullOrEmpty(RightCode) || MidCodes.Count > 0)
                {
                    List<TSD.View> ViewList = Com.EnumtoArrayD(Dr.GetSheet().GetAllViews()).OfType<TSD.View>().ToList();
                    ViewList = (from v in ViewList orderby v.Width descending select v).ToList();

                    MainBeam = (Com.MyModel.SelectModelObject(new Identifier((Dr as AssemblyDrawing).AssemblyIdentifier.ID)) as TSM.Assembly).GetMainPart() as TSM.Beam;
                    string ProType = Com.GetProType(MainBeam);


                    FrontView = (from v in ViewList where v.ViewType == TSD.View.ViewTypes.FrontView select v).FirstOrDefault();

                    if (FrontView == null)
                        FrontView = (from v in ViewList where v.ViewType != TSD.View.ViewTypes.SectionView select v).FirstOrDefault();

                    if (FrontView != null)
                    {
                        TopView = (from v in ViewList where ViewOrgY(v) > ViewOrgY(FrontView) && v.Width > (FrontView.Width / 2) select v).FirstOrDefault();
                        BottomView = (from v in ViewList where ViewOrgY(v) < ViewOrgY(FrontView) && v.Width > (FrontView.Width / 2) select v).FirstOrDefault();
                    }

                    if (FrontView != null)
                    {
                        SectViews = (from v in ViewList where v.ViewType != View.ViewTypes.DetailView && v.Width < (FrontView.Width / 2) select v).ToList();
                        DetViews = (from v in ViewList where v.ViewType == View.ViewTypes.DetailView && v.Width < (FrontView.Width / 2) select v).ToList();

                        if (SectViews?.Count == 0 && TopView != null)
                            SectViews = (from v in ViewList where v.ViewType == View.ViewTypes.SectionView && v.Width < FrontView.Width && dc.GetViewID(TopView)!= dc.GetViewID(v) select v).ToList();
                    }

                    if (FrontView != null)
                    {
                        ViewName = "Front View";
                        proceedView(FrontView, IsDeleteDim);
                        dc.ModifyMarkPlace(FrontView);
                        Com.SetBoltType(FrontView);
                    }

                    if (TopView != null)
                    {
                        ViewName = "Top View";
                        proceedView(TopView, IsDeleteDim);
                        dc.ModifyMarkPlace(TopView);
                        Com.SetBoltType(TopView);
                    }

                    if (BottomView != null)
                    {
                        ViewName = "Bottom View";
                        proceedView(BottomView, IsDeleteDim);
                        dc.ModifyMarkPlace(BottomView);
                        Com.SetBoltType(BottomView);
                    }

                    if (SectViews != null && SectViews.Count > 0)
                    {
                        // ClearRecord();
                        foreach (TSD.View SecView in SectViews)
                        {
                            ViewName = "Section View";
                            proceedView(SecView, IsDeleteDim);
                            dc.ModifyMarkPlace(SecView);
                            Com.SetBoltType(SecView);
                        }
                    }


                    if (DetViews != null && DetViews.Count > 0)
                    {
                        // ClearRecord();
                        foreach (TSD.View DetView in DetViews)
                        {
                            ViewName = "Detail View";
                            proceedView(DetView, IsDeleteDim);
                            dc.ModifyMarkPlace(DetView);
                            Com.SetBoltType(DetView);
                        }
                    }

                }

            }
        }

        private void proceedView(TSD.View CView, bool IsDeleteDim)
        {
            if (ViewName == "Front View")
            {
                if (IsDeleteDim)
                    Com.DeleteDim(CView);


                for (int i = 0; i < 2; i++)
                {
                    string code = "";
                    string Position = "";
                    if (!string.IsNullOrEmpty(LeftCode) && i == 0)
                    {
                        code = LeftCode;
                        Position = "Left";

                    }
                    else if (!string.IsNullOrEmpty(RightCode) && i == 1)
                    {
                        code = RightCode;
                        Position = "Right";
                    }

                    if (!string.IsNullOrEmpty(code))
                    {
                        SetParameters(code);

                        if (code == "BG8")
                            BD_BG8.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Position);

                        else if (code == "BG5")
                            BD_BG5.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Position);
                        else if (code == "BG6")
                            BD_BG6.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Position);
                        else if (code == "BG7")
                            BD_BG7.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Position);
                        else if (code == "BSP3")
                            BD_BSP3.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Position);
                        else if (code == "BSP4")
                            BD_BSP4.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Position);
                        else if (code == "BEP3")
                            BD_BEP3.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Position);
                        else if (code == "BEP2")
                            BD_BEP2.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Position);
                        else if (code == "BHP1")
                            BD_BHP1.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Position);
                        else if (code == "BSP2")
                            BD_BSP2.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Position);
                        else if (code == "BDP1")
                            BD_BDP1.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Position);
                        else if (code == "BCR1")
                            BD_BCR1.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Position);
                        else if (code == "BC2")
                            BD_BC2.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Position);
                    }

                }


                if (MidCodes != null && MidCodes.Count > 0)
                {
                    List<int> Ids = new List<int>();
                    string LastCode = "";
                    foreach (string code in MidCodes)
                    {
                        if (Com.CodeNames.Keys.Contains(code))
                        {
                            SetParameters(code);

                            if (code == "BG18")
                            {
                                if (LastCode != code)
                                    Ids.AddRange(BD_BG18.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Ids));
                            }
                            else if (code == "BG17")
                            {
                                if (LastCode != code)
                                    Ids.AddRange(BD_BG17.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Ids));
                            }
                            else if (code == "BG3")
                            {
                                if (LastCode != code)
                                    Ids.AddRange(BD_BG3.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Ids));
                            }
                            else if (code == "BG22")
                            {
                                if (LastCode != code)
                                    Ids.AddRange(BD_BG22.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Ids));
                            }
                            else if (code == "BG21")
                            {
                                if (LastCode != code)
                                    Ids.AddRange(BD_BG21.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Ids));
                            }
                            else if (code == "BG19")
                                Ids.AddRange(BD_BG19.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Ids));
                            else if (code == "BG9")
                            {
                                if (LastCode != code)
                                    Ids.AddRange(BD_BG9.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Ids));
                            }
                            else if (code == "BG2")
                            {
                                if (LastCode != code)
                                    Ids.AddRange(BD_BG2.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Ids));
                            }
                            else if (code == "BG13")
                            {
                                if (LastCode != code)
                                    Ids.AddRange(BD_BG13.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Ids));
                            }

                            else if (code == "BG12")
                            {
                                if (LastCode != code)
                                    Ids.AddRange(BD_BG12.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Ids));
                            }

                            else if (code == "BS2")
                            {
                                Ids.AddRange(BD_BS2.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Ids));
                            }

                            else if (code == "BBP1")
                            {
                                Ids.AddRange(BD_BBP1.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Ids));
                            }

                            LastCode = code;
                        }

                    }

                }
            }

            if (ViewName == "Section View")
            {
                if (IsDeleteDim)
                    Com.DeleteDim(CView);

                string code = "";
                string Position = "";

                // Left End Section
                if (CView.Origin.X < FrontView.Origin.X)
                {
                    code = LeftCode;
                    Position = "Left";

                }
                else
                {
                    code = RightCode;
                    Position = "Right";
                }

                if (!string.IsNullOrEmpty(code))
                {
                    SetParameters(code);

                    if (code == "BG8")
                        BD_BG8.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Position);

                    else if (code == "BG5")
                        BD_BG5.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Position); 
                    else if (code == "BSP3")
                        BD_BSP3.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Position);
                    else if (code == "BSP4")
                        BD_BSP4.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Position);
                    else if (code == "BEP3")
                        BD_BEP3.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Position);
                    else if (code == "BEP2")
                        BD_BEP2.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Position);
                    else if (code == "BHP1")
                        BD_BHP1.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Position);
                    else if (code == "BDP1")
                        BD_BDP1.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Position);
                    else if (code == "BSP2")
                        BD_BSP2.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Position);
                    else if (code == "BCR1")
                        BD_BCR1.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Position);
                    else if (code == "BC2")
                        BD_BC2.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Position);

                }

                if (MidCodes != null && MidCodes.Count > 0)
                {

                    List<int> Ids = new List<int>();
                    foreach (string codeM in MidCodes)
                    {
                        if (Com.CodeNames.Keys.Contains(codeM))
                        {
                            SetParameters(codeM);

                            if (codeM == "BG18")
                                Ids.AddRange(BD_BG18.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Ids));
                            else if (codeM == "BG17")
                                Ids.AddRange(BD_BG17.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Ids));
                            else if (codeM == "BG3")
                                Ids.AddRange(BD_BG3.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Ids));
                            else if (codeM == "BG22")
                                Ids.AddRange(BD_BG22.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Ids));
                            else if (codeM == "BG21")
                                Ids.AddRange(BD_BG21.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Ids));
                            else if (codeM == "BG19")
                                Ids.AddRange(BD_BG19.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Ids));
                            else if (codeM == "BG9")
                                Ids.AddRange(BD_BG9.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Ids));
                            else if (codeM == "BG2")
                                Ids.AddRange(BD_BG2.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Ids));
                            else if (codeM == "BG13")
                                Ids.AddRange(BD_BG13.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Ids));
                            else if (codeM == "BG12")
                                Ids.AddRange(BD_BG12.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Ids));
                            else if (codeM == "BS2")
                                Ids.AddRange(BD_BS2.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Ids));
                            else if (codeM == "BBP1")
                                Ids.AddRange(BD_BBP1.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Ids));

                            if (Ids.Count > 0)
                                break;

                        }

                    }

                }


            }

            if (ViewName == "Top View")
            {
                if (IsDeleteDim)
                    Com.DeleteDim(CView);

                for (int i = 0; i < 2; i++)
                {
                    string code = "";
                    string Position = "";
                    if (!string.IsNullOrEmpty(LeftCode) && i == 0)
                    {
                        code = LeftCode;
                        Position = "Left";

                    }
                    else if (!string.IsNullOrEmpty(RightCode) && i == 1)
                    {
                        code = RightCode;
                        Position = "Right";
                    }

                    if (!string.IsNullOrEmpty(code))
                    {
                        SetParameters(code);
                        if (code == "BSP4")
                            BD_BSP4.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Position);
                        if (code == "BSP2")
                            BD_BSP2.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Position);


                    }

                }


                if (MidCodes != null && MidCodes.Count > 0)
                {

                    List<int> Ids = new List<int>();
                    foreach (string codeM in MidCodes)
                    {
                        if (Com.CodeNames.Keys.Contains(codeM))
                        {
                            SetParameters(codeM);

                            if (codeM == "BG21")
                                Ids.AddRange(BD_BG21.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Ids));
                            else if (codeM == "BG22")
                                Ids.AddRange(BD_BG22.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Ids));
                            else if (codeM == "BG19")
                                Ids.AddRange(BD_BG19.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Ids));
                            else if (codeM == "BG9")
                                Ids.AddRange(BD_BG9.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Ids));
                            else if (codeM == "BG2")
                                Ids.AddRange(BD_BG2.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Ids));
                            else if (codeM == "BG13")
                                Ids.AddRange(BD_BG13.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Ids));
                            else if (codeM == "BG12")
                                Ids.AddRange(BD_BG12.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Ids));
                            else if (codeM == "BS2")
                                Ids.AddRange(BD_BS2.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Ids));
                            else if (codeM == "BBP1")
                                Ids.AddRange(BD_BBP1.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Ids));

                        }

                    }

                }
            }

            if (ViewName == "Bottom View")
            {
                if (IsDeleteDim)
                    Com.DeleteDim(CView);

                for (int i = 0; i < 2; i++)
                {
                    string code = "";
                    string Position = "";
                    if (!string.IsNullOrEmpty(LeftCode) && i == 0)
                    {
                        code = LeftCode;
                        Position = "Left";

                    }
                    else if (!string.IsNullOrEmpty(RightCode) && i == 1)
                    {
                        code = RightCode;
                        Position = "Right";
                    }

                    if (!string.IsNullOrEmpty(code))
                    {
                        SetParameters(code);
                        
                        if (code == "BSP2")
                            BD_BSP2.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Position);


                    }

                }


                if (MidCodes != null && MidCodes.Count > 0)
                {

                    List<int> Ids = new List<int>();
                    foreach (string codeM in MidCodes)
                    {
                        if (Com.CodeNames.Keys.Contains(codeM))
                        {
                            SetParameters(codeM);

                            if (codeM == "BG21")
                                Ids.AddRange(BD_BG21.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Ids));
                            else if (codeM == "BG22")
                                Ids.AddRange(BD_BG22.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Ids));
                            else if (codeM == "BG19")
                                Ids.AddRange(BD_BG19.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Ids));
                            else if (codeM == "BG9")
                                Ids.AddRange(BD_BG9.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Ids));
                            else if (codeM == "BG2")
                                Ids.AddRange(BD_BG2.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Ids));
                            else if (codeM == "BG13")
                                Ids.AddRange(BD_BG13.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Ids));
                            else if (codeM == "BG12")
                                Ids.AddRange(BD_BG12.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Ids));
                            else if (codeM == "BS2")
                                Ids.AddRange(BD_BS2.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Ids));
                            else if (codeM == "BBP1")
                                Ids.AddRange(BD_BBP1.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Ids));
                        }

                    }

                }

            }

            if (ViewName == "Detail View")
            {
                if (IsDeleteDim)
                    Com.DeleteDim(CView);

                string code = "";
                string Position = "";

                // Left End Section
                if (CView.Origin.X < FrontView.Origin.X)
                {
                    code = LeftCode;
                    Position = "Left";

                }
                else
                {
                    code = RightCode;
                    Position = "Right";
                }

                if (!string.IsNullOrEmpty(code))
                {
                    SetParameters(code);
                    List<int> Ids = new List<int>();
                    if (code == "BC2")
                        BD_BC2.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Position);
                
                  

                }


                if (MidCodes != null && MidCodes.Count > 0)
                {

                    List<int> Ids = new List<int>();
                    foreach (string codeM in MidCodes)
                    {
                        if (Com.CodeNames.Keys.Contains(codeM))
                        {
                            SetParameters(codeM);

                            if (codeM == "BS2")
                                Ids.AddRange(BD_BS2.ApplyDim(CView, ViewName, autoDimensioningTypes, drawingAttributeInfo, Ids));
                            

                            if (Ids.Count > 0)
                                break;

                        }

                    }

                }




            }
        }

        private void ClearRecord()
        {
            List<TSM.Part> SecParts = MainBeam.GetAssembly().GetSecondaries().OfType<TSM.Part>().ToList();
            SecParts.ForEach(x => Com.ClearCode(x));

        }

        private double ViewOrgY(TSD.View CView)
        {
            return CView.Origin.Y;
        }

        #region Setup Data Retrieval

        private void SetParameters(string code)
        {
            try
            {

                typeof(BeamDim).GetMethod("SetParameters" + code, BindingFlags.NonPublic | BindingFlags.Instance).Invoke(this, null);
            }
            catch (Exception ex)
            { }
        }

        private bool SetParametersBG2()
        {
            bool RetCheck = false;
            string FilePath = Com.MyModel.GetInfo().ModelPath + @"\attributes\standard.Auto_Detailing_Tool_Beam.Setup_BG2.xml";
            if (File.Exists(FilePath))
            {

                Setup_BG2_Data setup_BG2_Data = Com.TeklaXMLToClass<Setup_BG2_Data>(FilePath);
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.StandardDimension = setup_BG2_Data.txtStDim;
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.RunningDimension = setup_BG2_Data.txtRdDim;
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.ElevationDimension = setup_BG2_Data.txtELDim;

                autoDimensioningTypes.Bg2.DimIDNo1 = setup_BG2_Data.chkDimIDNo1;
                autoDimensioningTypes.Bg2.DimIDNo10 = setup_BG2_Data.chkDimIDNo10;
                autoDimensioningTypes.Bg2.DimIDNo11 = setup_BG2_Data.chkDimIDNo11;
                autoDimensioningTypes.Bg2.DimIDNo12 = setup_BG2_Data.chkDimIDNo12;
                autoDimensioningTypes.Bg2.DimIDNo13 = setup_BG2_Data.chkDimIDNo13;
                autoDimensioningTypes.Bg2.DimIDNo13Dot1 = setup_BG2_Data.chkDimIDNo13Dot1;
                autoDimensioningTypes.Bg2.DimIDNo14 = setup_BG2_Data.chkDimIDNo14;
                autoDimensioningTypes.Bg2.DimIDNo14Dot1 = setup_BG2_Data.chkDimIDNo14Dot1;
                autoDimensioningTypes.Bg2.DimIDNo15 = setup_BG2_Data.chkDimIDNo15;
                autoDimensioningTypes.Bg2.DimIDNo15Dot1 = setup_BG2_Data.chkDimIDNo15Dot1;
                autoDimensioningTypes.Bg2.DimIDNo16 = setup_BG2_Data.chkDimIDNo16;
                autoDimensioningTypes.Bg2.DimIDNo17 = setup_BG2_Data.chkDimIDNo17;
                autoDimensioningTypes.Bg2.DimIDNo18 = setup_BG2_Data.chkDimIDNo18;
                autoDimensioningTypes.Bg2.DimIDNo18Dot1 = setup_BG2_Data.chkDimIDNo18Dot1;
                autoDimensioningTypes.Bg2.DimIDNo19 = setup_BG2_Data.chkDimIDNo19;
                autoDimensioningTypes.Bg2.DimIDNo19Dot1 = setup_BG2_Data.chkDimIDNo19Dot1;
                autoDimensioningTypes.Bg2.DimIDNo1Dot1 = setup_BG2_Data.chkDimIDNo1Dot1;
                autoDimensioningTypes.Bg2.DimIDNo2 = setup_BG2_Data.chkDimIDNo2;
                autoDimensioningTypes.Bg2.DimIDNo20 = setup_BG2_Data.chkDimIDNo20;
                autoDimensioningTypes.Bg2.DimIDNo20Dot1 = setup_BG2_Data.chkDimIDNo20Dot1;
                autoDimensioningTypes.Bg2.DimIDNo21 = setup_BG2_Data.chkDimIDNo21;
                autoDimensioningTypes.Bg2.DimIDNo21Dot1 = setup_BG2_Data.chkDimIDNo21Dot1;
                autoDimensioningTypes.Bg2.DimIDNo22 = setup_BG2_Data.chkDimIDNo22;
                autoDimensioningTypes.Bg2.DimIDNo2Dot1 = setup_BG2_Data.chkDimIDNo2Dot1;
                autoDimensioningTypes.Bg2.DimIDNo2Dot2 = setup_BG2_Data.chkDimIDNo2Dot2;
                autoDimensioningTypes.Bg2.DimIDNo2Dot3 = setup_BG2_Data.chkDimIDNo2Dot3;
                autoDimensioningTypes.Bg2.DimIDNo2Dot4 = setup_BG2_Data.chkDimIDNo2Dot4;
                autoDimensioningTypes.Bg2.DimIDNo3 = setup_BG2_Data.chkDimIDNo3;
                autoDimensioningTypes.Bg2.DimIDNo3Dot1 = setup_BG2_Data.chkDimIDNo3Dot1;
                autoDimensioningTypes.Bg2.DimIDNo3Dot2 = setup_BG2_Data.chkDimIDNo3Dot2;
                autoDimensioningTypes.Bg2.DimIDNo4 = setup_BG2_Data.chkDimIDNo4;
                autoDimensioningTypes.Bg2.DimIDNo4Dot1 = setup_BG2_Data.chkDimIDNo4Dot1;
                autoDimensioningTypes.Bg2.DimIDNo5 = setup_BG2_Data.chkDimIDNo5;
                autoDimensioningTypes.Bg2.DimIDNo6 = setup_BG2_Data.chkDimIDNo6;
                autoDimensioningTypes.Bg2.DimIDNo6Dot1 = setup_BG2_Data.chkDimIDNo6Dot1;
                autoDimensioningTypes.Bg2.DimIDNo6Dot2 = setup_BG2_Data.chkDimIDNo6Dot2;
                autoDimensioningTypes.Bg2.DimIDNo6Dot3 = setup_BG2_Data.chkDimIDNo6Dot3;
                autoDimensioningTypes.Bg2.DimIDNo6Dot4 = setup_BG2_Data.chkDimIDNo6Dot4;
                autoDimensioningTypes.Bg2.DimIDNo6Dot5 = setup_BG2_Data.chkDimIDNo6Dot5;
                autoDimensioningTypes.Bg2.DimIDNo7 = setup_BG2_Data.chkDimIDNo7;
                autoDimensioningTypes.Bg2.DimIDNo7Dot1 = setup_BG2_Data.chkDimIDNo7Dot1;
                autoDimensioningTypes.Bg2.DimIDNo8 = setup_BG2_Data.chkDimIDNo8;
                autoDimensioningTypes.Bg2.DimIDNo9 = setup_BG2_Data.chkDimIDNo9;
                autoDimensioningTypes.Bg2.DimIDNo23 = setup_BG2_Data.chkDimIDNo23;



                RetCheck = true;

            }

            return RetCheck;

        }

        private bool SetParametersBG3()
        {
            bool RetCheck = false;
            string FilePath = Com.MyModel.GetInfo().ModelPath + @"\attributes\standard.Auto_Detailing_Tool_Beam.Setup_BG3.xml";
            if (File.Exists(FilePath))
            {

                Setup_BG3_Data setup_BG3_Data = Com.TeklaXMLToClass<Setup_BG3_Data>(FilePath);
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.StandardDimension = setup_BG3_Data.txtStDim;
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.RunningDimension = setup_BG3_Data.txtRdDim;
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.ElevationDimension = setup_BG3_Data.txtELDim;

                autoDimensioningTypes.Bg3.DimIDNo1 = setup_BG3_Data.chkDimIDNo1;
                autoDimensioningTypes.Bg3.DimIDNo10 = setup_BG3_Data.chkDimIDNo10;
                autoDimensioningTypes.Bg3.DimIDNo11 = setup_BG3_Data.chkDimIDNo11;
                autoDimensioningTypes.Bg3.DimIDNo12 = setup_BG3_Data.chkDimIDNo12;
                autoDimensioningTypes.Bg3.DimIDNo13 = setup_BG3_Data.chkDimIDNo13;
                autoDimensioningTypes.Bg3.DimIDNo15 = setup_BG3_Data.chkDimIDNo15;
                autoDimensioningTypes.Bg3.DimIDNo16 = setup_BG3_Data.chkDimIDNo16;
                autoDimensioningTypes.Bg3.DimIDNo17 = setup_BG3_Data.chkDimIDNo17;
                autoDimensioningTypes.Bg3.DimIDNo18 = setup_BG3_Data.chkDimIDNo18;
                autoDimensioningTypes.Bg3.DimIDNo19 = setup_BG3_Data.chkDimIDNo19;
                autoDimensioningTypes.Bg3.DimIDNo1Dot1 = setup_BG3_Data.chkDimIDNo1Dot1;
                autoDimensioningTypes.Bg3.DimIDNo1Dot2 = setup_BG3_Data.chkDimIDNo1Dot2;
                autoDimensioningTypes.Bg3.DimIDNo1Dot3 = setup_BG3_Data.chkDimIDNo1Dot3;
                autoDimensioningTypes.Bg3.DimIDNo1Dot4 = setup_BG3_Data.chkDimIDNo1Dot4;
                autoDimensioningTypes.Bg3.DimIDNo1Dot5 = setup_BG3_Data.chkDimIDNo1Dot5;
                autoDimensioningTypes.Bg3.DimIDNo1Dot6 = setup_BG3_Data.chkDimIDNo1Dot6;
                autoDimensioningTypes.Bg3.DimIDNo2 = setup_BG3_Data.chkDimIDNo2;
                autoDimensioningTypes.Bg3.DimIDNo22 = setup_BG3_Data.chkDimIDNo22;
                autoDimensioningTypes.Bg3.DimIDNo2Dot1 = setup_BG3_Data.chkDimIDNo2Dot1;
                autoDimensioningTypes.Bg3.DimIDNo2Dot2 = setup_BG3_Data.chkDimIDNo2Dot2;
                autoDimensioningTypes.Bg3.DimIDNo2Dot3 = setup_BG3_Data.chkDimIDNo2Dot3;
                autoDimensioningTypes.Bg3.DimIDNo2Dot4 = setup_BG3_Data.chkDimIDNo2Dot4;
                autoDimensioningTypes.Bg3.DimIDNo2Dot5 = setup_BG3_Data.chkDimIDNo2Dot5;
                autoDimensioningTypes.Bg3.DimIDNo3 = setup_BG3_Data.chkDimIDNo3;
                autoDimensioningTypes.Bg3.DimIDNo4 = setup_BG3_Data.chkDimIDNo4;
                autoDimensioningTypes.Bg3.DimIDNo5 = setup_BG3_Data.chkDimIDNo5;
                autoDimensioningTypes.Bg3.DimIDNo6 = setup_BG3_Data.chkDimIDNo6;
                autoDimensioningTypes.Bg3.DimIDNo7 = setup_BG3_Data.chkDimIDNo7;
                autoDimensioningTypes.Bg3.DimIDNo7Dot1 = setup_BG3_Data.chkDimIDNo7Dot1;
                autoDimensioningTypes.Bg3.DimIDNo7Dot2 = setup_BG3_Data.chkDimIDNo7Dot2;
                autoDimensioningTypes.Bg3.DimIDNo8 = setup_BG3_Data.chkDimIDNo8;
                autoDimensioningTypes.Bg3.DimIDNo8Dot1 = setup_BG3_Data.chkDimIDNo8Dot1;
                autoDimensioningTypes.Bg3.DimIDNo8Dot2 = setup_BG3_Data.chkDimIDNo8Dot2;
                autoDimensioningTypes.Bg3.DimIDNo9 = setup_BG3_Data.chkDimIDNo9;



                RetCheck = true;

            }

            return RetCheck;

        }

        private bool SetParametersBG5()
        {
            bool RetCheck = false;
            string FilePath = Com.MyModel.GetInfo().ModelPath + @"\attributes\standard.Auto_Detailing_Tool_Beam.Setup_BG5.xml";
            if (File.Exists(FilePath))
            {

                Setup_BG5_Data setup_BG5_Data = Com.TeklaXMLToClass<Setup_BG5_Data>(FilePath);
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.StandardDimension = setup_BG5_Data.txtStDim;
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.RunningDimension = setup_BG5_Data.txtRdDim;
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.ElevationDimension = setup_BG5_Data.txtELDim;

                autoDimensioningTypes.Bg5.DimIDNo1 = setup_BG5_Data.chkDimIDNo1;
                autoDimensioningTypes.Bg5.DimIDNo10 = setup_BG5_Data.chkDimIDNo10;
                autoDimensioningTypes.Bg5.DimIDNo11 = setup_BG5_Data.chkDimIDNo11;
                autoDimensioningTypes.Bg5.DimIDNo12 = setup_BG5_Data.chkDimIDNo12;
                autoDimensioningTypes.Bg5.DimIDNo13 = setup_BG5_Data.chkDimIDNo13;
                autoDimensioningTypes.Bg5.DimIDNo14 = setup_BG5_Data.chkDimIDNo14;
                autoDimensioningTypes.Bg5.DimIDNo15 = setup_BG5_Data.chkDimIDNo15;
                autoDimensioningTypes.Bg5.DimIDNo16 = setup_BG5_Data.chkDimIDNo16;
                autoDimensioningTypes.Bg5.DimIDNo17 = setup_BG5_Data.chkDimIDNo17;
                autoDimensioningTypes.Bg5.DimIDNo18 = setup_BG5_Data.chkDimIDNo18;
                autoDimensioningTypes.Bg5.DimIDNo19 = setup_BG5_Data.chkDimIDNo19;
                autoDimensioningTypes.Bg5.DimIDNo1Dot1 = setup_BG5_Data.chkDimIDNo1Dot1;
                autoDimensioningTypes.Bg5.DimIDNo1Dot2 = setup_BG5_Data.chkDimIDNo1Dot2;
                autoDimensioningTypes.Bg5.DimIDNo1Dot3 = setup_BG5_Data.chkDimIDNo1Dot3;
                autoDimensioningTypes.Bg5.DimIDNo2 = setup_BG5_Data.chkDimIDNo2;
                autoDimensioningTypes.Bg5.DimIDNo20 = setup_BG5_Data.chkDimIDNo20;
                autoDimensioningTypes.Bg5.DimIDNo21 = setup_BG5_Data.chkDimIDNo21;
                autoDimensioningTypes.Bg5.DimIDNo22 = setup_BG5_Data.chkDimIDNo22;
                autoDimensioningTypes.Bg5.DimIDNo23 = setup_BG5_Data.chkDimIDNo23;
                autoDimensioningTypes.Bg5.DimIDNo24 = setup_BG5_Data.chkDimIDNo24;
                autoDimensioningTypes.Bg5.DimIDNo24Dot1 = setup_BG5_Data.chkDimIDNo24Dot1;
                autoDimensioningTypes.Bg5.DimIDNo25 = setup_BG5_Data.chkDimIDNo25;
                autoDimensioningTypes.Bg5.DimIDNo25Dot1 = setup_BG5_Data.chkDimIDNo25Dot1;
                autoDimensioningTypes.Bg5.DimIDNo25Dot2 = setup_BG5_Data.chkDimIDNo25Dot2;
                autoDimensioningTypes.Bg5.DimIDNo26 = setup_BG5_Data.chkDimIDNo26;
                autoDimensioningTypes.Bg5.DimIDNo26Dot1 = setup_BG5_Data.chkDimIDNo26Dot1;
                autoDimensioningTypes.Bg5.DimIDNo27 = setup_BG5_Data.chkDimIDNo27;
                autoDimensioningTypes.Bg5.DimIDNo27Dot1 = setup_BG5_Data.chkDimIDNo27Dot1;
                autoDimensioningTypes.Bg5.DimIDNo28 = setup_BG5_Data.chkDimIDNo28;
                autoDimensioningTypes.Bg5.DimIDNo28Dot1 = setup_BG5_Data.chkDimIDNo28Dot1;
                autoDimensioningTypes.Bg5.DimIDNo29 = setup_BG5_Data.chkDimIDNo29;
                autoDimensioningTypes.Bg5.DimIDNo2Dot1 = setup_BG5_Data.chkDimIDNo2Dot1;
                autoDimensioningTypes.Bg5.DimIDNo2Dot2 = setup_BG5_Data.chkDimIDNo2Dot2;
                autoDimensioningTypes.Bg5.DimIDNo3 = setup_BG5_Data.chkDimIDNo3;
                autoDimensioningTypes.Bg5.DimIDNo30 = setup_BG5_Data.chkDimIDNo30;
                autoDimensioningTypes.Bg5.DimIDNo31 = setup_BG5_Data.chkDimIDNo31;
                autoDimensioningTypes.Bg5.DimIDNo32 = setup_BG5_Data.chkDimIDNo32;
                autoDimensioningTypes.Bg5.DimIDNo33 = setup_BG5_Data.chkDimIDNo33;
                autoDimensioningTypes.Bg5.DimIDNo34 = setup_BG5_Data.chkDimIDNo34;
                autoDimensioningTypes.Bg5.DimIDNo34Dot1 = setup_BG5_Data.chkDimIDNo34Dot1;
                autoDimensioningTypes.Bg5.DimIDNo35 = setup_BG5_Data.chkDimIDNo35;
                autoDimensioningTypes.Bg5.DimIDNo36 = setup_BG5_Data.chkDimIDNo36;
                autoDimensioningTypes.Bg5.DimIDNo37 = setup_BG5_Data.chkDimIDNo37;
                autoDimensioningTypes.Bg5.DimIDNo37Dot1 = setup_BG5_Data.chkDimIDNo37Dot1;
                autoDimensioningTypes.Bg5.DimIDNo38 = setup_BG5_Data.chkDimIDNo38;
                autoDimensioningTypes.Bg5.DimIDNo39 = setup_BG5_Data.chkDimIDNo39;
                autoDimensioningTypes.Bg5.DimIDNo3Dot1 = setup_BG5_Data.chkDimIDNo3Dot1;
                autoDimensioningTypes.Bg5.DimIDNo3Dot2 = setup_BG5_Data.chkDimIDNo3Dot2;
                autoDimensioningTypes.Bg5.DimIDNo4 = setup_BG5_Data.chkDimIDNo4;
                autoDimensioningTypes.Bg5.DimIDNo40 = setup_BG5_Data.chkDimIDNo40;
                autoDimensioningTypes.Bg5.DimIDNo41 = setup_BG5_Data.chkDimIDNo41;
                autoDimensioningTypes.Bg5.DimIDNo42 = setup_BG5_Data.chkDimIDNo42;
                autoDimensioningTypes.Bg5.DimIDNo5 = setup_BG5_Data.chkDimIDNo5;
                autoDimensioningTypes.Bg5.DimIDNo6 = setup_BG5_Data.chkDimIDNo6;
                autoDimensioningTypes.Bg5.DimIDNo7 = setup_BG5_Data.chkDimIDNo7;
                autoDimensioningTypes.Bg5.DimIDNo8 = setup_BG5_Data.chkDimIDNo8;
                autoDimensioningTypes.Bg5.DimIDNo8Dot1 = setup_BG5_Data.chkDimIDNo8Dot1;
                autoDimensioningTypes.Bg5.DimIDNo8Dot2 = setup_BG5_Data.chkDimIDNo8Dot2;
                autoDimensioningTypes.Bg5.DimIDNo8Dot3 = setup_BG5_Data.chkDimIDNo8Dot3;
                autoDimensioningTypes.Bg5.DimIDNo9 = setup_BG5_Data.chkDimIDNo9;

                RetCheck = true;

            }

            return RetCheck;

        }

        private bool SetParametersBG6()
        {
            bool RetCheck = false;
            string FilePath = Com.MyModel.GetInfo().ModelPath + @"\attributes\standard.Auto_Detailing_Tool_Beam.Setup_BG6.xml";
            if (File.Exists(FilePath))
            {

                Setup_BG6_Data setup_BG6_Data = Com.TeklaXMLToClass<Setup_BG6_Data>(FilePath);
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.StandardDimension = setup_BG6_Data.txtStDim;
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.RunningDimension = setup_BG6_Data.txtRdDim;
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.ElevationDimension = setup_BG6_Data.txtELDim;

                autoDimensioningTypes.Bg6.DimIDNo1 = setup_BG6_Data.chkDimIDNo1;
                autoDimensioningTypes.Bg6.DimIDNo10 = setup_BG6_Data.chkDimIDNo10;
                autoDimensioningTypes.Bg6.DimIDNo11 = setup_BG6_Data.chkDimIDNo11;
                autoDimensioningTypes.Bg6.DimIDNo12 = setup_BG6_Data.chkDimIDNo12;
                autoDimensioningTypes.Bg6.DimIDNo13 = setup_BG6_Data.chkDimIDNo13;
                autoDimensioningTypes.Bg6.DimIDNo13Dot1 = setup_BG6_Data.chkDimIDNo13Dot1;
                autoDimensioningTypes.Bg6.DimIDNo13Dot2 = setup_BG6_Data.chkDimIDNo13Dot2;
                autoDimensioningTypes.Bg6.DimIDNo13Dot3 = setup_BG6_Data.chkDimIDNo13Dot3;
                autoDimensioningTypes.Bg6.DimIDNo14 = setup_BG6_Data.chkDimIDNo14;
                autoDimensioningTypes.Bg6.DimIDNo14Dot1 = setup_BG6_Data.chkDimIDNo14Dot1;
                autoDimensioningTypes.Bg6.DimIDNo14Dot2 = setup_BG6_Data.chkDimIDNo14Dot2;
                autoDimensioningTypes.Bg6.DimIDNo15 = setup_BG6_Data.chkDimIDNo15;
                autoDimensioningTypes.Bg6.DimIDNo15Dot1 = setup_BG6_Data.chkDimIDNo15Dot1;
                autoDimensioningTypes.Bg6.DimIDNo16 = setup_BG6_Data.chkDimIDNo16;
                autoDimensioningTypes.Bg6.DimIDNo17 = setup_BG6_Data.chkDimIDNo17;
                autoDimensioningTypes.Bg6.DimIDNo18 = setup_BG6_Data.chkDimIDNo18;
                autoDimensioningTypes.Bg6.DimIDNo19 = setup_BG6_Data.chkDimIDNo19;
                autoDimensioningTypes.Bg6.DimIDNo1Dot1 = setup_BG6_Data.chkDimIDNo1Dot1;
                autoDimensioningTypes.Bg6.DimIDNo1Dot2 = setup_BG6_Data.chkDimIDNo1Dot2;
                autoDimensioningTypes.Bg6.DimIDNo2 = setup_BG6_Data.chkDimIDNo2;
                autoDimensioningTypes.Bg6.DimIDNo20 = setup_BG6_Data.chkDimIDNo20;
                autoDimensioningTypes.Bg6.DimIDNo21 = setup_BG6_Data.chkDimIDNo21;
                autoDimensioningTypes.Bg6.DimIDNo21Dot1 = setup_BG6_Data.chkDimIDNo21Dot1;
                autoDimensioningTypes.Bg6.DimIDNo22 = setup_BG6_Data.chkDimIDNo22;
                autoDimensioningTypes.Bg6.DimIDNo23 = setup_BG6_Data.chkDimIDNo23;
                autoDimensioningTypes.Bg6.DimIDNo23Dot1 = setup_BG6_Data.chkDimIDNo23Dot1;
                autoDimensioningTypes.Bg6.DimIDNo24 = setup_BG6_Data.chkDimIDNo24;
                autoDimensioningTypes.Bg6.DimIDNo24Dot1 = setup_BG6_Data.chkDimIDNo24Dot1;
                autoDimensioningTypes.Bg6.DimIDNo25 = setup_BG6_Data.chkDimIDNo25;
                autoDimensioningTypes.Bg6.DimIDNo26 = setup_BG6_Data.chkDimIDNo26;
                autoDimensioningTypes.Bg6.DimIDNo27 = setup_BG6_Data.chkDimIDNo27;
                autoDimensioningTypes.Bg6.DimIDNo27Dot1 = setup_BG6_Data.chkDimIDNo27Dot1;
                autoDimensioningTypes.Bg6.DimIDNo28 = setup_BG6_Data.chkDimIDNo28;
                autoDimensioningTypes.Bg6.DimIDNo2Dot1 = setup_BG6_Data.chkDimIDNo2Dot1;
                autoDimensioningTypes.Bg6.DimIDNo3 = setup_BG6_Data.chkDimIDNo3;
                autoDimensioningTypes.Bg6.DimIDNo3Dot1 = setup_BG6_Data.chkDimIDNo3Dot1;
                autoDimensioningTypes.Bg6.DimIDNo4 = setup_BG6_Data.chkDimIDNo4;
                autoDimensioningTypes.Bg6.DimIDNo5 = setup_BG6_Data.chkDimIDNo5;
                autoDimensioningTypes.Bg6.DimIDNo5Dot1 = setup_BG6_Data.chkDimIDNo5Dot1;
                autoDimensioningTypes.Bg6.DimIDNo5Dot2 = setup_BG6_Data.chkDimIDNo5Dot2;
                autoDimensioningTypes.Bg6.DimIDNo5Dot3 = setup_BG6_Data.chkDimIDNo5Dot3;
                autoDimensioningTypes.Bg6.DimIDNo6 = setup_BG6_Data.chkDimIDNo6;
                autoDimensioningTypes.Bg6.DimIDNo7 = setup_BG6_Data.chkDimIDNo7;
                autoDimensioningTypes.Bg6.DimIDNo7Dot1 = setup_BG6_Data.chkDimIDNo7Dot1;
                autoDimensioningTypes.Bg6.DimIDNo7Dot2 = setup_BG6_Data.chkDimIDNo7Dot2;
                autoDimensioningTypes.Bg6.DimIDNo8 = setup_BG6_Data.chkDimIDNo8;
                autoDimensioningTypes.Bg6.DimIDNo9 = setup_BG6_Data.chkDimIDNo9;

                RetCheck = true;

            }

            return RetCheck;

        }

        private bool SetParametersBG7()
        {
            bool RetCheck = false;
            string FilePath = Com.MyModel.GetInfo().ModelPath + @"\attributes\standard.Auto_Detailing_Tool_Beam.Setup_BG7.xml";
            if (File.Exists(FilePath))
            {

                Setup_BG7_Data setup_BG7_Data = Com.TeklaXMLToClass<Setup_BG7_Data>(FilePath);
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.StandardDimension = setup_BG7_Data.txtStDim;
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.RunningDimension = setup_BG7_Data.txtRdDim;
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.ElevationDimension = setup_BG7_Data.txtELDim;

                autoDimensioningTypes.Bg7.DimIDNo1 = setup_BG7_Data.chkDimIDNo1;
                autoDimensioningTypes.Bg7.DimIDNo10 = setup_BG7_Data.chkDimIDNo10;
                autoDimensioningTypes.Bg7.DimIDNo11 = setup_BG7_Data.chkDimIDNo11;
                autoDimensioningTypes.Bg7.DimIDNo12 = setup_BG7_Data.chkDimIDNo12;
                autoDimensioningTypes.Bg7.DimIDNo13 = setup_BG7_Data.chkDimIDNo13;
                autoDimensioningTypes.Bg7.DimIDNo14 = setup_BG7_Data.chkDimIDNo14;
                autoDimensioningTypes.Bg7.DimIDNo15 = setup_BG7_Data.chkDimIDNo15;
                autoDimensioningTypes.Bg7.DimIDNo16 = setup_BG7_Data.chkDimIDNo16;
                autoDimensioningTypes.Bg7.DimIDNo17 = setup_BG7_Data.chkDimIDNo17;
                autoDimensioningTypes.Bg7.DimIDNo18 = setup_BG7_Data.chkDimIDNo18;
                autoDimensioningTypes.Bg7.DimIDNo18Dot1 = setup_BG7_Data.chkDimIDNo18Dot1;
                autoDimensioningTypes.Bg7.DimIDNo19 = setup_BG7_Data.chkDimIDNo19;
                autoDimensioningTypes.Bg7.DimIDNo19Dot1 = setup_BG7_Data.chkDimIDNo19Dot1;
                autoDimensioningTypes.Bg7.DimIDNo1Dot1 = setup_BG7_Data.chkDimIDNo1Dot1;
                autoDimensioningTypes.Bg7.DimIDNo1Dot2 = setup_BG7_Data.chkDimIDNo1Dot2;
                autoDimensioningTypes.Bg7.DimIDNo2 = setup_BG7_Data.chkDimIDNo2;
                autoDimensioningTypes.Bg7.DimIDNo20 = setup_BG7_Data.chkDimIDNo20;
                autoDimensioningTypes.Bg7.DimIDNo20Dot1 = setup_BG7_Data.chkDimIDNo20Dot1;
                autoDimensioningTypes.Bg7.DimIDNo21 = setup_BG7_Data.chkDimIDNo21;
                autoDimensioningTypes.Bg7.DimIDNo21Dot1 = setup_BG7_Data.chkDimIDNo21Dot1;
                autoDimensioningTypes.Bg7.DimIDNo22 = setup_BG7_Data.chkDimIDNo22;
                autoDimensioningTypes.Bg7.DimIDNo23 = setup_BG7_Data.chkDimIDNo23;
                autoDimensioningTypes.Bg7.DimIDNo24 = setup_BG7_Data.chkDimIDNo24;
                autoDimensioningTypes.Bg7.DimIDNo25 = setup_BG7_Data.chkDimIDNo25;
                autoDimensioningTypes.Bg7.DimIDNo26 = setup_BG7_Data.chkDimIDNo26;
                autoDimensioningTypes.Bg7.DimIDNo27 = setup_BG7_Data.chkDimIDNo27;
                autoDimensioningTypes.Bg7.DimIDNo28 = setup_BG7_Data.chkDimIDNo28;
               // autoDimensioningTypes.Bg7.DimIDNo29 = setup_BG7_Data.chkDimIDNo29;
                autoDimensioningTypes.Bg7.DimIDNo3 = setup_BG7_Data.chkDimIDNo3;
                autoDimensioningTypes.Bg7.DimIDNo31 = setup_BG7_Data.chkDimIDNo31;
                autoDimensioningTypes.Bg7.DimIDNo3Dot1 = setup_BG7_Data.chkDimIDNo3Dot1;
                autoDimensioningTypes.Bg7.DimIDNo4 = setup_BG7_Data.chkDimIDNo4;
                autoDimensioningTypes.Bg7.DimIDNo5 = setup_BG7_Data.chkDimIDNo5;
                autoDimensioningTypes.Bg7.DimIDNo5Dot1 = setup_BG7_Data.chkDimIDNo5Dot1;
                autoDimensioningTypes.Bg7.DimIDNo5Dot2 = setup_BG7_Data.chkDimIDNo5Dot2;
                autoDimensioningTypes.Bg7.DimIDNo6 = setup_BG7_Data.chkDimIDNo6;
                autoDimensioningTypes.Bg7.DimIDNo6Dot1 = setup_BG7_Data.chkDimIDNo6Dot1;
                autoDimensioningTypes.Bg7.DimIDNo6Dot2 = setup_BG7_Data.chkDimIDNo6Dot2;
                autoDimensioningTypes.Bg7.DimIDNo7 = setup_BG7_Data.chkDimIDNo7;
                autoDimensioningTypes.Bg7.DimIDNo7Dot1 = setup_BG7_Data.chkDimIDNo7Dot1;
                autoDimensioningTypes.Bg7.DimIDNo7Dot2 = setup_BG7_Data.chkDimIDNo7Dot2;
                autoDimensioningTypes.Bg7.DimIDNo8 = setup_BG7_Data.chkDimIDNo8;
                autoDimensioningTypes.Bg7.DimIDNo9 = setup_BG7_Data.chkDimIDNo9;

                RetCheck = true;

            }

            return RetCheck;

        }

        private bool SetParametersBG8()
        {
            bool RetCheck = false;
            string FilePath = Com.MyModel.GetInfo().ModelPath + @"\attributes\standard.Auto_Detailing_Tool_Beam.Setup_BG8.xml";
            if (File.Exists(FilePath))
            {

                Setup_BG8_Data setup_BG8_Data = Com.TeklaXMLToClass<Setup_BG8_Data>(FilePath);
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.StandardDimension = setup_BG8_Data.txtStDim;
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.RunningDimension = setup_BG8_Data.txtRdDim;
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.ElevationDimension = setup_BG8_Data.txtELDim;

                autoDimensioningTypes.Bg8.DimIDNo1 = setup_BG8_Data.chkDimIDNo1;
                autoDimensioningTypes.Bg8.DimIDNo10 = setup_BG8_Data.chkDimIDNo10;
                autoDimensioningTypes.Bg8.DimIDNo11 = setup_BG8_Data.chkDimIDNo11;
                autoDimensioningTypes.Bg8.DimIDNo11Dot1 = setup_BG8_Data.chkDimIDNo11Dot1;
                autoDimensioningTypes.Bg8.DimIDNo12 = setup_BG8_Data.chkDimIDNo12;
                autoDimensioningTypes.Bg8.DimIDNo12Dot1 = setup_BG8_Data.chkDimIDNo12Dot1;
                autoDimensioningTypes.Bg8.DimIDNo12Dot2 = setup_BG8_Data.chkDimIDNo12Dot2;
                autoDimensioningTypes.Bg8.DimIDNo12Dot3 = setup_BG8_Data.chkDimIDNo12Dot3;
                autoDimensioningTypes.Bg8.DimIDNo13 = setup_BG8_Data.chkDimIDNo13;
                autoDimensioningTypes.Bg8.DimIDNo14 = setup_BG8_Data.chkDimIDNo14;
                autoDimensioningTypes.Bg8.DimIDNo14Dot1 = setup_BG8_Data.chkDimIDNo14Dot1;
                autoDimensioningTypes.Bg8.DimIDNo14Dot2 = setup_BG8_Data.chkDimIDNo14Dot2;
                autoDimensioningTypes.Bg8.DimIDNo14Dot3 = setup_BG8_Data.chkDimIDNo14Dot3;
                autoDimensioningTypes.Bg8.DimIDNo15 = setup_BG8_Data.chkDimIDNo15;
                autoDimensioningTypes.Bg8.DimIDNo15Dot1 = setup_BG8_Data.chkDimIDNo15Dot1;
                autoDimensioningTypes.Bg8.DimIDNo16 = setup_BG8_Data.chkDimIDNo16;
                autoDimensioningTypes.Bg8.DimIDNo17 = setup_BG8_Data.chkDimIDNo17;
                autoDimensioningTypes.Bg8.DimIDNo18 = setup_BG8_Data.chkDimIDNo18;
                autoDimensioningTypes.Bg8.DimIDNo19 = setup_BG8_Data.chkDimIDNo19;
                autoDimensioningTypes.Bg8.DimIDNo19Dot1 = setup_BG8_Data.chkDimIDNo19Dot1;
                autoDimensioningTypes.Bg8.DimIDNo1Dot1 = setup_BG8_Data.chkDimIDNo1Dot1;
                autoDimensioningTypes.Bg8.DimIDNo1Dot2 = setup_BG8_Data.chkDimIDNo1Dot2;
                autoDimensioningTypes.Bg8.DimIDNo1Dot3 = setup_BG8_Data.chkDimIDNo1Dot3;
                autoDimensioningTypes.Bg8.DimIDNo1Dot4 = setup_BG8_Data.chkDimIDNo1Dot4;
                autoDimensioningTypes.Bg8.DimIDNo1Dot5 = setup_BG8_Data.chkDimIDNo1Dot5;
                autoDimensioningTypes.Bg8.DimIDNo1Dot6 = setup_BG8_Data.chkDimIDNo1Dot6;
                autoDimensioningTypes.Bg8.DimIDNo1Dot7 = setup_BG8_Data.chkDimIDNo1Dot7;
                autoDimensioningTypes.Bg8.DimIDNo2 = setup_BG8_Data.chkDimIDNo2;
                autoDimensioningTypes.Bg8.DimIDNo20 = setup_BG8_Data.chkDimIDNo20;
                autoDimensioningTypes.Bg8.DimIDNo20Dot1 = setup_BG8_Data.chkDimIDNo20Dot1;
                autoDimensioningTypes.Bg8.DimIDNo21 = setup_BG8_Data.chkDimIDNo21;
                autoDimensioningTypes.Bg8.DimIDNo21Dot1 = setup_BG8_Data.chkDimIDNo21Dot1;
                autoDimensioningTypes.Bg8.DimIDNo22 = setup_BG8_Data.chkDimIDNo22;
                autoDimensioningTypes.Bg8.DimIDNo2Dot1 = setup_BG8_Data.chkDimIDNo2Dot1;
                autoDimensioningTypes.Bg8.DimIDNo3 = setup_BG8_Data.chkDimIDNo3;
                autoDimensioningTypes.Bg8.DimIDNo4 = setup_BG8_Data.chkDimIDNo4;
                autoDimensioningTypes.Bg8.DimIDNo5 = setup_BG8_Data.chkDimIDNo5;
                autoDimensioningTypes.Bg8.DimIDNo5Dot1 = setup_BG8_Data.chkDimIDNo5Dot1;
                autoDimensioningTypes.Bg8.DimIDNo5Dot2 = setup_BG8_Data.chkDimIDNo5Dot2;
                autoDimensioningTypes.Bg8.DimIDNo6 = setup_BG8_Data.chkDimIDNo6;
                autoDimensioningTypes.Bg8.DimIDNo7 = setup_BG8_Data.chkDimIDNo7;
                autoDimensioningTypes.Bg8.DimIDNo7Dot1 = setup_BG8_Data.chkDimIDNo7Dot1;
                autoDimensioningTypes.Bg8.DimIDNo7Dot2 = setup_BG8_Data.chkDimIDNo7Dot2;
                autoDimensioningTypes.Bg8.DimIDNo7Dot3 = setup_BG8_Data.chkDimIDNo7Dot3;
                autoDimensioningTypes.Bg8.DimIDNo7Dot4 = setup_BG8_Data.chkDimIDNo7Dot4;
                autoDimensioningTypes.Bg8.DimIDNo7Dot5 = setup_BG8_Data.chkDimIDNo7Dot5;
                autoDimensioningTypes.Bg8.DimIDNo8 = setup_BG8_Data.chkDimIDNo8;
                autoDimensioningTypes.Bg8.DimIDNo9 = setup_BG8_Data.chkDimIDNo9;
                autoDimensioningTypes.Bg8.DimIDNo4Dot1 = setup_BG8_Data.chkDimIDNo4Dot1;


                RetCheck = true;

            }

            return RetCheck;

        }

        private bool SetParametersBG9()
        {
            bool RetCheck = false;
            string FilePath = Com.MyModel.GetInfo().ModelPath + @"\attributes\standard.Auto_Detailing_Tool_Beam.Setup_BG9.xml";
            if (File.Exists(FilePath))
            {

                Setup_BG9_Data setup_BG9_Data = Com.TeklaXMLToClass<Setup_BG9_Data>(FilePath);
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.StandardDimension = setup_BG9_Data.txtStDim;
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.RunningDimension = setup_BG9_Data.txtRdDim;
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.ElevationDimension = setup_BG9_Data.txtELDim;

                autoDimensioningTypes.Bg9.DimIDNo1 = setup_BG9_Data.chkDimIDNo1;
                autoDimensioningTypes.Bg9.DimIDNo10 = setup_BG9_Data.chkDimIDNo10;
                autoDimensioningTypes.Bg9.DimIDNo11 = setup_BG9_Data.chkDimIDNo11;
                autoDimensioningTypes.Bg9.DimIDNo12 = setup_BG9_Data.chkDimIDNo12;
                autoDimensioningTypes.Bg9.DimIDNo13 = setup_BG9_Data.chkDimIDNo13;
                autoDimensioningTypes.Bg9.DimIDNo14 = setup_BG9_Data.chkDimIDNo14;
                autoDimensioningTypes.Bg9.DimIDNo14Dot1 = setup_BG9_Data.chkDimIDNo14Dot1;
                autoDimensioningTypes.Bg9.DimIDNo15 = setup_BG9_Data.chkDimIDNo15;
                autoDimensioningTypes.Bg9.DimIDNo15Dot1 = setup_BG9_Data.chkDimIDNo15Dot1;
                autoDimensioningTypes.Bg9.DimIDNo16 = setup_BG9_Data.chkDimIDNo16;
                autoDimensioningTypes.Bg9.DimIDNo17 = setup_BG9_Data.chkDimIDNo17;
                autoDimensioningTypes.Bg9.DimIDNo18 = setup_BG9_Data.chkDimIDNo18;
                autoDimensioningTypes.Bg9.DimIDNo19 = setup_BG9_Data.chkDimIDNo19;
                autoDimensioningTypes.Bg9.DimIDNo1Dot1 = setup_BG9_Data.chkDimIDNo1Dot1;
                autoDimensioningTypes.Bg9.DimIDNo2 = setup_BG9_Data.chkDimIDNo2;
                autoDimensioningTypes.Bg9.DimIDNo20 = setup_BG9_Data.chkDimIDNo20;
                autoDimensioningTypes.Bg9.DimIDNo20Dot1 = setup_BG9_Data.chkDimIDNo20Dot1;
                autoDimensioningTypes.Bg9.DimIDNo20Dot2 = setup_BG9_Data.chkDimIDNo20Dot2;
                autoDimensioningTypes.Bg9.DimIDNo21 = setup_BG9_Data.chkDimIDNo21;
                autoDimensioningTypes.Bg9.DimIDNo21Dot1 = setup_BG9_Data.chkDimIDNo21Dot1;
                autoDimensioningTypes.Bg9.DimIDNo22 = setup_BG9_Data.chkDimIDNo22;
                autoDimensioningTypes.Bg9.DimIDNo23 = setup_BG9_Data.chkDimIDNo23;
                autoDimensioningTypes.Bg9.DimIDNo23Dot1 = setup_BG9_Data.chkDimIDNo23Dot1;
                autoDimensioningTypes.Bg9.DimIDNo24 = setup_BG9_Data.chkDimIDNo24;
                autoDimensioningTypes.Bg9.DimIDNo24Dot1 = setup_BG9_Data.chkDimIDNo24Dot1;
                autoDimensioningTypes.Bg9.DimIDNo25 = setup_BG9_Data.chkDimIDNo25;
                autoDimensioningTypes.Bg9.DimIDNo26 = setup_BG9_Data.chkDimIDNo26;
                autoDimensioningTypes.Bg9.DimIDNo27 = setup_BG9_Data.chkDimIDNo27;
                autoDimensioningTypes.Bg9.DimIDNo28 = setup_BG9_Data.chkDimIDNo28;
                autoDimensioningTypes.Bg9.DimIDNo29 = setup_BG9_Data.chkDimIDNo29;
                autoDimensioningTypes.Bg9.DimIDNo2Dot1 = setup_BG9_Data.chkDimIDNo2Dot1;
                autoDimensioningTypes.Bg9.DimIDNo3 = setup_BG9_Data.chkDimIDNo3;
                autoDimensioningTypes.Bg9.DimIDNo30 = setup_BG9_Data.chkDimIDNo30;
                autoDimensioningTypes.Bg9.DimIDNo3Dot1 = setup_BG9_Data.chkDimIDNo3Dot1;
                autoDimensioningTypes.Bg9.DimIDNo4 = setup_BG9_Data.chkDimIDNo4;
                autoDimensioningTypes.Bg9.DimIDNo4Dot1 = setup_BG9_Data.chkDimIDNo4Dot1;
                autoDimensioningTypes.Bg9.DimIDNo4Dot2 = setup_BG9_Data.chkDimIDNo4Dot2;
                autoDimensioningTypes.Bg9.DimIDNo4Dot3 = setup_BG9_Data.chkDimIDNo4Dot3;
                autoDimensioningTypes.Bg9.DimIDNo4Dot4 = setup_BG9_Data.chkDimIDNo4Dot4;
                autoDimensioningTypes.Bg9.DimIDNo5 = setup_BG9_Data.chkDimIDNo5;
                autoDimensioningTypes.Bg9.DimIDNo5Dot1 = setup_BG9_Data.chkDimIDNo5Dot1;
                autoDimensioningTypes.Bg9.DimIDNo6 = setup_BG9_Data.chkDimIDNo6;
                autoDimensioningTypes.Bg9.DimIDNo7 = setup_BG9_Data.chkDimIDNo7;
                autoDimensioningTypes.Bg9.DimIDNo8 = setup_BG9_Data.chkDimIDNo8;
                autoDimensioningTypes.Bg9.DimIDNo9 = setup_BG9_Data.chkDimIDNo9;

                RetCheck = true;

            }

            return RetCheck;

        }

        private bool SetParametersBG12()
        {
            bool RetCheck = false;
            string FilePath = Com.MyModel.GetInfo().ModelPath + @"\attributes\standard.Auto_Detailing_Tool_Beam.Setup_BG12.xml";
            if (File.Exists(FilePath))
            {

                Setup_BG12_Data setup_BG12_Data = Com.TeklaXMLToClass<Setup_BG12_Data>(FilePath);
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.StandardDimension = setup_BG12_Data.txtStDim;
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.RunningDimension = setup_BG12_Data.txtRdDim;
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.ElevationDimension = setup_BG12_Data.txtELDim;

                autoDimensioningTypes.Bg12.DimIDNo1 = setup_BG12_Data.chkDimIDNo1;
                autoDimensioningTypes.Bg12.DimIDNo10 = setup_BG12_Data.chkDimIDNo10;
                autoDimensioningTypes.Bg12.DimIDNo11 = setup_BG12_Data.chkDimIDNo11;
                autoDimensioningTypes.Bg12.DimIDNo12 = setup_BG12_Data.chkDimIDNo12;
                autoDimensioningTypes.Bg12.DimIDNo13 = setup_BG12_Data.chkDimIDNo13;
                autoDimensioningTypes.Bg12.DimIDNo13Dot1 = setup_BG12_Data.chkDimIDNo13Dot1;
                autoDimensioningTypes.Bg12.DimIDNo14 = setup_BG12_Data.chkDimIDNo14;
                autoDimensioningTypes.Bg12.DimIDNo14Dot1 = setup_BG12_Data.chkDimIDNo14Dot1;
                autoDimensioningTypes.Bg12.DimIDNo14Dot2 = setup_BG12_Data.chkDimIDNo14Dot2;
                autoDimensioningTypes.Bg12.DimIDNo14Dot3 = setup_BG12_Data.chkDimIDNo14Dot3;
                autoDimensioningTypes.Bg12.DimIDNo15 = setup_BG12_Data.chkDimIDNo15;
                autoDimensioningTypes.Bg12.DimIDNo15Dot1 = setup_BG12_Data.chkDimIDNo15Dot1;
                autoDimensioningTypes.Bg12.DimIDNo15Dot2 = setup_BG12_Data.chkDimIDNo15Dot2;
                autoDimensioningTypes.Bg12.DimIDNo15Dot3 = setup_BG12_Data.chkDimIDNo15Dot3;
                autoDimensioningTypes.Bg12.DimIDNo16 = setup_BG12_Data.chkDimIDNo16;
                autoDimensioningTypes.Bg12.DimIDNo16Dot1 = setup_BG12_Data.chkDimIDNo16Dot1;
                autoDimensioningTypes.Bg12.DimIDNo17 = setup_BG12_Data.chkDimIDNo17;
                autoDimensioningTypes.Bg12.DimIDNo17Dot1 = setup_BG12_Data.chkDimIDNo17Dot1;
                autoDimensioningTypes.Bg12.DimIDNo18 = setup_BG12_Data.chkDimIDNo18;
                autoDimensioningTypes.Bg12.DimIDNo18Dot1 = setup_BG12_Data.chkDimIDNo18Dot1;
                autoDimensioningTypes.Bg12.DimIDNo19 = setup_BG12_Data.chkDimIDNo19;
                autoDimensioningTypes.Bg12.DimIDNo19Dot1 = setup_BG12_Data.chkDimIDNo19Dot1;
                autoDimensioningTypes.Bg12.DimIDNo1Dot1 = setup_BG12_Data.chkDimIDNo1Dot1;
                autoDimensioningTypes.Bg12.DimIDNo2 = setup_BG12_Data.chkDimIDNo2;
                autoDimensioningTypes.Bg12.DimIDNo2Dot1 = setup_BG12_Data.chkDimIDNo2Dot1;
                autoDimensioningTypes.Bg12.DimIDNo2Dot2 = setup_BG12_Data.chkDimIDNo2Dot2;
                autoDimensioningTypes.Bg12.DimIDNo2Dot3 = setup_BG12_Data.chkDimIDNo2Dot3;
                autoDimensioningTypes.Bg12.DimIDNo2Dot4 = setup_BG12_Data.chkDimIDNo2Dot4;
                autoDimensioningTypes.Bg12.DimIDNo2Dot5 = setup_BG12_Data.chkDimIDNo2Dot5;
                autoDimensioningTypes.Bg12.DimIDNo2Dot6 = setup_BG12_Data.chkDimIDNo2Dot6;
                autoDimensioningTypes.Bg12.DimIDNo2Dot7 = setup_BG12_Data.chkDimIDNo2Dot7;
                autoDimensioningTypes.Bg12.DimIDNo2Dot8 = setup_BG12_Data.chkDimIDNo2Dot8;
                autoDimensioningTypes.Bg12.DimIDNo3 = setup_BG12_Data.chkDimIDNo3;
                autoDimensioningTypes.Bg12.DimIDNo3Dot1 = setup_BG12_Data.chkDimIDNo3Dot1;
                autoDimensioningTypes.Bg12.DimIDNo3Dot2 = setup_BG12_Data.chkDimIDNo3Dot2;
                autoDimensioningTypes.Bg12.DimIDNo3Dot3 = setup_BG12_Data.chkDimIDNo3Dot3;
                autoDimensioningTypes.Bg12.DimIDNo3Dot4 = setup_BG12_Data.chkDimIDNo3Dot4;
                autoDimensioningTypes.Bg12.DimIDNo4 = setup_BG12_Data.chkDimIDNo4;
                autoDimensioningTypes.Bg12.DimIDNo5 = setup_BG12_Data.chkDimIDNo5;
                autoDimensioningTypes.Bg12.DimIDNo5Dot1 = setup_BG12_Data.chkDimIDNo5Dot1;
                autoDimensioningTypes.Bg12.DimIDNo5Dot2 = setup_BG12_Data.chkDimIDNo5Dot2;
                autoDimensioningTypes.Bg12.DimIDNo6 = setup_BG12_Data.chkDimIDNo6;
                autoDimensioningTypes.Bg12.DimIDNo6Dot1 = setup_BG12_Data.chkDimIDNo6Dot1;
                autoDimensioningTypes.Bg12.DimIDNo7 = setup_BG12_Data.chkDimIDNo7;
                autoDimensioningTypes.Bg12.DimIDNo8 = setup_BG12_Data.chkDimIDNo8;
                autoDimensioningTypes.Bg12.DimIDNo9 = setup_BG12_Data.chkDimIDNo9;
                autoDimensioningTypes.Bg12.DimIDNo9Dot1 = setup_BG12_Data.chkDimIDNo9Dot1;
                autoDimensioningTypes.Bg12.DimIDNo20 = setup_BG12_Data.chkDimIDNo20;
                autoDimensioningTypes.Bg12.DimIDNo20Dot1 = setup_BG12_Data.chkDimIDNo20Dot1;
                RetCheck = true;

            }

            return RetCheck;

        }

        private bool SetParametersBG13()
        {
            bool RetCheck = false;
            string FilePath = Com.MyModel.GetInfo().ModelPath + @"\attributes\standard.Auto_Detailing_Tool_Beam.Setup_BG13.xml";
            if (File.Exists(FilePath))
            {

                Setup_BG13_Data setup_BG13_Data = Com.TeklaXMLToClass<Setup_BG13_Data>(FilePath);
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.StandardDimension = setup_BG13_Data.txtStDim;
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.RunningDimension = setup_BG13_Data.txtRdDim;
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.ElevationDimension = setup_BG13_Data.txtELDim;

                autoDimensioningTypes.Bg13.DimIDNo1 = setup_BG13_Data.chkDimIDNo1;
                autoDimensioningTypes.Bg13.DimIDNo10 = setup_BG13_Data.chkDimIDNo10;
                autoDimensioningTypes.Bg13.DimIDNo11 = setup_BG13_Data.chkDimIDNo11;
                autoDimensioningTypes.Bg13.DimIDNo12 = setup_BG13_Data.chkDimIDNo12;
                autoDimensioningTypes.Bg13.DimIDNo13 = setup_BG13_Data.chkDimIDNo13;
                autoDimensioningTypes.Bg13.DimIDNo14 = setup_BG13_Data.chkDimIDNo14;
                autoDimensioningTypes.Bg13.DimIDNo15 = setup_BG13_Data.chkDimIDNo15;
                autoDimensioningTypes.Bg13.DimIDNo16 = setup_BG13_Data.chkDimIDNo16;
                autoDimensioningTypes.Bg13.DimIDNo17 = setup_BG13_Data.chkDimIDNo17;
                autoDimensioningTypes.Bg13.DimIDNo17Dot1 = setup_BG13_Data.chkDimIDNo17Dot1;
                autoDimensioningTypes.Bg13.DimIDNo17Dot2 = setup_BG13_Data.chkDimIDNo17Dot2;
                autoDimensioningTypes.Bg13.DimIDNo17Dot3 = setup_BG13_Data.chkDimIDNo17Dot3;
                autoDimensioningTypes.Bg13.DimIDNo18 = setup_BG13_Data.chkDimIDNo18;
                autoDimensioningTypes.Bg13.DimIDNo18Dot1 = setup_BG13_Data.chkDimIDNo18Dot1;
                autoDimensioningTypes.Bg13.DimIDNo19 = setup_BG13_Data.chkDimIDNo19;
                autoDimensioningTypes.Bg13.DimIDNo19Dot1 = setup_BG13_Data.chkDimIDNo19Dot1;
                autoDimensioningTypes.Bg13.DimIDNo1Dot1 = setup_BG13_Data.chkDimIDNo1Dot1;
                autoDimensioningTypes.Bg13.DimIDNo1Dot2 = setup_BG13_Data.chkDimIDNo1Dot2;
                autoDimensioningTypes.Bg13.DimIDNo1Dot3 = setup_BG13_Data.chkDimIDNo1Dot3;
                autoDimensioningTypes.Bg13.DimIDNo1Dot4 = setup_BG13_Data.chkDimIDNo1Dot4;
                autoDimensioningTypes.Bg13.DimIDNo1Dot5 = setup_BG13_Data.chkDimIDNo1Dot5;
                autoDimensioningTypes.Bg13.DimIDNo1Dot6 = setup_BG13_Data.chkDimIDNo1Dot6;
                autoDimensioningTypes.Bg13.DimIDNo1Dot7 = setup_BG13_Data.chkDimIDNo1Dot7;
                autoDimensioningTypes.Bg13.DimIDNo2 = setup_BG13_Data.chkDimIDNo2;
                autoDimensioningTypes.Bg13.DimIDNo20 = setup_BG13_Data.chkDimIDNo20;
                autoDimensioningTypes.Bg13.DimIDNo21 = setup_BG13_Data.chkDimIDNo21;
                autoDimensioningTypes.Bg13.DimIDNo21Dot1 = setup_BG13_Data.chkDimIDNo21Dot1;
                autoDimensioningTypes.Bg13.DimIDNo22 = setup_BG13_Data.chkDimIDNo22;
                autoDimensioningTypes.Bg13.DimIDNo23 = setup_BG13_Data.chkDimIDNo23;
                autoDimensioningTypes.Bg13.DimIDNo23Dot1 = setup_BG13_Data.chkDimIDNo23Dot1;
                autoDimensioningTypes.Bg13.DimIDNo24 = setup_BG13_Data.chkDimIDNo24;
                autoDimensioningTypes.Bg13.DimIDNo24Dot1 = setup_BG13_Data.chkDimIDNo24Dot1;
                autoDimensioningTypes.Bg13.DimIDNo25 = setup_BG13_Data.chkDimIDNo25;
                autoDimensioningTypes.Bg13.DimIDNo25Dot1 = setup_BG13_Data.chkDimIDNo25Dot1;
                //autoDimensioningTypes.Bg13.DimIDNo26 = setup_BG13_Data.chkDimIDNo26;
                autoDimensioningTypes.Bg13.DimIDNo27 = setup_BG13_Data.chkDimIDNo27;
                autoDimensioningTypes.Bg13.DimIDNo27Dot1 = setup_BG13_Data.chkDimIDNo27Dot1;
                autoDimensioningTypes.Bg13.DimIDNo28 = setup_BG13_Data.chkDimIDNo28;
                autoDimensioningTypes.Bg13.DimIDNo28Dot1 = setup_BG13_Data.chkDimIDNo28Dot1;
                autoDimensioningTypes.Bg13.DimIDNo3 = setup_BG13_Data.chkDimIDNo3;
                autoDimensioningTypes.Bg13.DimIDNo3Dot1 = setup_BG13_Data.chkDimIDNo3Dot1;
                autoDimensioningTypes.Bg13.DimIDNo3Dot2 = setup_BG13_Data.chkDimIDNo3Dot2;
                autoDimensioningTypes.Bg13.DimIDNo4 = setup_BG13_Data.chkDimIDNo4;
                autoDimensioningTypes.Bg13.DimIDNo4Dot1 = setup_BG13_Data.chkDimIDNo4Dot1;
                autoDimensioningTypes.Bg13.DimIDNo5 = setup_BG13_Data.chkDimIDNo5;
                autoDimensioningTypes.Bg13.DimIDNo6 = setup_BG13_Data.chkDimIDNo6;
                autoDimensioningTypes.Bg13.DimIDNo7 = setup_BG13_Data.chkDimIDNo7;
                autoDimensioningTypes.Bg13.DimIDNo7Dot1 = setup_BG13_Data.chkDimIDNo7Dot1;
                autoDimensioningTypes.Bg13.DimIDNo8 = setup_BG13_Data.chkDimIDNo8;
                autoDimensioningTypes.Bg13.DimIDNo9 = setup_BG13_Data.chkDimIDNo9;
                autoDimensioningTypes.Bg13.DimIDNo9Dot1 = setup_BG13_Data.chkDimIDNo9Dot1;
                autoDimensioningTypes.Bg13.DimIDNo9Dot2 = setup_BG13_Data.chkDimIDNo9Dot2;
                autoDimensioningTypes.Bg13.DimIDNo9Dot3 = setup_BG13_Data.chkDimIDNo9Dot3;
                autoDimensioningTypes.Bg13.DimIDNo29 = setup_BG13_Data.chkDimIDNo29;
                autoDimensioningTypes.Bg13.DimIDNo29Dot1 = setup_BG13_Data.chkDimIDNo29Dot1;

                RetCheck = true;

            }

            return RetCheck;

        }

        private bool SetParametersBG17()
        {
            bool RetCheck = false;
            string FilePath = Com.MyModel.GetInfo().ModelPath + @"\attributes\standard.Auto_Detailing_Tool_Beam.Setup_BG17.xml";
            if (File.Exists(FilePath))
            {

                Setup_BG17_Data setup_BG17_Data = Com.TeklaXMLToClass<Setup_BG17_Data>(FilePath);
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.StandardDimension = setup_BG17_Data.txtStDim;
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.RunningDimension = setup_BG17_Data.txtRdDim;
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.ElevationDimension = setup_BG17_Data.txtELDim;

                autoDimensioningTypes.Bg17.DimIDNo1 = setup_BG17_Data.chkDimIDNo1;
                autoDimensioningTypes.Bg17.DimIDNo10 = setup_BG17_Data.chkDimIDNo10;
                autoDimensioningTypes.Bg17.DimIDNo11 = setup_BG17_Data.chkDimIDNo11;
                autoDimensioningTypes.Bg17.DimIDNo12 = setup_BG17_Data.chkDimIDNo12;
                autoDimensioningTypes.Bg17.DimIDNo13 = setup_BG17_Data.chkDimIDNo13;
                autoDimensioningTypes.Bg17.DimIDNo13Dot1 = setup_BG17_Data.chkDimIDNo13Dot1;
                autoDimensioningTypes.Bg17.DimIDNo14 = setup_BG17_Data.chkDimIDNo14;
                autoDimensioningTypes.Bg17.DimIDNo14Dot1 = setup_BG17_Data.chkDimIDNo14Dot1;
                autoDimensioningTypes.Bg17.DimIDNo15 = setup_BG17_Data.chkDimIDNo15;
                autoDimensioningTypes.Bg17.DimIDNo15Dot1 = setup_BG17_Data.chkDimIDNo15Dot1;
                autoDimensioningTypes.Bg17.DimIDNo15Dot2 = setup_BG17_Data.chkDimIDNo15Dot2;
                autoDimensioningTypes.Bg17.DimIDNo15Dot3 = setup_BG17_Data.chkDimIDNo15Dot3;
                autoDimensioningTypes.Bg17.DimIDNo15Dot4 = setup_BG17_Data.chkDimIDNo15Dot4;
                autoDimensioningTypes.Bg17.DimIDNo16 = setup_BG17_Data.chkDimIDNo16;
                autoDimensioningTypes.Bg17.DimIDNo17 = setup_BG17_Data.chkDimIDNo17;
                autoDimensioningTypes.Bg17.DimIDNo1Dot1 = setup_BG17_Data.chkDimIDNo1Dot1;
                autoDimensioningTypes.Bg17.DimIDNo1Dot2 = setup_BG17_Data.chkDimIDNo1Dot2;
                autoDimensioningTypes.Bg17.DimIDNo1Dot3 = setup_BG17_Data.chkDimIDNo1Dot3;
                autoDimensioningTypes.Bg17.DimIDNo1Dot4 = setup_BG17_Data.chkDimIDNo1Dot4;
                autoDimensioningTypes.Bg17.DimIDNo1Dot5 = setup_BG17_Data.chkDimIDNo1Dot5;
                autoDimensioningTypes.Bg17.DimIDNo2 = setup_BG17_Data.chkDimIDNo2;
                autoDimensioningTypes.Bg17.DimIDNo2Dot1 = setup_BG17_Data.chkDimIDNo2Dot1;
                autoDimensioningTypes.Bg17.DimIDNo2Dot2 = setup_BG17_Data.chkDimIDNo2Dot2;
                autoDimensioningTypes.Bg17.DimIDNo3 = setup_BG17_Data.chkDimIDNo3;
                autoDimensioningTypes.Bg17.DimIDNo4 = setup_BG17_Data.chkDimIDNo4;
                autoDimensioningTypes.Bg17.DimIDNo5 = setup_BG17_Data.chkDimIDNo5;
                autoDimensioningTypes.Bg17.DimIDNo6 = setup_BG17_Data.chkDimIDNo6;
                autoDimensioningTypes.Bg17.DimIDNo6Dot1 = setup_BG17_Data.chkDimIDNo6Dot1;
                autoDimensioningTypes.Bg17.DimIDNo6Dot2 = setup_BG17_Data.chkDimIDNo6Dot2;
                autoDimensioningTypes.Bg17.DimIDNo6Dot3 = setup_BG17_Data.chkDimIDNo6Dot3;
                autoDimensioningTypes.Bg17.DimIDNo7 = setup_BG17_Data.chkDimIDNo7;
                autoDimensioningTypes.Bg17.DimIDNo8 = setup_BG17_Data.chkDimIDNo8;
                autoDimensioningTypes.Bg17.DimIDNo9 = setup_BG17_Data.chkDimIDNo9;
                autoDimensioningTypes.Bg17.DimIDNo9Dot1 = setup_BG17_Data.chkDimIDNo9Dot1;

                RetCheck = true;

            }

            return RetCheck;

        }

        private bool SetParametersBG18()
        {
            bool RetCheck = false;
            string FilePath = Com.MyModel.GetInfo().ModelPath + @"\attributes\standard.Auto_Detailing_Tool_Beam.Setup_BG18.xml";
            if (File.Exists(FilePath))
            {

                Setup_BG18_Data setup_BG18_Data = Com.TeklaXMLToClass<Setup_BG18_Data>(FilePath);
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.StandardDimension = setup_BG18_Data.txtStDim;
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.RunningDimension = setup_BG18_Data.txtRdDim;
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.ElevationDimension = setup_BG18_Data.txtELDim;

                autoDimensioningTypes.Bg18.DimIDNo1 = setup_BG18_Data.chkDimIDNo1;
                autoDimensioningTypes.Bg18.DimIDNo10 = setup_BG18_Data.chkDimIDNo10;
                autoDimensioningTypes.Bg18.DimIDNo10Dot1 = setup_BG18_Data.chkDimIDNo10Dot1;
                autoDimensioningTypes.Bg18.DimIDNo10Dot2 = setup_BG18_Data.chkDimIDNo10Dot2;
                autoDimensioningTypes.Bg18.DimIDNo11 = setup_BG18_Data.chkDimIDNo11;
                autoDimensioningTypes.Bg18.DimIDNo12 = setup_BG18_Data.chkDimIDNo12;
                autoDimensioningTypes.Bg18.DimIDNo13 = setup_BG18_Data.chkDimIDNo13;
                autoDimensioningTypes.Bg18.DimIDNo14 = setup_BG18_Data.chkDimIDNo14;
                autoDimensioningTypes.Bg18.DimIDNo15 = setup_BG18_Data.chkDimIDNo15;
                autoDimensioningTypes.Bg18.DimIDNo16 = setup_BG18_Data.chkDimIDNo16;
                autoDimensioningTypes.Bg18.DimIDNo16Dot1 = setup_BG18_Data.chkDimIDNo16Dot1;
                autoDimensioningTypes.Bg18.DimIDNo17 = setup_BG18_Data.chkDimIDNo17;
                autoDimensioningTypes.Bg18.DimIDNo17Dot1 = setup_BG18_Data.chkDimIDNo17Dot1;
                autoDimensioningTypes.Bg18.DimIDNo18 = setup_BG18_Data.chkDimIDNo18;
                autoDimensioningTypes.Bg18.DimIDNo18Dot1 = setup_BG18_Data.chkDimIDNo18Dot1;
                autoDimensioningTypes.Bg18.DimIDNo18Dot2 = setup_BG18_Data.chkDimIDNo18Dot2;
                autoDimensioningTypes.Bg18.DimIDNo18Dot3 = setup_BG18_Data.chkDimIDNo18Dot3;
                autoDimensioningTypes.Bg18.DimIDNo18Dot4 = setup_BG18_Data.chkDimIDNo18Dot4;
                autoDimensioningTypes.Bg18.DimIDNo1Dot1 = setup_BG18_Data.chkDimIDNo1Dot1;
                autoDimensioningTypes.Bg18.DimIDNo1Dot2 = setup_BG18_Data.chkDimIDNo1Dot2;
                autoDimensioningTypes.Bg18.DimIDNo1Dot3 = setup_BG18_Data.chkDimIDNo1Dot3;
                autoDimensioningTypes.Bg18.DimIDNo1Dot4 = setup_BG18_Data.chkDimIDNo1Dot4;
                autoDimensioningTypes.Bg18.DimIDNo1Dot5 = setup_BG18_Data.chkDimIDNo1Dot5;
                autoDimensioningTypes.Bg18.DimIDNo1Dot6 = setup_BG18_Data.chkDimIDNo1Dot6;
                autoDimensioningTypes.Bg18.DimIDNo1Dot7 = setup_BG18_Data.chkDimIDNo1Dot7;
                autoDimensioningTypes.Bg18.DimIDNo1Dot8 = setup_BG18_Data.chkDimIDNo1Dot8;
                autoDimensioningTypes.Bg18.DimIDNo2 = setup_BG18_Data.chkDimIDNo2;
                autoDimensioningTypes.Bg18.DimIDNo2Dot1 = setup_BG18_Data.chkDimIDNo2Dot1;
                autoDimensioningTypes.Bg18.DimIDNo2Dot2 = setup_BG18_Data.chkDimIDNo2Dot2;
                autoDimensioningTypes.Bg18.DimIDNo2Dot3 = setup_BG18_Data.chkDimIDNo2Dot3;
                autoDimensioningTypes.Bg18.DimIDNo2Dot4 = setup_BG18_Data.chkDimIDNo2Dot4;
                autoDimensioningTypes.Bg18.DimIDNo2Dot5 = setup_BG18_Data.chkDimIDNo2Dot5;
                autoDimensioningTypes.Bg18.DimIDNo3 = setup_BG18_Data.chkDimIDNo3;
                autoDimensioningTypes.Bg18.DimIDNo4 = setup_BG18_Data.chkDimIDNo4;
                autoDimensioningTypes.Bg18.DimIDNo5 = setup_BG18_Data.chkDimIDNo5;
                autoDimensioningTypes.Bg18.DimIDNo6 = setup_BG18_Data.chkDimIDNo6;
                autoDimensioningTypes.Bg18.DimIDNo6Dot1 = setup_BG18_Data.chkDimIDNo6Dot1;
                autoDimensioningTypes.Bg18.DimIDNo7 = setup_BG18_Data.chkDimIDNo7;
                autoDimensioningTypes.Bg18.DimIDNo8 = setup_BG18_Data.chkDimIDNo8;
                autoDimensioningTypes.Bg18.DimIDNo9 = setup_BG18_Data.chkDimIDNo9;
                autoDimensioningTypes.Bg18.DimIDNo9Dot1 = setup_BG18_Data.chkDimIDNo9Dot1;
                autoDimensioningTypes.Bg18.DimIDNo9Dot2 = setup_BG18_Data.chkDimIDNo9Dot2;
                autoDimensioningTypes.Bg18.DimIDNo9Dot3 = setup_BG18_Data.chkDimIDNo9Dot3;
                autoDimensioningTypes.Bg18.DimIDNo9Dot4 = setup_BG18_Data.chkDimIDNo9Dot4;
                autoDimensioningTypes.Bg18.DimIDNo9Dot5 = setup_BG18_Data.chkDimIDNo9Dot5;

                RetCheck = true;

            }

            return RetCheck;

        }

        private bool SetParametersBG19()
        {
            bool RetCheck = false;
            string FilePath = Com.MyModel.GetInfo().ModelPath + @"\attributes\standard.Auto_Detailing_Tool_Beam.Setup_BG19.xml";
            if (File.Exists(FilePath))
            {

                Setup_BG19_Data setup_BG19_Data = Com.TeklaXMLToClass<Setup_BG19_Data>(FilePath);
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.StandardDimension = setup_BG19_Data.txtStDim;
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.RunningDimension = setup_BG19_Data.txtRdDim;
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.ElevationDimension = setup_BG19_Data.txtELDim;

                autoDimensioningTypes.Bg19.DimIDNo1 = setup_BG19_Data.chkDimIDNo1;
                autoDimensioningTypes.Bg19.DimIDNo10 = setup_BG19_Data.chkDimIDNo10;
                autoDimensioningTypes.Bg19.DimIDNo11 = setup_BG19_Data.chkDimIDNo11;
                autoDimensioningTypes.Bg19.DimIDNo12 = setup_BG19_Data.chkDimIDNo12;
                autoDimensioningTypes.Bg19.DimIDNo13 = setup_BG19_Data.chkDimIDNo13;
                autoDimensioningTypes.Bg19.DimIDNo13Dot1 = setup_BG19_Data.chkDimIDNo13Dot1;
                autoDimensioningTypes.Bg19.DimIDNo13Dot2 = setup_BG19_Data.chkDimIDNo13Dot2;
                autoDimensioningTypes.Bg19.DimIDNo13Dot3 = setup_BG19_Data.chkDimIDNo13Dot3;
                autoDimensioningTypes.Bg19.DimIDNo13Dot4 = setup_BG19_Data.chkDimIDNo13Dot4;
                autoDimensioningTypes.Bg19.DimIDNo13Dot5 = setup_BG19_Data.chkDimIDNo13Dot5;
                autoDimensioningTypes.Bg19.DimIDNo13Dot6 = setup_BG19_Data.chkDimIDNo13Dot6;
                autoDimensioningTypes.Bg19.DimIDNo13Dot7 = setup_BG19_Data.chkDimIDNo13Dot7;
                autoDimensioningTypes.Bg19.DimIDNo13Dot8 = setup_BG19_Data.chkDimIDNo13Dot8;
                autoDimensioningTypes.Bg19.DimIDNo13Dot9 = setup_BG19_Data.chkDimIDNo13Dot9;
                autoDimensioningTypes.Bg19.DimIDNo14 = setup_BG19_Data.chkDimIDNo14;
                autoDimensioningTypes.Bg19.DimIDNo15 = setup_BG19_Data.chkDimIDNo15;
                autoDimensioningTypes.Bg19.DimIDNo15Dot1 = setup_BG19_Data.chkDimIDNo15Dot1;
                autoDimensioningTypes.Bg19.DimIDNo15Dot2 = setup_BG19_Data.chkDimIDNo15Dot2;
                autoDimensioningTypes.Bg19.DimIDNo15Dot3 = setup_BG19_Data.chkDimIDNo15Dot3;
                autoDimensioningTypes.Bg19.DimIDNo16 = setup_BG19_Data.chkDimIDNo16;
                autoDimensioningTypes.Bg19.DimIDNo16Dot1 = setup_BG19_Data.chkDimIDNo16Dot1;
                autoDimensioningTypes.Bg19.DimIDNo16Dot2 = setup_BG19_Data.chkDimIDNo16Dot2;
                autoDimensioningTypes.Bg19.DimIDNo16Dot3 = setup_BG19_Data.chkDimIDNo16Dot3;
                autoDimensioningTypes.Bg19.DimIDNo17 = setup_BG19_Data.chkDimIDNo17;
                autoDimensioningTypes.Bg19.DimIDNo18 = setup_BG19_Data.chkDimIDNo18;
                autoDimensioningTypes.Bg19.DimIDNo18Dot1 = setup_BG19_Data.chkDimIDNo18Dot1;
                autoDimensioningTypes.Bg19.DimIDNo19 = setup_BG19_Data.chkDimIDNo19;
                autoDimensioningTypes.Bg19.DimIDNo19Dot1 = setup_BG19_Data.chkDimIDNo19Dot1;
                autoDimensioningTypes.Bg19.DimIDNo19Dot2 = setup_BG19_Data.chkDimIDNo19Dot2;
                autoDimensioningTypes.Bg19.DimIDNo2 = setup_BG19_Data.chkDimIDNo2;
                autoDimensioningTypes.Bg19.DimIDNo20 = setup_BG19_Data.chkDimIDNo20;
                autoDimensioningTypes.Bg19.DimIDNo21 = setup_BG19_Data.chkDimIDNo21;
                autoDimensioningTypes.Bg19.DimIDNo21Dot1 = setup_BG19_Data.chkDimIDNo21Dot1;
                autoDimensioningTypes.Bg19.DimIDNo21Dot2 = setup_BG19_Data.chkDimIDNo21Dot2;
                autoDimensioningTypes.Bg19.DimIDNo21Dot3 = setup_BG19_Data.chkDimIDNo21Dot3;
                autoDimensioningTypes.Bg19.DimIDNo22 = setup_BG19_Data.chkDimIDNo22;
                autoDimensioningTypes.Bg19.DimIDNo22Dot1 = setup_BG19_Data.chkDimIDNo22Dot1;
                autoDimensioningTypes.Bg19.DimIDNo23 = setup_BG19_Data.chkDimIDNo23;
                autoDimensioningTypes.Bg19.DimIDNo23Dot1 = setup_BG19_Data.chkDimIDNo23Dot1;
                autoDimensioningTypes.Bg19.DimIDNo24 = setup_BG19_Data.chkDimIDNo24;
                autoDimensioningTypes.Bg19.DimIDNo24Dot1 = setup_BG19_Data.chkDimIDNo24Dot1;
                autoDimensioningTypes.Bg19.DimIDNo25 = setup_BG19_Data.chkDimIDNo25;
                autoDimensioningTypes.Bg19.DimIDNo25Dot1 = setup_BG19_Data.chkDimIDNo25Dot1;
                autoDimensioningTypes.Bg19.DimIDNo26 = setup_BG19_Data.chkDimIDNo26;
                autoDimensioningTypes.Bg19.DimIDNo27 = setup_BG19_Data.chkDimIDNo27;
                autoDimensioningTypes.Bg19.DimIDNo28 = setup_BG19_Data.chkDimIDNo28;
                autoDimensioningTypes.Bg19.DimIDNo28Dot1 = setup_BG19_Data.chkDimIDNo28Dot1;
                autoDimensioningTypes.Bg19.DimIDNo29 = setup_BG19_Data.chkDimIDNo29;
                autoDimensioningTypes.Bg19.DimIDNo29Dot1 = setup_BG19_Data.chkDimIDNo29Dot1;
                autoDimensioningTypes.Bg19.DimIDNo2Dot1 = setup_BG19_Data.chkDimIDNo2Dot1;
                autoDimensioningTypes.Bg19.DimIDNo3 = setup_BG19_Data.chkDimIDNo3;
                autoDimensioningTypes.Bg19.DimIDNo30 = setup_BG19_Data.chkDimIDNo30;
                autoDimensioningTypes.Bg19.DimIDNo30Dot1 = setup_BG19_Data.chkDimIDNo30Dot1;
               // autoDimensioningTypes.Bg19.DimIDNo30Dot2 = setup_BG19_Data.chkDimIDNo30Dot2;
                autoDimensioningTypes.Bg19.DimIDNo3Dot1 = setup_BG19_Data.chkDimIDNo3Dot1;
                autoDimensioningTypes.Bg19.DimIDNo4 = setup_BG19_Data.chkDimIDNo4;
                autoDimensioningTypes.Bg19.DimIDNo5 = setup_BG19_Data.chkDimIDNo5;
                autoDimensioningTypes.Bg19.DimIDNo5Dot1 = setup_BG19_Data.chkDimIDNo5Dot1;
                autoDimensioningTypes.Bg19.DimIDNo6 = setup_BG19_Data.chkDimIDNo6;
                autoDimensioningTypes.Bg19.DimIDNo6Dot1 = setup_BG19_Data.chkDimIDNo6Dot1;
                autoDimensioningTypes.Bg19.DimIDNo7 = setup_BG19_Data.chkDimIDNo7;
                autoDimensioningTypes.Bg19.DimIDNo8 = setup_BG19_Data.chkDimIDNo8;
                autoDimensioningTypes.Bg19.DimIDNo9 = setup_BG19_Data.chkDimIDNo9;
                autoDimensioningTypes.Bg19.DimIDNo31 = setup_BG19_Data.chkDimIDNo31;

                RetCheck = true;

            }

            return RetCheck;

        }

        private bool SetParametersBG21()
        {
            bool RetCheck = false;
            string FilePath = Com.MyModel.GetInfo().ModelPath + @"\attributes\standard.Auto_Detailing_Tool_Beam.Setup_BG21.xml";
            if (File.Exists(FilePath))
            {

                Setup_BG21_Data setup_BG21_Data = Com.TeklaXMLToClass<Setup_BG21_Data>(FilePath);
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.StandardDimension = setup_BG21_Data.txtStDim;
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.RunningDimension = setup_BG21_Data.txtRdDim;
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.ElevationDimension = setup_BG21_Data.txtELDim;

                autoDimensioningTypes.BG21.DimIDNo1 = setup_BG21_Data.chkDimIDNo1;
                autoDimensioningTypes.BG21.DimIDNo10 = setup_BG21_Data.chkDimIDNo10;
                autoDimensioningTypes.BG21.DimIDNo10Dot1 = setup_BG21_Data.chkDimIDNo10Dot1;
                autoDimensioningTypes.BG21.DimIDNo11 = setup_BG21_Data.chkDimIDNo11;
                autoDimensioningTypes.BG21.DimIDNo12 = setup_BG21_Data.chkDimIDNo12;
                autoDimensioningTypes.BG21.DimIDNo12Dot1 = setup_BG21_Data.chkDimIDNo12Dot1;
                autoDimensioningTypes.BG21.DimIDNo13 = setup_BG21_Data.chkDimIDNo13;
                autoDimensioningTypes.BG21.DimIDNo14 = setup_BG21_Data.chkDimIDNo14;
                autoDimensioningTypes.BG21.DimIDNo15 = setup_BG21_Data.chkDimIDNo15;
                autoDimensioningTypes.BG21.DimIDNo15Dot1 = setup_BG21_Data.chkDimIDNo15Dot1;
                autoDimensioningTypes.BG21.DimIDNo16 = setup_BG21_Data.chkDimIDNo16;
                autoDimensioningTypes.BG21.DimIDNo17 = setup_BG21_Data.chkDimIDNo17;
                autoDimensioningTypes.BG21.DimIDNo17Dot1 = setup_BG21_Data.chkDimIDNo17Dot1;
                autoDimensioningTypes.BG21.DimIDNo18 = setup_BG21_Data.chkDimIDNo18;
                autoDimensioningTypes.BG21.DimIDNo19 = setup_BG21_Data.chkDimIDNo19;
                autoDimensioningTypes.BG21.DimIDNo19Dot1 = setup_BG21_Data.chkDimIDNo19Dot1;
                autoDimensioningTypes.BG21.DimIDNo1Dot1 = setup_BG21_Data.chkDimIDNo1Dot1;
                autoDimensioningTypes.BG21.DimIDNo1Dot2 = setup_BG21_Data.chkDimIDNo1Dot2;
                autoDimensioningTypes.BG21.DimIDNo1Dot3 = setup_BG21_Data.chkDimIDNo1Dot3;
                autoDimensioningTypes.BG21.DimIDNo1Dot4 = setup_BG21_Data.chkDimIDNo1Dot4;
                autoDimensioningTypes.BG21.DimIDNo1Dot5 = setup_BG21_Data.chkDimIDNo1Dot5;
                autoDimensioningTypes.BG21.DimIDNo1Dot6 = setup_BG21_Data.chkDimIDNo1Dot6;
                autoDimensioningTypes.BG21.DimIDNo1Dot7 = setup_BG21_Data.chkDimIDNo1Dot7;
                autoDimensioningTypes.BG21.DimIDNo1Dot8 = setup_BG21_Data.chkDimIDNo1Dot8;
                autoDimensioningTypes.BG21.DimIDNo1Dot9 = setup_BG21_Data.chkDimIDNo1Dot9;
                autoDimensioningTypes.BG21.DimIDNo2 = setup_BG21_Data.chkDimIDNo2;
                autoDimensioningTypes.BG21.DimIDNo20 = setup_BG21_Data.chkDimIDNo20;
                autoDimensioningTypes.BG21.DimIDNo21 = setup_BG21_Data.chkDimIDNo21;
                autoDimensioningTypes.BG21.DimIDNo22 = setup_BG21_Data.chkDimIDNo22;
                autoDimensioningTypes.BG21.DimIDNo23 = setup_BG21_Data.chkDimIDNo23;
                autoDimensioningTypes.BG21.DimIDNo24 = setup_BG21_Data.chkDimIDNo24;
                autoDimensioningTypes.BG21.DimIDNo24Dot1 = setup_BG21_Data.chkDimIDNo24Dot1;
                autoDimensioningTypes.BG21.DimIDNo25 = setup_BG21_Data.chkDimIDNo25;
                autoDimensioningTypes.BG21.DimIDNo25Dot1 = setup_BG21_Data.chkDimIDNo25Dot1;
                autoDimensioningTypes.BG21.DimIDNo25Dot2 = setup_BG21_Data.chkDimIDNo25Dot2;
                autoDimensioningTypes.BG21.DimIDNo26 = setup_BG21_Data.chkDimIDNo26;
                autoDimensioningTypes.BG21.DimIDNo27 = setup_BG21_Data.chkDimIDNo27;
                autoDimensioningTypes.BG21.DimIDNo28 = setup_BG21_Data.chkDimIDNo28;
                autoDimensioningTypes.BG21.DimIDNo29 = setup_BG21_Data.chkDimIDNo29;
                autoDimensioningTypes.BG21.DimIDNo2Dot1 = setup_BG21_Data.chkDimIDNo2Dot1;
                autoDimensioningTypes.BG21.DimIDNo2Dot2 = setup_BG21_Data.chkDimIDNo2Dot2;
                autoDimensioningTypes.BG21.DimIDNo2Dot3 = setup_BG21_Data.chkDimIDNo2Dot3;
                autoDimensioningTypes.BG21.DimIDNo2Dot4 = setup_BG21_Data.chkDimIDNo2Dot4;
                autoDimensioningTypes.BG21.DimIDNo3 = setup_BG21_Data.chkDimIDNo3;
                autoDimensioningTypes.BG21.DimIDNo3Dot1 = setup_BG21_Data.chkDimIDNo3Dot1;
                autoDimensioningTypes.BG21.DimIDNo4 = setup_BG21_Data.chkDimIDNo4;
                autoDimensioningTypes.BG21.DimIDNo5 = setup_BG21_Data.chkDimIDNo5;
                autoDimensioningTypes.BG21.DimIDNo6 = setup_BG21_Data.chkDimIDNo6;
                autoDimensioningTypes.BG21.DimIDNo7 = setup_BG21_Data.chkDimIDNo7;
                autoDimensioningTypes.BG21.DimIDNo8 = setup_BG21_Data.chkDimIDNo8;
                autoDimensioningTypes.BG21.DimIDNo9 = setup_BG21_Data.chkDimIDNo9;
                autoDimensioningTypes.BG21.DimIDNo9Dot1 = setup_BG21_Data.chkDimIDNo9Dot1;

                RetCheck = true;

            }

            return RetCheck;

        }

        private bool SetParametersBG22()
        {
            bool RetCheck = false;
            string FilePath = Com.MyModel.GetInfo().ModelPath + @"\attributes\standard.Auto_Detailing_Tool_Beam.Setup_BG22.xml";
            if (File.Exists(FilePath))
            {

                Setup_BG22_Data setup_BG22_Data = Com.TeklaXMLToClass<Setup_BG22_Data>(FilePath);
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.StandardDimension = setup_BG22_Data.txtStDim;
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.RunningDimension = setup_BG22_Data.txtRdDim;
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.ElevationDimension = setup_BG22_Data.txtELDim;

                autoDimensioningTypes.BG22.DimIDNo1 = setup_BG22_Data.chkDimIDNo1;
                autoDimensioningTypes.BG22.DimIDNo10 = setup_BG22_Data.chkDimIDNo10;
                autoDimensioningTypes.BG22.DimIDNo10Dot1 = setup_BG22_Data.chkDimIDNo10Dot1;
                autoDimensioningTypes.BG22.DimIDNo11 = setup_BG22_Data.chkDimIDNo11;
                autoDimensioningTypes.BG22.DimIDNo11Dot1 = setup_BG22_Data.chkDimIDNo11Dot1;
                autoDimensioningTypes.BG22.DimIDNo11Dot2 = setup_BG22_Data.chkDimIDNo11Dot2;
                autoDimensioningTypes.BG22.DimIDNo11Dot3 = setup_BG22_Data.chkDimIDNo11Dot3;
                autoDimensioningTypes.BG22.DimIDNo12 = setup_BG22_Data.chkDimIDNo12;
                autoDimensioningTypes.BG22.DimIDNo12Dot1 = setup_BG22_Data.chkDimIDNo12Dot1;
                autoDimensioningTypes.BG22.DimIDNo13 = setup_BG22_Data.chkDimIDNo13;
                autoDimensioningTypes.BG22.DimIDNo14 = setup_BG22_Data.chkDimIDNo14;
                autoDimensioningTypes.BG22.DimIDNo15 = setup_BG22_Data.chkDimIDNo15;
                autoDimensioningTypes.BG22.DimIDNo16 = setup_BG22_Data.chkDimIDNo16;
                autoDimensioningTypes.BG22.DimIDNo17 = setup_BG22_Data.chkDimIDNo17;
                autoDimensioningTypes.BG22.DimIDNo17Dot1 = setup_BG22_Data.chkDimIDNo17Dot1;
                autoDimensioningTypes.BG22.DimIDNo18 = setup_BG22_Data.chkDimIDNo18;
                autoDimensioningTypes.BG22.DimIDNo19 = setup_BG22_Data.chkDimIDNo19;
                autoDimensioningTypes.BG22.DimIDNo1Dot1 = setup_BG22_Data.chkDimIDNo1Dot1;
                autoDimensioningTypes.BG22.DimIDNo1Dot2 = setup_BG22_Data.chkDimIDNo1Dot2;
                autoDimensioningTypes.BG22.DimIDNo1Dot3 = setup_BG22_Data.chkDimIDNo1Dot3;
                autoDimensioningTypes.BG22.DimIDNo1Dot4 = setup_BG22_Data.chkDimIDNo1Dot4;
                autoDimensioningTypes.BG22.DimIDNo1Dot5 = setup_BG22_Data.chkDimIDNo1Dot5;
                autoDimensioningTypes.BG22.DimIDNo1Dot6 = setup_BG22_Data.chkDimIDNo1Dot6;
                autoDimensioningTypes.BG22.DimIDNo2 = setup_BG22_Data.chkDimIDNo2;
                autoDimensioningTypes.BG22.DimIDNo20 = setup_BG22_Data.chkDimIDNo20;
                autoDimensioningTypes.BG22.DimIDNo21 = setup_BG22_Data.chkDimIDNo21;
                autoDimensioningTypes.BG22.DimIDNo21Dot1 = setup_BG22_Data.chkDimIDNo21Dot1;
                autoDimensioningTypes.BG22.DimIDNo22 = setup_BG22_Data.chkDimIDNo22;
                autoDimensioningTypes.BG22.DimIDNo22Dot1 = setup_BG22_Data.chkDimIDNo22Dot1;
                autoDimensioningTypes.BG22.DimIDNo23 = setup_BG22_Data.chkDimIDNo23;
                autoDimensioningTypes.BG22.DimIDNo23Dot1 = setup_BG22_Data.chkDimIDNo23Dot1;
                autoDimensioningTypes.BG22.DimIDNo24 = setup_BG22_Data.chkDimIDNo24;
                autoDimensioningTypes.BG22.DimIDNo28 = setup_BG22_Data.chkDimIDNo28;
                autoDimensioningTypes.BG22.DimIDNo28Dot1 = setup_BG22_Data.chkDimIDNo28Dot1;
                autoDimensioningTypes.BG22.DimIDNo29 = setup_BG22_Data.chkDimIDNo29;
                autoDimensioningTypes.BG22.DimIDNo2Dot1 = setup_BG22_Data.chkDimIDNo2Dot1;
                autoDimensioningTypes.BG22.DimIDNo2Dot2 = setup_BG22_Data.chkDimIDNo2Dot2;
                autoDimensioningTypes.BG22.DimIDNo2Dot3 = setup_BG22_Data.chkDimIDNo2Dot3;
                autoDimensioningTypes.BG22.DimIDNo2Dot4 = setup_BG22_Data.chkDimIDNo2Dot4;
                autoDimensioningTypes.BG22.DimIDNo3 = setup_BG22_Data.chkDimIDNo3;
                autoDimensioningTypes.BG22.DimIDNo31 = setup_BG22_Data.chkDimIDNo31;
                autoDimensioningTypes.BG22.DimIDNo32 = setup_BG22_Data.chkDimIDNo32;
                autoDimensioningTypes.BG22.DimIDNo3Dot1 = setup_BG22_Data.chkDimIDNo3Dot1;
                autoDimensioningTypes.BG22.DimIDNo3Dot2 = setup_BG22_Data.chkDimIDNo3Dot2;
                autoDimensioningTypes.BG22.DimIDNo3Dot3 = setup_BG22_Data.chkDimIDNo3Dot3;
                autoDimensioningTypes.BG22.DimIDNo4 = setup_BG22_Data.chkDimIDNo4;
                autoDimensioningTypes.BG22.DimIDNo5 = setup_BG22_Data.chkDimIDNo5;
                autoDimensioningTypes.BG22.DimIDNo6 = setup_BG22_Data.chkDimIDNo6;
                autoDimensioningTypes.BG22.DimIDNo7 = setup_BG22_Data.chkDimIDNo7;
                autoDimensioningTypes.BG22.DimIDNo8 = setup_BG22_Data.chkDimIDNo8;
                autoDimensioningTypes.BG22.DimIDNo9 = setup_BG22_Data.chkDimIDNo9;


                RetCheck = true;

            }

            return RetCheck;

        }

        private bool SetParametersBBP1()
        {
            bool RetCheck = false;
            string FilePath = Com.MyModel.GetInfo().ModelPath + @"\attributes\standard.Auto_Detailing_Tool_Beam.Setup_BBP1.xml";
            if (File.Exists(FilePath))
            {

                Setup_BBP1_Data setup_BBP1_Data = Com.TeklaXMLToClass<Setup_BBP1_Data>(FilePath);
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.StandardDimension = setup_BBP1_Data.txtStDim;
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.RunningDimension = setup_BBP1_Data.txtRdDim;
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.ElevationDimension = setup_BBP1_Data.txtELDim;

                autoDimensioningTypes.Bbp1.DimIDNo1 = setup_BBP1_Data.chkDimIDNo1;
                autoDimensioningTypes.Bbp1.DimIDNo10 = setup_BBP1_Data.chkDimIDNo10;
                autoDimensioningTypes.Bbp1.DimIDNo10Dot1 = setup_BBP1_Data.chkDimIDNo10Dot1;
                autoDimensioningTypes.Bbp1.DimIDNo10Dot2 = setup_BBP1_Data.chkDimIDNo10Dot2;
                autoDimensioningTypes.Bbp1.DimIDNo10Dot3 = setup_BBP1_Data.chkDimIDNo10Dot3;
                autoDimensioningTypes.Bbp1.DimIDNo11 = setup_BBP1_Data.chkDimIDNo11;
                autoDimensioningTypes.Bbp1.DimIDNo11Dot1 = setup_BBP1_Data.chkDimIDNo11Dot1;
                autoDimensioningTypes.Bbp1.DimIDNo12 = setup_BBP1_Data.chkDimIDNo12;
                autoDimensioningTypes.Bbp1.DimIDNo12Dot1 = setup_BBP1_Data.chkDimIDNo12Dot1;
                autoDimensioningTypes.Bbp1.DimIDNo12Dot2 = setup_BBP1_Data.chkDimIDNo12Dot2;
                autoDimensioningTypes.Bbp1.DimIDNo13 = setup_BBP1_Data.chkDimIDNo13;
                autoDimensioningTypes.Bbp1.DimIDNo13Dot1 = setup_BBP1_Data.chkDimIDNo13Dot1;
                autoDimensioningTypes.Bbp1.DimIDNo14 = setup_BBP1_Data.chkDimIDNo14;
                autoDimensioningTypes.Bbp1.DimIDNo14Dot1 = setup_BBP1_Data.chkDimIDNo14Dot1;
                autoDimensioningTypes.Bbp1.DimIDNo15 = setup_BBP1_Data.chkDimIDNo15;
                autoDimensioningTypes.Bbp1.DimIDNo15Dot1 = setup_BBP1_Data.chkDimIDNo15Dot1;
                autoDimensioningTypes.Bbp1.DimIDNo16 = setup_BBP1_Data.chkDimIDNo16;
                autoDimensioningTypes.Bbp1.DimIDNo17 = setup_BBP1_Data.chkDimIDNo17;
                autoDimensioningTypes.Bbp1.DimIDNo18 = setup_BBP1_Data.chkDimIDNo18;
                autoDimensioningTypes.Bbp1.DimIDNo18Dot1 = setup_BBP1_Data.chkDimIDNo18Dot1;
                autoDimensioningTypes.Bbp1.DimIDNo19 = setup_BBP1_Data.chkDimIDNo19;
                autoDimensioningTypes.Bbp1.DimIDNo19Dot1 = setup_BBP1_Data.chkDimIDNo19Dot1;
                autoDimensioningTypes.Bbp1.DimIDNo1Dot1 = setup_BBP1_Data.chkDimIDNo1Dot1;
                autoDimensioningTypes.Bbp1.DimIDNo2 = setup_BBP1_Data.chkDimIDNo2;
                autoDimensioningTypes.Bbp1.DimIDNo20 = setup_BBP1_Data.chkDimIDNo20;
                autoDimensioningTypes.Bbp1.DimIDNo21 = setup_BBP1_Data.chkDimIDNo21;
                autoDimensioningTypes.Bbp1.DimIDNo21Dot1 = setup_BBP1_Data.chkDimIDNo21Dot1;
                autoDimensioningTypes.Bbp1.DimIDNo22 = setup_BBP1_Data.chkDimIDNo22;
                autoDimensioningTypes.Bbp1.DimIDNo22Dot1 = setup_BBP1_Data.chkDimIDNo22Dot1;
                autoDimensioningTypes.Bbp1.DimIDNo23 = setup_BBP1_Data.chkDimIDNo23;
                autoDimensioningTypes.Bbp1.DimIDNo23Dot1 = setup_BBP1_Data.chkDimIDNo23Dot1;
                autoDimensioningTypes.Bbp1.DimIDNo24 = setup_BBP1_Data.chkDimIDNo24;
                autoDimensioningTypes.Bbp1.DimIDNo25 = setup_BBP1_Data.chkDimIDNo25;
                autoDimensioningTypes.Bbp1.DimIDNo25Dot1 = setup_BBP1_Data.chkDimIDNo25Dot1;
                autoDimensioningTypes.Bbp1.DimIDNo25Dot2 = setup_BBP1_Data.chkDimIDNo25Dot2;
                autoDimensioningTypes.Bbp1.DimIDNo27 = setup_BBP1_Data.chkDimIDNo27;
                autoDimensioningTypes.Bbp1.DimIDNo27Dot1 = setup_BBP1_Data.chkDimIDNo27Dot1;
                autoDimensioningTypes.Bbp1.DimIDNo27Dot2 = setup_BBP1_Data.chkDimIDNo27Dot2;
                autoDimensioningTypes.Bbp1.DimIDNo28 = setup_BBP1_Data.chkDimIDNo28;
                autoDimensioningTypes.Bbp1.DimIDNo28Dot1 = setup_BBP1_Data.chkDimIDNo28Dot1;
                autoDimensioningTypes.Bbp1.DimIDNo4 = setup_BBP1_Data.chkDimIDNo4;
                autoDimensioningTypes.Bbp1.DimIDNo4Dot1 = setup_BBP1_Data.chkDimIDNo4Dot1;
                autoDimensioningTypes.Bbp1.DimIDNo5 = setup_BBP1_Data.chkDimIDNo5;
                autoDimensioningTypes.Bbp1.DimIDNo6 = setup_BBP1_Data.chkDimIDNo6;
                autoDimensioningTypes.Bbp1.DimIDNo7 = setup_BBP1_Data.chkDimIDNo7;
                autoDimensioningTypes.Bbp1.DimIDNo7Dot1 = setup_BBP1_Data.chkDimIDNo7Dot1;
                autoDimensioningTypes.Bbp1.DimIDNo7Dot2 = setup_BBP1_Data.chkDimIDNo7Dot2;
                autoDimensioningTypes.Bbp1.DimIDNo8 = setup_BBP1_Data.chkDimIDNo8;
                autoDimensioningTypes.Bbp1.DimIDNo8Dot1 = setup_BBP1_Data.chkDimIDNo8Dot1;
                autoDimensioningTypes.Bbp1.DimIDNo9 = setup_BBP1_Data.chkDimIDNo9;

                RetCheck = true;

            }

            return RetCheck;

        }

        private bool SetParametersBC2()
        {
            bool RetCheck = false;
            string FilePath = Com.MyModel.GetInfo().ModelPath + @"\attributes\standard.Auto_Detailing_Tool_Beam.Setup_BC2.xml";
            if (File.Exists(FilePath))
            {

                Setup_BC2_Data setup_BC2_Data = Com.TeklaXMLToClass<Setup_BC2_Data>(FilePath);
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.StandardDimension = setup_BC2_Data.txtStDim;
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.RunningDimension = setup_BC2_Data.txtRdDim;
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.ElevationDimension = setup_BC2_Data.txtELDim;

                autoDimensioningTypes.Bc2.DimIDNo1 = setup_BC2_Data.chkDimIDNo1;
                autoDimensioningTypes.Bc2.DimIDNo10 = setup_BC2_Data.chkDimIDNo10;
                autoDimensioningTypes.Bc2.DimIDNo10Dot1 = setup_BC2_Data.chkDimIDNo10Dot1;
                autoDimensioningTypes.Bc2.DimIDNo11 = setup_BC2_Data.chkDimIDNo11;
                autoDimensioningTypes.Bc2.DimIDNo12 = setup_BC2_Data.chkDimIDNo12;
                autoDimensioningTypes.Bc2.DimIDNo12Dot1 = setup_BC2_Data.chkDimIDNo12Dot1;
                autoDimensioningTypes.Bc2.DimIDNo12Dot2 = setup_BC2_Data.chkDimIDNo12Dot2;
                autoDimensioningTypes.Bc2.DimIDNo13 = setup_BC2_Data.chkDimIDNo13;
                autoDimensioningTypes.Bc2.DimIDNo14 = setup_BC2_Data.chkDimIDNo14;
                autoDimensioningTypes.Bc2.DimIDNo14Dot1 = setup_BC2_Data.chkDimIDNo14Dot1;
                autoDimensioningTypes.Bc2.DimIDNo16 = setup_BC2_Data.chkDimIDNo16;
                autoDimensioningTypes.Bc2.DimIDNo16Dot1 = setup_BC2_Data.chkDimIDNo16Dot1;
                autoDimensioningTypes.Bc2.DimIDNo17 = setup_BC2_Data.chkDimIDNo17;
                autoDimensioningTypes.Bc2.DimIDNo17Dot1 = setup_BC2_Data.chkDimIDNo17Dot1;
                autoDimensioningTypes.Bc2.DimIDNo18 = setup_BC2_Data.chkDimIDNo18;
                autoDimensioningTypes.Bc2.DimIDNo18Dot1 = setup_BC2_Data.chkDimIDNo18Dot1;
                autoDimensioningTypes.Bc2.DimIDNo19 = setup_BC2_Data.chkDimIDNo19;
                autoDimensioningTypes.Bc2.DimIDNo19Dot1 = setup_BC2_Data.chkDimIDNo19Dot1;
                autoDimensioningTypes.Bc2.DimIDNo2 = setup_BC2_Data.chkDimIDNo2;
                autoDimensioningTypes.Bc2.DimIDNo20 = setup_BC2_Data.chkDimIDNo20;
                autoDimensioningTypes.Bc2.DimIDNo20Dot1 = setup_BC2_Data.chkDimIDNo20Dot1;
                autoDimensioningTypes.Bc2.DimIDNo21 = setup_BC2_Data.chkDimIDNo21;
                autoDimensioningTypes.Bc2.DimIDNo22 = setup_BC2_Data.chkDimIDNo22;
                autoDimensioningTypes.Bc2.DimIDNo23 = setup_BC2_Data.chkDimIDNo23;
                autoDimensioningTypes.Bc2.DimIDNo23Dot1 = setup_BC2_Data.chkDimIDNo23Dot1;
                autoDimensioningTypes.Bc2.DimIDNo24 = setup_BC2_Data.chkDimIDNo24;
                autoDimensioningTypes.Bc2.DimIDNo25 = setup_BC2_Data.chkDimIDNo25;
                autoDimensioningTypes.Bc2.DimIDNo25Dot1 = setup_BC2_Data.chkDimIDNo25Dot1;
                autoDimensioningTypes.Bc2.DimIDNo26 = setup_BC2_Data.chkDimIDNo26;
                autoDimensioningTypes.Bc2.DimIDNo27 = setup_BC2_Data.chkDimIDNo27;
                autoDimensioningTypes.Bc2.DimIDNo27Dot1 = setup_BC2_Data.chkDimIDNo27Dot1;
                autoDimensioningTypes.Bc2.DimIDNo28 = setup_BC2_Data.chkDimIDNo28;
                autoDimensioningTypes.Bc2.DimIDNo29 = setup_BC2_Data.chkDimIDNo29;
                autoDimensioningTypes.Bc2.DimIDNo3 = setup_BC2_Data.chkDimIDNo3;
                autoDimensioningTypes.Bc2.DimIDNo30 = setup_BC2_Data.chkDimIDNo30;
                autoDimensioningTypes.Bc2.DimIDNo3Dot1 = setup_BC2_Data.chkDimIDNo3Dot1;
                autoDimensioningTypes.Bc2.DimIDNo3Dot2 = setup_BC2_Data.chkDimIDNo3Dot2;
                autoDimensioningTypes.Bc2.DimIDNo3Dot3 = setup_BC2_Data.chkDimIDNo3Dot3;
                autoDimensioningTypes.Bc2.DimIDNo4 = setup_BC2_Data.chkDimIDNo4;
                autoDimensioningTypes.Bc2.DimIDNo5 = setup_BC2_Data.chkDimIDNo5;
                autoDimensioningTypes.Bc2.DimIDNo6 = setup_BC2_Data.chkDimIDNo6;
                autoDimensioningTypes.Bc2.DimIDNo7 = setup_BC2_Data.chkDimIDNo7;
                autoDimensioningTypes.Bc2.DimIDNo8 = setup_BC2_Data.chkDimIDNo8;
                autoDimensioningTypes.Bc2.DimIDNo8Dot1 = setup_BC2_Data.chkDimIDNo8Dot1;
                autoDimensioningTypes.Bc2.DimIDNo9 = setup_BC2_Data.chkDimIDNo9;
                autoDimensioningTypes.Bc2.DimIDNo9Dot1 = setup_BC2_Data.chkDimIDNo9Dot1;

                RetCheck = true;

            }

            return RetCheck;

        }

        private bool SetParametersBCR1()
        {
            bool RetCheck = false;
            string FilePath = Com.MyModel.GetInfo().ModelPath + @"\attributes\standard.Auto_Detailing_Tool_Beam.Setup_BCR1.xml";
            if (File.Exists(FilePath))
            {

                Setup_BCR1_Data setup_BCR1_Data = Com.TeklaXMLToClass<Setup_BCR1_Data>(FilePath);
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.StandardDimension = setup_BCR1_Data.txtStDim;
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.RunningDimension = setup_BCR1_Data.txtRdDim;
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.ElevationDimension = setup_BCR1_Data.txtELDim;

                autoDimensioningTypes.Bcr1.DimIDNo1 = setup_BCR1_Data.chkDimIDNo1;
                autoDimensioningTypes.Bcr1.DimIDNo10 = setup_BCR1_Data.chkDimIDNo10;
                autoDimensioningTypes.Bcr1.DimIDNo11 = setup_BCR1_Data.chkDimIDNo11;
                autoDimensioningTypes.Bcr1.DimIDNo11Dot1 = setup_BCR1_Data.chkDimIDNo11Dot1;
                autoDimensioningTypes.Bcr1.DimIDNo12 = setup_BCR1_Data.chkDimIDNo12;
                autoDimensioningTypes.Bcr1.DimIDNo12Dot1 = setup_BCR1_Data.chkDimIDNo12Dot1;
                autoDimensioningTypes.Bcr1.DimIDNo13 = setup_BCR1_Data.chkDimIDNo13;
                autoDimensioningTypes.Bcr1.DimIDNo13Dot1 = setup_BCR1_Data.chkDimIDNo13Dot1;
                autoDimensioningTypes.Bcr1.DimIDNo14 = setup_BCR1_Data.chkDimIDNo14;
                autoDimensioningTypes.Bcr1.DimIDNo15 = setup_BCR1_Data.chkDimIDNo15;
                autoDimensioningTypes.Bcr1.DimIDNo16 = setup_BCR1_Data.chkDimIDNo16;
                autoDimensioningTypes.Bcr1.DimIDNo16Dot1 = setup_BCR1_Data.chkDimIDNo16Dot1;
                autoDimensioningTypes.Bcr1.DimIDNo17 = setup_BCR1_Data.chkDimIDNo17;
                autoDimensioningTypes.Bcr1.DimIDNo17Dot1 = setup_BCR1_Data.chkDimIDNo17Dot1;
                autoDimensioningTypes.Bcr1.DimIDNo18 = setup_BCR1_Data.chkDimIDNo18;
                autoDimensioningTypes.Bcr1.DimIDNo18Dot1 = setup_BCR1_Data.chkDimIDNo18Dot1;
                autoDimensioningTypes.Bcr1.DimIDNo19 = setup_BCR1_Data.chkDimIDNo19;
                autoDimensioningTypes.Bcr1.DimIDNo19Dot1 = setup_BCR1_Data.chkDimIDNo19Dot1;
                autoDimensioningTypes.Bcr1.DimIDNo2 = setup_BCR1_Data.chkDimIDNo2;
                autoDimensioningTypes.Bcr1.DimIDNo20 = setup_BCR1_Data.chkDimIDNo20;
                autoDimensioningTypes.Bcr1.DimIDNo21 = setup_BCR1_Data.chkDimIDNo21;
                autoDimensioningTypes.Bcr1.DimIDNo21Dot1 = setup_BCR1_Data.chkDimIDNo21Dot1;
                autoDimensioningTypes.Bcr1.DimIDNo22 = setup_BCR1_Data.chkDimIDNo22;
                autoDimensioningTypes.Bcr1.DimIDNo23 = setup_BCR1_Data.chkDimIDNo23;
                autoDimensioningTypes.Bcr1.DimIDNo24 = setup_BCR1_Data.chkDimIDNo24;
                autoDimensioningTypes.Bcr1.DimIDNo24Dot1 = setup_BCR1_Data.chkDimIDNo24Dot1;
                autoDimensioningTypes.Bcr1.DimIDNo25 = setup_BCR1_Data.chkDimIDNo25;
                autoDimensioningTypes.Bcr1.DimIDNo25Dot1 = setup_BCR1_Data.chkDimIDNo25Dot1;
                autoDimensioningTypes.Bcr1.DimIDNo26 = setup_BCR1_Data.chkDimIDNo26;
                autoDimensioningTypes.Bcr1.DimIDNo27 = setup_BCR1_Data.chkDimIDNo27;
                autoDimensioningTypes.Bcr1.DimIDNo28 = setup_BCR1_Data.chkDimIDNo28;
                autoDimensioningTypes.Bcr1.DimIDNo28Dot1 = setup_BCR1_Data.chkDimIDNo28Dot1;
                autoDimensioningTypes.Bcr1.DimIDNo3 = setup_BCR1_Data.chkDimIDNo3;
                autoDimensioningTypes.Bcr1.DimIDNo3Dot1 = setup_BCR1_Data.chkDimIDNo3Dot1;
                autoDimensioningTypes.Bcr1.DimIDNo3Dot2 = setup_BCR1_Data.chkDimIDNo3Dot2;
                autoDimensioningTypes.Bcr1.DimIDNo4 = setup_BCR1_Data.chkDimIDNo4;
                autoDimensioningTypes.Bcr1.DimIDNo5 = setup_BCR1_Data.chkDimIDNo5;
                autoDimensioningTypes.Bcr1.DimIDNo5Dot1 = setup_BCR1_Data.chkDimIDNo5Dot1;
                autoDimensioningTypes.Bcr1.DimIDNo6 = setup_BCR1_Data.chkDimIDNo6;
                autoDimensioningTypes.Bcr1.DimIDNo7 = setup_BCR1_Data.chkDimIDNo7;
                autoDimensioningTypes.Bcr1.DimIDNo7Dot1 = setup_BCR1_Data.chkDimIDNo7Dot1;
                autoDimensioningTypes.Bcr1.DimIDNo8 = setup_BCR1_Data.chkDimIDNo8;
                autoDimensioningTypes.Bcr1.DimIDNo9 = setup_BCR1_Data.chkDimIDNo9;
                autoDimensioningTypes.Bcr1.DimIDNo9Dot1 = setup_BCR1_Data.chkDimIDNo9Dot1;
                autoDimensioningTypes.Bcr1.DimIDNo9Dot2 = setup_BCR1_Data.chkDimIDNo9Dot2;

                RetCheck = true;

            }

            return RetCheck;

        }

        private bool SetParametersBDP1()
        {
            bool RetCheck = false;
            string FilePath = Com.MyModel.GetInfo().ModelPath + @"\attributes\standard.Auto_Detailing_Tool_Beam.Setup_BDP1.xml";
            if (File.Exists(FilePath))
            {

                Setup_BDP1_Data setup_BDP1_Data = Com.TeklaXMLToClass<Setup_BDP1_Data>(FilePath);
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.StandardDimension = setup_BDP1_Data.txtStDim;
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.RunningDimension = setup_BDP1_Data.txtRdDim;
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.ElevationDimension = setup_BDP1_Data.txtELDim;

                autoDimensioningTypes.Bdp1.DimIDNo1 = setup_BDP1_Data.chkDimIDNo1;
                autoDimensioningTypes.Bdp1.DimIDNo10 = setup_BDP1_Data.chkDimIDNo10;
                autoDimensioningTypes.Bdp1.DimIDNo11 = setup_BDP1_Data.chkDimIDNo11;
                autoDimensioningTypes.Bdp1.DimIDNo11Dot1 = setup_BDP1_Data.chkDimIDNo11Dot1;
                autoDimensioningTypes.Bdp1.DimIDNo12 = setup_BDP1_Data.chkDimIDNo12;
                autoDimensioningTypes.Bdp1.DimIDNo12Dot1 = setup_BDP1_Data.chkDimIDNo12Dot1;
                autoDimensioningTypes.Bdp1.DimIDNo13 = setup_BDP1_Data.chkDimIDNo13;
                autoDimensioningTypes.Bdp1.DimIDNo13Dot1 = setup_BDP1_Data.chkDimIDNo13Dot1;
                autoDimensioningTypes.Bdp1.DimIDNo14 = setup_BDP1_Data.chkDimIDNo14;
                autoDimensioningTypes.Bdp1.DimIDNo15 = setup_BDP1_Data.chkDimIDNo15;
                autoDimensioningTypes.Bdp1.DimIDNo17 = setup_BDP1_Data.chkDimIDNo17;
                autoDimensioningTypes.Bdp1.DimIDNo18 = setup_BDP1_Data.chkDimIDNo18;
                autoDimensioningTypes.Bdp1.DimIDNo2 = setup_BDP1_Data.chkDimIDNo2;
                autoDimensioningTypes.Bdp1.DimIDNo2Dot1 = setup_BDP1_Data.chkDimIDNo2Dot1;
                autoDimensioningTypes.Bdp1.DimIDNo2Dot2 = setup_BDP1_Data.chkDimIDNo2Dot2; 
                autoDimensioningTypes.Bdp1.DimIDNo2Dot3 = setup_BDP1_Data.chkDimIDNo2Dot3;
                autoDimensioningTypes.Bdp1.DimIDNo3 = setup_BDP1_Data.chkDimIDNo3;
                autoDimensioningTypes.Bdp1.DimIDNo4 = setup_BDP1_Data.chkDimIDNo4;
                autoDimensioningTypes.Bdp1.DimIDNo5 = setup_BDP1_Data.chkDimIDNo5;
                autoDimensioningTypes.Bdp1.DimIDNo5Dot1 = setup_BDP1_Data.chkDimIDNo5Dot1;
                autoDimensioningTypes.Bdp1.DimIDNo5Dot2 = setup_BDP1_Data.chkDimIDNo5Dot2;
                autoDimensioningTypes.Bdp1.DimIDNo6 = setup_BDP1_Data.chkDimIDNo6;
                autoDimensioningTypes.Bdp1.DimIDNo7 = setup_BDP1_Data.chkDimIDNo7;
                autoDimensioningTypes.Bdp1.DimIDNo9 = setup_BDP1_Data.chkDimIDNo9;
                autoDimensioningTypes.Bdp1.DimIDNo9Dot1 = setup_BDP1_Data.chkDimIDNo9Dot1;

                RetCheck = true;

            }

            return RetCheck;

        }

        private bool SetParametersBEP2()
        {
            bool RetCheck = false;
            string FilePath = Com.MyModel.GetInfo().ModelPath + @"\attributes\standard.Auto_Detailing_Tool_Beam.Setup_BEP2.xml";
            if (File.Exists(FilePath))
            {

                Setup_BEP2_Data setup_BEP2_Data = Com.TeklaXMLToClass<Setup_BEP2_Data>(FilePath);
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.StandardDimension = setup_BEP2_Data.txtStDim;
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.RunningDimension = setup_BEP2_Data.txtRdDim;
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.ElevationDimension = setup_BEP2_Data.txtELDim;

                autoDimensioningTypes.Bep2.DimIDNo1 = setup_BEP2_Data.chkDimIDNo1;
                autoDimensioningTypes.Bep2.DimIDNo10 = setup_BEP2_Data.chkDimIDNo10;
                autoDimensioningTypes.Bep2.DimIDNo11 = setup_BEP2_Data.chkDimIDNo11;
                autoDimensioningTypes.Bep2.DimIDNo11Dot1 = setup_BEP2_Data.chkDimIDNo11Dot1;
                autoDimensioningTypes.Bep2.DimIDNo12 = setup_BEP2_Data.chkDimIDNo12;
                autoDimensioningTypes.Bep2.DimIDNo12Dot1 = setup_BEP2_Data.chkDimIDNo12Dot1;
                autoDimensioningTypes.Bep2.DimIDNo13 = setup_BEP2_Data.chkDimIDNo13;
                autoDimensioningTypes.Bep2.DimIDNo13Dot1 = setup_BEP2_Data.chkDimIDNo13Dot1;
                autoDimensioningTypes.Bep2.DimIDNo14 = setup_BEP2_Data.chkDimIDNo14;
                autoDimensioningTypes.Bep2.DimIDNo15 = setup_BEP2_Data.chkDimIDNo15;
                autoDimensioningTypes.Bep2.DimIDNo16 = setup_BEP2_Data.chkDimIDNo16;
                autoDimensioningTypes.Bep2.DimIDNo17 = setup_BEP2_Data.chkDimIDNo17;
                autoDimensioningTypes.Bep2.DimIDNo1Dot1 = setup_BEP2_Data.chkDimIDNo1Dot1;
                autoDimensioningTypes.Bep2.DimIDNo1Dot2 = setup_BEP2_Data.chkDimIDNo1Dot2;
                autoDimensioningTypes.Bep2.DimIDNo2 = setup_BEP2_Data.chkDimIDNo2;
                autoDimensioningTypes.Bep2.DimIDNo2Dot1 = setup_BEP2_Data.chkDimIDNo2Dot1;
                autoDimensioningTypes.Bep2.DimIDNo3 = setup_BEP2_Data.chkDimIDNo3;
                autoDimensioningTypes.Bep2.DimIDNo4 = setup_BEP2_Data.chkDimIDNo4;
                autoDimensioningTypes.Bep2.DimIDNo4Dot1 = setup_BEP2_Data.chkDimIDNo4Dot1;
                autoDimensioningTypes.Bep2.DimIDNo5 = setup_BEP2_Data.chkDimIDNo5;
                autoDimensioningTypes.Bep2.DimIDNo6 = setup_BEP2_Data.chkDimIDNo6;
                autoDimensioningTypes.Bep2.DimIDNo7 = setup_BEP2_Data.chkDimIDNo7;
                autoDimensioningTypes.Bep2.DimIDNo7Dot1 = setup_BEP2_Data.chkDimIDNo7Dot1;
                autoDimensioningTypes.Bep2.DimIDNo8 = setup_BEP2_Data.chkDimIDNo8;
                autoDimensioningTypes.Bep2.DimIDNo8Dot1 = setup_BEP2_Data.chkDimIDNo8Dot1;
                autoDimensioningTypes.Bep2.DimIDNo9 = setup_BEP2_Data.chkDimIDNo9;
                autoDimensioningTypes.Bep2.DimIDNo9Dot1 = setup_BEP2_Data.chkDimIDNo9Dot1;

                RetCheck = true;

            }

            return RetCheck;

        }

        private bool SetParametersBEP3()
        {
            bool RetCheck = false;
            string FilePath = Com.MyModel.GetInfo().ModelPath + @"\attributes\standard.Auto_Detailing_Tool_Beam.Setup_BEP3.xml";
            if (File.Exists(FilePath))
            {

                Setup_BEP3_Data setup_BEP3_Data = Com.TeklaXMLToClass<Setup_BEP3_Data>(FilePath);
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.StandardDimension = setup_BEP3_Data.txtStDim;
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.RunningDimension = setup_BEP3_Data.txtRdDim;
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.ElevationDimension = setup_BEP3_Data.txtELDim;

                autoDimensioningTypes.Bep3.DimIDNo1 = setup_BEP3_Data.chkDimIDNo1;
                autoDimensioningTypes.Bep3.DimIDNo10 = setup_BEP3_Data.chkDimIDNo10;
                autoDimensioningTypes.Bep3.DimIDNo10Dot1 = setup_BEP3_Data.chkDimIDNo10Dot1;
                autoDimensioningTypes.Bep3.DimIDNo11 = setup_BEP3_Data.chkDimIDNo11;
                autoDimensioningTypes.Bep3.DimIDNo12 = setup_BEP3_Data.chkDimIDNo12;
                autoDimensioningTypes.Bep3.DimIDNo13 = setup_BEP3_Data.chkDimIDNo13;
                autoDimensioningTypes.Bep3.DimIDNo13Dot1 = setup_BEP3_Data.chkDimIDNo13Dot1;
                autoDimensioningTypes.Bep3.DimIDNo14 = setup_BEP3_Data.chkDimIDNo14;
                autoDimensioningTypes.Bep3.DimIDNo15 = setup_BEP3_Data.chkDimIDNo15;
                autoDimensioningTypes.Bep3.DimIDNo15Dot1 = setup_BEP3_Data.chkDimIDNo15Dot1;
                autoDimensioningTypes.Bep3.DimIDNo16 = setup_BEP3_Data.chkDimIDNo16;
                autoDimensioningTypes.Bep3.DimIDNo17 = setup_BEP3_Data.chkDimIDNo17;
                autoDimensioningTypes.Bep3.DimIDNo18 = setup_BEP3_Data.chkDimIDNo18;
                autoDimensioningTypes.Bep3.DimIDNo19 = setup_BEP3_Data.chkDimIDNo19;
                autoDimensioningTypes.Bep3.DimIDNo2 = setup_BEP3_Data.chkDimIDNo2;
                autoDimensioningTypes.Bep3.DimIDNo20 = setup_BEP3_Data.chkDimIDNo20;
                autoDimensioningTypes.Bep3.DimIDNo21 = setup_BEP3_Data.chkDimIDNo21;
                autoDimensioningTypes.Bep3.DimIDNo2Dot1 = setup_BEP3_Data.chkDimIDNo2Dot1;
                autoDimensioningTypes.Bep3.DimIDNo2Dot2 = setup_BEP3_Data.chkDimIDNo2Dot2;
                autoDimensioningTypes.Bep3.DimIDNo2Dot3 = setup_BEP3_Data.chkDimIDNo2Dot3;
                autoDimensioningTypes.Bep3.DimIDNo2Dot4 = setup_BEP3_Data.chkDimIDNo2Dot4;
                autoDimensioningTypes.Bep3.DimIDNo2Dot5 = setup_BEP3_Data.chkDimIDNo2Dot5;
                autoDimensioningTypes.Bep3.DimIDNo3 = setup_BEP3_Data.chkDimIDNo3;
                autoDimensioningTypes.Bep3.DimIDNo4 = setup_BEP3_Data.chkDimIDNo4;
                autoDimensioningTypes.Bep3.DimIDNo5 = setup_BEP3_Data.chkDimIDNo5;
                autoDimensioningTypes.Bep3.DimIDNo5Dot1 = setup_BEP3_Data.chkDimIDNo5Dot1;
                autoDimensioningTypes.Bep3.DimIDNo6 = setup_BEP3_Data.chkDimIDNo6;
                autoDimensioningTypes.Bep3.DimIDNo7 = setup_BEP3_Data.chkDimIDNo7;
                autoDimensioningTypes.Bep3.DimIDNo7Dot1 = setup_BEP3_Data.chkDimIDNo7Dot1;
                autoDimensioningTypes.Bep3.DimIDNo8 = setup_BEP3_Data.chkDimIDNo8;
                autoDimensioningTypes.Bep3.DimIDNo9 = setup_BEP3_Data.chkDimIDNo9;
                autoDimensioningTypes.Bep3.DimIDNo9Dot1 = setup_BEP3_Data.chkDimIDNo9Dot1;

                RetCheck = true;

            }

            return RetCheck;

        }

        private bool SetParametersBHP1()
        {
            bool RetCheck = false;
            string FilePath = Com.MyModel.GetInfo().ModelPath + @"\attributes\standard.Auto_Detailing_Tool_Beam.Setup_BHP1.xml";
            if (File.Exists(FilePath))
            {

                Setup_BHP1_Data setup_BHP1_Data = Com.TeklaXMLToClass<Setup_BHP1_Data>(FilePath);
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.StandardDimension = setup_BHP1_Data.txtStDim;
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.RunningDimension = setup_BHP1_Data.txtRdDim;
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.ElevationDimension = setup_BHP1_Data.txtELDim;

                autoDimensioningTypes.Bhp1.DimIDNo1 = setup_BHP1_Data.chkDimIDNo1;
                autoDimensioningTypes.Bhp1.DimIDNo10 = setup_BHP1_Data.chkDimIDNo10;
                autoDimensioningTypes.Bhp1.DimIDNo10Dot1 = setup_BHP1_Data.chkDimIDNo10Dot1;
                autoDimensioningTypes.Bhp1.DimIDNo11 = setup_BHP1_Data.chkDimIDNo11;
                autoDimensioningTypes.Bhp1.DimIDNo11Dot1 = setup_BHP1_Data.chkDimIDNo11Dot1;
                autoDimensioningTypes.Bhp1.DimIDNo12 = setup_BHP1_Data.chkDimIDNo12;
                autoDimensioningTypes.Bhp1.DimIDNo12Dot1 = setup_BHP1_Data.chkDimIDNo12Dot1;
                autoDimensioningTypes.Bhp1.DimIDNo13 = setup_BHP1_Data.chkDimIDNo13;
                autoDimensioningTypes.Bhp1.DimIDNo14 = setup_BHP1_Data.chkDimIDNo14;
                autoDimensioningTypes.Bhp1.DimIDNo15 = setup_BHP1_Data.chkDimIDNo15;
                autoDimensioningTypes.Bhp1.DimIDNo16 = setup_BHP1_Data.chkDimIDNo16;
                autoDimensioningTypes.Bhp1.DimIDNo17 = setup_BHP1_Data.chkDimIDNo17;
                autoDimensioningTypes.Bhp1.DimIDNo18 = setup_BHP1_Data.chkDimIDNo18;
                autoDimensioningTypes.Bhp1.DimIDNo2 = setup_BHP1_Data.chkDimIDNo2;
                autoDimensioningTypes.Bhp1.DimIDNo2Dot1 = setup_BHP1_Data.chkDimIDNo2Dot1;
                autoDimensioningTypes.Bhp1.DimIDNo3 = setup_BHP1_Data.chkDimIDNo3;
                autoDimensioningTypes.Bhp1.DimIDNo3Dot1 = setup_BHP1_Data.chkDimIDNo3Dot1;
                autoDimensioningTypes.Bhp1.DimIDNo3Dot2 = setup_BHP1_Data.chkDimIDNo3Dot2;
                autoDimensioningTypes.Bhp1.DimIDNo4 = setup_BHP1_Data.chkDimIDNo4;
                autoDimensioningTypes.Bhp1.DimIDNo5 = setup_BHP1_Data.chkDimIDNo5;
                autoDimensioningTypes.Bhp1.DimIDNo5Dot1 = setup_BHP1_Data.chkDimIDNo5Dot1;
                autoDimensioningTypes.Bhp1.DimIDNo6 = setup_BHP1_Data.chkDimIDNo6;
                autoDimensioningTypes.Bhp1.DimIDNo6Dot1 = setup_BHP1_Data.chkDimIDNo6Dot1;
                autoDimensioningTypes.Bhp1.DimIDNo7 = setup_BHP1_Data.chkDimIDNo7;
                autoDimensioningTypes.Bhp1.DimIDNo7Dot1 = setup_BHP1_Data.chkDimIDNo7Dot1;
                autoDimensioningTypes.Bhp1.DimIDNo8 = setup_BHP1_Data.chkDimIDNo8;
                autoDimensioningTypes.Bhp1.DimIDNo8Dot1 = setup_BHP1_Data.chkDimIDNo8Dot1;
                autoDimensioningTypes.Bhp1.DimIDNo9 = setup_BHP1_Data.chkDimIDNo9;

                RetCheck = true;

            }

            return RetCheck;

        }

        private bool SetParametersBS2()
        {
            bool RetCheck = false;
            string FilePath = Com.MyModel.GetInfo().ModelPath + @"\attributes\standard.Auto_Detailing_Tool_Beam.Setup_BS2.xml";
            if (File.Exists(FilePath))
            {

                Setup_BS2_Data setup_BS2_Data = Com.TeklaXMLToClass<Setup_BS2_Data>(FilePath);
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.StandardDimension = setup_BS2_Data.txtStDim;
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.RunningDimension = setup_BS2_Data.txtRdDim;
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.ElevationDimension = setup_BS2_Data.txtELDim;

                autoDimensioningTypes.Bs2.DimIDNo1 = setup_BS2_Data.chkDimIDNo1;
                autoDimensioningTypes.Bs2.DimIDNo10 = setup_BS2_Data.chkDimIDNo10;
                autoDimensioningTypes.Bs2.DimIDNo11 = setup_BS2_Data.chkDimIDNo11;
                autoDimensioningTypes.Bs2.DimIDNo1Dot1 = setup_BS2_Data.chkDimIDNo1Dot1;
                autoDimensioningTypes.Bs2.DimIDNo2 = setup_BS2_Data.chkDimIDNo2;
                autoDimensioningTypes.Bs2.DimIDNo3 = setup_BS2_Data.chkDimIDNo3;
                autoDimensioningTypes.Bs2.DimIDNo4 = setup_BS2_Data.chkDimIDNo4;
                autoDimensioningTypes.Bs2.DimIDNo4Dot1 = setup_BS2_Data.chkDimIDNo4Dot1;
                autoDimensioningTypes.Bs2.DimIDNo4Dot2 = setup_BS2_Data.chkDimIDNo4Dot2;
                autoDimensioningTypes.Bs2.DimIDNo5 = setup_BS2_Data.chkDimIDNo5;
                autoDimensioningTypes.Bs2.DimIDNo5Dot1 = setup_BS2_Data.chkDimIDNo5Dot1;
                autoDimensioningTypes.Bs2.DimIDNo5Dot2 = setup_BS2_Data.chkDimIDNo5Dot2;
                autoDimensioningTypes.Bs2.DimIDNo5Dot3 = setup_BS2_Data.chkDimIDNo5Dot3;
                autoDimensioningTypes.Bs2.DimIDNo5Dot4 = setup_BS2_Data.chkDimIDNo5Dot4;
                autoDimensioningTypes.Bs2.DimIDNo6 = setup_BS2_Data.chkDimIDNo6;
                autoDimensioningTypes.Bs2.DimIDNo6Dot1 = setup_BS2_Data.chkDimIDNo6Dot1;
                autoDimensioningTypes.Bs2.DimIDNo7 = setup_BS2_Data.chkDimIDNo7;
                autoDimensioningTypes.Bs2.DimIDNo8 = setup_BS2_Data.chkDimIDNo8;
                autoDimensioningTypes.Bs2.DimIDNo8Dot1 = setup_BS2_Data.chkDimIDNo8Dot1;
                autoDimensioningTypes.Bs2.DimIDNo9 = setup_BS2_Data.chkDimIDNo9;

                RetCheck = true;

            }

            return RetCheck;

        }

        private bool SetParametersBSP2()
        {
            bool RetCheck = false;
            string FilePath = Com.MyModel.GetInfo().ModelPath + @"\attributes\standard.Auto_Detailing_Tool_Beam.Setup_BSP2.xml";
            if (File.Exists(FilePath))
            {

                Setup_BSP2_Data setup_BSP2_Data = Com.TeklaXMLToClass<Setup_BSP2_Data>(FilePath);
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.StandardDimension = setup_BSP2_Data.txtStDim;
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.RunningDimension = setup_BSP2_Data.txtRdDim;
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.ElevationDimension = setup_BSP2_Data.txtELDim;

                autoDimensioningTypes.Bsp2.DimIDNo1 = setup_BSP2_Data.chkDimIDNo1;
                autoDimensioningTypes.Bsp2.DimIDNo10 = setup_BSP2_Data.chkDimIDNo10;
                autoDimensioningTypes.Bsp2.DimIDNo10Dot1 = setup_BSP2_Data.chkDimIDNo10Dot1;
                autoDimensioningTypes.Bsp2.DimIDNo11 = setup_BSP2_Data.chkDimIDNo11;
                autoDimensioningTypes.Bsp2.DimIDNo11Dot1 = setup_BSP2_Data.chkDimIDNo11Dot1;
                autoDimensioningTypes.Bsp2.DimIDNo12 = setup_BSP2_Data.chkDimIDNo12;
                autoDimensioningTypes.Bsp2.DimIDNo12Dot1 = setup_BSP2_Data.chkDimIDNo12Dot1;
                autoDimensioningTypes.Bsp2.DimIDNo12Dot2 = setup_BSP2_Data.chkDimIDNo12Dot2;
                autoDimensioningTypes.Bsp2.DimIDNo13 = setup_BSP2_Data.chkDimIDNo13;
                autoDimensioningTypes.Bsp2.DimIDNo13Dot1 = setup_BSP2_Data.chkDimIDNo13Dot1;
                autoDimensioningTypes.Bsp2.DimIDNo14 = setup_BSP2_Data.chkDimIDNo14;
                autoDimensioningTypes.Bsp2.DimIDNo15 = setup_BSP2_Data.chkDimIDNo15;
                autoDimensioningTypes.Bsp2.DimIDNo15Dot1 = setup_BSP2_Data.chkDimIDNo15Dot1;
                autoDimensioningTypes.Bsp2.DimIDNo15Dot2 = setup_BSP2_Data.chkDimIDNo15Dot2;
                autoDimensioningTypes.Bsp2.DimIDNo16 = setup_BSP2_Data.chkDimIDNo16;
                autoDimensioningTypes.Bsp2.DimIDNo16Dot1 = setup_BSP2_Data.chkDimIDNo16Dot1;
                autoDimensioningTypes.Bsp2.DimIDNo17 = setup_BSP2_Data.chkDimIDNo17;
                autoDimensioningTypes.Bsp2.DimIDNo18 = setup_BSP2_Data.chkDimIDNo18;
                autoDimensioningTypes.Bsp2.DimIDNo18Dot1 = setup_BSP2_Data.chkDimIDNo18Dot1;
                autoDimensioningTypes.Bsp2.DimIDNo18Dot2 = setup_BSP2_Data.chkDimIDNo18Dot2;
                autoDimensioningTypes.Bsp2.DimIDNo19 = setup_BSP2_Data.chkDimIDNo19;
                autoDimensioningTypes.Bsp2.DimIDNo2 = setup_BSP2_Data.chkDimIDNo2;
                autoDimensioningTypes.Bsp2.DimIDNo20 = setup_BSP2_Data.chkDimIDNo20;
                autoDimensioningTypes.Bsp2.DimIDNo2Dot1 = setup_BSP2_Data.chkDimIDNo2Dot1;
                autoDimensioningTypes.Bsp2.DimIDNo2Dot2 = setup_BSP2_Data.chkDimIDNo2Dot2;
                autoDimensioningTypes.Bsp2.DimIDNo2Dot3 = setup_BSP2_Data.chkDimIDNo2Dot3;
                autoDimensioningTypes.Bsp2.DimIDNo3 = setup_BSP2_Data.chkDimIDNo3;
                autoDimensioningTypes.Bsp2.DimIDNo3Dot1 = setup_BSP2_Data.chkDimIDNo3Dot1;
                autoDimensioningTypes.Bsp2.DimIDNo4 = setup_BSP2_Data.chkDimIDNo4;
                autoDimensioningTypes.Bsp2.DimIDNo4Dot1 = setup_BSP2_Data.chkDimIDNo4Dot1;
                autoDimensioningTypes.Bsp2.DimIDNo4Dot2 = setup_BSP2_Data.chkDimIDNo4Dot2;
                autoDimensioningTypes.Bsp2.DimIDNo5 = setup_BSP2_Data.chkDimIDNo5;
                autoDimensioningTypes.Bsp2.DimIDNo5Dot1 = setup_BSP2_Data.chkDimIDNo5Dot1;
                autoDimensioningTypes.Bsp2.DimIDNo6 = setup_BSP2_Data.chkDimIDNo6;
                autoDimensioningTypes.Bsp2.DimIDNo6Dot1 = setup_BSP2_Data.chkDimIDNo6Dot1;
                autoDimensioningTypes.Bsp2.DimIDNo7 = setup_BSP2_Data.chkDimIDNo7;
                autoDimensioningTypes.Bsp2.DimIDNo7Dot1 = setup_BSP2_Data.chkDimIDNo7Dot1;
                autoDimensioningTypes.Bsp2.DimIDNo8 = setup_BSP2_Data.chkDimIDNo8;
                autoDimensioningTypes.Bsp2.DimIDNo8Dot1 = setup_BSP2_Data.chkDimIDNo8Dot1;
                autoDimensioningTypes.Bsp2.DimIDNo9 = setup_BSP2_Data.chkDimIDNo9;

                RetCheck = true;

            }

            return RetCheck;

        }

        private bool SetParametersBSP4()
        {
            bool RetCheck = false;
            string FilePath = Com.MyModel.GetInfo().ModelPath + @"\attributes\standard.Auto_Detailing_Tool_Beam.Setup_BSP4.xml";
            if (File.Exists(FilePath))
            {

                Setup_BSP4_Data setup_BSP4_Data = Com.TeklaXMLToClass<Setup_BSP4_Data>(FilePath);
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.StandardDimension = setup_BSP4_Data.txtStDim;
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.RunningDimension = setup_BSP4_Data.txtRdDim;
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.ElevationDimension = setup_BSP4_Data.txtELDim;

                autoDimensioningTypes.BSP4.DimIDNo1 = setup_BSP4_Data.chkDimIDNo1;
                autoDimensioningTypes.BSP4.DimIDNo10 = setup_BSP4_Data.chkDimIDNo10;
                autoDimensioningTypes.BSP4.DimIDNo11 = setup_BSP4_Data.chkDimIDNo11;
                autoDimensioningTypes.BSP4.DimIDNo11Dot1 = setup_BSP4_Data.chkDimIDNo11Dot1;
                autoDimensioningTypes.BSP4.DimIDNo12 = setup_BSP4_Data.chkDimIDNo12;
                autoDimensioningTypes.BSP4.DimIDNo12Dot1 = setup_BSP4_Data.chkDimIDNo12Dot1;
                autoDimensioningTypes.BSP4.DimIDNo13 = setup_BSP4_Data.chkDimIDNo13;
                autoDimensioningTypes.BSP4.DimIDNo13Dot1 = setup_BSP4_Data.chkDimIDNo13Dot1;
                autoDimensioningTypes.BSP4.DimIDNo14 = setup_BSP4_Data.chkDimIDNo14;
                autoDimensioningTypes.BSP4.DimIDNo15 = setup_BSP4_Data.chkDimIDNo15;
                autoDimensioningTypes.BSP4.DimIDNo16 = setup_BSP4_Data.chkDimIDNo16;
                autoDimensioningTypes.BSP4.DimIDNo17 = setup_BSP4_Data.chkDimIDNo17;
                autoDimensioningTypes.BSP4.DimIDNo18 = setup_BSP4_Data.chkDimIDNo18;
                autoDimensioningTypes.BSP4.DimIDNo19 = setup_BSP4_Data.chkDimIDNo19;
                autoDimensioningTypes.BSP4.DimIDNo2 = setup_BSP4_Data.chkDimIDNo2;
                autoDimensioningTypes.BSP4.DimIDNo21 = setup_BSP4_Data.chkDimIDNo21;
                autoDimensioningTypes.BSP4.DimIDNo21Dot1 = setup_BSP4_Data.chkDimIDNo21Dot1;
                autoDimensioningTypes.BSP4.DimIDNo22 = setup_BSP4_Data.chkDimIDNo22;
                autoDimensioningTypes.BSP4.DimIDNo22Dot1 = setup_BSP4_Data.chkDimIDNo22Dot1;
                autoDimensioningTypes.BSP4.DimIDNo22Dot2 = setup_BSP4_Data.chkDimIDNo22Dot2;
                autoDimensioningTypes.BSP4.DimIDNo23 = setup_BSP4_Data.chkDimIDNo23;
                autoDimensioningTypes.BSP4.DimIDNo24 = setup_BSP4_Data.chkDimIDNo24;
                autoDimensioningTypes.BSP4.DimIDNo24Dot1 = setup_BSP4_Data.chkDimIDNo24Dot1;
                autoDimensioningTypes.BSP4.DimIDNo24Dot2 = setup_BSP4_Data.chkDimIDNo24Dot2;
                autoDimensioningTypes.BSP4.DimIDNo25 = setup_BSP4_Data.chkDimIDNo25;
                autoDimensioningTypes.BSP4.DimIDNo26 = setup_BSP4_Data.chkDimIDNo26;
                autoDimensioningTypes.BSP4.DimIDNo27 = setup_BSP4_Data.chkDimIDNo27;
                autoDimensioningTypes.BSP4.DimIDNo28 = setup_BSP4_Data.chkDimIDNo28;
                autoDimensioningTypes.BSP4.DimIDNo29 = setup_BSP4_Data.chkDimIDNo29;
                autoDimensioningTypes.BSP4.DimIDNo29Dot1 = setup_BSP4_Data.chkDimIDNo29Dot1;
                autoDimensioningTypes.BSP4.DimIDNo29Dot2 = setup_BSP4_Data.chkDimIDNo29Dot2;
                autoDimensioningTypes.BSP4.DimIDNo3 = setup_BSP4_Data.chkDimIDNo3;
                autoDimensioningTypes.BSP4.DimIDNo30 = setup_BSP4_Data.chkDimIDNo30;
                autoDimensioningTypes.BSP4.DimIDNo30Dot1 = setup_BSP4_Data.chkDimIDNo30Dot1;
                autoDimensioningTypes.BSP4.DimIDNo31 = setup_BSP4_Data.chkDimIDNo31;
                autoDimensioningTypes.BSP4.DimIDNo32 = setup_BSP4_Data.chkDimIDNo32;
                autoDimensioningTypes.BSP4.DimIDNo33 = setup_BSP4_Data.chkDimIDNo33;
                autoDimensioningTypes.BSP4.DimIDNo34 = setup_BSP4_Data.chkDimIDNo34;
                autoDimensioningTypes.BSP4.DimIDNo35 = setup_BSP4_Data.chkDimIDNo35;
                autoDimensioningTypes.BSP4.DimIDNo36 = setup_BSP4_Data.chkDimIDNo36;
                autoDimensioningTypes.BSP4.DimIDNo4 = setup_BSP4_Data.chkDimIDNo4;
                autoDimensioningTypes.BSP4.DimIDNo4Dot1 = setup_BSP4_Data.chkDimIDNo4Dot1;
                autoDimensioningTypes.BSP4.DimIDNo4Dot2 = setup_BSP4_Data.chkDimIDNo4Dot2;
                autoDimensioningTypes.BSP4.DimIDNo4Dot3 = setup_BSP4_Data.chkDimIDNo4Dot3;
                autoDimensioningTypes.BSP4.DimIDNo5 = setup_BSP4_Data.chkDimIDNo5;
                autoDimensioningTypes.BSP4.DimIDNo6 = setup_BSP4_Data.chkDimIDNo6;
                autoDimensioningTypes.BSP4.DimIDNo6Dot1 = setup_BSP4_Data.chkDimIDNo6Dot1;
                autoDimensioningTypes.BSP4.DimIDNo7 = setup_BSP4_Data.chkDimIDNo7;
                autoDimensioningTypes.BSP4.DimIDNo8 = setup_BSP4_Data.chkDimIDNo8;
                autoDimensioningTypes.BSP4.DimIDNo9 = setup_BSP4_Data.chkDimIDNo9;
                autoDimensioningTypes.BSP4.DimIDNo9Dot1 = setup_BSP4_Data.chkDimIDNo9Dot1;
                autoDimensioningTypes.BSP4.DimIDNo9Dot2 = setup_BSP4_Data.chkDimIDNo9Dot2;
                autoDimensioningTypes.BSP4.DimIDNo9Dot3 = setup_BSP4_Data.chkDimIDNo9Dot3;
                autoDimensioningTypes.BSP4.DimIDNo9Dot4 = setup_BSP4_Data.chkDimIDNo9Dot4;
                autoDimensioningTypes.BSP4.DimIDNo9Dot5 = setup_BSP4_Data.chkDimIDNo9Dot5;
                autoDimensioningTypes.BSP4.DimIDNo9Dot6 = setup_BSP4_Data.chkDimIDNo9Dot6;
                autoDimensioningTypes.BSP4.DimIDNo9Dot7 = setup_BSP4_Data.chkDimIDNo9Dot7;

                RetCheck = true;

            }

            return RetCheck;

        }

        private bool SetParametersBSP3()
        {
            bool RetCheck = false;
            string FilePath = Com.MyModel.GetInfo().ModelPath + @"\attributes\standard.Auto_Detailing_Tool_Beam.Setup_BSP3.xml";
            if (File.Exists(FilePath))
            {

                Setup_BSP3_Data setup_BSP3_Data = Com.TeklaXMLToClass<Setup_BSP3_Data>(FilePath);
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.StandardDimension = setup_BSP3_Data.txtStDim;
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.RunningDimension = setup_BSP3_Data.txtRdDim;
                drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files.ElevationDimension = setup_BSP3_Data.txtELDim;

                autoDimensioningTypes.BSP3.DimIDNo1 = setup_BSP3_Data.chkDimIDNo1;
                autoDimensioningTypes.BSP3.DimIDNo10 = setup_BSP3_Data.chkDimIDNo10;
                autoDimensioningTypes.BSP3.DimIDNo11 = setup_BSP3_Data.chkDimIDNo11;
                autoDimensioningTypes.BSP3.DimIDNo11Dot1 = setup_BSP3_Data.chkDimIDNo11Dot1;
                autoDimensioningTypes.BSP3.DimIDNo12 = setup_BSP3_Data.chkDimIDNo12;
                autoDimensioningTypes.BSP3.DimIDNo12Dot1 = setup_BSP3_Data.chkDimIDNo12Dot1;
                autoDimensioningTypes.BSP3.DimIDNo13 = setup_BSP3_Data.chkDimIDNo13;
                autoDimensioningTypes.BSP3.DimIDNo13Dot1 = setup_BSP3_Data.chkDimIDNo13Dot1;
                autoDimensioningTypes.BSP3.DimIDNo14 = setup_BSP3_Data.chkDimIDNo14;
                autoDimensioningTypes.BSP3.DimIDNo15 = setup_BSP3_Data.chkDimIDNo15;
                autoDimensioningTypes.BSP3.DimIDNo16 = setup_BSP3_Data.chkDimIDNo16;
                autoDimensioningTypes.BSP3.DimIDNo17 = setup_BSP3_Data.chkDimIDNo17;
                autoDimensioningTypes.BSP3.DimIDNo18 = setup_BSP3_Data.chkDimIDNo18;
                autoDimensioningTypes.BSP3.DimIDNo19 = setup_BSP3_Data.chkDimIDNo19;
                autoDimensioningTypes.BSP3.DimIDNo2 = setup_BSP3_Data.chkDimIDNo2;
                autoDimensioningTypes.BSP3.DimIDNo20 = setup_BSP3_Data.chkDimIDNo20;
                autoDimensioningTypes.BSP3.DimIDNo21 = setup_BSP3_Data.chkDimIDNo21;
                autoDimensioningTypes.BSP3.DimIDNo21Dot1 = setup_BSP3_Data.chkDimIDNo21Dot1;
                autoDimensioningTypes.BSP3.DimIDNo22 = setup_BSP3_Data.chkDimIDNo22;
                autoDimensioningTypes.BSP3.DimIDNo22Dot1 = setup_BSP3_Data.chkDimIDNo22Dot1;
                autoDimensioningTypes.BSP3.DimIDNo23 = setup_BSP3_Data.chkDimIDNo23;
                autoDimensioningTypes.BSP3.DimIDNo24 = setup_BSP3_Data.chkDimIDNo24;
                autoDimensioningTypes.BSP3.DimIDNo24Dot1 = setup_BSP3_Data.chkDimIDNo24Dot1;
                autoDimensioningTypes.BSP3.DimIDNo3 = setup_BSP3_Data.chkDimIDNo3;
                autoDimensioningTypes.BSP3.DimIDNo4 = setup_BSP3_Data.chkDimIDNo4;
                autoDimensioningTypes.BSP3.DimIDNo4Dot1 = setup_BSP3_Data.chkDimIDNo4Dot1;
                autoDimensioningTypes.BSP3.DimIDNo4Dot2 = setup_BSP3_Data.chkDimIDNo4Dot2;
                autoDimensioningTypes.BSP3.DimIDNo4Dot3 = setup_BSP3_Data.chkDimIDNo4Dot3;
                autoDimensioningTypes.BSP3.DimIDNo5 = setup_BSP3_Data.chkDimIDNo5;
                autoDimensioningTypes.BSP3.DimIDNo6 = setup_BSP3_Data.chkDimIDNo6;
                autoDimensioningTypes.BSP3.DimIDNo6Dot1 = setup_BSP3_Data.chkDimIDNo6Dot1;
                autoDimensioningTypes.BSP3.DimIDNo7 = setup_BSP3_Data.chkDimIDNo7;
                autoDimensioningTypes.BSP3.DimIDNo8 = setup_BSP3_Data.chkDimIDNo8;
                autoDimensioningTypes.BSP3.DimIDNo9 = setup_BSP3_Data.chkDimIDNo9;
                autoDimensioningTypes.BSP3.DimIDNo9Dot1 = setup_BSP3_Data.chkDimIDNo9Dot1;
                autoDimensioningTypes.BSP3.DimIDNo9Dot2 = setup_BSP3_Data.chkDimIDNo9Dot2;
                autoDimensioningTypes.BSP3.DimIDNo9Dot3 = setup_BSP3_Data.chkDimIDNo9Dot3;
                autoDimensioningTypes.BSP3.DimIDNo9Dot4 = setup_BSP3_Data.chkDimIDNo9Dot4;
                autoDimensioningTypes.BSP3.DimIDNo9Dot5 = setup_BSP3_Data.chkDimIDNo9Dot5;

                RetCheck = true;

            }

            return RetCheck;

        }
        #endregion

    }
}
