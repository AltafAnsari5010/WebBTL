﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Tekla.Structures;
using Tekla.Structures.Drawing;
using Tekla.Structures.Geometry3d;
using Tekla.Structures.Model;
using TSD = Tekla.Structures.Drawing;
using TSM = Tekla.Structures.Model;
using VirtueleDrawingAutomation;
using TSDD = Tekla.Structures.Datatype;
using TSG = Tekla.Structures.Geometry3d;

namespace Auto_Detailing_Tool_Beam
{
    public class BeamDim_BEP2
    {
        #region Global Variables
        DimCom dc = new DimCom();
        StraightDimensionSet.StraightDimensionSetAttributes StAtrr = new StraightDimensionSet.StraightDimensionSetAttributes("standard");
        StraightDimensionSet.StraightDimensionSetAttributes RdAtrr = new StraightDimensionSet.StraightDimensionSetAttributes("standard");

        public Beam MainBeam = null;
        VirtueleDrawingAutomation.Json.DrawingAttributeInfoJson.AttributeFiles dimAttrClass = null;
        List<TSD.StraightDimension> KnockDim = new List<StraightDimension>();
        BeamClass_BEP2 BC = null;

        VirtueleDrawingAutomation.Json.AutoDimensionTypesJson.BEP2Json DN = null;
        string Position = "Left";
        TSD.View CView = null;
        string ViewName = "";
        public Point BoltPS = null;

        #endregion

        public void ApplyDim(TSD.View CView, string ViewName, AutoDimensioningTypes autoDimensioningTypes, DrawingAttributeInfo drawingAttributeInfo, string Position)
        {
            try
            {
                Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane());
                //Set model everything to the view
                Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane(CView.DisplayCoordinateSystem));

                this.CView = CView;
                this.dimAttrClass = drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files;
                this.DN = autoDimensioningTypes.Bep2;
                this.Position = Position;
                StAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.StandardDimension);
                RdAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.RunningDimension);
                this.MainBeam = (Com.MyModel.SelectModelObject(new Identifier((CView.GetDrawing() as AssemblyDrawing).AssemblyIdentifier.ID)) as TSM.Assembly).GetMainPart() as TSM.Beam;
                this.MainBeam.Select();
                string ProType = Com.GetProType(MainBeam);
                this.ViewName = ViewName;
                GetBeamClass(CView);

                if (Position == "Left")
                {
                    //TestDim();
                    if (ViewName == "Front View")
                        ApplyDimTypeLeft(CView);
                    else if (ViewName == "Section View")
                        AppySectionDim();
                }

                else if (Position == "Right")
                {
                    //TestDim();
                    if (ViewName == "Front View")
                        ApplyDimTypeRight(CView);
                    else if (ViewName == "Section View")
                        AppySectionDim();
                }
            }
            catch (Exception ex)
            { }

            Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane());


        }

        private void ApplyDimTypeLeft(TSD.View CView)
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            TSD.PointList TempList = new PointList();



            if (BC.EP != null)
            {

                TSG.Line YLine = new TSG.Line(BC.Points.P1, BC.Points.P2);
                TSG.Line XLine = new TSG.Line(BC.EP.EndPlate.Points.P1, BC.EP.EndPlate.Points.P4);
                Vector LeftVect = XLine.Direction;

                if (LeftVect.X > 0)
                    LeftVect = dc.ChangeVector(LeftVect);

                Vect = new Vector(-1, 0, 0);

                #region Left Dim

                // Dim No 1.1
                if (DN.DimIDNo1Dot1)
                {
                    bool IsDim = false;

                    pointList = new PointList();

                    if (BC.EP.TopBoltP != null)
                        pointList.Add(Com.MaxP(BC.EP.TopBoltP, "Y"));
                    else
                        pointList.Add(Com.MaxP(BC.EP.MidBoltP, "Y"));

                    pointList.Add(BC.EP.EndPlate.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistLeft);
                        IsDim = true;
                    }



                    pointList = new PointList();

                    if (BC.EP.BottBoltP != null)
                        pointList.Add(Com.MinP(BC.EP.BottBoltP, "Y"));
                    else
                        pointList.Add(Com.MinP(BC.EP.MidBoltP, "Y"));

                    pointList.Add(BC.EP.EndPlate.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistLeft);
                        IsDim = true;
                    }


                    if (IsDim)
                        BC.PC.DistLeft += BC.PC.DistInc;
                }

                // Dim No 3
                if (DN.DimIDNo3)
                {
                    pointList = new PointList();
                    if (BC.EP.TopBoltP != null)
                        pointList.Add(Com.MinP(BC.EP.TopBoltP, "Y"));
                    pointList.Add(BC.Points.P1);
                    pointList.Add(Com.MaxP(BC.EP.MidBoltP, "Y"));
                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistLeft);
                        BC.PC.DistLeft += (BC.PC.DistInc * 0.6);
                    }
                }


                // Dim No 1.2
                if (DN.DimIDNo1Dot2)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(BC.EP.MidBoltP, "Y"));
                    pointList.Add(BC.Points.P2);
                    if (BC.EP.BottBoltP != null)
                        pointList.Add(Com.MaxP(BC.EP.BottBoltP, "Y"));
                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistLeft);

                }


                if (DN.DimIDNo5 || DN.DimIDNo5 || DN.DimIDNo1 || DN.DimIDNo11 || DN.DimIDNo2Dot1)
                    BC.PC.DistLeft += BC.PC.DistInc;

                // Dim No 1
                if (DN.DimIDNo1)
                {
                    pointList = new PointList();
                    pointList.AddRange(BC.EP.AllPoints);
                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistLeft);
                        BC.PC.DistLeft += (BC.PC.DistInc);
                    }
                }

                // Dim No 2
                if (DN.DimIDNo2)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(Com.MaxP(BC.EP.MidBoltP, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                        BC.PC.DistLeft += (BC.PC.DistInc);
                    }
                }

                // Dim No 2.1
                if (DN.DimIDNo2Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(Com.MinP(BC.EP.AllPoints, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                        BC.PC.DistLeft += (BC.PC.DistInc * 0.6);
                    }
                }


                // Dim No 14 Elevation Dim
                if (DN.DimIDNo14)
                {

                    BC.PC.DistLeft += BC.PC.DistInc;
                    Vect = new Vector(-1, 0, 0);
                    StraightDimensionSet.StraightDimensionSetAttributes ElAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.ElevationDimension);
                    ElAtrr.DimensionType = DimensionSetBaseAttributes.DimensionTypes.Elevation;
                    ElAtrr.Arrowhead.Head = ArrowheadTypes.FilledArrow;
                    pointList = new PointList();

                    if (MainBeam.StartPoint.X > MainBeam.EndPoint.X)
                    {
                        pointList.Add(MainBeam.EndPoint);
                        pointList.Add(MainBeam.EndPoint);

                    }
                    else
                    {
                        pointList.Add(MainBeam.StartPoint);
                        pointList.Add(MainBeam.StartPoint);
                    }

                    BC.PC.DistLeft = BC.PC.DistLeft - (BC.Points.P1.X - pointList[0].X);
                    xDim = dc.InsertDimm(CView, pointList, Vect, (-BC.PC.DistLeft), ElAtrr);
                    if (xDim != null)
                    {
                        xDim.Distance = (-BC.PC.DistLeft);
                        xDim.Modify();
                    }
                    BC.PC.DistLeft += BC.PC.DistInc;

                }


                #endregion

                Vector BottVect = YLine.Direction;
                if (BottVect.Y > 0)
                    BottVect = dc.ChangeVector(BottVect);

                // Dim No 4
                if (DN.DimIDNo4)
                {
                    pointList = new PointList();
                    pointList.Add(BC.EP.EndPlate.Points.P2);
                    pointList.Add(BC.EP.EndPlate.Points.P3);

                    xDim = dc.InsertDim(CView, pointList, BottVect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                }

                Vect = new Vector(0, 1, 0);
                // Dim No 10
                if (DN.DimIDNo10)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(BC.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                }


                //Dim Code 5 // Angle Dimension
                if (DN.DimIDNo5)
                {
                    double Dist = Distance.PointToPoint(BC.EP.EndPlate.Points.P2, BC.EP.EndPlate.Points.P1) * (0.13);
                    Com.InsertAngleDim(CView, BC.EP.EndPlate.Points.P2, BC.EP.EndPlate.Points.P1, "Top", Dist);

                }

                //Dim Code 4.1 // Angle Dimension
                if (DN.DimIDNo4Dot1)
                {
                    double Dist = (Distance.PointToPoint(BC.Points.P1, BC.Points.P2) * (0.13)) + 20;
                    Com.InsertAngleDim(CView, BC.Points.P1, BC.Points.P2, "Bottom", Dist);

                }

            }
        }

        private void ApplyDimTypeRight(TSD.View CView)
        {

            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            TSD.PointList TempList = new PointList();
            if (BC.EP != null)
            {

                TSG.Line YLine = new TSG.Line(BC.Points.P4, BC.Points.P3);
                TSG.Line XLine = new TSG.Line(BC.EP.EndPlate.Points.P1, BC.EP.EndPlate.Points.P4);
                Vector RightVect = XLine.Direction;

                if (RightVect.X < 0)
                    RightVect = dc.ChangeVector(RightVect);



                #region Right Dim

                // Dim No 1.1
                if (DN.DimIDNo1Dot1)
                {
                    bool IsDim = false;

                    pointList = new PointList();

                    if (BC.EP.TopBoltP != null)
                        pointList.Add(Com.MaxP(BC.EP.TopBoltP, "Y"));
                    else
                        pointList.Add(Com.MaxP(BC.EP.MidBoltP, "Y"));

                    pointList.Add(BC.EP.EndPlate.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistRight);
                        IsDim = true;
                    }



                    pointList = new PointList();

                    if (BC.EP.BottBoltP != null)
                        pointList.Add(Com.MinP(BC.EP.BottBoltP, "Y"));
                    else
                        pointList.Add(Com.MinP(BC.EP.MidBoltP, "Y"));

                    pointList.Add(BC.EP.EndPlate.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistRight);
                        IsDim = true;
                    }


                    if (IsDim)
                        BC.PC.DistRight += BC.PC.DistInc;
                }

                // Dim No 3
                if (DN.DimIDNo3)
                {
                    pointList = new PointList();
                    if (BC.EP.TopBoltP != null)
                        pointList.Add(Com.MinP(BC.EP.TopBoltP, "Y"));
                    pointList.Add(BC.Points.P4);
                    pointList.Add(Com.MaxP(BC.EP.MidBoltP, "Y"));
                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistRight);
                        BC.PC.DistRight += (BC.PC.DistInc * 0.6);
                    }
                }


                // Dim No 1.2
                if (DN.DimIDNo1Dot2)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(BC.EP.MidBoltP, "Y"));
                    pointList.Add(BC.Points.P3);
                    if (BC.EP.BottBoltP != null)
                        pointList.Add(Com.MaxP(BC.EP.BottBoltP, "Y"));
                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistRight);

                }


                if (DN.DimIDNo3 || DN.DimIDNo1Dot2)
                    BC.PC.DistRight += BC.PC.DistInc;

                // Dim No 1
                if (DN.DimIDNo1)
                {
                    pointList = new PointList();
                    pointList.AddRange(BC.EP.AllPoints);
                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistRight);
                        BC.PC.DistRight += (BC.PC.DistInc);
                    }
                }

                Vect = new Vector(1, 0, 0);

                // Dim No 2
                if (DN.DimIDNo2)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P4);
                    pointList.Add(Com.MaxP(BC.EP.MidBoltP, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                        BC.PC.DistRight += (BC.PC.DistInc);
                    }
                }

                // Dim No 2.1
                if (DN.DimIDNo2Dot1)
                {

                    pointList = new PointList();
                    pointList.Add(BC.Points.P4);
                    pointList.Add(Com.MinP(BC.EP.AllPoints, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                        BC.PC.DistRight += (BC.PC.DistInc * 0.6);
                    }
                }


                #endregion

                Vector BottVect = YLine.Direction;
                if (BottVect.Y > 0)
                    BottVect = dc.ChangeVector(BottVect);

                // Dim No 4
                if (DN.DimIDNo4)
                {
                    pointList = new PointList();
                    pointList.Add(BC.EP.EndPlate.Points.P2);
                    pointList.Add(BC.EP.EndPlate.Points.P3);

                    xDim = dc.InsertDim(CView, pointList, BottVect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                }

                Vect = new Vector(0, 1, 0);
                // Dim No 10
                if (DN.DimIDNo10)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P4);
                    pointList.Add(BC.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                }


                //Dim Code 5 // Angle Dimension
                if (DN.DimIDNo5)
                {
                    double Dist = Distance.PointToPoint(BC.EP.EndPlate.Points.P3, BC.EP.EndPlate.Points.P4) * (0.13);
                    Com.InsertAngleDim(CView, BC.EP.EndPlate.Points.P3, BC.EP.EndPlate.Points.P4, "Top", Dist);


                }

                //Dim Code 4.1 // Angle Dimension
                if (DN.DimIDNo4Dot1)
                {
                    double Dist = (Distance.PointToPoint(BC.Points.P4, BC.Points.P3) * (0.13)) + 20;
                    Com.InsertAngleDim(CView, BC.Points.P4, BC.Points.P3, "Bottom", Dist);

                }

            }

        }

        private void AppySectionDim()
        {
            StraightDimensionSet xDim = null;
            PointList pointList = new PointList();
            Vector Vect = new Vector(0, 1, 0);
            PointList TempList = new PointList();

            Point ViewPoint = Com.CenterPoint(CView.RestrictionBox.MinPoint, CView.RestrictionBox.MaxPoint);
            Point BeamPoint = dc.NearestPoint(MainBeam.StartPoint, MainBeam.EndPoint, ViewPoint);


            //Point BeamPoint = MainBeam.StartPoint;

            //if (BeamPoint.Z < MainBeam.EndPoint.Z)
            //    BeamPoint = MainBeam.EndPoint;

            if (BC.EP != null && BC.EP.AllPoints?.Count > 0)
            {
                Vect = new Vector(0, 1, 0);
                TempList = dc.ChangePints(BC.EP.AllPoints, CView, Vect);

                // Dim No 6
                if (DN.DimIDNo6)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    pointList.Add(BeamPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);
                }


                // Dim No 7
                if (DN.DimIDNo7)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                }

                // Dim No 7.1
                if (DN.DimIDNo7Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "X"));
                    pointList.Add(BC.EP.EndPlate.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);

                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "X"));
                    pointList.Add(BC.EP.EndPlate.Points.P4);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                }

                if (DN.DimIDNo7 || DN.DimIDNo7Dot1)
                    BC.PC.DistTop += BC.PC.DistInc;


                // Dim No 8.1
                if (DN.DimIDNo8Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(BC.EP.EndPlate.Points.P1);
                    pointList.Add(BeamPoint);
                    pointList.Add(BC.EP.EndPlate.Points.P4);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);
                }

                // Dim No 8
                if (DN.DimIDNo8)
                {
                    pointList = new PointList();
                    pointList.Add(BC.EP.EndPlate.Points.P1);
                    pointList.Add(BC.EP.EndPlate.Points.P4);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);
                }


                Vect = new Vector(-1, 0, 0);
                TempList = dc.ChangePints(BC.EP.AllPoints, CView, Vect);
                // Dim No 9.1
                if (DN.DimIDNo9Dot1)
                {
                    bool IsDim = false;

                    pointList = new PointList();
                    if (BC.EP.TopBoltP != null)
                        pointList.Add(Com.MaxPofX(BC.EP.TopBoltP, "Y", Com.MaxP(BC.EP.TopBoltP, "X").X));
                    else
                        pointList.Add(Com.MaxPofX(BC.EP.MidBoltP, "Y", Com.MaxP(BC.EP.MidBoltP, "X").X));

                    pointList.Add(BC.EP.EndPlate.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                        IsDim = true;
                    }



                    pointList = new PointList();

                    if (BC.EP.BottBoltP != null)
                        pointList.Add(Com.MinPofX(BC.EP.BottBoltP, "Y", Com.MaxP(BC.EP.BottBoltP, "X").X));
                    else
                        pointList.Add(Com.MinPofX(BC.EP.MidBoltP, "Y", Com.MaxP(BC.EP.MidBoltP, "X").X));

                    pointList.Add(BC.EP.EndPlate.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                        IsDim = true;
                    }


                    if (IsDim)
                        BC.PC.DistLeft += BC.PC.DistInc;
                }

                // Dim No 9
                if (DN.DimIDNo9)
                {
                    pointList = new PointList();
                    pointList.AddRange(dc.ChangePints(BC.EP.AllPoints, CView, Vect));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByLeftX(xDim, BC.PC);
                }


                Vect = new Vector(1, 0, 0);
                // Dim No 15, 16
                if (DN.DimIDNo15 || DN.DimIDNo16)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo15) // Dim 15
                        pointList.Add(BC.EP.EndPlate.Points.P4);

                    pointList.Add(BC.Points.P4);

                    if (DN.DimIDNo16) // Dim 16
                        pointList.Add(BC.EP.EndPlate.Points.P3);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }

                }

                // Dim No 17
                if (DN.DimIDNo17)
                {
                    pointList = new PointList();
                    pointList.Add(BC.EP.EndPlate.Points.P4);
                    pointList.Add(BC.EP.EndPlate.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }

                }


            }

        }

        #region Get Data

        private void GetBeamClass(TSD.View CView)
        {
            if (ViewName == "Front View")
            {
                BC = new BeamClass_BEP2();
                BC.beam = MainBeam;
                BC.Points = GetBeamPoints();

                List<TSM.Part> PartListC = BC.beam.GetAssembly().GetSecondaries().OfType<TSM.Part>().ToList();

                GetEndPlateProperties(PartListC);

                PartListC.Add(MainBeam);

                TSM.Part LeftPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.X ascending select p).FirstOrDefault();
                TSM.Part RightPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.X descending select p).FirstOrDefault();
                TSM.Part TopPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.Y descending select p).FirstOrDefault();
                TSM.Part BottPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.Y ascending select p).FirstOrDefault();

                BC.PC = new PlacingClass();
                BC.PC.TopY = TopPart.GetSolid().MaximumPoint.Y;
                BC.PC.BottomY = BottPart.GetSolid().MinimumPoint.Y;
                BC.PC.LeftX = LeftPart.GetSolid().MinimumPoint.X;// Math.Round(CView.RestrictionBox.MinPoint.X);
                BC.PC.RightX = RightPart.GetSolid().MaximumPoint.X;

                if (BC.EP?.EndPlate != null)
                {
                    BC.PC.TopY = BC.EP.EndPlate.Points.P1.Y;
                    BC.PC.BottomY = BC.EP.EndPlate.Points.P2.Y;
                }

                double AvScale = 12;
                double AvDistInc = 100;
                double DistPerScale = AvDistInc / AvScale;
                double CScale = CView.Attributes.Scale;
                BC.PC.DistInc = CScale * DistPerScale;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;
            }
            else if (ViewName == "Section View")
            {
                if (CView.Name.Contains("D") || CView.Name.Contains("E"))
                { }

                BC = new BeamClass_BEP2();
                BC.beam = MainBeam;
                BC.Points = Com.GetPartPoints(MainBeam);
                List<TSM.Part> PartListC = BC.beam.GetAssembly().GetSecondaries().OfType<TSM.Part>().ToList();

                double MinZ = CView.RestrictionBox.MinPoint.Z - 150;
                double MaxZ = CView.RestrictionBox.MaxPoint.Z + 150;
                PointList VertList = dc.GetVertexList(MainBeam.GetSolid());
                List<Point> PList = VertList.OfType<Point>().Where(x => x.Z > MinZ).ToList();

                Point ViewPoint = Com.CenterPoint(CView.RestrictionBox.MinPoint, CView.RestrictionBox.MaxPoint);
                Point BeamPoint = dc.NearestPoint(MainBeam.StartPoint, MainBeam.EndPoint, ViewPoint);
                if (Com.IsEqualPoints(BeamPoint, MainBeam.StartPoint))
                    PList = VertList.OfType<Point>().Where(x => x.Z < MaxZ).ToList();


                BC.Points.P1 = Com.MaxPofX(PList, "Y", Com.MinP(PList, "X").X);
                BC.Points.P2 = Com.MinPofX(PList, "Y", Com.MinP(PList, "X").X);
                BC.Points.P3 = Com.MinPofX(PList, "Y", Com.MaxP(PList, "X").X);
                BC.Points.P4 = Com.MaxPofX(PList, "Y", Com.MaxP(PList, "X").X);

                List<TSM.Part> PartList = (from p in PartListC where Com.IsViewObj(p, CView) select p).ToList();
                Point CentP = Com.CenterPoint(MainBeam.StartPoint, MainBeam.EndPoint);

                //List<TSM.Part> PartListF = (from p in PartList where !Com.IsCode(p) select p).ToList();

                GetEndPlatePropertiesS(PartList);

                if (PartList == null || PartList.Count == 0)
                    PartList.Add(MainBeam);

                List<Point> RefPoints = MainBeam.GetReferenceLine(false).OfType<Point>().ToList();

                //PartListF.Add(MainBeam);
                TSM.Part LeftPart = (from p in PartList orderby p.GetSolid().MinimumPoint.X ascending select p).FirstOrDefault();
                TSM.Part RightPart = (from p in PartList orderby p.GetSolid().MaximumPoint.X descending select p).FirstOrDefault();
                TSM.Part TopPart = (from p in PartList orderby p.GetSolid().MaximumPoint.Y descending select p).FirstOrDefault();
                TSM.Part BottPart = (from p in PartList orderby p.GetSolid().MinimumPoint.Y ascending select p).FirstOrDefault();

                BC.PC = new PlacingClass();
                BC.PC.TopY = TopPart.GetSolid().MaximumPoint.Y;
                BC.PC.BottomY = BottPart.GetSolid().MinimumPoint.Y;


                BC.PC.LeftX = LeftPart.GetSolid().MinimumPoint.X;// Math.Round(CView.RestrictionBox.MinPoint.X);
                BC.PC.RightX = RightPart.GetSolid().MaximumPoint.X;



                double AvScale = 12;
                double AvDistInc = 100;
                double DistPerScale = AvDistInc / AvScale;
                double CScale = CView.Attributes.Scale;
                BC.PC.DistInc = CScale * DistPerScale;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;
            }

        }


        private PartPoints GetBeamPoints()
        {
            PartPoints PP = new PartPoints();
            PointList Plist = Com.GetVertxPointsD(MainBeam);
            PP.P1 = Com.MinPofY(Plist, "X", Com.MaxP(Plist, "Y").Y);
            PP.P2 = Com.MinPofY(Plist, "X", Com.MinP(Plist, "Y").Y);

            PP.P3 = Com.MaxPofY(Plist, "X", Com.MinP(Plist, "Y").Y);
            PP.P4 = Com.MaxPofY(Plist, "X", Com.MaxP(Plist, "Y").Y);


            return PP;
        }

        private bool IsNotMianView(TSM.Part EP)
        {
            bool RetCheck = false;

            if (EP is Beam)
            {
                Beam EPB = EP as Beam;
                Point P1 = new Point(EPB.StartPoint.X, EPB.StartPoint.Y);
                Point P2 = new Point(EPB.EndPoint.X, EPB.EndPoint.Y);
                double Ydist = Math.Abs((EPB.StartPoint.Y - EPB.EndPoint.Y));
                double Dist = Distance.PointToPoint(P1, P2);
                if (Dist < 20 || Ydist < 20)
                    RetCheck = true;
            }


            return RetCheck;
        }


        public static bool IsViewObj(TSM.Part part, TSD.View CView)
        {
            bool RetCheck = false;
            bool RetCheckZ = false;
            bool RetCheckX = false;
            double MinZ = CView.RestrictionBox.MinPoint.Z - 150;
            double MaxZ = CView.RestrictionBox.MaxPoint.Z + 150;

            double MinZP = part.GetSolid().MinimumPoint.Z;
            double MaxZP = part.GetSolid().MaximumPoint.Z;

            double MinX = CView.RestrictionBox.MinPoint.X;
            double MaxX = CView.RestrictionBox.MaxPoint.X;

            double MinXP = part.GetSolid().MinimumPoint.X;
            double MaxXP = part.GetSolid().MaximumPoint.X;

            RetCheckZ = ((MinZP >= MinZ && MaxZP <= MaxZ) || ((MinZ >= MinZP && MinZ <= MaxZP) || (MaxZ >= MinZP && MaxZ <= MaxZP)));

            RetCheckX = ((MinXP >= MinX && MaxXP <= MaxX) || ((MinX >= MinXP && MinX <= MaxXP) || (MaxX >= MinXP && MaxX <= MaxXP)));

            if (RetCheckZ && RetCheckX)
                RetCheck = true;

            return RetCheck;

        }

        private void GetEndPlateProperties(List<TSM.Part> PartListC)
        {
            TSM.Part EndPlate = null;
            Point CentP = Com.CenterPoint(BC.beam.StartPoint, BC.beam.EndPoint);
            double Lenght = (BC.beam.GetSolid().MaximumPoint.X - BC.beam.GetSolid().MinimumPoint.X) / 8;
            double MinX = BC.beam.GetSolid().MinimumPoint.X + Lenght;
            double MaxX = BC.beam.GetSolid().MaximumPoint.X - Lenght;

            if (Position == "Left")
                EndPlate = (from p in PartListC where dc.IsPlateSideViewN(p) && (p.GetSolid().MaximumPoint.X < CentP.X && p.GetSolid().MinimumPoint.X <= MinX) select p).FirstOrDefault();
            else
                EndPlate = (from p in PartListC where dc.IsPlateSideViewN(p) && (p.GetSolid().MinimumPoint.X > CentP.X && p.GetSolid().MaximumPoint.X >= MaxX) select p).FirstOrDefault();

            if (EndPlate != null)
            {
                BC.EP = new EndPlateClass();
                BC.EP.EndPlate = new PartClass();
                BC.EP.EndPlate.part = EndPlate;
                BC.EP.EndPlate.Points = dc.GetPartPointsSlop(EndPlate);

                List<BoltGroup> Bolts = Com.EnumtoArray(EndPlate.GetBolts()).OfType<BoltGroup>().ToList();
                if (Bolts != null && Bolts.Count > 0)
                {
                    PointList BoltsP = Com.GetBoltPoints(Bolts);

                    BC.EP.AllPoints = BoltsP;

                    List<Point> points = (from p in BoltsP.OfType<Point>() where p.Y > BC.Points.P1.Y orderby p.Y descending select p).ToList();

                    if (points != null && points.Count > 0)
                        BC.EP.TopBoltP = Com.PointToPointList(points);

                    points = (from p in BoltsP.OfType<Point>() where p.Y < BC.Points.P2.Y orderby p.Y descending select p).ToList();
                    if (points != null && points.Count > 0)
                        BC.EP.BottBoltP = Com.PointToPointList(points);

                    points = (from p in BoltsP.OfType<Point>() where p.Y < BC.Points.P1.Y && p.Y > BC.Points.P2.Y orderby p.Y descending select p).ToList();
                    if (points != null && points.Count > 0)
                        BC.EP.MidBoltP = Com.PointToPointList(points);
                }
            }




        }

        private void GetEndPlatePropertiesS(List<TSM.Part> PartListC)
        {
            TSM.Part EndPlate = null;

            Point CentP = Com.CenterPoint(BC.beam.StartPoint, BC.beam.EndPoint);
            EndPlate = (from p in PartListC where Com.HasBolt(p) && !dc.IsPlateSideViewN(p) && !IsNotMianView(p) select p).FirstOrDefault();

            if (EndPlate != null)
            {
                BC.EP = new EndPlateClass();
                BC.EP.EndPlate = new PartClass();
                BC.EP.EndPlate.part = EndPlate;
                BC.EP.EndPlate.Points = Com.GetPartPoints(EndPlate);

                List<BoltGroup> Bolts = Com.EnumtoArray(EndPlate.GetBolts()).OfType<BoltGroup>().ToList();
                if (Bolts != null && Bolts.Count > 0)
                {
                    PointList BoltsP = Com.GetBoltPoints(Bolts);

                    BC.EP.AllPoints = BoltsP;

                    List<Point> points = (from p in BoltsP.OfType<Point>() where p.Y > BC.Points.P1.Y orderby p.Y descending select p).ToList();

                    if (points != null && points.Count > 0)
                        BC.EP.TopBoltP = Com.PointToPointList(points);

                    points = (from p in BoltsP.OfType<Point>() where p.Y < BC.Points.P2.Y orderby p.Y descending select p).ToList();
                    if (points != null && points.Count > 0)
                        BC.EP.BottBoltP = Com.PointToPointList(points);

                    points = (from p in BoltsP.OfType<Point>() where p.Y < BC.Points.P1.Y && p.Y > BC.Points.P2.Y orderby p.Y descending select p).ToList();
                    if (points != null && points.Count > 0)
                        BC.EP.MidBoltP = Com.PointToPointList(points);
                }
            }



        }

        #endregion

        #region Helping Methods
        private double GetPartWidth(TSM.Part part)
        {
            return (part.GetSolid().MaximumPoint.X - part.GetSolid().MinimumPoint.X);
        }

        #endregion

        private class EndPlateClass
        {
            public PartClass EndPlate { get; set; }
            public PointList TopBoltP { get; set; }
            public PointList MidBoltP { get; set; }
            public PointList BottBoltP { get; set; }
            public PointList AllPoints { get; set; }
        }

        private class BeamClass_BEP2
        {
            public Beam beam { get; set; }
            public EndPlateClass EP { get; set; }
            public PartPoints Points { get; set; }
            public PlacingClass PC { get; set; }

        }

    }

}
