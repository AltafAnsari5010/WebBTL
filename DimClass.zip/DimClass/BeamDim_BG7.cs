﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Tekla.Structures;
using Tekla.Structures.Drawing;
using Tekla.Structures.Geometry3d;
using Tekla.Structures.Model;
using TSD = Tekla.Structures.Drawing;
using TSM = Tekla.Structures.Model;
using VirtueleDrawingAutomation;
using TSDD = Tekla.Structures.Datatype;
using TSG = Tekla.Structures.Geometry3d;

namespace Auto_Detailing_Tool_Beam
{
    public class BeamDim_BG7
    {
        #region Global Variables
        DimCom dc = new DimCom();
        StraightDimensionSet.StraightDimensionSetAttributes StAtrr = new StraightDimensionSet.StraightDimensionSetAttributes("standard");
        StraightDimensionSet.StraightDimensionSetAttributes RdAtrr = new StraightDimensionSet.StraightDimensionSetAttributes("standard");

        public Beam MainBeam = null;
        VirtueleDrawingAutomation.Json.DrawingAttributeInfoJson.AttributeFiles dimAttrClass = null;
        List<TSD.StraightDimension> KnockDim = new List<StraightDimension>();
        BeamClass_BG7 BC = null;
        VirtueleDrawingAutomation.Json.AutoDimensionTypesJson.BG7Json DN = null;
        string Position = "Left";
        TSD.View CView = null;
        #endregion

        public void ApplyDim(TSD.View CView, string ViewName, AutoDimensioningTypes autoDimensioningTypes, DrawingAttributeInfo drawingAttributeInfo, string Position)
        {
            try
            {
                Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane());
                //Set model everything to the view
                Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane(CView.DisplayCoordinateSystem));

                this.CView = CView;
                this.dimAttrClass = drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files;
                this.DN = autoDimensioningTypes.Bg7;
                this.Position = Position;
                StAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.StandardDimension);
                RdAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.RunningDimension);
                this.MainBeam = (Com.MyModel.SelectModelObject(new Identifier((CView.GetDrawing() as AssemblyDrawing).AssemblyIdentifier.ID)) as TSM.Assembly).GetMainPart() as TSM.Beam;
                this.MainBeam.Select();
                string ProType = Com.GetProType(MainBeam);
                BC = GetBeamClassClass(CView);

                if (Position == "Left")
                {
                    // TestDim();
                    if (ViewName == "Front View")
                        ApplyDimTypeLeft(CView);
                }

                else if (Position == "Right")
                {
                    // TestDim();
                    if (ViewName == "Front View")
                        ApplyDimTypeRight(CView);
                }
            }
            catch (Exception ex)
            { }

            Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane());


        }

        private void ApplyDimTypeLeft(TSD.View CView)
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;

            Vector Vect = new Vector(0, 1, 0);

            TSD.PointList TempList = new PointList();
            Point TopP = null;
            Point BottP = null;

            if (BC.TopGP?.BoltS != null)
            {
                BC.PC.DistLeft = BC.PC.DistInc;
                Vect = new Vector(-1, 0, 0);
                TempList = dc.ChangePints(BC.TopGP.BoltS, CView, Vect);
                TopP = Com.MaxP(TempList, "Y");
                // Dim No 1.2
                if (DN.DimIDNo1Dot2)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    pointList.Add(BC.TopGP.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                }

                // Dim No 1
                if (DN.DimIDNo1)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);


                }

                // Dim No 27
                if (DN.DimIDNo27)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "Y"));
                    pointList.Add(BC.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                }

                if (DN.DimIDNo1 || DN.DimIDNo27)
                    BC.PC.DistLeft += BC.PC.DistInc;

                // Dim No 1.1
                if (DN.DimIDNo1Dot1 && TempList.Count > 2)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                        Com.GroupDim(xDim);
                    }
                }

                // Dim No 28
                if (DN.DimIDNo28 && BC.LeftBolt != null)
                {
                    PointList PtList = Com.GetBoltPoints(BC.LeftBolt);
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "Y"));
                    pointList.Add(Com.MaxPofX(PtList, "Y", Com.MaxP(PtList, "X").X));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                }

                if ((DN.DimIDNo28 && BC.LeftBolt != null) || (DN.DimIDNo1Dot1 && TempList.Count > 2))
                    BC.PC.DistLeft += BC.PC.DistInc;

                Vect = new Vector(0, 1, 0);
                TempList = Com.GetBoltPoints(BC.TopGP.BoltS);
              
                if(BC.LeftBolt!=null)
                    TempList.AddRange(Com.GetBoltPoints(BC.LeftBolt));

                TempList = dc.ChangePints(TempList, CView, Vect);
               
                // Dim No 5 // RD Dim
                if (DN.DimIDNo5)
                {
                    BC.PC.DistTop += BC.PC.DistInc;
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);
                }
                else if (DN.DimIDNo5Dot2) // Dim No 5.2
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    pointList.Add(BC.TopGP.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);

                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(Com.MinP(TempList,"X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);
                }

               
            }

            if (BC.BottGP?.BoltS != null)
            {

                TempList = Com.GetBoltPoints(BC.BottGP.BoltS);
                BottP = Com.MinP(TempList, "Y");
            }

            if (BC.LeftBolt != null)
            {
                BC.PC.DistLeft = (BC.PC.DistInc);

                Vect = new Vector(-1, 0, 0);

                TempList = dc.ChangePints(BC.LeftBolt, CView, Vect);

                if (TopP == null)
                    TopP = Com.MaxP(TempList, "Y");
                else if (BottP == null)
                    BottP = Com.MinP(TempList, "Y");


                if (BC.TopGP?.RefPBrace != null || BC.BottGP?.RefPBrace != null)
                    BC.PC.DistLeft += (BC.PC.DistInc);

                // Dim No 31
                if (DN.DimIDNo31)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P2);
                    pointList.Add(Com.MinP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByLeftX(xDim, BC.PC);

                }

                // Dim No 2
                if (DN.DimIDNo2)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);

                }

                // Dim No 2
                if (DN.DimIDNo3)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                }

                // Dim No 23
                if (DN.DimIDNo23 && BC.BottGP?.BoltS != null)
                {
                    PointList PtList = Com.GetBoltPoints(BC.BottGP.BoltS);
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "Y"));
                    pointList.Add(Com.MaxP(PtList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                }

                if (DN.DimIDNo2 || DN.DimIDNo3 || DN.DimIDNo23)
                    BC.PC.DistLeft += BC.PC.DistInc;

                // Dim No 3.1
                if (DN.DimIDNo3Dot1)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlaceByLeftX(xDim, BC.PC);
                        Com.GroupDim(xDim);
                    }
                }

                // Dim No24
                if (DN.DimIDNo24)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);

                    if (BC.TopGP?.RefPBrace != null)
                        pointList.Add(BC.TopGP?.RefPBrace);
                    else if (BC.BottGP?.RefPBrace != null)
                        pointList.Add(BC.BottGP?.RefPBrace);

                    pointList.Add(BC.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                    }
                }

            }

            if (BC.BottGP?.BoltS != null)
            {
                BC.PC.DistLeft = (BC.PC.DistInc * 3);
                Vect = new Vector(-1, 0, 0);
                TempList = dc.ChangePints(BC.BottGP.BoltS, CView, Vect);

                // Dim No 15
                if (DN.DimIDNo15)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P2);
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistInc, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistInc);

                }

                // Dim No 1.2
                if (DN.DimIDNo1Dot2)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P1);
                    pointList.Add(Com.MinP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistInc, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistInc);
                }



                // Dim No 1
                if (DN.DimIDNo1)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByLeftX(xDim, BC.PC);
                }

                // Dim No 1.1
                if (DN.DimIDNo1Dot1)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlaceByLeftX(xDim, BC.PC);
                        Com.GroupDim(xDim);
                    }
                }

                // Dim No 4
                if (DN.DimIDNo4)
                {
                    BC.PC.DistLeft += BC.PC.DistInc;
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByLeftX(xDim, BC.PC);

                }


                Vect = new Vector(0, -1, 0);
                TempList = dc.ChangePints(BC.BottGP.BoltS, CView, Vect);

                // Dim No 5 // RD Dim
                if (DN.DimIDNo5)
                {
                    BC.PC.DistBot += BC.PC.DistInc;
                    pointList = new PointList();
                    pointList.Add(BC.Points.P2);
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);
                }
                else if (DN.DimIDNo5Dot2) // Dim No 5.2
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    pointList.Add(BC.TopGP.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);

                    pointList = new PointList();
                    pointList.Add(BC.Points.P2);
                    pointList.Add(Com.MinP(TempList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);
                }

            }

            //if (TopP != null && BottP != null)
            //    Com.DrawLine(CView, TopP, BottP);

            CreateLine(BC.TopGP?.BoltS, BC.LeftBolt, BC.BottGP?.BoltS);

            Vect = new Vector(-1, 0, 0);

            // Dim No 17
            if (DN.DimIDNo17)
            {
                StraightDimensionSet.StraightDimensionSetAttributes ElAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.ElevationDimension);
                ElAtrr.DimensionType = DimensionSetBaseAttributes.DimensionTypes.Elevation;
                ElAtrr.Arrowhead.Head = ArrowheadTypes.FilledArrow;
                pointList = new PointList();

                if (MainBeam.StartPoint.X > MainBeam.EndPoint.X)
                {
                    pointList.Add(MainBeam.EndPoint);
                    pointList.Add(MainBeam.EndPoint);

                }
                else
                {
                    pointList.Add(MainBeam.StartPoint);
                    pointList.Add(MainBeam.StartPoint);
                }


                xDim = dc.InsertDimm(CView, pointList, Vect, -(BC.PC.DistLeft), ElAtrr);
                if (xDim != null)
                {
                    xDim.Distance = -(BC.PC.DistLeft);
                    xDim.Modify();
                }
                BC.PC.DistLeft += BC.PC.DistInc;

            }

            if (BC.TopGP?.GussetPlate != null && BC.BottGP?.GussetPlate != null)
            {
                //Dim Code 16
                if (DN.DimIDNo16)
                {
                    Vect = new Vector(-1, 0, 0);
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P1);
                    pointList.Add(BC.TopGP.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByLeftX(xDim, BC.PC);
                }
            }

            if (BC.TopGP?.GussetPlate != null)
            {

                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;

                PointList MidPList = Com.GetBoltPoints(BC.TopGP.BoltM);
                TempList = Com.GetBoltPoints(BC.TopGP.BoltM);
                TSG.Line YLine = new TSG.Line(BC.TopGP.Points.P4, BC.TopGP.Points.P5);
                //TSG.Line XLine = new TSG.Line(Com.MinP(TempList, "Y"), Com.MaxP(TempList, "Y"));
                TSG.Line XLine = new TSG.Line(BC.TopGP.IntPoint, BC.TopGP.RefPBrace);
                Vector LeftVect = BC.TopGP.BoltM.GetCoordinateSystem().AxisY;

                if (LeftVect.X > 0)
                    LeftVect = dc.ChangeVector(LeftVect);

                Vector RightVect = BC.TopGP.BoltM.GetCoordinateSystem().AxisY;
                if (RightVect.X < 0)
                    RightVect = dc.ChangeVector(RightVect);

                Vector TopVect = BC.TopGP.BoltM.GetCoordinateSystem().AxisX;
                if (TopVect.Y < 0)
                    TopVect = dc.ChangeVector(TopVect);

                Vector BottVect = BC.TopGP.BoltM.GetCoordinateSystem().AxisX;
                if (BottVect.Y > 0)
                    BottVect = dc.ChangeVector(BottVect);


                MidPList = dc.ChangePints(BC.TopGP.BoltM, CView, RightVect);


                #region RD Dimensions

                BC.PC.DistTop += (BC.PC.DistInc * 2);
                //RD Dim
                Vect = new Vector(0, 1, 0);

                // Dim No 7.2
                if (DN.DimIDNo7Dot2 && BC.TopGP.IntPointB.X > BC.Points.P1.X)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(BC.TopGP.IntPointB);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);

                    BC.PC.DistTop += BC.PC.DistInc;
                }

                // Dim No 7.1
                if (DN.DimIDNo7Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(BC.TopGP.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);


                    BC.PC.DistTop += BC.PC.DistInc;
                }

                // Dim No 7
                if (DN.DimIDNo7)
                {
                    TempList = Com.GetBoltPoints(BC.TopGP.BoltM);
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(Com.MinP(TempList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);

                    BC.PC.DistTop += BC.PC.DistInc;
                }

                #endregion

                #region Top Straight Dim
                Vect = new Vector(0, 1, 0);
                BC.PC.DistRight = (BC.PC.DistInc * 2);
                // Dim No 5.1
                if (DN.DimIDNo5Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P1);
                    pointList.Add(BC.TopGP.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistRight);

                }

                // Dim No 8
                if (DN.DimIDNo8)
                {
                    pointList = new PointList();
                    pointList.AddRange(MidPList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistInc, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistRight);

                }

                //// Dim No 29
                //if (DN.DimIDNo29)
                //{
                //    pointList = new PointList();
                //    pointList.Add(BC.TopGP.Points.P1);
                //    pointList.Add(BC.TopGP.Points.P3);
                //    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                //    if (xDim != null)
                //    {
                //        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                //        BC.PC.DistTop += BC.PC.DistInc;
                //    }
                //}


                // Dim No 25
                if (DN.DimIDNo25)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P1);
                    pointList.Add(BC.TopGP.IntPointB);
                    pointList.Add(BC.TopGP.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }

                // Dim No 26
                if (DN.DimIDNo26)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P2);
                    pointList.Add(BC.TopGP.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }


                }

                BC.PC.DistTop = BC.PC.DistInc;
                #endregion

                #region Right Straight Dim
                Vect = new Vector(1, 0, 0);
                BC.PC.DistRight = (BC.PC.DistInc * 2);


                // Dim No 12
                if (DN.DimIDNo12)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(MidPList, "Y"));
                    pointList.Add(Com.MaxP(MidPList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.TopGP.Points.P3.X, BC.PC.DistRight);

                }


                // Dim No 9
                if (DN.DimIDNo9)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(MidPList, "Y"));
                    pointList.Add(BC.TopGP.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.TopGP.Points.P3.X, BC.PC.DistRight);
                }

                if (DN.DimIDNo9 || DN.DimIDNo12)
                    BC.PC.DistRight += BC.PC.DistInc;

                // Dim No 13
                if (DN.DimIDNo13)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.IntPoint);
                    pointList.Add(BC.TopGP.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.TopGP.Points.P3.X, BC.PC.DistRight);

                }


                #endregion

                #region Diagonal Left

                TempList = dc.ChangePints(BC.TopGP.BoltM, CView, RightVect);
                // Dim No 15.1
                if (DN.DimIDNo21Dot1 || DN.DimIDNo21)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo21Dot1) // Dim No 21.1
                        pointList.Add(Com.MinP(TempList, "Y"));

                    pointList.Add(BC.TopGP.IntPointB);

                    if (DN.DimIDNo21) // Dim No 21
                        pointList.Add(BC.TopGP.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);

                }

                TempList = dc.ChangePints(BC.TopGP.BoltM, CView, LeftVect);
                // Dim No 6.1
                if (DN.DimIDNo6Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    pointList.Add(BC.TopGP.Points.P5);
                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);

                }

                // Dim No 6
                if (DN.DimIDNo6)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);

                }

                // Dim No 22
                if (DN.DimIDNo22)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.RefPBrace);
                    pointList.Add(Com.MinP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);

                }

                if (DN.DimIDNo6Dot1 || DN.DimIDNo6 || DN.DimIDNo22)
                    BC.PC.DistLeft += BC.PC.DistInc;


                // Dim No 6.2
                if (DN.DimIDNo6Dot2)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);
                        Com.GroupDim(xDim);
                    }

                }
                #endregion

                //  Com.DrawLineDotted(CView, BC.TopGP.IntPoint, BC.TopGP.RefPBrace);

                //Dim Code 11 // Angle Dimension
                if (DN.DimIDNo11)
                {
                   double Dist = CalcDistAngel(BC.TopGP.RefPBrace, BC.TopGP.IntPoint);
                    Com.InsertAngleDim(CView, BC.TopGP.RefPBrace, BC.TopGP.IntPoint, "Top", Dist);
                }
            }

            if (BC.BottGP?.GussetPlate != null)
            {

                BC.PC.DistLeft = BC.PC.DistInc;
                PointList MidPList = Com.GetBoltPoints(BC.BottGP.BoltM);
                TempList = Com.GetBoltPoints(BC.BottGP.BoltM);
                TSG.Line YLine = new TSG.Line(BC.BottGP.Points.P4, BC.BottGP.Points.P5);
                TSG.Line XLine = new TSG.Line(BC.BottGP.IntPoint, BC.BottGP.RefPBrace);
                //TSG.Line XLine = new TSG.Line(Com.MinP(TempList, "Y"), Com.MaxP(TempList, "Y"));
                Vector LeftVect = BC.BottGP.BoltM.GetCoordinateSystem().AxisY;

                if (LeftVect.X > 0)
                    LeftVect = dc.ChangeVector(LeftVect);

                Vector RightVect = BC.BottGP.BoltM.GetCoordinateSystem().AxisY;
                if (RightVect.X < 0)
                    RightVect = dc.ChangeVector(RightVect);

                Vector TopVect = BC.BottGP.BoltM.GetCoordinateSystem().AxisX;
                if (TopVect.Y < 0)
                    TopVect = dc.ChangeVector(TopVect);

                Vector BottVect = BC.BottGP.BoltM.GetCoordinateSystem().AxisX;
                if (BottVect.Y > 0)
                    BottVect = dc.ChangeVector(BottVect);


                MidPList = dc.ChangePints(BC.BottGP.BoltM, CView, RightVect);


                #region RD Dimensions

                BC.PC.DistBot += BC.PC.DistInc;
                //RD Dim
                Vect = new Vector(0, -1, 0);

                // Dim No 7.2
                if (DN.DimIDNo7Dot2 && BC.BottGP.IntPointB.X > BC.Points.P1.X)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(BC.BottGP.IntPointB);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }


                }

                // Dim No 7.1
                if (DN.DimIDNo7Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(BC.BottGP.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }

                // Dim No 7
                if (DN.DimIDNo7)
                {
                    TempList = Com.GetBoltPoints(BC.BottGP.BoltM);
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(Com.MinP(TempList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }

                #endregion

                #region Bottom Straight Dim
                Vect = new Vector(0, -1, 0);
                BC.PC.DistRight = (BC.PC.DistInc * 2);
                // Dim No 5.1
                if (DN.DimIDNo5Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P1);
                    pointList.Add(BC.BottGP.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistRight);

                }

                // Dim No 8
                if (DN.DimIDNo8)
                {
                    pointList = new PointList();
                    pointList.AddRange(MidPList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistInc, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistRight);

                }

                // Dim No 25
                if (DN.DimIDNo25)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P1);
                    pointList.Add(BC.BottGP.IntPointB);
                    pointList.Add(BC.BottGP.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }

                // Dim No 26
                if (DN.DimIDNo26)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P2);
                    pointList.Add(BC.BottGP.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }


                }

                BC.PC.DistBot = BC.PC.DistInc;
                #endregion

                #region Right Straight Dim
                Vect = new Vector(1, 0, 0);
                BC.PC.DistRight = (BC.PC.DistInc * 2);


                // Dim No 12
                if (DN.DimIDNo12)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(MidPList, "Y"));
                    pointList.Add(Com.MaxP(MidPList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.BottGP.Points.P3.X, BC.PC.DistRight);

                }


                // Dim No 9
                if (DN.DimIDNo9)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(MidPList, "Y"));
                    pointList.Add(BC.BottGP.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.BottGP.Points.P3.X, BC.PC.DistRight);
                }

                if (DN.DimIDNo9 || DN.DimIDNo12)
                    BC.PC.DistRight += BC.PC.DistInc;

                // Dim No 13
                if (DN.DimIDNo13)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.IntPoint);
                    pointList.Add(BC.BottGP.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, BC.BottGP.Points.P3.X, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }

                }

                // Dim No 10
                if (DN.DimIDNo10)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(MidPList, "Y"));
                    pointList.Add(new Point(BC.BottGP.Points.P3.X, BC.Points.P1.Y));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, BC.BottGP.Points.P3.X, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }

                }

                // Dim No 14
                if (DN.DimIDNo14)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.IntPoint);
                    pointList.Add(new Point(BC.BottGP.Points.P3.X, BC.Points.P1.Y));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, BC.BottGP.Points.P3.X, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }

                }


                #endregion

                #region Diagonal Left

                TempList = dc.ChangePints(BC.BottGP.BoltM, CView, RightVect);
                // Dim No 15.1
                if (DN.DimIDNo21Dot1 || DN.DimIDNo21)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo21Dot1) // Dim No 21.1
                        pointList.Add(Com.MaxP(TempList, "Y"));

                    pointList.Add(BC.BottGP.IntPointB);

                    if (DN.DimIDNo21) // Dim No 21
                        pointList.Add(BC.BottGP.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);

                }

                TempList = dc.ChangePints(BC.BottGP.BoltM, CView, LeftVect);
                // Dim No 6.1
                if (DN.DimIDNo6Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "Y"));
                    pointList.Add(BC.BottGP.Points.P5);
                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);

                }

                // Dim No 6
                if (DN.DimIDNo6)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);

                }

                // Dim No 22
                if (DN.DimIDNo22)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.RefPBrace);
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);

                }

                if (DN.DimIDNo6Dot1 || DN.DimIDNo6 || DN.DimIDNo22)
                    BC.PC.DistLeft += BC.PC.DistInc;

                // Dim No 6.2
                if (DN.DimIDNo6Dot2)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);
                        Com.GroupDim(xDim);
                    }

                }

                #endregion

                // Com.DrawLineDotted(CView, BC.BottGP.IntPoint, BC.BottGP.RefPBrace);


                //Dim Code 11 // Angle Dimension
                if (DN.DimIDNo11)
                {
                    double Dist = CalcDistAngel(BC.BottGP.RefPBrace, BC.BottGP.IntPoint);
                    Com.InsertAngleDim(CView, BC.BottGP.RefPBrace, BC.BottGP.IntPoint, "Bottom", Dist);
                }



            }
        }

        private void ApplyDimTypeRight(TSD.View CView)
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;

            Vector Vect = new Vector(0, 1, 0);

            TSD.PointList TempList = new PointList();
            Point TopP = null;
            Point BottP = null;

            if (BC.TopGP?.BoltS != null)
            {
                BC.PC.DistRight = BC.PC.DistInc;
                Vect = new Vector(1, 0, 0);
                TempList = dc.ChangePints(BC.TopGP.BoltS, CView, Vect);
                TopP = Com.MaxP(TempList, "Y");
                // Dim No 1.2
                if (DN.DimIDNo1Dot2)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    pointList.Add(BC.TopGP.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                }

                // Dim No 1
                if (DN.DimIDNo1)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);


                }

                // Dim No 27
                if (DN.DimIDNo27 || DN.DimIDNo1Dot2)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "Y"));
                    pointList.Add(BC.Points.P4);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                }

                if (DN.DimIDNo1 || DN.DimIDNo27)
                    BC.PC.DistRight += BC.PC.DistInc;

                // Dim No 1.1
                if (DN.DimIDNo1Dot1 && TempList.Count > 2)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                        Com.GroupDim(xDim);
                    }
                }


                // Dim No 28
                if (DN.DimIDNo28 && BC.RightBolt != null)
                {
                    PointList PtList = Com.GetBoltPoints(BC.RightBolt);
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "Y"));
                    pointList.Add(Com.MaxPofX(PtList, "Y", Com.MaxP(PtList, "X").X));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                }

                if ((DN.DimIDNo28 && BC.LeftBolt != null) || (DN.DimIDNo1Dot1 && TempList.Count > 2))
                    BC.PC.DistLeft += BC.PC.DistInc;


                Vect = new Vector(0, 1, 0);
                Vect = new Vector(0, 1, 0);
                TempList = Com.GetBoltPoints(BC.TopGP.BoltS);

                if (BC.LeftBolt != null)
                    TempList.AddRange(Com.GetBoltPoints(BC.RightBolt));

                TempList = dc.ChangePints(TempList, CView, Vect);

                // Dim No 5 // RD Dim
                if (DN.DimIDNo5)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList,"X"));
                    pointList.Add(BC.TopGP.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);

                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);
                }
                else if (DN.DimIDNo5Dot2) // Dim No 5.2
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    pointList.Add(BC.TopGP.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);

                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(Com.MinP(TempList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);
                }

            }

            if (BC.BottGP?.BoltS != null)
            {

                TempList = Com.GetBoltPoints(BC.BottGP.BoltS);
                BottP = Com.MinP(TempList, "Y");
            }

            if (BC.RightBolt != null)
            {
                BC.PC.DistRight = (BC.PC.DistInc);

                Vect = new Vector(1, 0, 0);

                TempList = dc.ChangePints(BC.RightBolt, CView, Vect);

                if (TopP == null)
                    TopP = Com.MaxP(TempList, "Y");
                else if (BottP == null)
                    BottP = Com.MinP(TempList, "Y");


                if (BC.TopGP?.RefPBrace != null || BC.BottGP?.RefPBrace != null)
                    BC.PC.DistRight += (BC.PC.DistInc);

                // Dim No 31
                if (DN.DimIDNo31)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P3);
                    pointList.Add(Com.MinP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByRightX(xDim, BC.PC);

                }



                // Dim No 2
                if (DN.DimIDNo2)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P4);
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);

                }

                // Dim No 2
                if (DN.DimIDNo3)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                }

                // Dim No 23
                if (DN.DimIDNo23 && BC.BottGP?.BoltS != null)
                {
                    PointList PtList = Com.GetBoltPoints(BC.BottGP.BoltS);
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "Y"));
                    pointList.Add(Com.MaxP(PtList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                }

                if (DN.DimIDNo2 || DN.DimIDNo3 || DN.DimIDNo23)
                    BC.PC.DistRight += BC.PC.DistInc;

                // Dim No 3.1
                if (DN.DimIDNo3Dot1)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlaceByRightX(xDim, BC.PC);
                        Com.GroupDim(xDim);
                    }
                }

                // Dim No24
                if (DN.DimIDNo24)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P4);

                    if (BC.TopGP?.RefPBrace != null)
                        pointList.Add(BC.TopGP?.RefPBrace);
                    else if (BC.BottGP?.RefPBrace != null)
                        pointList.Add(BC.BottGP?.RefPBrace);

                    pointList.Add(BC.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                    }
                }

            }

            if (BC.BottGP?.BoltS != null)
            {
                BC.PC.DistRight = (BC.PC.DistInc * 3);
                Vect = new Vector(1, 0, 0);
                TempList = dc.ChangePints(BC.BottGP.BoltS, CView, Vect);

                // Dim No 15
                if (DN.DimIDNo15)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    pointList.Add(BC.Points.P3);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistInc, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistInc);

                }

                // Dim No 1.2
                if (DN.DimIDNo1Dot2)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "Y"));
                    pointList.Add(BC.BottGP.Points.P1);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistInc, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistInc);
                }



                // Dim No 1
                if (DN.DimIDNo1)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByRightX(xDim, BC.PC);
                }

                // Dim No 1.1
                if (DN.DimIDNo1Dot1)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlaceByRightX(xDim, BC.PC);
                        Com.GroupDim(xDim);
                    }
                }

                // Dim No 4
                if (DN.DimIDNo4)
                {
                    BC.PC.DistRight += BC.PC.DistInc;
                    pointList = new PointList();
                    pointList.Add(BC.Points.P4);
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByRightX(xDim, BC.PC);

                }

                Vect = new Vector(0, -1, 0);
                // Dim No 5
                if (DN.DimIDNo5)
                {
                    TempList = Com.GetBoltPoints(BC.BottGP.BoltS);
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    pointList.Add(BC.BottGP.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);
                }

                if (BC.TopGP?.BoltS == null)
                {
                    TempList = Com.GetBoltPoints(BC.BottGP.BoltS);

                    if (DN.DimIDNo5)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.Points.P2);
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                        if (xDim != null)
                            PL.DimPlaceByBottomY(xDim, BC.PC);
                    }
                    else if (DN.DimIDNo5Dot2)
                        {
                            pointList = new PointList();
                            pointList.Add(BC.Points.P2);
                            pointList.Add(Com.MinP(TempList, "X"));
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                        if (xDim != null)
                            PL.DimPlaceByBottomY(xDim, BC.PC);
                    }
                    
                }

            }

            //if (TopP != null && BottP != null)
            //    Com.DrawLine(CView, TopP, BottP);

            CreateLine(BC.TopGP?.BoltS, BC.RightBolt, BC.BottGP?.BoltS);

            if (BC.TopGP?.GussetPlate != null && BC.BottGP?.GussetPlate != null)
            {
                //Dim Code 16
                if (DN.DimIDNo16)
                {
                    Vect = new Vector(1, 0, 0);
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P1);
                    pointList.Add(BC.TopGP.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByRightX(xDim, BC.PC);
                }
            }

            if (BC.TopGP?.GussetPlate != null)
            {

                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;

                PointList MidPList = Com.GetBoltPoints(BC.TopGP.BoltM);
                TempList = Com.GetBoltPoints(BC.TopGP.BoltM);
                TSG.Line YLine = new TSG.Line(BC.TopGP.Points.P4, BC.TopGP.Points.P5);
                //TSG.Line XLine = new TSG.Line(Com.MinP(TempList, "Y"), Com.MaxP(TempList, "Y"));
                TSG.Line XLine = new TSG.Line(BC.TopGP.IntPoint, BC.TopGP.RefPBrace);
                Vector LeftVect = BC.TopGP.BoltM.GetCoordinateSystem().AxisY;

                if (LeftVect.X > 0)
                    LeftVect = dc.ChangeVector(LeftVect);

                Vector RightVect = BC.TopGP.BoltM.GetCoordinateSystem().AxisY;
                if (RightVect.X < 0)
                    RightVect = dc.ChangeVector(RightVect);

                Vector TopVect = BC.TopGP.BoltM.GetCoordinateSystem().AxisX;
                if (TopVect.Y < 0)
                    TopVect = dc.ChangeVector(TopVect);

                Vector BottVect = BC.TopGP.BoltM.GetCoordinateSystem().AxisX;
                if (BottVect.Y > 0)
                    BottVect = dc.ChangeVector(BottVect);


                MidPList = dc.ChangePints(BC.TopGP.BoltM, CView, RightVect);


                #region RD Dimensions

                BC.PC.DistTop += (BC.PC.DistInc * 2);
                //RD Dim
                Vect = new Vector(0, 1, 0);

                // Dim No 7.2
                if (DN.DimIDNo7Dot2 && BC.TopGP.IntPointB.X < BC.Points.P4.X)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(BC.TopGP.IntPointB);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);

                    BC.PC.DistTop += BC.PC.DistInc;
                }

                // Dim No 7.1
                if (DN.DimIDNo7Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(BC.TopGP.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);


                    BC.PC.DistTop += BC.PC.DistInc;
                }

                // Dim No 7
                if (DN.DimIDNo7)
                {
                    TempList = Com.GetBoltPoints(BC.TopGP.BoltM);
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(Com.MinP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);

                    BC.PC.DistTop += BC.PC.DistInc;
                }

                #endregion

                #region Top Straight Dim
                Vect = new Vector(0, 1, 0);
                BC.PC.DistLeft = (BC.PC.DistInc * 2);
                // Dim No 5.1
                if (DN.DimIDNo5Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P1);
                    pointList.Add(BC.TopGP.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistLeft);

                }

                // Dim No 8
                if (DN.DimIDNo8)
                {
                    pointList = new PointList();
                    pointList.AddRange(MidPList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistInc, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistLeft);

                }

                // Dim No 25
                if (DN.DimIDNo25)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P1);
                    pointList.Add(BC.TopGP.IntPointB);
                    pointList.Add(BC.TopGP.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }

                // Dim No 26
                if (DN.DimIDNo26)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P2);
                    pointList.Add(BC.TopGP.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }


                }

                BC.PC.DistTop = BC.PC.DistInc;
                #endregion

                #region Left Straight Dim
                Vect = new Vector(-1, 0, 0);
                BC.PC.DistLeft = (BC.PC.DistInc * 2);


                // Dim No 12
                if (DN.DimIDNo12)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(MidPList, "Y"));
                    pointList.Add(Com.MaxP(MidPList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.TopGP.Points.P3.X, BC.PC.DistLeft);

                }


                // Dim No 9
                if (DN.DimIDNo9)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(MidPList, "Y"));
                    pointList.Add(BC.TopGP.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.TopGP.Points.P3.X, BC.PC.DistLeft);
                }

                if (DN.DimIDNo9 || DN.DimIDNo12)
                    BC.PC.DistLeft += BC.PC.DistInc;

                // Dim No 13
                if (DN.DimIDNo13)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.IntPoint);
                    pointList.Add(BC.TopGP.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.TopGP.Points.P3.X, BC.PC.DistLeft);

                }


                #endregion

                #region Diagonal Right
                BC.PC.DistLeft = BC.PC.DistInc;
                TempList = dc.ChangePints(BC.TopGP.BoltM, CView, LeftVect);
                // Dim No 15.1
                if (DN.DimIDNo21Dot1 || DN.DimIDNo21)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo21Dot1) // Dim No 21.1
                        pointList.Add(Com.MinP(TempList, "Y"));

                    pointList.Add(BC.TopGP.IntPointB);

                    if (DN.DimIDNo21) // Dim No 21
                        pointList.Add(BC.TopGP.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);

                }

                TempList = dc.ChangePints(BC.TopGP.BoltM, CView, RightVect);
                // Dim No 6.1
                if (DN.DimIDNo6Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    pointList.Add(BC.TopGP.Points.P5);
                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);

                }

                // Dim No 6
                if (DN.DimIDNo6)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);

                }

                // Dim No 22
                if (DN.DimIDNo22)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.RefPBrace);
                    pointList.Add(Com.MinP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);

                }

                if (DN.DimIDNo6Dot1 || DN.DimIDNo6 || DN.DimIDNo22)
                    BC.PC.DistLeft += BC.PC.DistInc;


                // Dim No 6.2
                if (DN.DimIDNo6Dot2)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);
                        Com.GroupDim(xDim);
                    }

                }
                #endregion

                 Com.DrawLineDotted(CView, BC.TopGP.IntPoint, BC.TopGP.RefPBrace);

                //Dim Code 11 // Angle Dimension
                if (DN.DimIDNo11)
                {
                    double Dist = CalcDistAngel(BC.TopGP.RefPBrace, BC.TopGP.IntPoint);
                    Com.InsertAngleDim(CView, BC.TopGP.RefPBrace, BC.TopGP.IntPoint, "Top", Dist);
                }

            }

            if (BC.BottGP?.GussetPlate != null)
            {

                BC.PC.DistLeft = BC.PC.DistInc;
                PointList MidPList = Com.GetBoltPoints(BC.BottGP.BoltM);
                TempList = Com.GetBoltPoints(BC.BottGP.BoltM);
                TSG.Line YLine = new TSG.Line(BC.BottGP.Points.P4, BC.BottGP.Points.P5);
                TSG.Line XLine = new TSG.Line(BC.BottGP.IntPoint, BC.BottGP.RefPBrace);
                //TSG.Line XLine = new TSG.Line(Com.MinP(TempList, "Y"), Com.MaxP(TempList, "Y"));
                Vector LeftVect = BC.BottGP.BoltM.GetCoordinateSystem().AxisY;

                if (LeftVect.X > 0)
                    LeftVect = dc.ChangeVector(LeftVect);

                Vector RightVect = BC.BottGP.BoltM.GetCoordinateSystem().AxisY;
                if (RightVect.X < 0)
                    RightVect = dc.ChangeVector(RightVect);

                Vector TopVect = BC.BottGP.BoltM.GetCoordinateSystem().AxisX;
                if (TopVect.Y < 0)
                    TopVect = dc.ChangeVector(TopVect);

                Vector BottVect = BC.BottGP.BoltM.GetCoordinateSystem().AxisX;
                if (BottVect.Y > 0)
                    BottVect = dc.ChangeVector(BottVect);


                MidPList = dc.ChangePints(BC.BottGP.BoltM, CView, RightVect);


                #region RD Dimensions

                BC.PC.DistBot += (BC.PC.DistInc*2);
                //RD Dim
                Vect = new Vector(0, -1, 0);

                // Dim No 7.2
                if (DN.DimIDNo7Dot2 && BC.BottGP.IntPointB.X < BC.Points.P4.X)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(BC.BottGP.IntPointB);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }


                }

                // Dim No 7.1
                if (DN.DimIDNo7Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(BC.BottGP.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }

                // Dim No 7
                if (DN.DimIDNo7)
                {
                    TempList = Com.GetBoltPoints(BC.BottGP.BoltM);
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }

                #endregion

                #region Bottom Straight Dim
                Vect = new Vector(0, -1, 0);
                BC.PC.DistLeft = (BC.PC.DistInc * 2);
                // Dim No 5.1
                if (DN.DimIDNo5Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P1);
                    pointList.Add(BC.BottGP.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistLeft);

                }

                // Dim No 8
                if (DN.DimIDNo8)
                {
                    pointList = new PointList();
                    pointList.AddRange(MidPList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistLeft);

                }

                // Dim No 25
                if (DN.DimIDNo25)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P1);
                    pointList.Add(BC.BottGP.IntPointB);
                    pointList.Add(BC.BottGP.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }

                // Dim No 26
                if (DN.DimIDNo26)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P2);
                    pointList.Add(BC.BottGP.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }


                }

                BC.PC.DistBot = BC.PC.DistInc;
                #endregion

                #region Left Straight Dim
                Vect = new Vector(-1, 0, 0);
                BC.PC.DistLeft = (BC.PC.DistInc * 2);


                // Dim No 12
                if (DN.DimIDNo12)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(MidPList, "Y"));
                    pointList.Add(Com.MaxP(MidPList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.BottGP.Points.P3.X, BC.PC.DistLeft);

                }


                // Dim No 9
                if (DN.DimIDNo9)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(MidPList, "Y"));
                    pointList.Add(BC.BottGP.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.BottGP.Points.P3.X, BC.PC.DistLeft);
                }

                if (DN.DimIDNo9 || DN.DimIDNo12)
                    BC.PC.DistLeft += BC.PC.DistInc;

                // Dim No 13
                if (DN.DimIDNo13)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.IntPoint);
                    pointList.Add(BC.BottGP.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, BC.BottGP.Points.P3.X, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }

                }

                // Dim No 10
                if (DN.DimIDNo10)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(MidPList, "Y"));
                    pointList.Add(new Point(BC.BottGP.Points.P3.X, BC.Points.P1.Y));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, BC.BottGP.Points.P3.X, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }

                }

                // Dim No 14
                if (DN.DimIDNo14)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.IntPoint);
                    pointList.Add(new Point(BC.BottGP.Points.P3.X, BC.Points.P1.Y));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, BC.BottGP.Points.P3.X, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }

                }


                #endregion

                #region Diagonal Right
                BC.PC.DistLeft = BC.PC.DistInc;
                TempList = dc.ChangePints(BC.BottGP.BoltM, CView, LeftVect);
                // Dim No 15.1
                if (DN.DimIDNo21Dot1 || DN.DimIDNo21)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo21Dot1) // Dim No 21.1
                        pointList.Add(Com.MaxP(TempList, "Y"));

                    pointList.Add(BC.BottGP.IntPointB);

                    if (DN.DimIDNo21) // Dim No 21
                        pointList.Add(BC.BottGP.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);

                }

                TempList = dc.ChangePints(BC.BottGP.BoltM, CView, RightVect);
                // Dim No 6.1
                if (DN.DimIDNo6Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "Y"));
                    pointList.Add(BC.BottGP.Points.P5);
                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);

                }

                // Dim No 6
                if (DN.DimIDNo6)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);

                }

                // Dim No 22
                if (DN.DimIDNo22)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.RefPBrace);
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);

                }

                if (DN.DimIDNo6Dot1 || DN.DimIDNo6 || DN.DimIDNo22)
                    BC.PC.DistLeft += BC.PC.DistInc;

                // Dim No 6.2
                if (DN.DimIDNo6Dot2)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);
                        Com.GroupDim(xDim);
                    }

                }

                #endregion

                Com.DrawLineDotted(CView, BC.BottGP.IntPoint, BC.BottGP.RefPBrace);

                //Dim Code 11 // Angle Dimension
                if (DN.DimIDNo11)
                {
                    double Dist = CalcDistAngel(BC.BottGP.RefPBrace, BC.BottGP.IntPoint);
                    Com.InsertAngleDim(CView, BC.BottGP.RefPBrace, BC.BottGP.IntPoint, "Bottom", Dist);
                }



            }
        }

        private void TestDim()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;

            Vector Vect = new Vector(0, 1, 0);

            TSD.PointList TempList = new PointList();

            if (BC.TopGP?.GussetPlate != null || BC.BottGP?.GussetPlate != null)
            {
                if (BC.TopGP != null)
                {
                    double Dist = CalcDistAngel(BC.TopGP.RefPBrace, BC.TopGP.IntPoint);
                    Com.InsertAngleDim(CView, BC.TopGP.RefPBrace, BC.TopGP.IntPoint, "Top", Dist);
                   
                }


                if (BC.BottGP != null)
                {
                    double Dist = CalcDistAngel(BC.BottGP.RefPBrace, BC.BottGP.IntPoint);
                    Com.InsertAngleDim(CView, BC.BottGP.RefPBrace, BC.BottGP.IntPoint, "Bottom", Dist);
                  
                }

            }
        }

        private void CreateLine(BoltGroup BoltT, BoltGroup BoltM, BoltGroup BoltB)
        {
            Point Top1 = null;
            Point Top2 = null;
            Point Bott1 = null;
            Point Bott2 = null;

            if (BoltT != null)
            {
                PointList Plist = Com.GetBoltPoints(BoltT);
                Top1 = Com.MaxPofX(Plist, "Y", Com.MinP(Plist, "X").X);
                Top2 = Com.MaxPofX(Plist, "Y", Com.MaxP(Plist, "X").X);
            }
            else if (BoltB != null && BoltM != null)
            {

                PointList Plist = Com.GetBoltPoints(BoltM);
                Top1 = Com.MaxPofX(Plist, "Y", Com.MinP(Plist, "X").X);
                Top2 = Com.MaxPofX(Plist, "Y", Com.MaxP(Plist, "X").X);
            }


            if (BoltB != null)
            {
                PointList Plist = Com.GetBoltPoints(BoltB);
                Bott1 = Com.MinPofX(Plist, "Y", Com.MinP(Plist, "X").X);
                Bott2 = Com.MinPofX(Plist, "Y", Com.MaxP(Plist, "X").X);
            }
            else if (BoltT != null && BoltM != null)
            {
                PointList Plist = Com.GetBoltPoints(BoltM);
                Bott1 = Com.MinPofX(Plist, "Y", Com.MinP(Plist, "X").X);
                Bott2 = Com.MinPofX(Plist, "Y", Com.MaxP(Plist, "X").X);
            }


            if (Top1 != null && Bott1 != null)
                Com.DrawLine(CView, Top1, Bott1);

            if (Top2 != null && Bott2 != null)
                Com.DrawLine(CView, Top2, Bott2);

        }

        private double CalcDistAngel(Point StartP, Point EndP)
        {
            double Dv = 12 / 0.25;
            double ScalM = (12 - CView.Attributes.Scale) * 10;
            double ScaleD = 0.18 - ((12 - CView.Attributes.Scale) / Dv);
           
            if (ScaleD == 0.18)
                ScaleD = 0.12;

            double Dist = (Distance.PointToPoint(StartP, EndP) * ScaleD);
            Dist += ScalM;
            return Dist;
        }


        #region Get Data

        private BeamClass_BG7 GetBeamClassClass(TSD.View CView)
        {
            BC = new BeamClass_BG7();
            BC.beam = MainBeam;
            List<TSM.Part> PartListC = BC.beam.GetAssembly().GetSecondaries().OfType<TSM.Part>().ToList();
            PartListC.Add(MainBeam);
            BC.Points = Com.GetPartPoints(BC.beam);

            List<TSM.BoltGroup> BoltDList = Com.EnumtoArray(BC.beam.GetBolts()).OfType<TSM.BoltGroup>().ToList();
            Point CentP = Com.CenterPoint(BC.beam.StartPoint, BC.beam.EndPoint);
            double Lenght = (BC.beam.GetSolid().MaximumPoint.X - BC.beam.GetSolid().MinimumPoint.X) / 8;
            double MinX = BC.beam.GetSolid().MinimumPoint.X + Lenght;
            double MaxX = BC.beam.GetSolid().MaximumPoint.X - Lenght;
            BoltGroup LeftBolt = (from b in BoltDList where Com.GetBoltPoints(b)[0].X < CentP.X && Com.GetBoltPoints(b)[0].X <= MinX select b).FirstOrDefault();
            BoltGroup RightBolt = (from b in BoltDList where Com.GetBoltPoints(b)[0].X > CentP.X && Com.GetBoltPoints(b)[0].X >= MaxX select b).FirstOrDefault();

            if (LeftBolt != null)
                BC.LeftBolt = LeftBolt;

            if (RightBolt != null)
                BC.RightBolt = RightBolt;


            ContourPlate TopGP = null;
            ContourPlate BottGP = null;

            if (Position == "Left")
            {

                TopGP = (from p in PartListC.OfType<ContourPlate>() where (p.GetSolid().MinimumPoint.X < CentP.X && p.GetSolid().MinimumPoint.X <= MinX) && (Com.CenterPoint(p).Y > BC.Points.CentP.Y) select p).FirstOrDefault();
                BottGP = (from p in PartListC.OfType<ContourPlate>() where (p.GetSolid().MinimumPoint.X < CentP.X && p.GetSolid().MinimumPoint.X <= MinX) && (Com.CenterPoint(p).Y < BC.Points.CentP.Y) select p).FirstOrDefault();

                if (TopGP != null)
                    BC.TopGP = GetGussetClass(TopGP, "Top");

                if (BottGP != null)
                    BC.BottGP = GetGussetClass(BottGP, "Bottom");


            }
            else
            {

                TopGP = (from p in PartListC.OfType<ContourPlate>() where (p.GetSolid().MaximumPoint.X > CentP.X && p.GetSolid().MaximumPoint.X >= MaxX) && (Com.CenterPoint(p).Y > BC.Points.CentP.Y) select p).FirstOrDefault();
                BottGP = (from p in PartListC.OfType<ContourPlate>() where (p.GetSolid().MaximumPoint.X > CentP.X && p.GetSolid().MaximumPoint.X >= MaxX) && (Com.CenterPoint(p).Y < BC.Points.CentP.Y) select p).FirstOrDefault();

                if (TopGP != null)
                    BC.TopGP = GetGussetClass(TopGP, "Top");

                if (BottGP != null)
                    BC.BottGP = GetGussetClass(BottGP, "Bottom");
            }


            List<Point> RefPoints = MainBeam.GetReferenceLine(false).OfType<Point>().ToList();

            double MinXP = (from p in RefPoints orderby p.X ascending select p.X).FirstOrDefault();
            double MaxXP = (from p in RefPoints orderby p.X descending select p.X).FirstOrDefault();

            MinXP -= 100;
            MaxXP += 100;

            TSM.Part LeftPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.X ascending select p).FirstOrDefault();
            TSM.Part RightPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.X descending select p).FirstOrDefault();
            TSM.Part TopPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.Y descending select p).FirstOrDefault();
            TSM.Part BottPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.Y ascending select p).FirstOrDefault();

            BC.PC = new PlacingClass();
            BC.PC.TopY = TopPart.GetSolid().MaximumPoint.Y;
            BC.PC.BottomY = BottPart.GetSolid().MinimumPoint.Y;



            BC.PC.LeftX = LeftPart.GetSolid().MinimumPoint.X;// Math.Round(CView.RestrictionBox.MinPoint.X);
            BC.PC.RightX = RightPart.GetSolid().MaximumPoint.X;


            if (BC.TopGP?.GussetPlate != null)
                BC.PC.TopY = BC.TopGP.GussetPlate.GetSolid().MaximumPoint.Y;

            if (BC.BottGP?.GussetPlate != null)
                BC.PC.BottomY = BC.BottGP.GussetPlate.GetSolid().MinimumPoint.Y;

            if (Position == "Left")
            {

                if (BC.TopGP?.RefPBrace != null && BC.PC.LeftX > BC.TopGP.RefPBrace.X)
                    BC.PC.LeftX = (double)(BC.TopGP?.RefPBrace.X);
                else if (BC.BottGP?.RefPBrace != null && BC.PC.LeftX > BC.BottGP.RefPBrace.X)
                    BC.PC.LeftX = (double)(BC.BottGP?.RefPBrace.X);
            }

            if (Position == "Right")
            {

                if (BC.TopGP?.RefPBrace != null && BC.PC.LeftX < BC.TopGP.RefPBrace.X)
                    BC.PC.RightX = (double)(BC.TopGP?.RefPBrace.X);
                else if (BC.BottGP?.RefPBrace != null && BC.PC.LeftX < BC.BottGP.RefPBrace.X)
                    BC.PC.RightX = (double)(BC.BottGP?.RefPBrace.X);
            }


            double AvScale = 12;
            double AvDistInc = 100;
            double DistPerScale = AvDistInc / AvScale;
            double CScale = CView.Attributes.Scale;
            BC.PC.DistInc = CScale * DistPerScale;
            BC.PC.DistBot = BC.PC.DistInc;
            BC.PC.DistTop = BC.PC.DistInc;
            BC.PC.DistLeft = BC.PC.DistInc;
            BC.PC.DistRight = BC.PC.DistInc;


            return BC;

        }

        private GussetClass GetGussetClass(ContourPlate GP, string VPosition)
        {
            GussetClass GC = new GussetClass();
            GC.GussetPlate = GP;
            GC.Points = GetGussetPoints(GP);

            List<BoltGroup> Bolts = Com.EnumtoArray(GP.GetBolts()).OfType<BoltGroup>().ToList();

            if (Bolts != null && Bolts.Count > 0)
            {
                BoltGroup MidBolt = (from b in Bolts where dc.IsDiagonalBolt(b) select b).FirstOrDefault();

                if (MidBolt != null)
                {
                    GC.BoltM = MidBolt;
                    Beam brace = GetBrace(GC.BoltM, GP);
                    if (brace != null)
                    {
                        GC.Brace = brace;
                        GC.RefPBrace = dc.NearestPoint(GC.Brace.StartPoint, GC.Brace.EndPoint, MidBolt.FirstPosition);
                        GC.IntPoint = GetIntSectPoint(GC.BoltM, brace, VPosition);
                        if (VPosition == "Top")
                        {
                            if (GC.RefPBrace != null && GC.IntPoint != null)
                                GC.IntPointB = Com.GetIntersectionPoint(GC.RefPBrace, GC.IntPoint, BC.Points.P1, BC.Points.P4);
                        }
                        else
                        {
                            if (GC.RefPBrace != null && GC.IntPoint != null)
                                GC.IntPointB = Com.GetIntersectionPoint(GC.RefPBrace, GC.IntPoint, BC.Points.P2, BC.Points.P3);
                        }


                        if (GC.IntPointB != null)
                        {
                            if (Position == "Left" && dc.IsLess(GC.IntPointB.X, BC.Points.P1.X))
                                GC.IntPointB = Com.GetIntersectionPoint(GC.RefPBrace, GC.IntPoint, GC.Points.P1, GC.Points.P2);
                            if (Position == "Right" && dc.IsGreater(GC.IntPointB.X, BC.Points.P4.X))
                                GC.IntPointB = Com.GetIntersectionPoint(GC.RefPBrace, GC.IntPoint, GC.Points.P1, GC.Points.P2);
                        }

                    }
                }

                BoltGroup Sbolt = (from b in Bolts where !dc.IsDiagonalBolt(b) select b).FirstOrDefault();

                if (Sbolt != null)
                    GC.BoltS = Sbolt;

            }

            return GC;
        }

        private Beam GetBrace(BoltGroup BoltL, TSM.Part GP)
        {

            Beam brace = (from b in Com.GetBoltParts(BoltL).OfType<TSM.Beam>() where b.Identifier.ID != GP.Identifier.ID && (b.Name.ToLower().Contains("brace") || (dc.IsMainPart(b) && !dc.IsPlate(b))) select b).FirstOrDefault();
            if (brace == null)
            {
                List<TSM.Part> PartList = (from b in Com.GetBoltParts(BoltL).OfType<TSM.Part>() where b.Identifier.ID != GP.Identifier.ID select b).ToList();

                foreach (TSM.Part part in PartList)
                {

                    BoltGroup bolt2 = Com.EnumtoArray(part.GetBolts()).OfType<BoltGroup>().Where(x => x.Identifier.ID != BoltL.Identifier.ID).FirstOrDefault();
                    if (bolt2 != null)
                    {
                        brace = (from b in Com.GetBoltParts(bolt2).OfType<TSM.Beam>() where b.Identifier.ID != GP.Identifier.ID && (b.Name.ToLower().Contains("brace") || (dc.IsMainPart(b) && !dc.IsPlate(b))) select b).FirstOrDefault();
                    }

                }

                if (brace == null)
                {
                    foreach (TSM.Part part in PartList)
                    {
                        if (dc.IsMainPart(part) && dc.IsPlate(part))
                        {

                            List<TSM.Part> PartLists = Com.EnumtoArray(part.GetWelds()).OfType<TSM.Weld>().Select(x => x.MainObject).OfType<TSM.Part>().ToList();
                            PartLists.AddRange(Com.EnumtoArray(part.GetWelds()).OfType<TSM.Weld>().Select(x => x.SecondaryObject).OfType<TSM.Part>().ToList());

                            brace = (from b in PartLists.OfType<Beam>() where IsBrace(b) select b).FirstOrDefault();
                            if (brace == null)
                            {
                                PartLists = (from b in PartLists where !dc.IsMainPart(b) select b.GetAssembly().GetMainPart()).OfType<TSM.Part>().ToList();
                                brace = (from b in PartLists.OfType<Beam>() where IsBrace(b) select b).FirstOrDefault();
                                if (brace != null)
                                    break;
                            }


                        }

                    }
                }

                if (brace == null)
                {
                    foreach (TSM.Part part in PartList)
                    {
                        if (dc.IsMainPart(part) && dc.IsPlate(part))
                        {

                            List<BoltGroup> BoltsList = Com.EnumtoArray(part.GetBolts()).OfType<TSM.BoltGroup>().ToList();
                            if (BoltsList != null && BoltsList.Count > 0)
                            {
                                List<TSM.Part> PartLists = new List<TSM.Part>();

                                BoltsList.ForEach(x => PartLists.AddRange(Com.GetBoltParts(x)));

                                brace = (from b in PartLists.OfType<Beam>() where IsBrace(b) select b).FirstOrDefault();
                                if (brace == null)
                                {
                                    PartLists = (from b in PartLists where !dc.IsMainPart(b) select b.GetAssembly().GetMainPart()).OfType<TSM.Part>().ToList();
                                    brace = (from b in PartLists.OfType<Beam>() where IsBrace(b) select b).FirstOrDefault();
                                    if (brace != null)
                                        break;
                                }
                            }


                        }

                    }
                }
            }

            return brace;

        }

        private PartPoints GetGussetPoints(ContourPlate GP)
        {


            PartPoints RetP = new PartPoints();
            PointList pointList = Com.ContPList(GP);
            RetP.CentP = Com.CenterPoint(GP);

            double MinY = GP.GetSolid().MinimumPoint.Y + 25;
            double MaxY = GP.GetSolid().MaximumPoint.Y - 25;
            if (Position == "Left")
            {
                if (RetP.CentP.Y > BC.Points.CentP.Y)
                {

                    RetP.P2 = (from p in pointList.OfType<Point>() where p.Y < MinY orderby p.X ascending select p).FirstOrDefault();
                    RetP.P3 = (from p in pointList.OfType<Point>() where p.Y < MinY orderby p.X descending select p).FirstOrDefault();
                    RetP.P1 = (from p in pointList.OfType<Point>() where p.Y > MinY orderby p.X ascending select p).FirstOrDefault();
                    RetP.P5 = (from p in pointList.OfType<Point>() where p.Y > MinY orderby p.X descending select p).FirstOrDefault();

                    RetP.P4 = (from p in pointList.OfType<Point>() where p.Y > RetP.P5.Y orderby p.X descending select p).FirstOrDefault();

                }
                else
                {
                    RetP.P2 = (from p in pointList.OfType<Point>() where p.Y > MaxY orderby p.X ascending select p).FirstOrDefault();
                    RetP.P3 = (from p in pointList.OfType<Point>() where p.Y > MaxY orderby p.X descending select p).FirstOrDefault();
                    RetP.P1 = (from p in pointList.OfType<Point>() where p.Y < MaxY orderby p.X ascending select p).FirstOrDefault();
                    RetP.P5 = (from p in pointList.OfType<Point>() where p.Y < MaxY orderby p.X descending select p).FirstOrDefault();


                    RetP.P4 = (from p in pointList.OfType<Point>() where p.Y < RetP.P5.Y orderby p.X descending select p).FirstOrDefault();
                }
            }

            else
            {
                if (RetP.CentP.Y > BC.Points.CentP.Y)
                {
                    RetP.P2 = (from p in pointList.OfType<Point>() where p.Y < MinY orderby p.X descending select p).FirstOrDefault();
                    RetP.P3 = (from p in pointList.OfType<Point>() where p.Y < MinY orderby p.X ascending select p).FirstOrDefault();
                    RetP.P1 = (from p in pointList.OfType<Point>() where p.Y > MinY orderby p.X descending select p).FirstOrDefault();
                    RetP.P5 = (from p in pointList.OfType<Point>() where p.Y > MinY orderby p.X ascending select p).FirstOrDefault();

                    RetP.P4 = (from p in pointList.OfType<Point>() where p.Y > RetP.P5.Y orderby p.X ascending select p).FirstOrDefault();

                }
                else
                {

                    RetP.P2 = (from p in pointList.OfType<Point>() where p.Y > MaxY orderby p.X descending select p).FirstOrDefault();
                    RetP.P3 = (from p in pointList.OfType<Point>() where p.Y > MaxY orderby p.X ascending select p).FirstOrDefault();
                    RetP.P1 = (from p in pointList.OfType<Point>() where p.Y < MaxY orderby p.X descending select p).FirstOrDefault();
                    RetP.P5 = (from p in pointList.OfType<Point>() where p.Y < MaxY orderby p.X ascending select p).FirstOrDefault();


                    RetP.P4 = (from p in pointList.OfType<Point>() where p.Y < RetP.P5.Y orderby p.X ascending select p).FirstOrDefault();

                }
            }
            return RetP;
        }

        #endregion

        #region Helping Methods

        private bool IsBrace(Beam b)
        {
            bool RetCheck = false;
            if (b.Name.ToLower().Contains("brace") || (dc.IsMainPart(b) && !dc.IsPlate(b)))
            {
                if ((b.StartPoint.Y < BC.Points.P1.Y && b.StartPoint.Y > BC.Points.P2.Y) || (b.EndPoint.Y < BC.Points.P1.Y && b.EndPoint.Y > BC.Points.P2.Y))
                    RetCheck = true;
            }

            return RetCheck;
        }

        private Point GetIntSectPoint(BoltGroup bolt, Beam brace, string Position)
        {
            Vector Vect = bolt.GetCoordinateSystem().AxisX;
            PointList PtList = new PointList();
            Point IntSectP = null;
            if (Position == "Top")
            {
                if (Vect.Y > 0)
                    Vect = Com.ChangeVector(Vect);
            }
            else
            {
                if (Vect.Y < 0)
                    Vect = Com.ChangeVector(Vect);
            }

            PtList = dc.ChangePints(bolt, CView, Vect);
            if (PtList.Count > 1)
                IntSectP = Com.GetIntersectionPoint(PtList[0], PtList[1], brace.StartPoint, brace.EndPoint);
            else if (PtList.Count == 1)
                IntSectP = PtList[0];

            return IntSectP;

        }


        #endregion

    }

    public class BeamClass_BG7
    {
        public Beam beam { get; set; }
        public GussetClass TopGP { get; set; }
        public GussetClass BottGP { get; set; }
        public BoltGroup LeftBolt { get; set; }
        public BoltGroup RightBolt { get; set; }
        public PartPoints Points { get; set; }
        public PlacingClass PC { get; set; }
        public Beam SecBeam { get; set; }

    }


}
