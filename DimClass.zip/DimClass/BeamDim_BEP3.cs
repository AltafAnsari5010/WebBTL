﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Tekla.Structures;
using Tekla.Structures.Drawing;
using Tekla.Structures.Geometry3d;
using Tekla.Structures.Model;
using TSD = Tekla.Structures.Drawing;
using TSM = Tekla.Structures.Model;
using VirtueleDrawingAutomation;
using TSDD = Tekla.Structures.Datatype;
using TSG = Tekla.Structures.Geometry3d;

namespace Auto_Detailing_Tool_Beam
{
    public class BeamDim_BEP3
    {
        #region Global Variables
        DimCom dc = new DimCom();
        StraightDimensionSet.StraightDimensionSetAttributes StAtrr = new StraightDimensionSet.StraightDimensionSetAttributes("standard");
        StraightDimensionSet.StraightDimensionSetAttributes RdAtrr = new StraightDimensionSet.StraightDimensionSetAttributes("standard");

        public Beam MainBeam = null;
        VirtueleDrawingAutomation.Json.DrawingAttributeInfoJson.AttributeFiles dimAttrClass = null;
        List<TSD.StraightDimension> KnockDim = new List<StraightDimension>();
        BeamClass_BEP3 BC = null;

        VirtueleDrawingAutomation.Json.AutoDimensionTypesJson.BEP3Json DN = null;
        string Position = "Left";
        TSD.View CView = null;
        string ViewName = "";
        public Point BoltPS = null;

        #endregion

        public void ApplyDim(TSD.View CView, string ViewName, AutoDimensioningTypes autoDimensioningTypes, DrawingAttributeInfo drawingAttributeInfo, string Position)
        {
            //try
            //{
            Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane());
            //Set model everything to the view
            Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane(CView.DisplayCoordinateSystem));

            this.CView = CView;
            this.dimAttrClass = drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files;
            this.DN = autoDimensioningTypes.Bep3;
            this.Position = Position;
            StAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.StandardDimension);
            RdAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.RunningDimension);
            this.MainBeam = (Com.MyModel.SelectModelObject(new Identifier((CView.GetDrawing() as AssemblyDrawing).AssemblyIdentifier.ID)) as TSM.Assembly).GetMainPart() as TSM.Beam;
            this.MainBeam.Select();
            string ProType = Com.GetProType(MainBeam);
            this.ViewName = ViewName;
            GetBeamClassClass(CView);

            if (Position == "Left")
            {
                //TestDim();
                //if (ViewName == "Front View")
                //    ApplyDimTypeLeft(CView);
                //else 
                if (ViewName == "Section View")
                    AppySectionDim();
            }

            else if (Position == "Right")
            {
                //TestDim();
                //if (ViewName == "Front View")
                //    ApplyDimTypeRight(CView);
                //else 
                if (ViewName == "Section View")
                    AppySectionDim();
            }
            //}
            //catch (Exception ex)
            //{ }

            Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane());


        }

        private void ApplyDimTypeLeft(TSD.View CView)
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            TSD.PointList TempList = new PointList();
            if (BC.EP != null)
            {
                Vect = new Vector(-1, 0, 0);

                #region Left Dim

                // Dim No 2.1
                if (DN.DimIDNo2Dot1)
                {

                    pointList = new PointList();
                    pointList.Add(Com.MaxP(BC.EP.AllPoints, "Y"));
                    pointList.Add(BC.EP.EndPlate.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);

                    pointList = new PointList();
                    pointList.Add(Com.MinP(BC.EP.AllPoints, "Y"));
                    pointList.Add(BC.EP.EndPlate.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);

                    BC.PC.DistLeft += (BC.PC.DistInc * 0.6);
                }

                // Dim No 1, 11
                if (DN.DimIDNo1 || DN.DimIDNo11)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo1 && BC.EP.TopBoltP != null) // Dim 1
                        pointList.Add(Com.MinP(BC.EP.TopBoltP, "Y"));

                    pointList.Add(BC.Points.P1);

                    if (DN.DimIDNo1) // Dim 11
                        pointList.Add(Com.MaxP(BC.EP.MidBoltP, "Y"));

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                        BC.PC.DistLeft += (BC.PC.DistInc * 0.6);
                    }
                }


                // Dim No 2.2, 2.3
                if (DN.DimIDNo2Dot3 || DN.DimIDNo2Dot2)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo2Dot3) // Dim 2.3
                        pointList.Add(Com.MinP(BC.EP.MidBoltP, "Y"));

                    pointList.Add(BC.Points.P2);

                    if (DN.DimIDNo2Dot2 && BC.EP.BottBoltP != null) // Dim 2.2
                        pointList.Add(Com.MaxP(BC.EP.BottBoltP, "Y"));

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);

                }


                if (DN.DimIDNo2Dot3 || DN.DimIDNo2Dot2 || DN.DimIDNo1 || DN.DimIDNo11 || DN.DimIDNo2Dot1)
                    BC.PC.DistLeft += BC.PC.DistInc;

                // Dim No 2
                if (DN.DimIDNo2)
                {
                    pointList = new PointList();
                    pointList.AddRange(BC.EP.AllPoints);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByLeftX(xDim, BC.PC);
                }

                bool IsGroupDim = false;

                // Dim No 2.4
                if (DN.DimIDNo2Dot4)
                {
                    if (BC.EP.BottBoltP != null && BC.EP.BottBoltP?.Count > 2)
                    {
                        TempList = dc.ChangePints(BC.EP.BottBoltP, CView, Vect);
                        if (TempList?.Count > 2)
                        {
                            pointList = new PointList();
                            pointList.AddRange(TempList);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                            if (xDim != null)
                            {
                                PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                                Com.GroupDim(xDim);
                                IsGroupDim = true;
                            }
                        }
                    }


                    if (BC.EP.TopBoltP != null && BC.EP.TopBoltP.Count > 2)
                    {
                        TempList = dc.ChangePints(BC.EP.TopBoltP, CView, Vect);
                        if (TempList?.Count > 2)
                        {
                            pointList = new PointList();
                            pointList.AddRange(TempList);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                            if (xDim != null)
                            {
                                PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                                Com.GroupDim(xDim);
                                IsGroupDim = true;
                            }
                        }
                    }



                }

                // Dim No 2.5
                if (DN.DimIDNo2Dot5)
                {
                    if (BC.EP.MidBoltP != null && BC.EP.MidBoltP.Count > 2)
                    {
                        TempList = dc.ChangePints(BC.EP.MidBoltP, CView, Vect);
                        if (TempList?.Count > 2)
                        {
                            pointList = new PointList();
                            pointList.AddRange(TempList);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                            if (xDim != null)
                            {
                                PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                                Com.GroupDim(xDim);
                                IsGroupDim = true;
                            }
                        }
                    }

                }

                if (IsGroupDim)
                    BC.PC.DistLeft += BC.PC.DistInc;


                // Dim No 12 Elevation Dim
                if (DN.DimIDNo12)
                {

                    BC.PC.DistLeft += BC.PC.DistInc;
                    Vect = new Vector(-1, 0, 0);
                    StraightDimensionSet.StraightDimensionSetAttributes ElAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.ElevationDimension);
                    ElAtrr.DimensionType = DimensionSetBaseAttributes.DimensionTypes.Elevation;
                    ElAtrr.Arrowhead.Head = ArrowheadTypes.FilledArrow;
                    pointList = new PointList();

                    if (MainBeam.StartPoint.X > MainBeam.EndPoint.X)
                    {
                        pointList.Add(MainBeam.EndPoint);
                        pointList.Add(MainBeam.EndPoint);

                    }
                    else
                    {
                        pointList.Add(MainBeam.StartPoint);
                        pointList.Add(MainBeam.StartPoint);
                    }

                    BC.PC.DistLeft = BC.PC.DistLeft - (BC.Points.P1.X - pointList[0].X);
                    xDim = dc.InsertDimm(CView, pointList, Vect, (-BC.PC.DistLeft), ElAtrr);
                    if (xDim != null)
                    {
                        xDim.Distance = (-BC.PC.DistLeft);
                        xDim.Modify();
                    }
                    BC.PC.DistLeft += BC.PC.DistInc;

                }

                Vect = new Vector(0, 1, 0);
                // Dim No 3
                if (DN.DimIDNo3)
                {
                    pointList = new PointList();
                    pointList.Add(BC.EP.EndPlate.Points.P4);
                    pointList.Add(BC.EP.EndPlate.Points.P1);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                }
                #endregion

                if (BC.EP.HPTop != null)
                {
                    Vect = new Vector(0, 1, 0);
                    // Dim No 13.1
                    if (DN.DimIDNo13Dot1)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.EP.HPTop.Points.P1);
                        pointList.Add(BC.EP.HPTop.Points.P5);

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByTopY(xDim, BC.PC);
                    }

                    // Dim No 13
                    if (DN.DimIDNo13)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.EP.HPTop.Points.P4);
                        pointList.Add(BC.EP.HPTop.Points.P5);

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByTopY(xDim, BC.PC);
                    }

                    // Dim No 14
                    if (DN.DimIDNo14)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.EP.HPTop.Points.P1);
                        pointList.Add(BC.EP.HPTop.Points.P4);

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByTopY(xDim, BC.PC);
                    }

                    Vect = new Vector(1, 0, 0);

                    // Dim No 15.1
                    if (DN.DimIDNo15Dot1)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.EP.HPTop.Points.P4);
                        pointList.Add(BC.EP.HPTop.Points.P3);

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceRightP(xDim, BC.EP.HPTop.Points.P3.X, BC.PC.DistRight);
                    }

                    // Dim No 15
                    if (DN.DimIDNo15)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.EP.HPTop.Points.P4);
                        pointList.Add(BC.EP.HPTop.Points.P5);

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceRightP(xDim, BC.EP.HPTop.Points.P3.X, BC.PC.DistRight);
                    }

                    if (DN.DimIDNo15Dot1 || DN.DimIDNo15)
                        BC.PC.DistRight += BC.PC.DistInc;

                    // Dim No 16
                    if (DN.DimIDNo16)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.EP.HPTop.Points.P5);
                        pointList.Add(BC.EP.HPTop.Points.P3);

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceRightP(xDim, BC.EP.HPTop.Points.P3.X, BC.PC.DistRight);
                            BC.PC.DistRight += BC.PC.DistInc;
                        }
                    }
                }


                if (BC.EP.HPBotom != null)
                {
                    BC.PC.DistRight = BC.PC.DistInc;

                    Vect = new Vector(0, -1, 0);
                    // Dim No 13.1
                    if (DN.DimIDNo13Dot1)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.EP.HPBotom.Points.P5);
                        pointList.Add(BC.EP.HPBotom.Points.P1);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                    }

                    // Dim No 13
                    if (DN.DimIDNo13)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.EP.HPBotom.Points.P5);
                        pointList.Add(BC.EP.HPBotom.Points.P4);

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                    }

                    if (DN.DimIDNo13Dot1 || DN.DimIDNo13)
                        BC.PC.DistBot += BC.PC.DistInc;

                    // Dim No 14
                    if (DN.DimIDNo14)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.EP.HPBotom.Points.P1);
                        pointList.Add(BC.EP.HPBotom.Points.P4);

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByBottomY(xDim, BC.PC);
                    }

                    Vect = new Vector(1, 0, 0);

                    // Dim No 15.1
                    if (DN.DimIDNo15Dot1)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.EP.HPBotom.Points.P4);
                        pointList.Add(BC.EP.HPBotom.Points.P3);

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceRightP(xDim, BC.EP.HPBotom.Points.P3.X, BC.PC.DistRight);
                    }

                    // Dim No 15
                    if (DN.DimIDNo15)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.EP.HPBotom.Points.P4);
                        pointList.Add(BC.EP.HPBotom.Points.P5);

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceRightP(xDim, BC.EP.HPBotom.Points.P3.X, BC.PC.DistRight);
                    }

                    if (DN.DimIDNo15Dot1 || DN.DimIDNo15)
                        BC.PC.DistRight += BC.PC.DistInc;

                    // Dim No 16
                    if (DN.DimIDNo16)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.EP.HPBotom.Points.P5);
                        pointList.Add(BC.EP.HPBotom.Points.P3);

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceRightP(xDim, BC.EP.HPBotom.Points.P3.X, BC.PC.DistRight);
                            BC.PC.DistRight += BC.PC.DistInc;
                        }
                    }

                    // Dim No 18
                    if (DN.DimIDNo18)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.EP.HPBotom.Points.P5);
                        pointList.Add(new Point(BC.EP.HPBotom.Points.P3.X, BC.Points.P1.Y));

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceRightP(xDim, BC.EP.HPBotom.Points.P3.X, BC.PC.DistRight);
                            BC.PC.DistRight += BC.PC.DistInc;
                        }
                    }
                }


            }
        }

        private void ApplyDimTypeRight(TSD.View CView)
        {

            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            TSD.PointList TempList = new PointList();
            if (BC.EP != null)
            {
                Vect = new Vector(1, 0, 0);

                #region Left Dim

                // Dim No 2.1
                if (DN.DimIDNo2Dot1)
                {

                    pointList = new PointList();
                    pointList.Add(Com.MaxP(BC.EP.AllPoints, "Y"));
                    pointList.Add(BC.EP.EndPlate.Points.P4);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);

                    pointList = new PointList();
                    pointList.Add(Com.MinP(BC.EP.AllPoints, "Y"));
                    pointList.Add(BC.EP.EndPlate.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);

                    BC.PC.DistRight += (BC.PC.DistInc * 0.6);

                }

                // Dim No 1, 11
                if (DN.DimIDNo1 || DN.DimIDNo11)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo1 && BC.EP.TopBoltP != null) // Dim 1
                        pointList.Add(Com.MinP(BC.EP.TopBoltP, "Y"));

                    pointList.Add(BC.Points.P4);

                    if (DN.DimIDNo1) // Dim 11
                        pointList.Add(Com.MaxP(BC.EP.MidBoltP, "Y"));

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                        BC.PC.DistRight += (BC.PC.DistInc * 0.6);
                    }
                }


                // Dim No 2.2, 2.3
                if (DN.DimIDNo2Dot3 || DN.DimIDNo2Dot2)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo2Dot3) // Dim 2.3
                        pointList.Add(Com.MinP(BC.EP.MidBoltP, "Y"));

                    pointList.Add(BC.Points.P3);

                    if (DN.DimIDNo2Dot2 && BC.EP.BottBoltP != null) // Dim 2.2
                        pointList.Add(Com.MaxP(BC.EP.BottBoltP, "Y"));

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);

                }


                if (DN.DimIDNo2Dot3 || DN.DimIDNo2Dot2 || DN.DimIDNo1 || DN.DimIDNo11 || DN.DimIDNo2Dot1)
                    BC.PC.DistRight += BC.PC.DistInc;

                // Dim No 2
                if (DN.DimIDNo2)
                {
                    pointList = new PointList();
                    pointList.AddRange(BC.EP.AllPoints);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByRightX(xDim, BC.PC);
                }

                bool IsGroupDim = false;
                // Dim No 2.4
                if (DN.DimIDNo2Dot4)
                {

                    if (BC.EP.BottBoltP != null)
                    {
                        TempList = dc.ChangePints(BC.EP.BottBoltP, CView, Vect);
                        if (TempList?.Count > 2)
                        {
                            pointList = new PointList();
                            pointList.AddRange(TempList);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                            if (xDim != null)
                            {
                                PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                                Com.GroupDim(xDim);
                                IsGroupDim = true;
                            }
                        }
                    }

                    if (BC.EP.TopBoltP != null)
                    {
                        TempList = dc.ChangePints(BC.EP.TopBoltP, CView, Vect);
                        if (TempList?.Count > 2)
                        {
                            pointList = new PointList();
                            pointList.AddRange(TempList);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                            if (xDim != null)
                            {
                                PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                                Com.GroupDim(xDim);
                                IsGroupDim = true;
                            }
                        }
                    }



                }


                // Dim No 2.5
                if (DN.DimIDNo2Dot5)
                {
                    if (BC.EP.MidBoltP != null)
                    {
                        TempList = dc.ChangePints(BC.EP.MidBoltP, CView, Vect);
                        if (TempList?.Count > 2)
                        {
                            pointList = new PointList();
                            pointList.AddRange(TempList);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                            if (xDim != null)
                            {
                                PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                                Com.GroupDim(xDim);
                                IsGroupDim = true;
                            }
                        }
                    }

                }

                if (IsGroupDim)
                    BC.PC.DistRight += BC.PC.DistInc;

                Vect = new Vector(0, 1, 0);
                // Dim No 3
                if (DN.DimIDNo3)
                {
                    pointList = new PointList();
                    pointList.Add(BC.EP.EndPlate.Points.P1);
                    pointList.Add(BC.EP.EndPlate.Points.P4);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                }
                #endregion

                if (BC.EP.HPTop != null)
                {
                    Vect = new Vector(0, 1, 0);
                    // Dim No 13.1
                    if (DN.DimIDNo13Dot1)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.EP.HPTop.Points.P1);
                        pointList.Add(BC.EP.HPTop.Points.P5);

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByTopY(xDim, BC.PC);
                    }

                    // Dim No 13
                    if (DN.DimIDNo13)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.EP.HPTop.Points.P4);
                        pointList.Add(BC.EP.HPTop.Points.P5);

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByTopY(xDim, BC.PC);
                    }

                    // Dim No 14
                    if (DN.DimIDNo14)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.EP.HPTop.Points.P1);
                        pointList.Add(BC.EP.HPTop.Points.P4);

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByTopY(xDim, BC.PC);
                    }

                    Vect = new Vector(-1, 0, 0);

                    // Dim No 15.1
                    if (DN.DimIDNo15Dot1)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.EP.HPTop.Points.P4);
                        pointList.Add(BC.EP.HPTop.Points.P3);

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceLeftP(xDim, BC.EP.HPTop.Points.P3.X, BC.PC.DistLeft);
                    }

                    // Dim No 15
                    if (DN.DimIDNo15)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.EP.HPTop.Points.P4);
                        pointList.Add(BC.EP.HPTop.Points.P5);

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceLeftP(xDim, BC.EP.HPTop.Points.P3.X, BC.PC.DistLeft);
                    }

                    if (DN.DimIDNo15Dot1 || DN.DimIDNo15)
                        BC.PC.DistLeft += BC.PC.DistInc;

                    // Dim No 16
                    if (DN.DimIDNo16)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.EP.HPTop.Points.P5);
                        pointList.Add(BC.EP.HPTop.Points.P3);

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceLeftP(xDim, BC.EP.HPTop.Points.P3.X, BC.PC.DistLeft);
                            BC.PC.DistLeft += BC.PC.DistInc;
                        }
                    }
                }


                if (BC.EP.HPBotom != null)
                {
                    BC.PC.DistLeft = BC.PC.DistInc;

                    Vect = new Vector(0, -1, 0);
                    // Dim No 13.1
                    if (DN.DimIDNo13Dot1)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.EP.HPBotom.Points.P5);
                        pointList.Add(BC.EP.HPBotom.Points.P1);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                    }

                    // Dim No 13
                    if (DN.DimIDNo13)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.EP.HPBotom.Points.P5);
                        pointList.Add(BC.EP.HPBotom.Points.P4);

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                    }

                    if (DN.DimIDNo13Dot1 || DN.DimIDNo13)
                        BC.PC.DistBot += BC.PC.DistInc;

                    // Dim No 14
                    if (DN.DimIDNo14)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.EP.HPBotom.Points.P1);
                        pointList.Add(BC.EP.HPBotom.Points.P4);

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByBottomY(xDim, BC.PC);
                    }

                    Vect = new Vector(-1, 0, 0);

                    // Dim No 15.1
                    if (DN.DimIDNo15Dot1)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.EP.HPBotom.Points.P4);
                        pointList.Add(BC.EP.HPBotom.Points.P3);

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceLeftP(xDim, BC.EP.HPBotom.Points.P3.X, BC.PC.DistLeft);
                    }

                    // Dim No 15
                    if (DN.DimIDNo15)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.EP.HPBotom.Points.P4);
                        pointList.Add(BC.EP.HPBotom.Points.P5);

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceLeftP(xDim, BC.EP.HPBotom.Points.P3.X, BC.PC.DistLeft);
                    }

                    if (DN.DimIDNo15Dot1 || DN.DimIDNo15)
                        BC.PC.DistLeft += BC.PC.DistInc;

                    // Dim No 16
                    if (DN.DimIDNo16)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.EP.HPBotom.Points.P5);
                        pointList.Add(BC.EP.HPBotom.Points.P3);

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceLeftP(xDim, BC.EP.HPBotom.Points.P3.X, BC.PC.DistLeft);
                            BC.PC.DistLeft += BC.PC.DistInc;
                        }
                    }

                    // Dim No 18
                    if (DN.DimIDNo18)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.EP.HPBotom.Points.P5);
                        pointList.Add(new Point(BC.EP.HPBotom.Points.P3.X, BC.Points.P1.Y));

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceLeftP(xDim, BC.EP.HPBotom.Points.P3.X, BC.PC.DistLeft);
                            BC.PC.DistLeft += BC.PC.DistInc;
                        }
                    }
                }


            }

        }

        private void AppySectionDim()
        {
            StraightDimensionSet xDim = null;
            PointList pointList = new PointList();
            Vector Vect = new Vector(0, 1, 0);
            PointList TempList = new PointList();

            if (BC.EP != null && BC.EP.AllPoints != null)
            {

                Point ViewPoint = Com.CenterPoint(CView.RestrictionBox.MinPoint, CView.RestrictionBox.MaxPoint);
                Point BeamPoint = dc.NearestPoint(MainBeam.StartPoint, MainBeam.EndPoint, ViewPoint);

                Vect = new Vector(0, 1, 0);
                TempList = dc.ChangePints(BC.EP.AllPoints, CView, Vect);

                // Dim No 4
                if (DN.DimIDNo4)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    pointList.Add(BeamPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);
                }


                // Dim No 5
                if (DN.DimIDNo5)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                }

                // Dim No 5.1
                if (DN.DimIDNo5Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "X"));
                    pointList.Add(BC.EP.EndPlate.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);

                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "X"));
                    pointList.Add(BC.EP.EndPlate.Points.P4);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                }

                if (DN.DimIDNo5 || DN.DimIDNo5Dot1)
                    BC.PC.DistTop += BC.PC.DistInc;


                // Dim No 17
                if (DN.DimIDNo17)
                {
                    pointList = new PointList();
                    pointList.Add(BC.EP.EndPlate.Points.P1);
                    pointList.Add(BeamPoint);
                    pointList.Add(BC.EP.EndPlate.Points.P4);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);
                }

                // Dim No 6
                if (DN.DimIDNo6)
                {
                    pointList = new PointList();
                    pointList.Add(BC.EP.EndPlate.Points.P1);
                    pointList.Add(BC.EP.EndPlate.Points.P4);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);
                }


                Vect = new Vector(-1, 0, 0);
                TempList = dc.ChangePints(BC.EP.AllPoints, CView, Vect);
                // Dim No 2.1
                if (DN.DimIDNo2Dot1)
                {
                    if (BC.EP.TopBoltP != null)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MaxPofX(BC.EP.TopBoltP, "Y", Com.MaxP(BC.EP.TopBoltP, "X").X));
                        pointList.Add(BC.EP.EndPlate.Points.P1);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                    }
                    else if(BC.EP.MidBoltP!=null)
                    {

                        pointList = new PointList();
                        pointList.Add(Com.MaxPofX(BC.EP.MidBoltP, "Y", Com.MaxP(BC.EP.MidBoltP, "X").X));
                        pointList.Add(BC.EP.EndPlate.Points.P1);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                            BC.PC.DistLeft += (BC.PC.DistInc);
                        }

                    }

                    if (BC.EP.BottBoltP != null)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MinPofX(BC.EP.BottBoltP, "Y", Com.MaxP(BC.EP.BottBoltP, "X").X));
                        pointList.Add(BC.EP.EndPlate.Points.P2);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                    }
                    else if (BC.EP.MidBoltP != null)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MinPofX(BC.EP.MidBoltP, "Y", Com.MaxP(BC.EP.MidBoltP, "X").X));
                        pointList.Add(BC.EP.EndPlate.Points.P2);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                            BC.PC.DistLeft += (BC.PC.DistInc * 0.6);
                        }
                    }
                }

                // Dim No 1, 11
                if (DN.DimIDNo1 || DN.DimIDNo11)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo1 && BC.EP.TopBoltP != null) // Dim 1
                        pointList.Add(Com.MinPofX(BC.EP.TopBoltP, "Y", Com.MaxP(BC.EP.TopBoltP, "X").X));

                    pointList.Add(BC.Points.P1);

                    if (DN.DimIDNo11 && BC.EP.MidBoltP != null) // Dim 11
                        pointList.Add(Com.MaxPofX(BC.EP.MidBoltP, "Y", Com.MaxP(BC.EP.MidBoltP, "X").X));

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                        BC.PC.DistLeft += (BC.PC.DistInc * 0.6);
                    }
                }


                // Dim No 2.2, 2.3
                if (DN.DimIDNo2Dot3 || DN.DimIDNo2Dot2)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo2Dot3) // Dim 2.3
                        pointList.Add(Com.MinPofX(BC.EP.MidBoltP, "Y", Com.MaxP(BC.EP.MidBoltP, "X").X));

                    pointList.Add(BC.Points.P2);

                    if (DN.DimIDNo2Dot2 && BC.EP.BottBoltP != null) // Dim 2.2
                        pointList.Add(Com.MaxPofX(BC.EP.BottBoltP, "Y", Com.MaxP(BC.EP.BottBoltP, "X").X));

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);

                }

                if (DN.DimIDNo2Dot3 || DN.DimIDNo2Dot2 || DN.DimIDNo1 || DN.DimIDNo11 || DN.DimIDNo2Dot1)
                    BC.PC.DistLeft += BC.PC.DistInc;

                // Dim No 2
                if (DN.DimIDNo2)
                {
                    pointList = new PointList();
                    pointList.AddRange(dc.ChangePints(BC.EP.AllPoints, CView, Vect));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByLeftX(xDim, BC.PC);
                }


                bool IsGroupDim = false;

                // Dim No 2.4
                if (DN.DimIDNo2Dot4)
                {
                    if (BC.EP.BottBoltP != null)
                    {
                        TempList = dc.ChangePints(BC.EP.BottBoltP, CView, Vect);
                        if (TempList.Count > 2)
                        {
                            pointList = new PointList();
                            pointList.AddRange(TempList);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                            if (xDim != null)
                            {
                                PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                                Com.GroupDim(xDim);
                                IsGroupDim = true;
                            }
                        }
                    }


                    if (BC.EP.TopBoltP != null)
                    {
                        TempList = dc.ChangePints(BC.EP.TopBoltP, CView, Vect);
                        if (TempList.Count > 2)
                        {
                            pointList = new PointList();
                            pointList.AddRange(TempList);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                            if (xDim != null)
                            {
                                PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                                Com.GroupDim(xDim);
                                IsGroupDim = true;
                            }
                        }
                    }



                }

                // Dim No 2.5
                if (DN.DimIDNo2Dot5)
                {
                    if (BC.EP.MidBoltP != null)
                    {
                        TempList = dc.ChangePints(BC.EP.MidBoltP, CView, Vect);
                        if (TempList.Count > 2)
                        {
                            pointList = new PointList();
                            pointList.AddRange(TempList);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                            if (xDim != null)
                            {
                                PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                                Com.GroupDim(xDim);
                                IsGroupDim = true;
                            }
                        }
                    }

                }

                if (IsGroupDim)
                    BC.PC.DistLeft += BC.PC.DistInc;



                Vect = new Vector(1, 0, 0);
                // Dim No 19, 20
                if (DN.DimIDNo19 || DN.DimIDNo20)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo19) // Dim 19
                        pointList.Add(BC.EP.EndPlate.Points.P4);

                    pointList.Add(BC.Points.P4);

                    if (DN.DimIDNo20) // Dim 20
                        pointList.Add(BC.EP.EndPlate.Points.P3);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }

                }

                // Dim No 21
                if (DN.DimIDNo21)
                {
                    pointList = new PointList();
                    pointList.Add(BC.EP.EndPlate.Points.P4);
                    pointList.Add(BC.EP.EndPlate.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }

                }


            }

        }

        #region Get Data

        private void GetBeamClassClass(TSD.View CView)
        {
            if (ViewName == "Front View")
            {
                BC = new BeamClass_BEP3();
                BC.beam = MainBeam;
                BC.Points = Com.GetPartPoints(MainBeam);
                List<TSM.Part> PartListC = BC.beam.GetAssembly().GetSecondaries().OfType<TSM.Part>().ToList();

                GetEndPlateProperties(PartListC);

                PartListC.Add(MainBeam);
                List<Point> RefPoints = MainBeam.GetReferenceLine(false).OfType<Point>().ToList();

                double MinXP = (from p in RefPoints orderby p.X ascending select p.X).FirstOrDefault();
                double MaxXP = (from p in RefPoints orderby p.X descending select p.X).FirstOrDefault();

                MinXP -= 100;
                MaxXP += 100;

                TSM.Part LeftPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.X ascending select p).FirstOrDefault();
                TSM.Part RightPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.X descending select p).FirstOrDefault();
                TSM.Part TopPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.Y descending select p).FirstOrDefault();
                TSM.Part BottPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.Y ascending select p).FirstOrDefault();

                BC.PC = new PlacingClass();
                BC.PC.TopY = TopPart.GetSolid().MaximumPoint.Y;
                BC.PC.BottomY = BottPart.GetSolid().MinimumPoint.Y;


                BC.PC.LeftX = LeftPart.GetSolid().MinimumPoint.X;// Math.Round(CView.RestrictionBox.MinPoint.X);
                BC.PC.RightX = RightPart.GetSolid().MaximumPoint.X;

                if (BC.EP?.EndPlate != null)
                {
                    BC.PC.TopY = BC.EP.EndPlate.Points.P1.Y;
                    BC.PC.BottomY = BC.EP.EndPlate.Points.P2.Y;
                }



                double AvScale = 12;
                double AvDistInc = 100;
                double DistPerScale = AvDistInc / AvScale;
                double CScale = CView.Attributes.Scale;
                BC.PC.DistInc = CScale * DistPerScale;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;
            }
            else if (ViewName == "Section View")
            {
                BC = new BeamClass_BEP3();
                BC.beam = MainBeam;
                BC.Points = Com.GetPartPoints(MainBeam);
                List<TSM.Part> PartListC = BC.beam.GetAssembly().GetSecondaries().OfType<TSM.Part>().ToList();

               

                List<TSM.Part> PartList = (from p in PartListC where Com.IsViewObj(p, CView) select p).ToList();
                double MinZ = CView.RestrictionBox.MinPoint.Z - 180;
                double MaxZ = CView.RestrictionBox.MaxPoint.Z + 180;
                PointList VertList = dc.GetVertexList(MainBeam.GetSolid());
                List<Point> PList = VertList.OfType<Point>().Where(x => x.Z > MinZ).ToList();

                Point ViewPoint = Com.CenterPoint(CView.RestrictionBox.MinPoint, CView.RestrictionBox.MaxPoint);
                Point BeamPoint = dc.NearestPoint(MainBeam.StartPoint, MainBeam.EndPoint, ViewPoint);
                if (Com.IsEqualPoints(BeamPoint, MainBeam.StartPoint))
                    PList = VertList.OfType<Point>().Where(x => x.Z < MaxZ).ToList();

                BC.Points.P1 = Com.MinPofY(PList, "X", Com.MaxP(PList, "Y").Y);
                BC.Points.P2 = Com.MinPofY(PList, "X", Com.MinP(PList, "Y").Y);
                BC.Points.P3 = Com.MaxPofY(PList, "X", Com.MinP(PList, "Y").Y);
                BC.Points.P4 = Com.MaxPofY(PList, "X", Com.MaxP(PList, "Y").Y);

                GetEndPlatePropertiesS(PartList);

                PartListC.Add(MainBeam);
                List<Point> RefPoints = MainBeam.GetReferenceLine(false).OfType<Point>().ToList();

                PartList.Add(MainBeam);
                TSM.Part LeftPart = (from p in PartList orderby p.GetSolid().MinimumPoint.X ascending select p).FirstOrDefault();
                TSM.Part RightPart = (from p in PartList orderby p.GetSolid().MaximumPoint.X descending select p).FirstOrDefault();
                TSM.Part TopPart = (from p in PartList orderby p.GetSolid().MaximumPoint.Y descending select p).FirstOrDefault();
                TSM.Part BottPart = (from p in PartList orderby p.GetSolid().MinimumPoint.Y ascending select p).FirstOrDefault();

                BC.PC = new PlacingClass();
                BC.PC.TopY = TopPart.GetSolid().MaximumPoint.Y;
                BC.PC.BottomY = BottPart.GetSolid().MinimumPoint.Y;


                BC.PC.LeftX = LeftPart.GetSolid().MinimumPoint.X;// Math.Round(CView.RestrictionBox.MinPoint.X);
                BC.PC.RightX = RightPart.GetSolid().MaximumPoint.X;



                double AvScale = 12;
                double AvDistInc = 100;
                double DistPerScale = AvDistInc / AvScale;
                double CScale = CView.Attributes.Scale;
                BC.PC.DistInc = CScale * DistPerScale;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;
            }


        }

        private void GetEndPlateProperties(List<TSM.Part> PartListC)
        {
            TSM.Part EndPlate = null;
            TSM.Part HPTop = null;
            TSM.Part HPBott = null;

            Point CentP = Com.CenterPoint(BC.beam.StartPoint, BC.beam.EndPoint);
            double Lenght = (BC.beam.GetSolid().MaximumPoint.X - BC.beam.GetSolid().MinimumPoint.X) / 8;
            double MinX = BC.beam.GetSolid().MinimumPoint.X + Lenght;
            double MaxX = BC.beam.GetSolid().MaximumPoint.X - Lenght;

            if (Position == "Left")
            {
                EndPlate = (from p in PartListC where dc.IsPlateSideViewN(p) && (p.GetSolid().MaximumPoint.X < CentP.X && p.GetSolid().MinimumPoint.X <= MinX) select p).FirstOrDefault();
                HPTop = (from p in PartListC where !dc.IsPlateSideViewN(p) && (p.GetSolid().MaximumPoint.X < CentP.X && p.GetSolid().MinimumPoint.X <= MinX) && Com.CenterPoint(p).Y > BC.Points.P1.Y select p).FirstOrDefault();
                HPBott = (from p in PartListC where !dc.IsPlateSideViewN(p) && (p.GetSolid().MaximumPoint.X < CentP.X && p.GetSolid().MinimumPoint.X <= MinX) && Com.CenterPoint(p).Y < BC.Points.P2.Y select p).FirstOrDefault();

            }
            else
            {
                EndPlate = (from p in PartListC where dc.IsPlateSideViewN(p) && (p.GetSolid().MinimumPoint.X > CentP.X && p.GetSolid().MaximumPoint.X >= MaxX) select p).FirstOrDefault();
                HPTop = (from p in PartListC where !dc.IsPlateSideViewN(p) && (p.GetSolid().MinimumPoint.X > CentP.X && p.GetSolid().MaximumPoint.X >= MaxX) && Com.CenterPoint(p).Y > BC.Points.P1.Y select p).FirstOrDefault();
                HPBott = (from p in PartListC where !dc.IsPlateSideViewN(p) && (p.GetSolid().MinimumPoint.X > CentP.X && p.GetSolid().MaximumPoint.X >= MaxX) && Com.CenterPoint(p).Y < BC.Points.P2.Y select p).FirstOrDefault();
            }

            if (EndPlate != null)
            {
                BC.EP = new EndPlateClass();
                BC.EP.EndPlate = new PartClass();
                BC.EP.EndPlate.part = EndPlate;

                BC.EP.EndPlate.Points = Com.GetPartPoints(EndPlate);

                List<BoltGroup> Bolts = Com.EnumtoArray(EndPlate.GetBolts()).OfType<BoltGroup>().ToList();
                if (Bolts != null && Bolts.Count > 0)
                {
                    PointList BoltsP = Com.GetBoltPoints(Bolts);

                    BC.EP.AllPoints = BoltsP;

                    List<Point> points = (from p in BoltsP.OfType<Point>() where p.Y > BC.Points.P1.Y orderby p.Y descending select p).ToList();

                    if (points != null && points.Count > 0)
                        BC.EP.TopBoltP = Com.PointToPointList(points);

                    points = (from p in BoltsP.OfType<Point>() where p.Y < BC.Points.P2.Y orderby p.Y descending select p).ToList();
                    if (points != null && points.Count > 0)
                        BC.EP.BottBoltP = Com.PointToPointList(points);

                    points = (from p in BoltsP.OfType<Point>() where p.Y < BC.Points.P1.Y && p.Y > BC.Points.P2.Y orderby p.Y descending select p).ToList();
                    if (points != null && points.Count > 0)
                        BC.EP.MidBoltP = Com.PointToPointList(points);
                }
            }

            if (HPTop != null)
            {
                if (BC.EP == null)
                    BC.EP = new EndPlateClass();


                PartPoints Points = Com.GetPartPoints(HPTop);

                PointList VertList = dc.GetVertexList(HPTop.GetSolid());
                BC.EP.HPTop = new PartClass();
                BC.EP.HPTop.part = HPTop;
                BC.EP.HPTop.Points = new PartPoints();
                if (Position == "Left")
                {
                    BC.EP.HPTop.Points.P1 = Points.P1;
                    BC.EP.HPTop.Points.P2 = Points.P2;



                    BC.EP.HPTop.Points.P3 = Points.P3;
                    BC.EP.HPTop.Points.P4 = (from p in VertList.OfType<Point>() where p.Y > Points.P3.Y && p.X > Points.CentP.X orderby p.Y ascending select p).FirstOrDefault();
                    BC.EP.HPTop.Points.P5 = (from p in VertList.OfType<Point>() where p.Y == Points.P1.Y orderby p.X descending select p).FirstOrDefault();


                }
                else
                {
                    BC.EP.HPTop.Points.P1 = Points.P4;
                    BC.EP.HPTop.Points.P2 = Points.P3;
                    BC.EP.HPTop.Points.P3 = Points.P2;
                    BC.EP.HPTop.Points.P4 = (from p in VertList.OfType<Point>() where p.Y > BC.EP.HPTop.Points.P3.Y && p.X < Points.CentP.X orderby p.Y ascending select p).FirstOrDefault();
                    BC.EP.HPTop.Points.P5 = (from p in VertList.OfType<Point>() where p.Y == BC.EP.HPTop.Points.P1.Y orderby p.X ascending select p).FirstOrDefault();
                }

            }

            if (HPBott != null)
            {
                if (BC.EP == null)
                    BC.EP = new EndPlateClass();


                PartPoints Points = Com.GetPartPoints(HPBott);

                PointList VertList = dc.GetVertexList(HPBott.GetSolid());
                BC.EP.HPBotom = new PartClass();
                BC.EP.HPBotom.part = HPBott;
                BC.EP.HPBotom.Points = new PartPoints();
                if (Position == "Left")
                {
                    BC.EP.HPBotom.Points.P1 = Points.P2;
                    BC.EP.HPBotom.Points.P2 = Points.P1;
                    BC.EP.HPBotom.Points.P3 = Points.P4;
                    BC.EP.HPBotom.Points.P4 = (from p in VertList.OfType<Point>() where p.Y < BC.EP.HPBotom.Points.P3.Y && p.X > Points.CentP.X orderby p.Y descending select p).FirstOrDefault();
                    BC.EP.HPBotom.Points.P5 = (from p in VertList.OfType<Point>() where p.Y == BC.EP.HPBotom.Points.P1.Y orderby p.X descending select p).FirstOrDefault();
                }
                else
                {
                    BC.EP.HPBotom.Points.P1 = Points.P3;
                    BC.EP.HPBotom.Points.P2 = Points.P4;
                    BC.EP.HPBotom.Points.P3 = Points.P1;
                    BC.EP.HPBotom.Points.P4 = (from p in VertList.OfType<Point>() where p.Y < BC.EP.HPBotom.Points.P3.Y && p.X < Points.CentP.X orderby p.Y descending select p).FirstOrDefault();
                    BC.EP.HPBotom.Points.P5 = (from p in VertList.OfType<Point>() where p.Y == BC.EP.HPBotom.Points.P1.Y orderby p.X ascending select p).FirstOrDefault();
                }

            }


        }

        private void GetEndPlatePropertiesS(List<TSM.Part> PartListC)
        {
            TSM.Part EndPlate = null;
            TSM.Part HPTop = null;
            TSM.Part HPBott = null;

            Point CentP = Com.CenterPoint(BC.beam.StartPoint, BC.beam.EndPoint);
            EndPlate = (from p in PartListC where Com.HasBolt(p) && !dc.IsPlateSideViewN(p) && !IsNotMianView(p) select p).FirstOrDefault();
            HPTop = (from p in PartListC where dc.IsPlateSideViewN(p) && Com.CenterPoint(p).Y > BC.Points.P1.Y select p).FirstOrDefault();
            HPBott = (from p in PartListC where dc.IsPlateSideViewN(p) && Com.CenterPoint(p).Y < BC.Points.P2.Y select p).FirstOrDefault();


            if (EndPlate != null)
            {
                BC.EP = new EndPlateClass();
                BC.EP.EndPlate = new PartClass();
                BC.EP.EndPlate.part = EndPlate;
                BC.EP.EndPlate.Points = Com.GetPartPoints(EndPlate);

                List<BoltGroup> Bolts = Com.EnumtoArray(EndPlate.GetBolts()).OfType<BoltGroup>().ToList();
                if (Bolts != null && Bolts.Count > 0)
                {
                    PointList BoltsP = Com.GetBoltPoints(Bolts);

                    BC.EP.AllPoints = BoltsP;

                    List<Point> points = (from p in BoltsP.OfType<Point>() where p.Y > BC.Points.P1.Y orderby p.Y descending select p).ToList();

                    if (points != null && points.Count > 0)
                        BC.EP.TopBoltP = Com.PointToPointList(points);

                    points = (from p in BoltsP.OfType<Point>() where p.Y < BC.Points.P2.Y orderby p.Y descending select p).ToList();
                    if (points != null && points.Count > 0)
                        BC.EP.BottBoltP = Com.PointToPointList(points);

                    points = (from p in BoltsP.OfType<Point>() where p.Y < BC.Points.P1.Y && p.Y > BC.Points.P2.Y orderby p.Y descending select p).ToList();
                    if (points != null && points.Count > 0)
                        BC.EP.MidBoltP = Com.PointToPointList(points);
                }
            }

            if (HPTop != null)
            {
                if (BC.EP == null)
                    BC.EP = new EndPlateClass();


                PointList VertList = dc.GetVertexList(HPTop.GetSolid());
                BC.EP.HPTop = new PartClass();
                BC.EP.HPTop.part = HPTop;
                BC.EP.HPTop.Points = Com.GetPartPoints(HPTop);


            }

            if (HPBott != null)
            {
                if (BC.EP == null)
                    BC.EP = new EndPlateClass();

                PointList VertList = dc.GetVertexList(HPBott.GetSolid());
                BC.EP.HPBotom = new PartClass();
                BC.EP.HPBotom.part = HPBott;
                BC.EP.HPBotom.Points = Com.GetPartPoints(HPBott);


            }


        }

        #endregion

        #region Helping Methods
        private double GetPartWidth(TSM.Part part)
        {
            return (part.GetSolid().MaximumPoint.X - part.GetSolid().MinimumPoint.X);
        }
        private bool IsNotMianView(TSM.Part EP)
        {
            bool RetCheck = false;

            if (EP is Beam)
            {
                Beam EPB = EP as Beam;
                Point P1 = new Point(EPB.StartPoint.X, EPB.StartPoint.Y);
                Point P2 = new Point(EPB.EndPoint.X, EPB.EndPoint.Y);
                double Ydist = Math.Abs((EPB.StartPoint.Y - EPB.EndPoint.Y));
                double Dist = Distance.PointToPoint(P1, P2);
                if (Dist < 20 || Ydist < 20)
                    RetCheck = true;
            }


            return RetCheck;
        }
        #endregion

        private class EndPlateClass
        {
            public PartClass EndPlate { get; set; }
            public PartClass HPTop { get; set; }
            public PartClass HPBotom { get; set; }
            public PointList TopBoltP { get; set; }
            public PointList MidBoltP { get; set; }
            public PointList BottBoltP { get; set; }
            public PointList AllPoints { get; set; }
        }

        private class BeamClass_BEP3
        {
            public Beam beam { get; set; }
            public EndPlateClass EP { get; set; }
            public PartPoints Points { get; set; }
            public PlacingClass PC { get; set; }

        }

    }

}
