﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Tekla.Structures;
using Tekla.Structures.Drawing;
using Tekla.Structures.Geometry3d;
using Tekla.Structures.Model;
using TSD = Tekla.Structures.Drawing;
using TSM = Tekla.Structures.Model;
using VirtueleDrawingAutomation;
using TSDD = Tekla.Structures.Datatype;
using TSG = Tekla.Structures.Geometry3d;

namespace Auto_Detailing_Tool_Beam
{
    public class BeamDim_BG22
    {
        #region Global Variables
        DimCom dc = new DimCom();
        StraightDimensionSet.StraightDimensionSetAttributes StAtrr = new StraightDimensionSet.StraightDimensionSetAttributes("standard");
        StraightDimensionSet.StraightDimensionSetAttributes RdAtrr = new StraightDimensionSet.StraightDimensionSetAttributes("standard");

        public Beam MainBeam = null;
        VirtueleDrawingAutomation.Json.DrawingAttributeInfoJson.AttributeFiles dimAttrClass = null;
        List<TSD.StraightDimension> KnockDim = new List<StraightDimension>();
        BeamClass_BG22 BC = null;
        BeamClass_BG22S BCS = null;
        VirtueleDrawingAutomation.Json.AutoDimensionTypesJson.BG22Json DN = null;
        TSD.View CView = null;
        string ViewName = "";
        List<int> Ids = new List<int>();
        #endregion

        public List<int> ApplyDim(TSD.View CView, string ViewName, AutoDimensioningTypes autoDimensioningTypes, DrawingAttributeInfo drawingAttributeInfo, List<int> Ids)
        {
            try
            {
                this.Ids = Ids;
            Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane());
            //Set model everything to the view
            Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane(CView.DisplayCoordinateSystem));

            this.CView = CView;
            this.dimAttrClass = drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files;
            this.DN = autoDimensioningTypes.BG22;
            StAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.StandardDimension);
            RdAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.RunningDimension);
            this.MainBeam = (Com.MyModel.SelectModelObject(new Identifier((CView.GetDrawing() as AssemblyDrawing).AssemblyIdentifier.ID)) as TSM.Assembly).GetMainPart() as TSM.Beam;
            this.MainBeam.Select();
            string ProType = Com.GetProType(MainBeam);
            this.ViewName = ViewName;


            GetBeamClassClass(CView);

            //TestDim();
            if (ViewName == "Front View")
            {
                while (BC.TopGP != null || BC.BottGP != null)
                {
                    ApplyDimType();
                    GetBeamClassClass(CView);
                }
            }
            else if (ViewName == "Section View")
                AppySectionDim();
            else if (ViewName == "Top View" || ViewName == "Bottom View")
                ApplyTVDim();


           
            }
            catch (Exception ex)
            { }

            Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane());

            return Ids;
        }

        private void ApplyDimType()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            TSD.PointList TempList = new PointList();

            bool IsVertDim = false;
            Point RefP = null;
            #region Top Gusset
            if (BC.TopGP?.GussetPlate != null)
            {

                ApplyLeftTopG();
                ApplyRightTopG();

                Ids.Add(BC.TopGP.GussetPlate.Identifier.ID);
                // Com.SetCode(BC.TopGP.GussetPlate);
            }
            #endregion


            #region Bottom Gusset
            if (BC.BottGP?.GussetPlate != null)
            {

                ApplyLeftBottG();
                ApplyRightBottG();


                //  Com.SetCode(BC.BottGP.GussetPlate);
                Ids.Add(BC.BottGP.GussetPlate.Identifier.ID);
            }
            #endregion

            AppyMidStiff();

        }

        private void ApplyLeftTopG()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            TSD.PointList TempList = new PointList();

            if (BC.TopGP?.LB != null)
            {

                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;

                PointList MidPList = Com.GetBoltPoints(BC.TopGP.LB.BoltM);
                PointList MidPList1 = null;
                if (BC.TopGP.LB.BoltM1 != null)
                    MidPList1 = Com.GetBoltPoints(BC.TopGP.LB.BoltM1);
                TempList = Com.GetBoltPoints(BC.TopGP.LB.BoltM);
                TSG.Line YLine = new TSG.Line(BC.TopGP.Points.P6, BC.TopGP.Points.P1);
                TSG.Line XLine = new TSG.Line(Com.MaxP(MidPList, "X"), Com.MaxP(MidPList, "Y"));
                TSG.Line XLineM = new TSG.Line(Com.MinP(MidPList, "X"), Com.MinP(MidPList, "Y"));

                TSG.Line YLineR = new TSG.Line(BC.TopGP.LB.IntPoint, Com.MaxP(MidPList, "Y"));
                // Com.DrawLineDotted(CView, BC.TopGP.Points.P6, BC.TopGP.Points.P1);
                Vector LeftVect = YLineR.Direction;



                if (LeftVect.X > 0)
                    LeftVect = dc.ChangeVector(LeftVect);

                Vector RightVect = YLineR.Direction;
                if (RightVect.X < 0)
                    RightVect = dc.ChangeVector(RightVect);

                Vector TopVect = XLine.Direction;
                if (TopVect.Y < 0)
                    TopVect = dc.ChangeVector(TopVect);

                Vector BottVect = XLine.Direction;
                if (BottVect.Y > 0)
                    BottVect = dc.ChangeVector(BottVect);


                #region Diagonal Right
                double DistRight = BC.PC.DistInc;
                TempList = dc.ChangePints(BC.TopGP.LB.BoltM, CView, RightVect);

                // Dim No 11.3
                if (DN.DimIDNo11Dot3)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    pointList.Add(BC.TopGP.Points.P6);
                    xDim = dc.InsertDim(CView, pointList, RightVect, DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, DistRight);
                }

                // Dim No 11
                if (DN.DimIDNo11)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, RightVect, DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, DistRight);
                }

                // Dim No 10.1
                if (DN.DimIDNo10Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "Y"));
                    pointList.Add(BC.TopGP.LB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, RightVect, DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, DistRight);
                }

                if (DN.DimIDNo11Dot3 || DN.DimIDNo10 || DN.DimIDNo11Dot3)
                    DistRight += DistRight;

                // Dim No 11.2
                if (DN.DimIDNo11Dot2)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, RightVect, DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, XLine, DistRight);
                        Com.GroupDim(xDim);
                    }

                }

                #endregion

                #region Diagonal Left
                if (BC.TopGP.LB.BoltM1 != null)
                {

                    DistRight = BC.PC.DistInc;
                    TempList = dc.ChangePints(BC.TopGP.LB.BoltM1, CView, LeftVect);

                    // Dim No 11.3
                    if (DN.DimIDNo11Dot3)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MaxP(TempList, "Y"));
                        pointList.Add(BC.TopGP.Points.P1);
                        xDim = dc.InsertDim(CView, pointList, LeftVect, DistRight, StAtrr);
                        if (xDim != null)
                            PL.DimPlacingDiag(xDim, XLineM, DistRight);
                    }

                    // Dim No 11
                    if (DN.DimIDNo11)
                    {
                        pointList = new PointList();
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, LeftVect, DistRight, StAtrr);
                        if (xDim != null)
                            PL.DimPlacingDiag(xDim, XLineM, DistRight);
                    }

                    // Dim No 10
                    if (DN.DimIDNo10)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MinP(TempList, "Y"));
                        pointList.Add(BC.TopGP.LB.RefPBrace);
                        xDim = dc.InsertDim(CView, pointList, LeftVect, DistRight, StAtrr);
                        if (xDim != null)
                            PL.DimPlacingDiag(xDim, XLineM, DistRight);
                    }

                    if (DN.DimIDNo11Dot3 || DN.DimIDNo10 || DN.DimIDNo11Dot3)
                        DistRight += DistRight;

                    // Dim No 31, 32
                    if (DN.DimIDNo31 || DN.DimIDNo32)
                    {
                        pointList = new PointList();
                        if (DN.DimIDNo31)// Dim No 31
                            pointList.Add(Com.MinP(TempList, "Y"));

                        pointList.Add(BC.TopGP.LB.IntPointB);

                        if (DN.DimIDNo32)// Dim No 32
                            pointList.Add(BC.TopGP.LB.RefPBrace);

                        xDim = dc.InsertDim(CView, pointList, LeftVect, DistRight, StAtrr);
                        if (xDim != null)
                            PL.DimPlacingDiag(xDim, XLineM, DistRight);
                    }

                    // Dim No 11.2
                    if (DN.DimIDNo11Dot2)
                    {
                        pointList = new PointList();
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, LeftVect, DistRight, StAtrr);
                        if (xDim != null)
                        {
                            PL.DimPlacingDiag(xDim, XLineM, DistRight);
                            Com.GroupDim(xDim);
                        }

                    }

                }

                #endregion

                #region Straight Left
                Vect = new Vector(-1, 0, 0);
                BC.PC.DistLeft = (BC.PC.DistInc);

                // Dim No 2
                if (DN.DimIDNo2 && BC.TopGP.LB.BoltM1 != null)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(MidPList1, "Y"));
                    pointList.Add(BC.TopGP.Points.P2);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, BC.TopGP.Points.P2.X, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }

                }

                // Dim No 2.3
                if (DN.DimIDNo2Dot3)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(MidPList, "X"));
                    pointList.Add(BC.TopGP.LB.IntPoint);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, BC.TopGP.Points.P2.X, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }

                }

                // Dim No 2.2
                if (DN.DimIDNo2Dot2)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(MidPList, "X"));
                    pointList.Add(BC.TopGP.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, BC.TopGP.Points.P2.X, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }

                }

                // Dim No 2.4
                if (DN.DimIDNo2Dot4)
                {

                    pointList = new PointList();
                    pointList.Add(BC.TopGP.LB.IntPoint);
                    pointList.Add(BC.TopGP.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.TopGP.Points.P2.X, BC.PC.DistLeft);

                    BC.PC.DistLeft += BC.PC.DistInc;
                }

                // Dim No 2.1
                if (DN.DimIDNo2Dot1)
                {

                    pointList = new PointList();
                    pointList.Add(Com.MaxP(MidPList, "Y"));
                    pointList.Add(BC.TopGP.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.TopGP.Points.P2.X, BC.PC.DistLeft);

                    BC.PC.DistLeft += BC.PC.DistInc;
                }


                #endregion

                #region RD Dim
                BC.PC.DistTop = (BC.PC.DistInc);
                //RD Dim
                Vect = new Vector(0, 1, 0);

                // Dim No 1.5
                if (DN.DimIDNo1Dot5)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(BC.TopGP.LB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                // Dim No 1.4
                if (DN.DimIDNo1Dot4)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(BC.TopGP.LB.IntPointB);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                // Dim No 28, 28.1
                if (BC.SCT != null && (DN.DimIDNo28 || DN.DimIDNo28Dot1))
                {

                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(BC.SCT.Points.P1);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }

                // Dim No 1.3
                if (DN.DimIDNo1Dot3 && BC.TopGP.LB.BoltM1 != null)
                {
                    TempList = Com.GetBoltPoints(BC.TopGP.LB.BoltM1);
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(Com.MinP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                // Dim No 1.2
                if (DN.DimIDNo1Dot2)
                {
                    TempList = Com.GetBoltPoints(BC.TopGP.LB.BoltM);
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                // Dim No 1.1
                if (DN.DimIDNo1Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(BC.TopGP.LB.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                // Dim No 1
                if (DN.DimIDNo1)
                {
                    TempList = Com.GetBoltPoints(BC.TopGP.LB.BoltM);
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(Com.MinP(TempList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                #endregion

                #region Top Straight Dim

                Vect = new Vector(0, 1, 0);

                // Dim No 13
                if (DN.DimIDNo13 || DN.DimIDNo14)
                {

                    pointList = new PointList();
                    if (DN.DimIDNo13) // Dim No 13
                        pointList.Add(BC.TopGP.LB.IntPoint);

                    pointList.Add(BC.TopGP.LB.IntPointB);

                    if (DN.DimIDNo14) // Dim No 14
                        pointList.Add(BC.TopGP.LB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }


                }

                // Dim No 15
                if (DN.DimIDNo15)
                {

                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P6);
                    pointList.Add(BC.TopGP.LB.IntPoint);
                    pointList.Add(BC.TopGP.LB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }


                // Dim No 16
                if (DN.DimIDNo16)
                {
                    TempList = Com.GetBoltPoints(BC.TopGP.LB.BoltM);
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    pointList.Add(BC.TopGP.LB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }

                // Dim No 17.1
                if (DN.DimIDNo17Dot1)
                {
                    TempList = Com.GetBoltPoints(BC.TopGP.LB.BoltM);
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.LB.IntPoint);
                    pointList.Add(Com.MinP(TempList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);

                    TempList = Com.GetBoltPoints(BC.TopGP.RB.BoltM);
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.RB.IntPoint);
                    pointList.Add(Com.MaxP(TempList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                }

                // Dim No 17
                if (DN.DimIDNo17)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.LB.IntPoint);
                    pointList.Add(BC.TopGP.RB.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                }

                if (DN.DimIDNo17 || DN.DimIDNo17Dot1)
                    BC.PC.DistTop += BC.PC.DistInc;

                // Dim No 18
                if (DN.DimIDNo18)
                {

                    pointList = new PointList();
                    TempList = Com.GetBoltPoints(BC.TopGP.LB.BoltM);
                    pointList.Add(Com.MinP(TempList, "X"));
                    pointList.Add(BC.TopGP.LB.RefPBrace);
                    TempList = Com.GetBoltPoints(BC.TopGP.RB.BoltM);
                    pointList.Add(Com.MaxP(TempList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }

                // Dim No 19
                if (DN.DimIDNo19)
                {

                    pointList = new PointList();
                    TempList = Com.GetBoltPoints(BC.TopGP.LB.BoltM);
                    pointList.Add(Com.MinP(TempList, "X"));
                    TempList = Com.GetBoltPoints(BC.TopGP.RB.BoltM);
                    pointList.Add(Com.MaxP(TempList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }

                // Dim No 20
                if (DN.DimIDNo20)
                {

                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P6);
                    pointList.Add(BC.TopGP.LB.RefPBrace);
                    pointList.Add(BC.TopGP.Points.P5);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }

                // Dim No 21
                if (DN.DimIDNo21)
                {

                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P2);
                    pointList.Add(BC.TopGP.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }

                // Dim No 21.1
                if (DN.DimIDNo21Dot1)
                {
                    BC.PC.DistTop += (BC.PC.DistInc / 3);
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P6);
                    pointList.Add(BC.TopGP.Points.P5);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        Com.SetMidDimText(xDim, "PROTECTED AREA NS & F/S");
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }

                // Dim No 9
                if (DN.DimIDNo9)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(BC.TopGP.LB.RefPBrace);
                    pointList.Add(BC.Points.P4);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }

                #endregion

                #region Diagonal Top
                BC.PC.DistTop = (BC.PC.DistInc * 3);
                if (BC.TopGP.LB.BoltM1 != null)
                {
                    TempList = dc.ChangePints(BC.TopGP.LB.BoltM1, CView, TopVect);
                    // Dim No 4
                    if (DN.DimIDNo4)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.TopGP.LB.IntPoint);
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, TopVect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                        {
                            PL.DimPlacingDiag(xDim, YLine, BC.PC.DistTop);
                            BC.PC.DistTop += BC.PC.DistInc;
                        }
                    }

                    // Dim No 5
                    if (DN.DimIDNo5)
                    {
                        pointList = new PointList();
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, TopVect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                        {
                            PL.DimPlacingDiag(xDim, YLine, BC.PC.DistTop);
                            BC.PC.DistTop += BC.PC.DistInc;
                        }
                    }

                }

                TempList = dc.ChangePints(BC.TopGP.LB.BoltM, CView, TopVect);
                // Dim No 6
                if (DN.DimIDNo6)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.LB.IntPoint);
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, TopVect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }

                // Dim No 7
                if (DN.DimIDNo7)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, TopVect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }

                #endregion

                // Com.DrawLineDotted(CView, BC.TopGP.LB.IntPoint, BC.TopGP.LB.RefPBrace);

                //Dim Code 8 // Angle Dimension
                if (DN.DimIDNo8)
                {
                    Point Temp = new Point(BC.TopGP.LB.IntPoint.X, BC.TopGP.LB.RefPBrace.Y, BC.TopGP.LB.IntPoint.Z);
                    AngleDimension angDimA = new AngleDimension(CView, BC.TopGP.LB.IntPoint, BC.TopGP.LB.RefPBrace, Temp, -80);
                    angDimA.Insert();
                }

            }
        }

        private void ApplyRightTopG()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            TSD.PointList TempList = new PointList();

            if (BC.TopGP?.LB != null)
            {

                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;

                PointList MidPList = Com.GetBoltPoints(BC.TopGP.RB.BoltM);

                PointList MidPList1 = null;
                if (BC.TopGP.LB.BoltM1 != null)
                    MidPList1 = Com.GetBoltPoints(BC.TopGP.RB.BoltM1);

                TempList = Com.GetBoltPoints(BC.TopGP.RB.BoltM);
                TSG.Line YLine = new TSG.Line(BC.TopGP.Points.P4, BC.TopGP.Points.P5);
                TSG.Line XLine = new TSG.Line(Com.MaxP(MidPList, "X"), Com.MinP(MidPList, "Y"));
                TSG.Line XLineM = new TSG.Line(Com.MinP(MidPList, "X"), Com.MaxP(MidPList, "Y"));
                //Com.DrawLineDotted(CView, BC.TopGP.Points.P4, BC.TopGP.Points.P5);
                TSG.Line YLineR = new TSG.Line(BC.TopGP.RB.IntPoint, Com.MaxP(MidPList, "Y"));
                Vector LeftVect = YLineR.Direction;



                if (LeftVect.X > 0)
                    LeftVect = dc.ChangeVector(LeftVect);

                Vector RightVect = YLineR.Direction;
                if (RightVect.X < 0)
                    RightVect = dc.ChangeVector(RightVect);

                Vector TopVect = XLine.Direction;
                if (TopVect.Y < 0)
                    TopVect = dc.ChangeVector(TopVect);

                Vector BottVect = XLine.Direction;
                if (BottVect.Y > 0)
                    BottVect = dc.ChangeVector(BottVect);


                #region Diagonal Right
                double DistRight = BC.PC.DistInc;
                TempList = dc.ChangePints(BC.TopGP.RB.BoltM, CView, RightVect);

                // Dim No 11.3
                if (DN.DimIDNo11Dot3)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    pointList.Add(BC.TopGP.Points.P5);
                    xDim = dc.InsertDim(CView, pointList, RightVect, DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, DistRight);
                }

                // Dim No 11
                if (DN.DimIDNo11)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, RightVect, DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, DistRight);
                }

                // Dim No 10.1
                if (DN.DimIDNo10Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "Y"));
                    pointList.Add(BC.TopGP.RB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, RightVect, DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, DistRight);
                }

                if (DN.DimIDNo11Dot3 || DN.DimIDNo10 || DN.DimIDNo11Dot3)
                    DistRight += DistRight;

                // Dim No 11.2
                if (DN.DimIDNo11Dot2)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, RightVect, DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, XLine, DistRight);
                        Com.GroupDim(xDim);
                    }

                }

                #endregion

                #region Diagonal Left
                DistRight = BC.PC.DistInc;

                if (BC.TopGP.LB.BoltM1 != null)
                {
                    TempList = dc.ChangePints(BC.TopGP.RB.BoltM1, CView, LeftVect);

                    // Dim No 11.3
                    if (DN.DimIDNo11Dot3)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MaxP(TempList, "Y"));
                        pointList.Add(BC.TopGP.Points.P4);
                        xDim = dc.InsertDim(CView, pointList, LeftVect, DistRight, StAtrr);
                        if (xDim != null)
                            PL.DimPlacingDiag(xDim, XLineM, DistRight);
                    }

                    // Dim No 11
                    if (DN.DimIDNo11)
                    {
                        pointList = new PointList();
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, LeftVect, DistRight, StAtrr);
                        if (xDim != null)
                            PL.DimPlacingDiag(xDim, XLineM, DistRight);
                    }

                    // Dim No 10
                    if (DN.DimIDNo10)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MinP(TempList, "Y"));
                        pointList.Add(BC.TopGP.RB.RefPBrace);
                        xDim = dc.InsertDim(CView, pointList, LeftVect, DistRight, StAtrr);
                        if (xDim != null)
                            PL.DimPlacingDiag(xDim, XLineM, DistRight);
                    }

                    if (DN.DimIDNo11Dot3 || DN.DimIDNo10 || DN.DimIDNo11Dot3)
                        DistRight += DistRight;

                    // Dim No 31, 32
                    if (DN.DimIDNo31 || DN.DimIDNo32)
                    {
                        pointList = new PointList();
                        if (DN.DimIDNo31)// Dim No 31
                            pointList.Add(Com.MinP(TempList, "Y"));

                        pointList.Add(BC.TopGP.RB.IntPointB);

                        if (DN.DimIDNo32)// Dim No 32
                            pointList.Add(BC.TopGP.RB.RefPBrace);

                        xDim = dc.InsertDim(CView, pointList, LeftVect, DistRight, StAtrr);
                        if (xDim != null)
                            PL.DimPlacingDiag(xDim, XLineM, DistRight);
                    }


                    // Dim No 11.2
                    if (DN.DimIDNo11Dot2)
                    {
                        pointList = new PointList();
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, LeftVect, DistRight, StAtrr);
                        if (xDim != null)
                        {
                            PL.DimPlacingDiag(xDim, XLineM, DistRight);
                            Com.GroupDim(xDim);
                        }

                    }
                }

                #endregion

                #region Straight Right
                Vect = new Vector(1, 0, 0);
                BC.PC.DistRight = (BC.PC.DistInc);

                // Dim No 2
                if (DN.DimIDNo2 && MidPList1 != null)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(MidPList1, "Y"));
                    pointList.Add(BC.TopGP.Points.P3);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, BC.TopGP.Points.P3.X, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }

                }

                // Dim No 2.3
                if (DN.DimIDNo2Dot3)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(MidPList, "X"));
                    pointList.Add(BC.TopGP.RB.IntPoint);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, BC.TopGP.Points.P3.X, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }

                }

                // Dim No 2.2
                if (DN.DimIDNo2Dot2)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(MidPList, "X"));
                    pointList.Add(BC.TopGP.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, BC.TopGP.Points.P3.X, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }

                }

                // Dim No 2.4
                if (DN.DimIDNo2Dot4)
                {

                    pointList = new PointList();
                    pointList.Add(BC.TopGP.RB.IntPoint);
                    pointList.Add(BC.TopGP.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.TopGP.Points.P3.X, BC.PC.DistRight);

                    BC.PC.DistRight += BC.PC.DistInc;
                }

                // Dim No 2.1
                if (DN.DimIDNo2Dot1)
                {

                    pointList = new PointList();
                    pointList.Add(Com.MaxP(MidPList, "Y"));
                    pointList.Add(BC.TopGP.Points.P3);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.TopGP.Points.P3.X, BC.PC.DistRight);

                    BC.PC.DistRight += BC.PC.DistInc;
                }


                #endregion



                #region RD Dim
                BC.PC.DistTop = (BC.PC.DistInc * 3);

                //RD Dim
                Vect = new Vector(0, 1, 0);

                // Dim No 1.6
                if (BC.SCM != null && DN.DimIDNo1Dot6)
                {

                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(BC.SCM.Points.P1);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.SCM.Points.P1.Y, (BC.PC.DistInc * 3));

                    }
                }

                // Dim No 1.4
                if (DN.DimIDNo1Dot4)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(BC.TopGP.RB.IntPointB);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                // Dim No 1.3
                if (DN.DimIDNo1Dot3 && BC.TopGP.RB.BoltM1 != null)
                {
                    TempList = Com.GetBoltPoints(BC.TopGP.RB.BoltM1);
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(Com.MinP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                // Dim No 1.2
                if (DN.DimIDNo1Dot2)
                {
                    TempList = Com.GetBoltPoints(BC.TopGP.RB.BoltM);
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                // Dim No 1.1
                if (DN.DimIDNo1Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(BC.TopGP.RB.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                // Dim No 1
                if (DN.DimIDNo1)
                {
                    TempList = Com.GetBoltPoints(BC.TopGP.RB.BoltM);
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(Com.MaxP(TempList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                #endregion

                #region Top Straight Dim

                Vect = new Vector(0, 1, 0);

                // Dim No 13
                if (DN.DimIDNo13 || DN.DimIDNo14)
                {

                    pointList = new PointList();
                    if (DN.DimIDNo13) // Dim No 13
                        pointList.Add(BC.TopGP.RB.IntPoint);

                    pointList.Add(BC.TopGP.RB.IntPointB);

                    if (DN.DimIDNo14) // Dim No 14
                        pointList.Add(BC.TopGP.RB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }


                }

                // Dim No 15
                if (DN.DimIDNo15)
                {

                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P5);
                    pointList.Add(BC.TopGP.RB.IntPoint);
                    pointList.Add(BC.TopGP.RB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }


                // Dim No 16
                if (DN.DimIDNo16)
                {
                    TempList = Com.GetBoltPoints(BC.TopGP.RB.BoltM);
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    pointList.Add(BC.TopGP.RB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }

                #endregion

                #region Diagonal Top
                BC.PC.DistTop = (BC.PC.DistInc * 3);
                if (BC.TopGP.LB.BoltM1 != null)
                {
                    TempList = dc.ChangePints(BC.TopGP.RB.BoltM1, CView, TopVect);
                    // Dim No 4
                    if (DN.DimIDNo4)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.TopGP.RB.IntPoint);
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, TopVect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                        {
                            PL.DimPlacingDiag(xDim, YLine, BC.PC.DistTop);
                            BC.PC.DistTop += BC.PC.DistInc;
                        }
                    }

                    // Dim No 5
                    if (DN.DimIDNo5)
                    {
                        pointList = new PointList();
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, TopVect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                        {
                            PL.DimPlacingDiag(xDim, YLine, BC.PC.DistTop);
                            BC.PC.DistTop += BC.PC.DistInc;
                        }
                    }

                }

                TempList = dc.ChangePints(BC.TopGP.RB.BoltM, CView, TopVect);
                // Dim No 6
                if (DN.DimIDNo6)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.RB.IntPoint);
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, TopVect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }

                // Dim No 7
                if (DN.DimIDNo7)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, TopVect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }

                #endregion

                // Com.DrawLineDotted(CView, BC.TopGP.RB.IntPoint, BC.TopGP.RB.RefPBrace);

                //Dim Code 8 // Angle Dimension
                if (DN.DimIDNo8)
                {
                    Point Temp = new Point(BC.TopGP.RB.IntPoint.X, BC.TopGP.RB.RefPBrace.Y, BC.TopGP.RB.IntPoint.Z);
                    AngleDimension angDimA = new AngleDimension(CView, BC.TopGP.RB.IntPoint, BC.TopGP.RB.RefPBrace, Temp, -80);
                    angDimA.Insert();
                }

            }
        }

        private void ApplyLeftBottG()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            TSD.PointList TempList = new PointList();

            if (BC.BottGP?.LB != null)
            {

                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;

                PointList MidPList = Com.GetBoltPoints(BC.BottGP.LB.BoltM);
                PointList MidPList1 = null;
                if (BC.BottGP.LB.BoltM1 != null)
                    MidPList1 = Com.GetBoltPoints(BC.BottGP.LB.BoltM1);
                TempList = Com.GetBoltPoints(BC.BottGP.LB.BoltM);
                TSG.Line YLine = new TSG.Line(BC.BottGP.Points.P6, BC.BottGP.Points.P1);
                TSG.Line XLine = new TSG.Line(Com.MaxP(MidPList, "X"), Com.MinP(MidPList, "Y"));
                TSG.Line XLineM = new TSG.Line(Com.MinP(MidPList, "X"), Com.MaxP(MidPList, "Y"));
                // Com.DrawLineDotted(CView, Com.MinP(MidPList, "X"), Com.MaxP(MidPList, "Y"));
                TSG.Line YLineR = new TSG.Line(BC.BottGP.LB.IntPoint, Com.MinP(MidPList, "Y"));
                Vector LeftVect = YLineR.Direction;



                if (LeftVect.X > 0)
                    LeftVect = dc.ChangeVector(LeftVect);

                Vector RightVect = YLineR.Direction;
                if (RightVect.X < 0)
                    RightVect = dc.ChangeVector(RightVect);

                Vector TopVect = XLine.Direction;
                if (TopVect.Y < 0)
                    TopVect = dc.ChangeVector(TopVect);

                Vector BottVect = XLine.Direction;
                if (BottVect.Y > 0)
                    BottVect = dc.ChangeVector(BottVect);


                #region Diagonal Right
                double DistRight = BC.PC.DistInc;
                TempList = dc.ChangePints(BC.BottGP.LB.BoltM, CView, RightVect);

                // Dim No 11.3
                if (DN.DimIDNo11Dot3)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "Y"));
                    pointList.Add(BC.BottGP.Points.P6);
                    xDim = dc.InsertDim(CView, pointList, RightVect, DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, DistRight);
                }

                // Dim No 11
                if (DN.DimIDNo11)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, RightVect, DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, DistRight);
                }

                // Dim No 10.1
                if (DN.DimIDNo10Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    pointList.Add(BC.BottGP.LB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, RightVect, DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, DistRight);
                }

                if (DN.DimIDNo11Dot3 || DN.DimIDNo10 || DN.DimIDNo11Dot3)
                    DistRight += DistRight;

                // Dim No 11.2
                if (DN.DimIDNo11Dot2)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, RightVect, DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, XLine, DistRight);
                        Com.GroupDim(xDim);
                    }

                }

                #endregion

                #region Diagonal Left
                if (BC.BottGP.LB.BoltM1 != null)
                {
                    DistRight = BC.PC.DistInc;
                    TempList = dc.ChangePints(BC.BottGP.LB.BoltM1, CView, LeftVect);

                    // Dim No 11.3
                    if (DN.DimIDNo11Dot3)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MinP(TempList, "Y"));
                        pointList.Add(BC.BottGP.Points.P1);
                        xDim = dc.InsertDim(CView, pointList, LeftVect, DistRight, StAtrr);
                        if (xDim != null)
                            PL.DimPlacingDiag(xDim, XLineM, DistRight);
                    }

                    // Dim No 11
                    if (DN.DimIDNo11)
                    {
                        pointList = new PointList();
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, LeftVect, DistRight, StAtrr);
                        if (xDim != null)
                            PL.DimPlacingDiag(xDim, XLineM, DistRight);
                    }

                    // Dim No 10
                    if (DN.DimIDNo10)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MaxP(TempList, "Y"));
                        pointList.Add(BC.BottGP.LB.RefPBrace);
                        xDim = dc.InsertDim(CView, pointList, LeftVect, DistRight, StAtrr);
                        if (xDim != null)
                            PL.DimPlacingDiag(xDim, XLineM, DistRight);
                    }

                    if (DN.DimIDNo11Dot3 || DN.DimIDNo10 || DN.DimIDNo11Dot3)
                        DistRight += DistRight;


                    // Dim No 31, 32
                    if (DN.DimIDNo31 || DN.DimIDNo32)
                    {
                        pointList = new PointList();
                        if (DN.DimIDNo31)// Dim No 31
                            pointList.Add(Com.MaxP(TempList, "Y"));

                        pointList.Add(BC.BottGP.LB.IntPointB);

                        if (DN.DimIDNo32)// Dim No 32
                            pointList.Add(BC.BottGP.LB.RefPBrace);

                        xDim = dc.InsertDim(CView, pointList, LeftVect, DistRight, StAtrr);
                        if (xDim != null)
                            PL.DimPlacingDiag(xDim, XLineM, DistRight);
                    }

                    // Dim No 11.2
                    if (DN.DimIDNo11Dot2)
                    {
                        pointList = new PointList();
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, LeftVect, DistRight, StAtrr);
                        if (xDim != null)
                        {
                            PL.DimPlacingDiag(xDim, XLineM, DistRight);
                            Com.GroupDim(xDim);
                        }

                    }
                }

                #endregion

                #region Straight Left
                Vect = new Vector(-1, 0, 0);
                BC.PC.DistLeft = (BC.PC.DistInc);

                if (MidPList1 != null)
                {
                    // Dim No 2
                    if (DN.DimIDNo2)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MaxP(MidPList1, "Y"));
                        pointList.Add(BC.BottGP.Points.P2);

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceLeftP(xDim, BC.BottGP.Points.P2.X, BC.PC.DistLeft);
                            BC.PC.DistLeft += BC.PC.DistInc;
                        }

                    }

                    // Dim No 3
                    if (DN.DimIDNo3)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MaxP(MidPList1, "Y"));
                        pointList.Add(new Point(BC.BottGP.Points.P2.X, BC.Points.P1.Y));

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                        PL.DistPlaceLeftP(xDim, BC.BottGP.Points.P2.X, BC.PC.DistLeft);

                    }
                }

                // Dim No 2.3
                if (DN.DimIDNo2Dot3)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.LB.IntPoint);
                    pointList.Add(Com.MinP(MidPList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.BottGP.Points.P2.X, BC.PC.DistLeft);

                }

                if (DN.DimIDNo3 || DN.DimIDNo2Dot3)
                    BC.PC.DistLeft += BC.PC.DistInc;

                // Dim No 2.2
                if (DN.DimIDNo2Dot2)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(MidPList, "X"));
                    pointList.Add(BC.BottGP.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, BC.BottGP.Points.P2.X, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }

                }

                // Dim No 2.4
                if (DN.DimIDNo2Dot4)
                {

                    pointList = new PointList();
                    pointList.Add(BC.BottGP.LB.IntPoint);
                    pointList.Add(BC.BottGP.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.BottGP.Points.P2.X, BC.PC.DistLeft);

                    BC.PC.DistLeft += BC.PC.DistInc;
                }

                // Dim No 2.1
                if (DN.DimIDNo2Dot1)
                {

                    pointList = new PointList();
                    pointList.Add(Com.MinP(MidPList, "Y"));
                    pointList.Add(BC.BottGP.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.BottGP.Points.P2.X, BC.PC.DistLeft);

                    BC.PC.DistLeft += BC.PC.DistInc;
                }

                // Dim No 3.2
                if (DN.DimIDNo3Dot2)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(MidPList, "X"));
                    pointList.Add(new Point(BC.BottGP.Points.P2.X, BC.Points.P1.Y));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.BottGP.Points.P2.X, BC.PC.DistLeft);

                    BC.PC.DistLeft += BC.PC.DistInc;
                }

                // Dim No 3.3
                if (DN.DimIDNo3Dot3)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.LB.IntPoint);
                    pointList.Add(new Point(BC.BottGP.Points.P2.X, BC.Points.P1.Y));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.BottGP.Points.P2.X, BC.PC.DistLeft);

                    BC.PC.DistLeft += BC.PC.DistInc;
                }

                // Dim No 3.1
                if (DN.DimIDNo3Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(MidPList, "Y"));
                    pointList.Add(new Point(BC.BottGP.Points.P2.X, BC.Points.P1.Y));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.BottGP.Points.P2.X, BC.PC.DistLeft);

                    BC.PC.DistLeft += BC.PC.DistInc;
                }
                #endregion

                BC.PC.DistBot = (BC.PC.DistInc);

                #region RD Dim
                //RD Dim

                // Dim No 1.6
                if (BC.TopGP == null && BC.SCM != null && DN.DimIDNo1Dot6)
                {
                    BC.PC.DistTop += BC.PC.DistInc;
                    Vect = new Vector(0, 1, 0);
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(BC.SCM.Points.P1);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }

                Vect = new Vector(0, -1, 0);

                // Dim No 1.5
                if (DN.DimIDNo1Dot5 && (BC.TopGP == null || (BC.TopGP != null && !dc.IsEqualPoints(BC.TopGP.LB.RefPBrace, BC.BottGP.LB.RefPBrace))))
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P2);
                    pointList.Add(BC.BottGP.LB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                // Dim No 1.4
                if (DN.DimIDNo1Dot4)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P2);
                    pointList.Add(BC.BottGP.LB.IntPointB);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                // Dim No 28, 28.1
                if (BC.SCB != null && (DN.DimIDNo28 || DN.DimIDNo28Dot1))
                {

                    pointList = new PointList();
                    pointList.Add(BC.Points.P2);
                    pointList.Add(BC.SCB.Points.P2);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }



                // Dim No 1.3
                if (DN.DimIDNo1Dot3 && BC.BottGP.LB.BoltM1 != null)
                {
                    TempList = Com.GetBoltPoints(BC.BottGP.LB.BoltM1);
                    pointList = new PointList();
                    pointList.Add(BC.Points.P2);
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                // Dim No 1.2
                if (DN.DimIDNo1Dot2)
                {
                    TempList = Com.GetBoltPoints(BC.BottGP.LB.BoltM);
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(Com.MinP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                // Dim No 1.1
                if (DN.DimIDNo1Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(BC.BottGP.LB.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                // Dim No 1
                if (DN.DimIDNo1)
                {
                    TempList = Com.GetBoltPoints(BC.BottGP.LB.BoltM);
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(Com.MinP(TempList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                #endregion

                #region Bottom Straight Dim

                Vect = new Vector(0, -1, 0);

                // Dim No 13
                if (DN.DimIDNo13 || DN.DimIDNo14)
                {

                    pointList = new PointList();
                    if (DN.DimIDNo13) // Dim No 13
                        pointList.Add(BC.BottGP.LB.IntPoint);

                    pointList.Add(BC.BottGP.LB.IntPointB);

                    if (DN.DimIDNo14) // Dim No 14
                        pointList.Add(BC.BottGP.LB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }


                }

                // Dim No 15
                if (DN.DimIDNo15)
                {

                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P6);
                    pointList.Add(BC.BottGP.LB.IntPoint);
                    pointList.Add(BC.BottGP.LB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }


                // Dim No 16
                if (DN.DimIDNo16)
                {
                    TempList = Com.GetBoltPoints(BC.BottGP.LB.BoltM);
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "Y"));
                    pointList.Add(BC.BottGP.LB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }

                // Dim No 17.1
                if (DN.DimIDNo17Dot1)
                {
                    TempList = Com.GetBoltPoints(BC.BottGP.LB.BoltM);
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.LB.IntPoint);
                    pointList.Add(Com.MinP(TempList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);

                    TempList = Com.GetBoltPoints(BC.BottGP.RB.BoltM);
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.RB.IntPoint);
                    pointList.Add(Com.MaxP(TempList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                }

                // Dim No 17
                if (DN.DimIDNo17)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.LB.IntPoint);
                    pointList.Add(BC.BottGP.RB.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                }

                if (DN.DimIDNo17 || DN.DimIDNo17Dot1)
                    BC.PC.DistBot += BC.PC.DistInc;

                // Dim No 18
                if (DN.DimIDNo18)
                {

                    pointList = new PointList();
                    TempList = Com.GetBoltPoints(BC.BottGP.LB.BoltM);
                    pointList.Add(Com.MinP(TempList, "X"));
                    pointList.Add(BC.BottGP.LB.RefPBrace);
                    TempList = Com.GetBoltPoints(BC.BottGP.RB.BoltM);
                    pointList.Add(Com.MaxP(TempList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }

                // Dim No 19
                if (DN.DimIDNo19)
                {

                    pointList = new PointList();
                    TempList = Com.GetBoltPoints(BC.BottGP.LB.BoltM);
                    pointList.Add(Com.MinP(TempList, "X"));
                    TempList = Com.GetBoltPoints(BC.BottGP.RB.BoltM);
                    pointList.Add(Com.MaxP(TempList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }

                // Dim No 20
                if (DN.DimIDNo20)
                {

                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P6);
                    pointList.Add(BC.BottGP.LB.RefPBrace);
                    pointList.Add(BC.BottGP.Points.P5);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }

                // Dim No 21
                if (DN.DimIDNo21)
                {

                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P2);
                    pointList.Add(BC.BottGP.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }

                // Dim No 21.1
                if (DN.DimIDNo21Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P6);
                    pointList.Add(BC.BottGP.Points.P5);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        Com.SetMidDimText(xDim, "PROTECTED AREA NS & F/S");
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                // Dim No 9
                if (DN.DimIDNo9 && (BC.TopGP==null || (BC.TopGP != null && !dc.IsEqualPoints(BC.TopGP.LB.RefPBrace, BC.BottGP.LB.RefPBrace))))
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P2);
                    pointList.Add(BC.BottGP.LB.RefPBrace);
                    pointList.Add(BC.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }

                #endregion

                #region Diagonal Bottom
                BC.PC.DistBot = (BC.PC.DistInc * 3);
                if (BC.BottGP.LB.BoltM1 != null)
                {
                    TempList = dc.ChangePints(BC.BottGP.LB.BoltM1, CView, BottVect);
                    // Dim No 4
                    if (DN.DimIDNo4)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.BottGP.LB.IntPoint);
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, BottVect, BC.PC.DistBot, StAtrr);
                        if (xDim != null)
                        {
                            PL.DimPlacingDiag(xDim, YLine, BC.PC.DistBot);
                            BC.PC.DistBot += BC.PC.DistInc;
                        }
                    }

                    // Dim No 5
                    if (DN.DimIDNo5)
                    {
                        pointList = new PointList();
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, BottVect, BC.PC.DistBot, StAtrr);
                        if (xDim != null)
                        {
                            PL.DimPlacingDiag(xDim, YLine, BC.PC.DistBot);
                            BC.PC.DistBot += BC.PC.DistInc;
                        }
                    }
                }

                TempList = dc.ChangePints(BC.BottGP.LB.BoltM, CView, BottVect);
                // Dim No 6
                if (DN.DimIDNo6)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.LB.IntPoint);
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, BottVect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }

                // Dim No 7
                if (DN.DimIDNo7)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, BottVect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }

                #endregion

                // Com.DrawLineDotted(CView, BC.BottGP.LB.IntPoint, BC.BottGP.LB.RefPBrace);

                //Dim Code 8 // Angle Dimension
                if (DN.DimIDNo8)
                {
                    Point Temp = new Point(BC.BottGP.LB.IntPoint.X, BC.BottGP.LB.RefPBrace.Y, BC.BottGP.LB.IntPoint.Z);
                    AngleDimension angDimA = new AngleDimension(CView, BC.BottGP.LB.IntPoint, BC.BottGP.LB.RefPBrace, Temp, -80);
                    angDimA.Insert();
                }

            }
        }

        private void ApplyRightBottG()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            TSD.PointList TempList = new PointList();

            if (BC.BottGP?.LB != null)
            {

                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;

                PointList MidPList = Com.GetBoltPoints(BC.BottGP.RB.BoltM);

                PointList MidPList1 = null;
                if (BC.BottGP.LB.BoltM1 != null)
                    MidPList1 = Com.GetBoltPoints(BC.BottGP.RB.BoltM1);


                TempList = Com.GetBoltPoints(BC.BottGP.RB.BoltM);
                TSG.Line YLine = new TSG.Line(BC.BottGP.Points.P4, BC.BottGP.Points.P5);
                TSG.Line XLine = new TSG.Line(Com.MaxP(MidPList, "X"), Com.MaxP(MidPList, "Y"));
                TSG.Line XLineM = new TSG.Line(Com.MinP(MidPList, "X"), Com.MinP(MidPList, "Y"));
                //Com.DrawLineDotted(CView, Com.MinP(MidPList, "X"), Com.MinP(MidPList, "Y"));

                TSG.Line YLineR = new TSG.Line(BC.BottGP.RB.IntPoint, Com.MinP(MidPList, "Y"));
                Vector LeftVect = YLineR.Direction;



                if (LeftVect.X > 0)
                    LeftVect = dc.ChangeVector(LeftVect);

                Vector RightVect = YLineR.Direction;
                if (RightVect.X < 0)
                    RightVect = dc.ChangeVector(RightVect);

                Vector TopVect = XLine.Direction;
                if (TopVect.Y < 0)
                    TopVect = dc.ChangeVector(TopVect);

                Vector BottVect = XLine.Direction;
                if (BottVect.Y > 0)
                    BottVect = dc.ChangeVector(BottVect);


                #region Diagonal Right
                double DistRight = BC.PC.DistInc;
                TempList = dc.ChangePints(BC.BottGP.RB.BoltM, CView, RightVect);

                // Dim No 11.3
                if (DN.DimIDNo11Dot3)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "Y"));
                    pointList.Add(BC.BottGP.Points.P4);
                    xDim = dc.InsertDim(CView, pointList, RightVect, DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, DistRight);
                }

                // Dim No 11
                if (DN.DimIDNo11)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, RightVect, DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, DistRight);
                }

                // Dim No 10.1
                if (DN.DimIDNo10Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    pointList.Add(BC.BottGP.RB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, RightVect, DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, DistRight);
                }

                if (DN.DimIDNo11Dot3 || DN.DimIDNo10 || DN.DimIDNo11Dot3)
                    DistRight += DistRight;

                // Dim No 11.2
                if (DN.DimIDNo11Dot2)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, RightVect, DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, XLine, DistRight);
                        Com.GroupDim(xDim);
                    }

                }

                #endregion

                #region Diagonal Left
                if (BC.BottGP.RB.BoltM1 != null)
                {
                    DistRight = BC.PC.DistInc;
                    TempList = dc.ChangePints(BC.BottGP.RB.BoltM1, CView, LeftVect);

                    // Dim No 11.3
                    if (DN.DimIDNo11Dot3)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MinP(TempList, "Y"));
                        pointList.Add(BC.BottGP.Points.P5);
                        xDim = dc.InsertDim(CView, pointList, LeftVect, DistRight, StAtrr);
                        if (xDim != null)
                            PL.DimPlacingDiag(xDim, XLineM, DistRight);
                    }

                    // Dim No 11
                    if (DN.DimIDNo11)
                    {
                        pointList = new PointList();
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, LeftVect, DistRight, StAtrr);
                        if (xDim != null)
                            PL.DimPlacingDiag(xDim, XLineM, DistRight);
                    }

                    // Dim No 10
                    if (DN.DimIDNo10)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MaxP(TempList, "Y"));
                        pointList.Add(BC.BottGP.RB.RefPBrace);
                        xDim = dc.InsertDim(CView, pointList, LeftVect, DistRight, StAtrr);
                        if (xDim != null)
                            PL.DimPlacingDiag(xDim, XLineM, DistRight);
                    }

                    if (DN.DimIDNo11Dot3 || DN.DimIDNo10 || DN.DimIDNo11Dot3)
                        DistRight += DistRight;

                    // Dim No 31, 32
                    if (DN.DimIDNo31 || DN.DimIDNo32)
                    {
                        pointList = new PointList();
                        if (DN.DimIDNo31)// Dim No 31
                            pointList.Add(Com.MaxP(TempList, "Y"));

                        pointList.Add(BC.BottGP.RB.IntPointB);

                        if (DN.DimIDNo32)// Dim No 32
                            pointList.Add(BC.BottGP.RB.RefPBrace);

                        xDim = dc.InsertDim(CView, pointList, LeftVect, DistRight, StAtrr);
                        if (xDim != null)
                            PL.DimPlacingDiag(xDim, XLineM, DistRight);
                    }

                    // Dim No 11.2
                    if (DN.DimIDNo11Dot2)
                    {
                        pointList = new PointList();
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, LeftVect, DistRight, StAtrr);
                        if (xDim != null)
                        {
                            PL.DimPlacingDiag(xDim, XLineM, DistRight);
                            Com.GroupDim(xDim);
                        }

                    }
                }

                #endregion

                #region Straight Right
                Vect = new Vector(1, 0, 0);
                BC.PC.DistRight = (BC.PC.DistInc);

                if (BC.BottGP.RB.BoltM1 != null)
                {
                    // Dim No 2
                    if (DN.DimIDNo2)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MaxP(MidPList1, "Y"));
                        pointList.Add(BC.BottGP.Points.P3);

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceRightP(xDim, BC.BottGP.Points.P3.X, BC.PC.DistRight);
                            BC.PC.DistRight += BC.PC.DistInc;
                        }

                    }


                    // Dim No 3
                    if (DN.DimIDNo3)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MaxP(MidPList1, "Y"));
                        pointList.Add(new Point(BC.BottGP.Points.P3.X, BC.Points.P1.Y));

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceRightP(xDim, BC.BottGP.Points.P3.X, BC.PC.DistRight);

                    }
                }

                // Dim No 2.3
                if (DN.DimIDNo2Dot3)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.RB.IntPoint);
                    pointList.Add(Com.MaxP(MidPList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.BottGP.Points.P3.X, BC.PC.DistRight);

                }

                if (DN.DimIDNo3 || DN.DimIDNo2Dot3)
                    BC.PC.DistRight += BC.PC.DistInc;

                // Dim No 2.2
                if (DN.DimIDNo2Dot2)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(MidPList, "X"));
                    pointList.Add(BC.BottGP.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, BC.BottGP.Points.P3.X, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }

                }

                // Dim No 2.4
                if (DN.DimIDNo2Dot4)
                {

                    pointList = new PointList();
                    pointList.Add(BC.BottGP.RB.IntPoint);
                    pointList.Add(BC.BottGP.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, BC.BottGP.Points.P3.X, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }
                }

                // Dim No 2.1
                if (DN.DimIDNo2Dot1)
                {

                    pointList = new PointList();
                    pointList.Add(Com.MinP(MidPList, "Y"));
                    pointList.Add(BC.BottGP.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, BC.BottGP.Points.P3.X, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }
                }

                // Dim No 3.2
                if (DN.DimIDNo3Dot2)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(MidPList, "X"));
                    pointList.Add(new Point(BC.BottGP.Points.P3.X, BC.Points.P1.Y));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, BC.BottGP.Points.P3.X, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }
                }

                // Dim No 3.3
                if (DN.DimIDNo3Dot3)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.RB.IntPoint);
                    pointList.Add(new Point(BC.BottGP.Points.P3.X, BC.Points.P1.Y));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, BC.BottGP.Points.P3.X, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }
                }

                // Dim No 3.1
                if (DN.DimIDNo3Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(MidPList, "Y"));
                    pointList.Add(new Point(BC.BottGP.Points.P3.X, BC.Points.P1.Y));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, BC.BottGP.Points.P3.X, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }
                }
                #endregion

                BC.PC.DistBot = (BC.PC.DistInc * 3);

                #region RD Dim
                //RD Dim
                Vect = new Vector(0, -1, 0);

                // Dim No 1.4
                if (DN.DimIDNo1Dot4)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P2);
                    pointList.Add(BC.BottGP.RB.IntPointB);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                // Dim No 1.3
                if (DN.DimIDNo1Dot3 && BC.BottGP.RB.BoltM1 != null)
                {
                    TempList = Com.GetBoltPoints(BC.BottGP.RB.BoltM1);
                    pointList = new PointList();
                    pointList.Add(BC.Points.P2);
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                // Dim No 1.2
                if (DN.DimIDNo1Dot2)
                {
                    TempList = Com.GetBoltPoints(BC.BottGP.RB.BoltM);
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(Com.MinP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                // Dim No 1.1
                if (DN.DimIDNo1Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(BC.BottGP.RB.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                // Dim No 1
                if (DN.DimIDNo1)
                {
                    TempList = Com.GetBoltPoints(BC.BottGP.RB.BoltM);
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(Com.MaxP(TempList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                #endregion

                #region Bottom Straight Dim

                Vect = new Vector(0, -1, 0);

                // Dim No 13
                if (DN.DimIDNo13 || DN.DimIDNo14)
                {

                    pointList = new PointList();
                    if (DN.DimIDNo13) // Dim No 13
                        pointList.Add(BC.BottGP.RB.IntPoint);

                    pointList.Add(BC.BottGP.RB.IntPointB);

                    if (DN.DimIDNo14) // Dim No 14
                        pointList.Add(BC.BottGP.RB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }


                }

                // Dim No 15
                if (DN.DimIDNo15)
                {

                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P5);
                    pointList.Add(BC.BottGP.RB.IntPoint);
                    pointList.Add(BC.BottGP.RB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }


                // Dim No 16
                if (DN.DimIDNo16)
                {
                    TempList = Com.GetBoltPoints(BC.BottGP.RB.BoltM);
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "Y"));
                    pointList.Add(BC.BottGP.RB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }


                #endregion

                #region Diagonal Bottom
                BC.PC.DistBot = (BC.PC.DistInc * 3);

                if (BC.BottGP.RB.BoltM1 != null)
                {
                    TempList = dc.ChangePints(BC.BottGP.RB.BoltM1, CView, BottVect);
                    // Dim No 4
                    if (DN.DimIDNo4)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.BottGP.RB.IntPoint);
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, BottVect, BC.PC.DistBot, StAtrr);
                        if (xDim != null)
                        {
                            PL.DimPlacingDiag(xDim, YLine, BC.PC.DistBot);
                            BC.PC.DistBot += BC.PC.DistInc;
                        }
                    }

                    // Dim No 5
                    if (DN.DimIDNo5)
                    {
                        pointList = new PointList();
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, BottVect, BC.PC.DistBot, StAtrr);
                        if (xDim != null)
                        {
                            PL.DimPlacingDiag(xDim, YLine, BC.PC.DistBot);
                            BC.PC.DistBot += BC.PC.DistInc;
                        }
                    }

                }

                TempList = dc.ChangePints(BC.BottGP.RB.BoltM, CView, BottVect);
                // Dim No 6
                if (DN.DimIDNo6)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.RB.IntPoint);
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, BottVect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }

                // Dim No 7
                if (DN.DimIDNo7)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, BottVect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }

                #endregion

                // Com.DrawLineDotted(CView, BC.BottGP.RB.IntPoint, BC.BottGP.RB.RefPBrace);

                //Dim Code 8 // Angle Dimension
                if (DN.DimIDNo8)
                {
                    Point Temp = new Point(BC.BottGP.RB.IntPoint.X, BC.BottGP.RB.RefPBrace.Y, BC.BottGP.RB.IntPoint.Z);
                    AngleDimension angDimA = new AngleDimension(CView, BC.BottGP.RB.IntPoint, BC.BottGP.RB.RefPBrace, Temp, -80);
                    angDimA.Insert();
                }

            }
        }

        private void AppyMidStiff()
        {
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            // Dim No 13, 13.1
            if (BC.SCT != null && (DN.DimIDNo13 || DN.DimIDNo1))
            {
                if (BC.SCM != null && (BC.SCB == null || BC.SCT == null))
                {
                    if (BC.SCT == null)
                    {

                        Vect = new Vector(0, 1, 0);
                        PointList pointList = new PointList();
                        pointList.Add(BC.Points.P1);
                        pointList.Add(BC.SCT.Points.P1);

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                            BC.PC.DistTop += BC.PC.DistInc;
                        }
                        //Ids.Add(BC.BottGP.GussetPlate.Identifier.ID);
                    }

                    if (BC.SCB == null)
                    {

                        Vect = new Vector(0, -1, 0);
                        PointList pointList = new PointList();
                        pointList.Add(BC.Points.P2);
                        pointList.Add(BC.SCT.Points.P2);

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceTopP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                            BC.PC.DistBot += BC.PC.DistInc;
                        }

                    }
                }
            }
        }

        private void AppySectionDim()
        {
            StraightDimensionSet xDim = null;
            PointList pointList = new PointList();
            Vector Vect = new Vector(0, 1, 0);

            // Dim No 24
            if (BCS.SCT != null && DN.DimIDNo24)
            {
                Vect = new Vector(0, 1, 0);
                if (BCS.SCT.SCL != null)
                {
                    pointList = new PointList();
                    pointList.Add(new Point(BCS.Points.CentP.X, BCS.SCT.SCL.Points.P4.Y));
                    pointList.Add(BCS.SCT.SCL.Points.P4);
                    xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BCS.PC.TopY, BCS.PC.DistTop);
                }

                if (BCS.SCT.SCR != null)
                {
                    pointList = new PointList();
                    pointList.Add(new Point(BCS.Points.CentP.X, BCS.SCT.SCR.Points.P1.Y));
                    pointList.Add(BCS.SCT.SCR.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BCS.PC.TopY, BCS.PC.DistTop);
                }
            }

            // Dim No 24
            if (BCS.SCB != null && DN.DimIDNo24)
            {
                Vect = new Vector(0, -1, 0);
                pointList = new PointList();
                pointList.Add(new Point(BCS.Points.CentP.X, BCS.SCB.SCL.Points.P3.Y));
                pointList.Add(BCS.SCB.SCL.Points.P3);
                xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistBot, StAtrr);
                if (xDim != null)
                    PL.DistPlaceBottP(xDim, BCS.PC.BottomY, BCS.PC.DistBot);


                pointList = new PointList();
                pointList.Add(new Point(BCS.Points.CentP.X, BCS.SCB.SCR.Points.P2.Y));
                pointList.Add(BCS.SCB.SCR.Points.P2);
                xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistTop, StAtrr);
                if (xDim != null)
                    PL.DistPlaceBottP(xDim, BCS.PC.BottomY, BCS.PC.DistBot);
            }

            if (BCS.SCM != null)
            {
                Vect = new Vector(0, 1, 0);
                // Dim No 22, 22.1
                if (DN.DimIDNo22 || DN.DimIDNo22Dot1)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo22) // Dim No 22
                        pointList.Add(BCS.SCM.SCL.Points.P1);
                    pointList.Add(BCS.SCM.SCL.Points.P4);
                    if (DN.DimIDNo22Dot1) // Dim No 22.1
                        pointList.Add(new Point(BCS.Points.CentP.X, BCS.SCM.SCL.Points.P4.Y));
                    xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistInc, StAtrr);

                    pointList = new PointList();
                    if (DN.DimIDNo22) // Dim No 22
                        pointList.Add(BCS.SCM.SCR.Points.P4);
                    pointList.Add(BCS.SCM.SCR.Points.P1);
                    if (DN.DimIDNo22Dot1) // Dim No 22.1
                        pointList.Add(new Point(BCS.Points.CentP.X, BCS.SCM.SCR.Points.P1.Y));
                    xDim = dc.InsertDim(CView, pointList, Vect, (BCS.PC.DistInc * 2), StAtrr);

                }
            }

            if (BCS.SCT != null)
            {
                BCS.PC.DistLeft = BCS.PC.DistInc * 2;
                Vect = new Vector(-1, 0, 0);
                // Dim No 29
                if (DN.DimIDNo29 && BCS.SCT.SCL != null)
                {
                    pointList = new PointList();
                    pointList.Add(BCS.SCT.SCL.Points.P1);
                    pointList.Add(BCS.SCT.SCL.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BCS.PC.LeftX, BCS.PC.DistLeft);

                }
                BCS.PC.DistRight = BCS.PC.DistInc * 2;
                Vect = new Vector(1, 0, 0);
                // Dim No 29
                if (DN.DimIDNo29 && BCS.SCT.SCR != null)
                {
                    pointList = new PointList();
                    pointList.Add(BCS.SCT.SCR.Points.P4);
                    pointList.Add(BCS.SCT.SCR.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BCS.PC.RightX, BCS.PC.DistRight);

                }
            }

            if (BCS.SCM != null)
            {
                BCS.PC.DistLeft = BCS.PC.DistInc * 2;
                Vect = new Vector(-1, 0, 0);
                // Dim No 23
                if (DN.DimIDNo23)
                {
                    pointList = new PointList();
                    pointList.Add(BCS.SCM.SCL.Points.P1);
                    pointList.Add(BCS.SCM.SCL.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BCS.PC.LeftX, BCS.PC.DistLeft);

                }
                BCS.PC.DistRight = BCS.PC.DistInc * 2;
                Vect = new Vector(1, 0, 0);
                // Dim No 23
                if (DN.DimIDNo23)
                {
                    pointList = new PointList();
                    pointList.Add(BCS.SCM.SCR.Points.P4);
                    pointList.Add(BCS.SCM.SCR.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BCS.PC.RightX, BCS.PC.DistRight);

                }
            }

            if (BCS.SCB != null)
            {
                BCS.PC.DistLeft = BCS.PC.DistInc * 2;
                Vect = new Vector(-1, 0, 0);
                // Dim No 29
                if (DN.DimIDNo29)
                {
                    pointList = new PointList();
                    pointList.Add(BCS.SCB.SCL.Points.P1);
                    pointList.Add(BCS.SCB.SCL.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BCS.PC.LeftX, BCS.PC.DistLeft);

                }
                BCS.PC.DistRight = BCS.PC.DistInc * 2;
                Vect = new Vector(1, 0, 0);
                // Dim No 29
                if (DN.DimIDNo29)
                {
                    pointList = new PointList();
                    pointList.Add(BCS.SCB.SCR.Points.P4);
                    pointList.Add(BCS.SCB.SCR.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BCS.PC.RightX, BCS.PC.DistRight);

                }
            }

            if (BCS.SCT != null && BCS.SCM != null)
            {
                BCS.PC.DistRight = BCS.PC.DistInc;
                BCS.PC.DistLeft = BCS.PC.DistInc;

                Vect = new Vector(-1, 0, 0);
                // Dim No 23.1
                if (DN.DimIDNo23Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(BCS.SCT.SCL.Points.P2);
                    pointList.Add(BCS.SCM.SCL.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BCS.PC.LeftX, BCS.PC.DistLeft);

                }

                Vect = new Vector(1, 0, 0);
                // Dim No 23.1
                if (DN.DimIDNo23Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(BCS.SCT.SCR.Points.P3);
                    pointList.Add(BCS.SCM.SCR.Points.P4);
                    xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BCS.PC.RightX, BCS.PC.DistRight);

                }
            }

            if (BCS.SCB != null && BCS.SCM != null)
            {
                BCS.PC.DistRight = BCS.PC.DistInc;
                BCS.PC.DistLeft = BCS.PC.DistInc;
                Vect = new Vector(-1, 0, 0);
                // Dim No 23.1
                if (DN.DimIDNo23Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(BCS.SCB.SCL.Points.P1);
                    pointList.Add(BCS.SCM.SCL.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BCS.PC.LeftX, BCS.PC.DistLeft);

                }

                Vect = new Vector(1, 0, 0);
                // Dim No 23.1
                if (DN.DimIDNo23Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(BCS.SCB.SCR.Points.P4);
                    pointList.Add(BCS.SCM.SCR.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BCS.PC.RightX, BCS.PC.DistRight);

                }
            }

        }

        private void ApplyTVDim()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);


            if (DN.DimIDNo12 || DN.DimIDNo12Dot1)
            {
                if (BCS.Stiffs?.Count > 0)
                {
                    foreach (PartClass PC in BCS.Stiffs)
                    {
                        BCS.PC.DistTop = (BCS.PC.DistInc * 2);
                        BCS.PC.DistBot = (BCS.PC.DistInc * 2);

                        if (PC.Points.CentP.Y > BCS.Points.CentP.Y)
                        {
                            Vect = new Vector(0, 1, 0);
                            pointList = new PointList();
                            pointList.Add(BCS.Points.P1);
                            pointList.Add(PC.Points.P1);
                            xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistTop, RdAtrr);
                            if (xDim != null)
                                PL.DimPlaceByTopY(xDim, BCS.PC);
                        }
                        else
                        {
                            Vect = new Vector(0, -1, 0);
                            pointList = new PointList();
                            pointList.Add(BCS.Points.P2);
                            pointList.Add(PC.Points.P2);
                            xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistBot, RdAtrr);
                            if (xDim != null)
                                PL.DimPlaceByBottomY(xDim, BCS.PC);
                        }

                        Ids.Add(PC.part.Identifier.ID);
                    }
                }



            }
        }


        private void TestDim()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;

            Vector Vect = new Vector(0, 1, 0);

            TSD.PointList TempList = new PointList();

            Point Temp = new Point(BC.TopGP.LB.IntPoint.X, BC.TopGP.LB.RefPBrace.Y, BC.TopGP.LB.IntPoint.Z);
            AngleDimension angDimA = new AngleDimension(CView, BC.TopGP.LB.IntPoint, BC.TopGP.LB.RefPBrace, Temp, -80);
            angDimA.Insert();

            Temp = new Point(BC.TopGP.RB.IntPoint.X, BC.TopGP.RB.RefPBrace.Y, BC.TopGP.RB.IntPoint.Z);
            angDimA = new AngleDimension(CView, BC.TopGP.RB.IntPoint, BC.TopGP.RB.RefPBrace, Temp, -80);
            angDimA.Insert();

            Temp = new Point(BC.BottGP.RB.IntPoint.X, BC.BottGP.RB.RefPBrace.Y, BC.BottGP.RB.IntPoint.Z);
            angDimA = new AngleDimension(CView, BC.BottGP.RB.IntPoint, BC.BottGP.RB.RefPBrace, Temp, -80);
            angDimA.Insert();

            Temp = new Point(BC.BottGP.LB.IntPoint.X, BC.BottGP.LB.RefPBrace.Y, BC.BottGP.LB.IntPoint.Z);
            angDimA = new AngleDimension(CView, BC.BottGP.LB.IntPoint, BC.BottGP.LB.RefPBrace, Temp, -80);
            angDimA.Insert();

        }

        #region Get Data

        private void GetBeamClassClass(TSD.View CView)
        {
            if (ViewName == "Front View")
            {
                BC = new BeamClass_BG22();
                BC.beam = MainBeam;
                List<TSM.Part> PartListC = BC.beam.GetAssembly().GetSecondaries().OfType<TSM.Part>().ToList();
                PartListC.Add(MainBeam);
                BC.Points = Com.GetPartPoints(BC.beam);

                List<TSM.BoltGroup> BoltDList = Com.EnumtoArray(BC.beam.GetBolts()).OfType<TSM.BoltGroup>().ToList();
                Point CentP = Com.CenterPoint(BC.beam.StartPoint, BC.beam.EndPoint);
                double Lenght = (BC.beam.GetSolid().MaximumPoint.X - BC.beam.GetSolid().MinimumPoint.X) / 6;
                double MinX = BC.beam.GetSolid().MinimumPoint.X + Lenght;
                double MaxX = BC.beam.GetSolid().MaximumPoint.X - Lenght;

                //  List<TSM.Part> PartListF = (from p in PartListC where !Com.IsCode(p) select p).ToList();
                List<TSM.Part> PartListF = (from p in PartListC where !Ids.Contains(p.Identifier.ID) select p).ToList();
                ContourPlate TopGP = (from p in PartListF.OfType<ContourPlate>() where IsBG22(p) && (Com.CenterPoint(p).Y > BC.Points.CentP.Y) && !dc.IsPlateSideView(p) select p).FirstOrDefault();
                ContourPlate BottGP = (from p in PartListF.OfType<ContourPlate>() where IsBG22(p) && (Com.CenterPoint(p).Y < BC.Points.CentP.Y) && !dc.IsPlateSideView(p) select p).FirstOrDefault();

                if (TopGP != null)
                {
                    BC.TopGP = GetGussetClass(TopGP, "Top");
                    BC.SCT = GetStiffClass(TopGP, PartListF, "Top");
                    if (BC.SCM == null)
                        BC.SCM = GetStiffClass(TopGP, PartListF, "Middle");
                }

                if (BottGP != null)
                {
                    BC.BottGP = GetGussetClass(BottGP, "Bottom");
                    BC.SCB = GetStiffClass(BottGP, PartListF, "Bottom");
                    if (BC.SCM == null)
                        BC.SCM = GetStiffClass(BottGP, PartListF, "Middle");
                }

                List<Point> RefPoints = MainBeam.GetReferenceLine(false).OfType<Point>().ToList();

                double MinXP = (from p in RefPoints orderby p.X ascending select p.X).FirstOrDefault();
                double MaxXP = (from p in RefPoints orderby p.X descending select p.X).FirstOrDefault();

                MinXP -= 100;
                MaxXP += 100;

                TSM.Part LeftPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.X ascending select p).FirstOrDefault();
                TSM.Part RightPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.X descending select p).FirstOrDefault();
                TSM.Part TopPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.Y descending select p).FirstOrDefault();
                TSM.Part BottPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.Y ascending select p).FirstOrDefault();

                BC.PC = new PlacingClass();
                BC.PC.TopY = TopPart.GetSolid().MaximumPoint.Y;
                BC.PC.BottomY = BottPart.GetSolid().MinimumPoint.Y;



                BC.PC.LeftX = MainBeam.StartPoint.X;// Math.Round(CView.RestrictionBox.MinPoint.X);
                BC.PC.RightX = RightPart.GetSolid().MaximumPoint.X;

                if (BC.PC.LeftX > MinXP)
                    BC.PC.LeftX = (MinXP + 100);

                if (BC.PC.RightX < MaxXP)
                    BC.PC.RightX = (MaxXP - 100);

                double AvScale = 12;
                double AvDistInc = 100;
                double DistPerScale = AvDistInc / AvScale;
                double CScale = CView.Attributes.Scale;
                BC.PC.DistInc = CScale * DistPerScale;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;
            }

            else if (ViewName == "Section View")
            {
                BCS = new BeamClass_BG22S();
                BCS.beam = MainBeam;
                List<TSM.Part> PartListC = BCS.beam.GetAssembly().GetSecondaries().OfType<TSM.Part>().ToList();

                BCS.Points = Com.GetPartPoints(BCS.beam);

                double MaxZ = CView.RestrictionBox.MinPoint.Z;
                List<TSM.Part> PartList = (from p in PartListC where Com.IsViewObj(p, CView) select p).ToList();
                //List<TSM.Part> PartList = (from p in PartListC where p.GetSolid().MaximumPoint.Z > MaxZ select p).ToList();
                Point CentP = Com.CenterPoint(BCS.beam.StartPoint, BCS.beam.EndPoint);

                List<TSM.Part> PartListF = (from p in PartList where !Ids.Contains(p.Identifier.ID) select p).ToList();
                // List<TSM.Part> PartListF = (from p in PartList where !Com.IsCode(p) select p).ToList();
                ContourPlate TopGP = (from p in PartListF.OfType<ContourPlate>() where IsBG22(p) && (Com.CenterPoint(p).Y > BCS.Points.CentP.Y) select p).FirstOrDefault();
                ContourPlate BottGP = (from p in PartListF.OfType<ContourPlate>() where IsBG22(p) && (Com.CenterPoint(p).Y < BCS.Points.CentP.Y) select p).FirstOrDefault();

                if (TopGP != null)
                {
                    BCS.TopGP = GetGussetClassS(TopGP, "Top");
                    BCS.SCT = GetStiffClassS(TopGP, PartListF, "Top");
                    if (BCS.SCM == null)
                        BCS.SCM = GetStiffClassS(TopGP, PartListF, "Middle");
                }

                if (BottGP != null)
                {
                    BCS.BottGP = GetGussetClassS(BottGP, "Bottom");
                    BCS.SCB = GetStiffClassS(BottGP, PartListF, "Bottom");
                    if (BCS.SCM == null)
                        BCS.SCM = GetStiffClassS(BottGP, PartListF, "Middle");
                }

                PartList.Add(MainBeam);
                List<Point> RefPoints = MainBeam.GetReferenceLine(false).OfType<Point>().ToList();

                TSM.Part LeftPart = (from p in PartList orderby p.GetSolid().MinimumPoint.X ascending select p).FirstOrDefault();
                TSM.Part RightPart = (from p in PartList orderby p.GetSolid().MaximumPoint.X descending select p).FirstOrDefault();
                TSM.Part TopPart = (from p in PartList orderby p.GetSolid().MaximumPoint.Y descending select p).FirstOrDefault();
                TSM.Part BottPart = (from p in PartList orderby p.GetSolid().MinimumPoint.Y ascending select p).FirstOrDefault();

                BCS.PC = new PlacingClass();
                BCS.PC.TopY = TopPart.GetSolid().MaximumPoint.Y;
                BCS.PC.BottomY = BottPart.GetSolid().MinimumPoint.Y;
                BCS.PC.LeftX = LeftPart.GetSolid().MinimumPoint.X; ;// Math.Round(CView.RestrictionBox.MinPoint.X);
                BCS.PC.RightX = RightPart.GetSolid().MaximumPoint.X;

                double AvScale = 12;
                double AvDistInc = 100;
                double DistPerScale = AvDistInc / AvScale;
                double CScale = CView.Attributes.Scale;
                BCS.PC.DistInc = CScale * DistPerScale;
                BCS.PC.DistBot = BCS.PC.DistInc;
                BCS.PC.DistTop = BCS.PC.DistInc;
                BCS.PC.DistLeft = BCS.PC.DistInc;
                BCS.PC.DistRight = BCS.PC.DistInc;
            }

            if (ViewName == "Top View" || ViewName == "Bottom View")
            {
                BCS = new BeamClass_BG22S();
                BCS.beam = MainBeam;
                List<TSM.Part> PartListC = BCS.beam.GetAssembly().GetSecondaries().OfType<TSM.Part>().ToList();

                BCS.Points = Com.GetPartPoints(BCS.beam);


                List<TSM.Part> Stiffs = (from p in PartListC where dc.IsPlateSideView(p) && !dc.IsHorzObj(p) select p).ToList();
                if (Stiffs != null && Stiffs.Count > 0)
                    BCS.Stiffs = GetStiff(Stiffs);

                PartListC.Add(MainBeam);
                List<Point> RefPoints = MainBeam.GetReferenceLine(false).OfType<Point>().ToList();

                TSM.Part LeftPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.X ascending select p).FirstOrDefault();
                TSM.Part RightPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.X descending select p).FirstOrDefault();
                TSM.Part TopPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.Y descending select p).FirstOrDefault();
                TSM.Part BottPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.Y ascending select p).FirstOrDefault();

                BCS.PC = new PlacingClass();
                BCS.PC.TopY = TopPart.GetSolid().MaximumPoint.Y;
                BCS.PC.BottomY = BottPart.GetSolid().MinimumPoint.Y;
                BCS.PC.LeftX = LeftPart.GetSolid().MinimumPoint.X; ;// Math.Round(CView.RestrictionBox.MinPoint.X);
                BCS.PC.RightX = RightPart.GetSolid().MaximumPoint.X;

                double AvScale = 12;
                double AvDistInc = 100;
                double DistPerScale = AvDistInc / AvScale;
                double CScale = CView.Attributes.Scale;
                BCS.PC.DistInc = CScale * DistPerScale;
                BCS.PC.DistBot = BCS.PC.DistInc;
                BCS.PC.DistTop = BCS.PC.DistInc;
                BCS.PC.DistLeft = BCS.PC.DistInc;
                BCS.PC.DistRight = BCS.PC.DistInc;
            }

        }

        private GussetClassB GetGussetClass(ContourPlate GP, string Position)
        {
            GussetClassB GC = new GussetClassB();
            GC.GussetPlate = GP;
            GC.Points = GetGussetPoints(GP);

            List<BoltGroup> Bolts = Com.EnumtoArray(GP.GetBolts()).OfType<BoltGroup>().ToList();

            List<BoltGroup> LeftBolts = (from b in Bolts where Com.CenterPoint(b).X < GC.Points.CentP.X orderby (b as BoltArray).GetBoltDistY(0) select b).ToList();
            List<BoltGroup> RightBolts = (from b in Bolts where Com.CenterPoint(b).X > GC.Points.CentP.X orderby (b as BoltArray).GetBoltDistY(0) select b).ToList();

            if (LeftBolts != null && LeftBolts.Count > 0)
            {

                BoltGroup MidBolt = LeftBolts[0];

                GC.LB = new GussetBrace();

                if (MidBolt != null)
                {
                    GC.LB.BoltM = MidBolt;
                    TSM.Part brace = GetBrace(GP, Position, "Left");
                    if (brace != null)
                    {
                        GC.LB.Brace = brace;
                        // GC.LB.RefPBrace = dc.NearestPoint(GC.LB.Brace.StartPoint, GC.LB.Brace.EndPoint, MidBolt.FirstPosition);
                        GC.LB.RefPBrace = GetBraceRefPoint(brace);
                        GC.LB.IntPoint = GetIntSectPoint(GC.LB.BoltM, brace, Position, "Left");
                        if (Position == "Top")
                        {
                            if (GC.LB.RefPBrace != null && GC.LB.IntPoint != null)
                                GC.LB.IntPointB = Com.GetIntersectionPoint(GC.LB.RefPBrace, GC.LB.IntPoint, BC.Points.P1, BC.Points.P4);

                            GC.LB.Degree = GetDegree(GC.LB.IntPointB, GC.LB.IntPoint, BC.Points.P1);
                        }
                        else
                        {
                            if (GC.LB.RefPBrace != null && GC.LB.IntPoint != null)
                                GC.LB.IntPointB = Com.GetIntersectionPoint(GC.LB.RefPBrace, GC.LB.IntPoint, BC.Points.P2, BC.Points.P3);

                            GC.LB.Degree = GetDegree(GC.LB.IntPointB, GC.LB.IntPoint, BC.Points.P2);
                        }
                    }
                }

                if (LeftBolts.Count > 1)
                    GC.LB.BoltM1 = LeftBolts[1];

            }


            if (RightBolts != null && RightBolts.Count > 0)
            {

                BoltGroup MidBolt = RightBolts[0];
                GC.RB = new GussetBrace();

                if (MidBolt != null)
                {
                    GC.RB.BoltM = MidBolt;
                    TSM.Part brace = GetBrace(GP, Position, "Right");
                    if (brace != null)
                    {
                        GC.RB.Brace = brace;
                        // GC.RB.RefPBrace = dc.NearestPoint(GC.RB.Brace.StartPoint, GC.RB.Brace.EndPoint, MidBolt.FirstPosition);
                        GC.RB.RefPBrace = GetBraceRefPoint(brace);
                        GC.RB.IntPoint = GetIntSectPoint(GC.RB.BoltM, brace, Position, "Right");
                        if (Position == "Top")
                        {
                            if (GC.RB.RefPBrace != null && GC.RB.IntPoint != null)
                                GC.RB.IntPointB = Com.GetIntersectionPoint(GC.RB.RefPBrace, GC.RB.IntPoint, BC.Points.P1, BC.Points.P4);

                            GC.RB.Degree = GetDegree(GC.RB.IntPointB, GC.RB.IntPoint, BC.Points.P4);
                        }
                        else
                        {
                            if (GC.RB.RefPBrace != null && GC.RB.IntPoint != null)
                                GC.RB.IntPointB = Com.GetIntersectionPoint(GC.RB.RefPBrace, GC.RB.IntPoint, BC.Points.P2, BC.Points.P3);

                            GC.RB.Degree = GetDegree(GC.RB.IntPointB, GC.RB.IntPoint, BC.Points.P3);
                        }
                    }
                }

                if (RightBolts.Count > 1)
                    GC.RB.BoltM1 = RightBolts[1];


            }

            return GC;
        }

        private GussetClass GetGussetClassS(ContourPlate GP, string Position)
        {
            GussetClass GC = new GussetClass();
            GC.GussetPlate = GP;
            GC.Points = Com.GetPartPoints(GP);

            return GC;
        }

        private StiffClass GetStiffClass(ContourPlate GP, List<TSM.Part> PartListF, string Position)
        {
            StiffClass SC = null;
            TSM.Part Stiff = null;
            if (Position == "Top")
            {
                Stiff = (from p in PartListF where dc.IsPlateSideView(p) && (Com.CenterPoint(p).X > GP.GetSolid().MinimumPoint.X && Com.CenterPoint(p).X < GP.GetSolid().MaximumPoint.X) && (Com.CenterPoint(p).Y > BC.Points.P1.Y) select p).FirstOrDefault();
            }
            else if (Position == "Bottom")
            {
                Stiff = (from p in PartListF where dc.IsPlateSideView(p) && (Com.CenterPoint(p).X > GP.GetSolid().MinimumPoint.X && Com.CenterPoint(p).X < GP.GetSolid().MaximumPoint.X) && (Com.CenterPoint(p).Y < BC.Points.P2.Y) select p).FirstOrDefault();
            }

            else if (Position == "Middle")
            {
                Stiff = (from p in PartListF where dc.IsPlateSideView(p) && (Com.CenterPoint(p).X > GP.GetSolid().MinimumPoint.X && Com.CenterPoint(p).X < GP.GetSolid().MaximumPoint.X) && (Com.CenterPoint(p).Y < BC.Points.P1.Y && Com.CenterPoint(p).Y > BC.Points.P2.Y) select p).FirstOrDefault();
            }

            if (Stiff != null)
            {
                SC = new StiffClass();
                SC.Stiff = Stiff;
                SC.Points = Com.GetPartPoints(Stiff);
            }


            return SC;
        }

        private StiffClassS GetStiffClassS(ContourPlate GP, List<TSM.Part> PartListF, string Position)
        {
            StiffClassS SCS = null;
            TSM.Part StiffL = null;
            TSM.Part StiffR = null;
            if (Position == "Top")
            {
                StiffL = (from p in PartListF where !dc.IsPlateSideViewN(p) && (Com.CenterPoint(p).X < Com.CenterPoint(GP).X) && (Com.CenterPoint(p).Y > BCS.Points.P1.Y) select p).FirstOrDefault();
                StiffR = (from p in PartListF where !dc.IsPlateSideViewN(p) && (Com.CenterPoint(p).X > Com.CenterPoint(GP).X) && (Com.CenterPoint(p).Y > BCS.Points.P1.Y) select p).FirstOrDefault();
            }
            else if (Position == "Bottom")
            {
                StiffL = (from p in PartListF where !dc.IsPlateSideViewN(p) && (Com.CenterPoint(p).X < Com.CenterPoint(GP).X) && (Com.CenterPoint(p).Y < BCS.Points.P2.Y) select p).FirstOrDefault();
                StiffR = (from p in PartListF where !dc.IsPlateSideViewN(p) && (Com.CenterPoint(p).X > Com.CenterPoint(GP).X) && (Com.CenterPoint(p).Y < BCS.Points.P2.Y) select p).FirstOrDefault();
            }

            else if (Position == "Middle")
            {
                StiffL = (from p in PartListF where !dc.IsPlateSideViewN(p) && (Com.CenterPoint(p).X < Com.CenterPoint(GP).X) && (Com.CenterPoint(p).Y > BCS.Points.P2.Y && Com.CenterPoint(p).Y < BCS.Points.P1.Y) select p).FirstOrDefault();
                StiffR = (from p in PartListF where !dc.IsPlateSideViewN(p) && (Com.CenterPoint(p).X > Com.CenterPoint(GP).X) && (Com.CenterPoint(p).Y > BCS.Points.P2.Y && Com.CenterPoint(p).Y < BCS.Points.P1.Y) select p).FirstOrDefault();
            }

            if (StiffL != null)
            {
                if (SCS == null)
                    SCS = new StiffClassS();


                StiffClass SC = new StiffClass();
                SC.Stiff = StiffL;
                SC.Points = Com.GetPartPoints(StiffL);
                SCS.SCL = SC;
            }

            if (StiffR != null)
            {
                if (SCS == null)
                    SCS = new StiffClassS();


                StiffClass SC = new StiffClass();
                SC.Stiff = StiffR;
                SC.Points = Com.GetPartPoints(StiffR);
                SCS.SCR = SC;
            }


            return SCS;
        }

        private TSM.Part GetBrace(TSM.Part GP, string PosV, string PosH)
        {
            List<int> PartIds = BC.beam.GetAssembly().GetSecondaries().OfType<TSM.Part>().Select(x => x.Identifier.ID).ToList();
            PartIds.Add(MainBeam.Identifier.ID);
            TSM.Part brace = null;
            Point CentP = Com.CenterPoint(GP);
            double Tol = 100;

            Point MinP = new Point(GP.GetSolid().MinimumPoint.X - Tol, GP.GetSolid().MinimumPoint.Y, MainBeam.GetSolid().MinimumPoint.Z);
            Point MaxP = new Point(GP.GetSolid().MaximumPoint.X + Tol, GP.GetSolid().MaximumPoint.Y + Tol, MainBeam.GetSolid().MaximumPoint.Z);

            if (PosV == "Bottom")
            {
                MinP = new Point(GP.GetSolid().MinimumPoint.X - Tol, GP.GetSolid().MinimumPoint.Y - Tol, MainBeam.GetSolid().MinimumPoint.Z);
                MaxP = new Point(GP.GetSolid().MaximumPoint.X + Tol, GP.GetSolid().MaximumPoint.Y, MainBeam.GetSolid().MaximumPoint.Z);
            }
            ModelObjectEnumerator Enum = Com.MyModel.GetModelObjectSelector().GetObjectsByBoundingBox(MinP, MaxP);
            List<TSM.Part> AllAPrts = Com.EnumtoArray(Enum).OfType<TSM.Part>().ToList();
            List<Brep> breps = AllAPrts.OfType<TSM.Brep>().ToList().Where(x => !PartIds.Contains(x.Identifier.ID)).OrderByDescending(x => Com.GetPartNetLength(x)).ToList();
            if (breps != null && breps.Count > 0)
            {
                if (PosH == "Left")
                    breps = (from b in breps where Com.CenterPoint(b).X < CentP.X select b).ToList();
                else
                    breps = (from b in breps where Com.CenterPoint(b).X > CentP.X select b).ToList();

                List<int> Ids = breps.Select(x => x.Identifier.ID).ToList();
                foreach (Brep brep in breps)
                {
                    if (IsBrace(brep, GP, PosH))
                    {
                        brace = brep;
                        break;
                    }

                }
            }
            else
            {
                List<TSM.Part> parts = AllAPrts.Where(x => !PartIds.Contains(x.Identifier.ID)).OrderByDescending(x => Com.GetPartNetLength(x)).ToList();
                List<Beam> braces = parts.OfType<Beam>().OrderByDescending(x => Com.GetPartNetLength(x)).ToList();
                if (PosH == "Left")
                    braces = (from b in braces where Com.CenterPoint(b).X < CentP.X select b).ToList();
                else
                    braces = (from b in braces where Com.CenterPoint(b).X > CentP.X select b).ToList();

                List<int> Ids = braces.Select(x => x.Identifier.ID).ToList();
                foreach (Beam brep in braces)
                {
                    if (IsBrace(brep, GP, PosH))
                    {
                        brace = brep;
                        break;
                    }

                }
            }

            return brace;

        }

        private bool IsBrace(TSM.Brep b, TSM.Part GP, string PosH)
        {
            bool RetCheck = false;
            if (dc.IsEqualOrLess(b.StartPoint.Y, BC.Points.P1.Y) && dc.IsEqualOrGreater(b.StartPoint.Y, BC.Points.P2.Y))
            {
                if (b.StartPoint.X > GP.GetSolid().MinimumPoint.X && b.StartPoint.X < GP.GetSolid().MaximumPoint.X)
                {
                    if ((PosH == "Left" && b.StartPoint.X > b.EndPoint.X) || PosH == "Right" && b.StartPoint.X < b.EndPoint.X)
                        RetCheck = true;
                }

            }

            else if (dc.IsEqualOrLess(b.EndPoint.Y, BC.Points.P1.Y) && dc.IsEqualOrGreater(b.EndPoint.Y, BC.Points.P2.Y))
            {
                if (b.EndPoint.X > GP.GetSolid().MinimumPoint.X && b.EndPoint.X < GP.GetSolid().MaximumPoint.X)
                {
                    if ((PosH == "Left" && b.EndPoint.X > b.StartPoint.X) || PosH == "Right" && b.EndPoint.X < b.StartPoint.X)
                        RetCheck = true;
                }
            }



            return RetCheck;
        }

        private bool IsBrace(TSM.Beam b, TSM.Part GP, string PosH)
        {
            bool RetCheck = false;
            if (dc.IsEqualOrLess(b.StartPoint.Y, BC.Points.P1.Y) && dc.IsEqualOrGreater(b.StartPoint.Y, BC.Points.P2.Y))
            {
                if (b.StartPoint.X > GP.GetSolid().MinimumPoint.X && b.StartPoint.X < GP.GetSolid().MaximumPoint.X)
                {
                    if ((PosH == "Left" && b.StartPoint.X > b.EndPoint.X) || PosH == "Right" && b.StartPoint.X < b.EndPoint.X)
                        RetCheck = true;
                }

            }

            else if (dc.IsEqualOrLess(b.EndPoint.Y, BC.Points.P1.Y) && dc.IsEqualOrGreater(b.EndPoint.Y, BC.Points.P2.Y))
            {
                if (b.EndPoint.X > GP.GetSolid().MinimumPoint.X && b.EndPoint.X < GP.GetSolid().MaximumPoint.X)
                {
                    if ((PosH == "Left" && b.EndPoint.X > b.StartPoint.X) || PosH == "Right" && b.EndPoint.X < b.StartPoint.X)
                        RetCheck = true;
                }
            }



            return RetCheck;
        }

        private PartPoints GetGussetPoints(ContourPlate GP)
        {
            PartPoints RetP = new PartPoints();
            PointList pointList = Com.ContPList(GP);
            RetP.CentP = Com.CenterPoint(GP);
            if (pointList.Count > 4)
            {
                if (RetP.CentP.Y > BC.Points.CentP.Y)
                {

                    RetP.P1 = (from p in pointList.OfType<Point>() where p.X < RetP.CentP.X orderby p.Y descending select p).FirstOrDefault();
                    RetP.P2 = (from p in pointList.OfType<Point>() where p.X < RetP.CentP.X orderby p.Y ascending select p).FirstOrDefault();
                    RetP.P6 = (from p in pointList.OfType<Point>() where p.X < RetP.CentP.X && p.Y > RetP.P2.Y orderby p.Y ascending select p).FirstOrDefault();

                    RetP.P4 = (from p in pointList.OfType<Point>() where p.X > RetP.CentP.X orderby p.Y descending select p).FirstOrDefault();
                    RetP.P3 = (from p in pointList.OfType<Point>() where p.X > RetP.CentP.X orderby p.Y ascending select p).FirstOrDefault();
                    RetP.P5 = (from p in pointList.OfType<Point>() where p.X > RetP.CentP.X && p.Y > RetP.P3.Y orderby p.Y ascending select p).FirstOrDefault();
                }
                else
                {

                    RetP.P1 = (from p in pointList.OfType<Point>() where p.X < RetP.CentP.X orderby p.Y ascending select p).FirstOrDefault();
                    RetP.P2 = (from p in pointList.OfType<Point>() where p.X < RetP.CentP.X orderby p.Y descending select p).FirstOrDefault();
                    RetP.P6 = (from p in pointList.OfType<Point>() where p.X < RetP.CentP.X && p.Y < RetP.P2.Y orderby p.Y descending select p).FirstOrDefault();

                    RetP.P4 = (from p in pointList.OfType<Point>() where p.X > RetP.CentP.X orderby p.Y ascending select p).FirstOrDefault();
                    RetP.P3 = (from p in pointList.OfType<Point>() where p.X > RetP.CentP.X orderby p.Y descending select p).FirstOrDefault();
                    RetP.P5 = (from p in pointList.OfType<Point>() where p.X > RetP.CentP.X && p.Y < RetP.P3.Y orderby p.Y descending select p).FirstOrDefault();
                }
            }
            else
            {
                pointList = dc.GetVertPointList(GP);
                if (RetP.CentP.Y > BC.Points.CentP.Y)
                {

                    RetP.P1 = (from p in pointList.OfType<Point>() where p.X < RetP.CentP.X orderby p.Y descending select p).FirstOrDefault();
                    RetP.P2 = (from p in pointList.OfType<Point>() where p.X < RetP.CentP.X orderby p.Y ascending select p).FirstOrDefault();
                    RetP.P6 = (from p in pointList.OfType<Point>() where p.X < RetP.CentP.X && p.Y > RetP.P2.Y orderby p.Y ascending select p).FirstOrDefault();

                    RetP.P4 = (from p in pointList.OfType<Point>() where p.X > RetP.CentP.X orderby p.Y descending select p).FirstOrDefault();
                    RetP.P3 = (from p in pointList.OfType<Point>() where p.X > RetP.CentP.X orderby p.Y ascending select p).FirstOrDefault();
                    RetP.P5 = (from p in pointList.OfType<Point>() where p.X > RetP.CentP.X && p.Y > RetP.P3.Y orderby p.Y ascending select p).FirstOrDefault();
                }
                else
                {

                    RetP.P1 = (from p in pointList.OfType<Point>() where p.X < RetP.CentP.X orderby p.Y ascending select p).FirstOrDefault();
                    RetP.P2 = (from p in pointList.OfType<Point>() where p.X < RetP.CentP.X orderby p.Y descending select p).FirstOrDefault();
                    RetP.P6 = (from p in pointList.OfType<Point>() where p.X < RetP.CentP.X && p.Y < RetP.P2.Y orderby p.Y descending select p).FirstOrDefault();

                    RetP.P4 = (from p in pointList.OfType<Point>() where p.X > RetP.CentP.X orderby p.Y ascending select p).FirstOrDefault();
                    RetP.P3 = (from p in pointList.OfType<Point>() where p.X > RetP.CentP.X orderby p.Y descending select p).FirstOrDefault();
                    RetP.P5 = (from p in pointList.OfType<Point>() where p.X > RetP.CentP.X && p.Y < RetP.P3.Y orderby p.Y descending select p).FirstOrDefault();
                }
            }

            return RetP;
        }

        private List<PartClass> GetStiff(List<TSM.Part> Stiffs)
        {
            List<PartClass> partClasses = new List<PartClass>();
            List<double> XVals = new List<double>();
            foreach (TSM.Part p in Stiffs)
            {
                PartClass PC = Com.GetPartClass(p);
                if (XVals.Where(x => Com.IsEqual(PC.Points.P1.X, x)).Count() == 0)
                {
                    partClasses.Add(PC);
                    XVals.Add(PC.Points.P1.X);
                }
            }


            return partClasses;
        }

        #endregion

        #region Helping Methods

        private Point GetBraceRefPoint(TSM.Part Brace)
        {
            Point StartPoint = new Point();
            Point EndPoint = new Point();

            if (Brace is Beam)
            {
                StartPoint = (Brace as Beam).StartPoint;
                EndPoint = (Brace as Beam).EndPoint;
            }
            else if (Brace is Brep)
            {

                StartPoint = (Brace as Brep).StartPoint;
                EndPoint = (Brace as Brep).EndPoint;

            }

            Point RefP = StartPoint;
            List<Point> CentPlist = MainBeam.GetCenterLine(false).OfType<Point>().ToList();
            Point StartP = Com.MinP(CentPlist, "X");
            Point EndP = Com.MaxP(CentPlist, "X");

            double DistS = Distance.PointToLine(StartPoint, new TSG.Line(StartP, EndP));
            double DistE = Distance.PointToLine(EndPoint, new TSG.Line(StartP, EndP));

            if (DistE < DistS)
                RefP = EndPoint;

            return RefP;
        }

        private double GetDegree(Point P1, Point P2, Point P3)
        {
            double degree = 0;
            try
            {

                AngleDimension angDimA = new AngleDimension(CView, P1, P2, P3, 50);
                degree = angDimA.GetAngle();
            }
            catch (Exception ex)
            { }
            return degree;
        }

        private Point GetIntSectPoint(BoltGroup bolt, TSM.Part brace, string Position, string PosH)
        {
            Point StartPoint = new Point();
            Point EndPoint = new Point();

            if (brace is Beam)
            {
                StartPoint = (brace as Beam).StartPoint;
                EndPoint = (brace as Beam).EndPoint;
            }
            else if (brace is Brep)
            {

                StartPoint = (brace as Brep).StartPoint;
                EndPoint = (brace as Brep).EndPoint;

            }

            PointList PList = Com.GetBoltPoints(bolt);
            Point P1 = Com.MaxP(PList, "Y");
            Point P2 = Com.MinP(PList, "X");
            Point IntSectP = null;
            if (Position == "Top")
            {
                if (PosH == "Right")
                {
                    P1 = Com.MaxP(PList, "Y");
                    P2 = Com.MaxP(PList, "X");
                }
            }
            else
            {
                if (PosH == "Right")
                {
                    P1 = Com.MinP(PList, "Y");
                    P2 = Com.MaxP(PList, "X");
                }
                else
                {
                    P1 = Com.MinP(PList, "Y");
                    P2 = Com.MinP(PList, "X");
                }
            }

            if (PList.Count > 1)
                IntSectP = Com.GetIntersectionPoint(P1, P2, StartPoint, EndPoint);
            else if (PList.Count == 1)
                IntSectP = PList[0];

            return IntSectP;

        }

        private bool IsBG22(TSM.Part part)
        {
            if (Com.GetNote5(part).ToUpper().Contains("BG22"))
                return true;
            else
                return false;
        }
        #endregion

        #region Classes
        private class GussetClassB
        {
            public TSM.Part GussetPlate { get; set; }
            public PartPoints Points { get; set; }
            public GussetBrace LB { get; set; }
            public GussetBrace RB { get; set; }
            public bool IsGussetSlop = false;

        }

        private class GussetBrace
        {
            public BoltGroup BoltM { get; set; }
            public BoltGroup BoltM1 { get; set; }
            public BoltGroup BoltL { get; set; }
            public BoltGroup BoltR { get; set; }
            public TSM.Part Brace { get; set; }
            public Point RefPBrace { get; set; }
            public Point IntPoint { get; set; }
            public Point IntPointB { get; set; }
            public double Degree { get; set; }
        }

        private class GussetClass
        {
            public TSM.Part GussetPlate { get; set; }
            public BoltGroup BoltM { get; set; }
            public BoltGroup BoltL { get; set; }
            public BoltGroup BoltR { get; set; }
            public BoltGroup BoltS { get; set; }
            public PartPoints Points { get; set; }
            public TSM.Part Brace { get; set; }
            public Point RefPBrace { get; set; }
            public Point IntPoint { get; set; }
            public Point IntPointB { get; set; }
            public Point IntPointTop { get; set; }
            public Point IntPointBott { get; set; }
            public string BracePos { get; set; }
            public double Degree { get; set; }
            public bool IsGussetSlop = false;

        }

        private class StiffClassS
        {
            public StiffClass SCL { get; set; }
            public StiffClass SCR { get; set; }
        }

        private class BeamClass_BG22S
        {
            public Beam beam { get; set; }
            public GussetClass TopGP { get; set; }
            public GussetClass BottGP { get; set; }
            public PartPoints Points { get; set; }
            public PlacingClass PC { get; set; }
            public StiffClassS SCT { get; set; }
            public StiffClassS SCM { get; set; }
            public StiffClassS SCB { get; set; }
            public List<PartClass> Stiffs { get; set; }

        }

        private class BeamClass_BG22
        {
            public Beam beam { get; set; }
            public GussetClassB TopGP { get; set; }
            public GussetClassB BottGP { get; set; }
            public PartPoints Points { get; set; }
            public PlacingClass PC { get; set; }
            public StiffClass SCT { get; set; }
            public StiffClass SCM { get; set; }
            public StiffClass SCB { get; set; }
        }

        #endregion

    }

}
