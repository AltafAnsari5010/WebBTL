﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Tekla.Structures;
using Tekla.Structures.Drawing;
using Tekla.Structures.Geometry3d;
using Tekla.Structures.Model;
using TSD = Tekla.Structures.Drawing;
using TSM = Tekla.Structures.Model;
using VirtueleDrawingAutomation;
using TSDD = Tekla.Structures.Datatype;
using TSG = Tekla.Structures.Geometry3d;

namespace Auto_Detailing_Tool_Beam
{
    public class BeamDim_BG21
    {
        #region Global Variables
        DimCom dc = new DimCom();
        StraightDimensionSet.StraightDimensionSetAttributes StAtrr = new StraightDimensionSet.StraightDimensionSetAttributes("standard");
        StraightDimensionSet.StraightDimensionSetAttributes RdAtrr = new StraightDimensionSet.StraightDimensionSetAttributes("standard");

        public Beam MainBeam = null;
        VirtueleDrawingAutomation.Json.DrawingAttributeInfoJson.AttributeFiles dimAttrClass = null;
        List<TSD.StraightDimension> KnockDim = new List<StraightDimension>();
        BeamClass_BG21 BC = null;
        BeamClass_BG21S BCS = null;
        VirtueleDrawingAutomation.Json.AutoDimensionTypesJson.BG21Json DN = null;
        TSD.View CView = null;
        string ViewName = "";
        List<int> Ids = new List<int>();
        #endregion

        public List<int> ApplyDim(TSD.View CView, string ViewName, AutoDimensioningTypes autoDimensioningTypes, DrawingAttributeInfo drawingAttributeInfo, List<int> Ids)
        {
            try
            {
                this.Ids = Ids;
            Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane());
            //Set model everything to the view
            Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane(CView.DisplayCoordinateSystem));

            this.CView = CView;
            this.dimAttrClass = drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files;
            this.DN = autoDimensioningTypes.BG21;
            StAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.StandardDimension);
            RdAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.RunningDimension);
            this.MainBeam = (Com.MyModel.SelectModelObject(new Identifier((CView.GetDrawing() as AssemblyDrawing).AssemblyIdentifier.ID)) as TSM.Assembly).GetMainPart() as TSM.Beam;
            this.MainBeam.Select();
            string ProType = Com.GetProType(MainBeam);
            this.ViewName = ViewName;


            GetBeamClassClass(CView);

            //TestDim();
            if (ViewName == "Front View")
            {

                while (BC.TopGP != null || BC.BottGP != null)
                {
                    ApplyDimType();
                    GetBeamClassClass(CView);
                }

            }
            else if (ViewName == "Section View")
                AppySectionDim();
            else if (ViewName == "Top View" || ViewName == "Bottom View")
                ApplyTVDim();


          
            }
            catch (Exception ex)
            { }

            Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane());
            return Ids;
        }

        private void ApplyDimType()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            TSD.PointList TempList = new PointList();

            bool IsVertDim = false;
            Point RefP = null;
            #region Top Gusset
            if (BC.TopGP?.GussetPlate != null)
            {

                ApplyLeftTopG();
                // Dim No 14
                if (DN.DimIDNo14)
                {
                    BC.PC.DistTop += BC.PC.DistInc;
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(BC.TopGP.LB.RefPBrace);
                    pointList.Add(BC.Points.P4);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                }
                ApplyRightTopG();



                Ids.Add(BC.TopGP.GussetPlate.Identifier.ID);
                // Com.SetCode(BC.TopGP.GussetPlate);
            }
            #endregion


            #region Bottom Gusset
            if (BC.BottGP?.GussetPlate != null)
            {

                ApplyLeftBottG();
                // Dim No 14
                if (DN.DimIDNo14 && (BC.TopGP == null || !dc.IsEqualPoints(BC.TopGP.LB.RefPBrace, BC.BottGP.LB.RefPBrace)))
                {
                    BC.PC.DistBot += BC.PC.DistInc;
                    pointList = new PointList();
                    pointList.Add(BC.Points.P2);
                    pointList.Add(BC.BottGP.LB.RefPBrace);
                    pointList.Add(BC.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                }
                ApplyRightBottG();



                Ids.Add(BC.BottGP.GussetPlate.Identifier.ID);
                //  Com.SetCode(BC.BottGP.GussetPlate);

            }
            #endregion


            AppyMidStiff();

        }

        private void ApplyLeftTopG()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            TSD.PointList TempList = new PointList();

            if (BC.TopGP?.LB != null)
            {

                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;

                PointList MidPList = Com.GetBoltPoints(BC.TopGP.LB.BoltM);
                TempList = Com.GetBoltPoints(BC.TopGP.LB.BoltM);
                TSG.Line YLine = new TSG.Line(BC.TopGP.Points.P6, BC.TopGP.Points.P1);
                TSG.Line XLine = new TSG.Line(BC.TopGP.LB.IntPoint, BC.TopGP.LB.RefPBrace);
                TSG.Line YLineR = new TSG.Line(BC.TopGP.LB.IntPoint, Com.MaxP(MidPList, "Y"));
                // Com.DrawLineDotted(CView, BC.TopGP.Points.P6, BC.TopGP.Points.P1);
                Vector LeftVect = YLineR.Direction;

                if (LeftVect.X > 0)
                    LeftVect = dc.ChangeVector(LeftVect);

                Vector RightVect = YLineR.Direction;
                if (RightVect.X < 0)
                    RightVect = dc.ChangeVector(RightVect);

                Vector TopVect = XLine.Direction;
                if (TopVect.Y < 0)
                    TopVect = dc.ChangeVector(TopVect);

                Vector BottVect = XLine.Direction;
                if (BottVect.Y > 0)
                    BottVect = dc.ChangeVector(BottVect);

                #region Diagonal Left
                TempList = dc.ChangePints(BC.TopGP.LB.BoltM, CView, LeftVect);
                double DisLeft = (BC.PC.DistLeft * 1.5);
                // Dim Code 9.1, 9
                if (DN.DimIDNo9Dot1 || DN.DimIDNo9)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo9Dot1) //  // Dim Code 9.1
                        pointList.Add(Com.MinP(TempList, "Y"));

                    pointList.Add(BC.TopGP.LB.IntPointB);

                    if (DN.DimIDNo9) //  // Dim Code 9
                        pointList.Add(BC.TopGP.LB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, XLine, DisLeft);
                        DisLeft += BC.PC.DistInc;
                    }

                }


                // Dim Code 10, 10.1
                if (DN.DimIDNo10Dot1 || DN.DimIDNo10)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo10Dot1) //  // Dim Code 10.1
                        pointList.Add(BC.TopGP.Points.P1);

                    pointList.AddRange(TempList);

                    if (DN.DimIDNo9) //  // Dim Code 10
                        pointList.Add(BC.TopGP.LB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, XLine, DisLeft);
                        DisLeft += BC.PC.DistInc;
                    }

                }

                // Dim Code 27
                if (DN.DimIDNo27 && BC.TopGP.LB.CutPoints != null)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P6);
                    pointList.Add(BC.TopGP.LB.CutPoints.P3);
                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, (BC.PC.DistRight * 1.5));

                }

                #endregion

                #region Diagonal Top
                BC.PC.DistTop = (BC.PC.DistInc * 3);
                TempList = dc.ChangePints(BC.TopGP.LB.BoltM, CView, TopVect);


                if (BC.TopGP.LB.CutPoints != null)
                {
                    // Dim No 4
                    if (DN.DimIDNo4)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.TopGP.LB.CutPoints.P1);
                        pointList.Add(BC.TopGP.LB.IntPoint);
                        pointList.Add(BC.TopGP.LB.CutPoints.P2);
                        xDim = dc.InsertDim(CView, pointList, TopVect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                        {
                            PL.DimPlacingDiag(xDim, YLine, BC.PC.DistTop);
                            BC.PC.DistTop += BC.PC.DistInc;
                        }
                    }

                    // Dim No 5
                    if (DN.DimIDNo5)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.TopGP.LB.CutPoints.P1);
                        pointList.Add(BC.TopGP.LB.CutPoints.P2);
                        xDim = dc.InsertDim(CView, pointList, TopVect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                        {
                            PL.DimPlacingDiag(xDim, YLine, BC.PC.DistTop);
                            BC.PC.DistTop += BC.PC.DistInc;
                        }
                    }
                }

                // Dim No 6
                if (DN.DimIDNo6)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.LB.IntPoint);
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, TopVect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }

                // Dim No 7
                if (DN.DimIDNo7)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, TopVect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }

                #endregion

                #region RD Dim

                TempList = Com.GetBoltPoints(BC.TopGP.LB.BoltM);
                BC.PC.DistTop = (BC.PC.DistInc);

                //RD Dim
                Vect = new Vector(0, 1, 0);

                // Dim No 1.6
                if (DN.DimIDNo1Dot6)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(BC.TopGP.LB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                // Dim No 1.7
                if (DN.DimIDNo1Dot7)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(BC.TopGP.LB.IntPointB);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                // Dim No 15
                if (BC.SCT != null && (DN.DimIDNo15 || DN.DimIDNo15Dot1))
                {

                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(BC.SCT.Points.P1);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }

                // Dim No 1.9
                if (BC.SCM != null && DN.DimIDNo1Dot9)
                {

                    if (BC.SCT == null || (BC.SCT != null && !dc.IsEqualPoints(BC.SCT.Points.P1, BC.SCM.Points.P1)))
                    {
                        pointList = new PointList();
                        pointList.Add(BC.Points.P1);
                        pointList.Add(BC.SCM.Points.P1);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                            BC.PC.DistTop += BC.PC.DistInc;
                        }
                    }

                }

                if (BC.PC.DistTop > 300)
                    BC.PC.DistTop = (BC.PC.DistInc * 3);

                // Dim No 1.4
                if (DN.DimIDNo1Dot4)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                // Dim No 1.1
                if (DN.DimIDNo1Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(BC.TopGP.LB.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                // Dim No 1
                if (DN.DimIDNo1)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(Com.MinP(TempList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }


                #endregion

                #region Top Staright Dim

                Vect = new Vector(0, 1, 0);

                // Dim No 19,20
                if (DN.DimIDNo19 || DN.DimIDNo20)
                {

                    pointList = new PointList();
                    if (DN.DimIDNo19) // Dim No 19
                        pointList.Add(Com.MaxP(TempList, "Y"));

                    pointList.Add(BC.TopGP.LB.IntPointB);

                    if (DN.DimIDNo20) // Dim No 20
                        pointList.Add(BC.TopGP.LB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }

                // Dim No 19.1
                if (DN.DimIDNo19Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    pointList.Add(BC.TopGP.LB.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }


                // Dim No 18
                if (DN.DimIDNo18)
                {

                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P6);
                    pointList.Add(BC.TopGP.LB.IntPoint);
                    pointList.Add(BC.TopGP.LB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }

                // Dim No 21
                if (DN.DimIDNo21)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P6);
                    pointList.Add(BC.TopGP.LB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }


                // Dim No 22
                if (DN.DimIDNo22)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    pointList.Add(BC.TopGP.LB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }

                // Dim No 23
                if (DN.DimIDNo23)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.LB.IntPoint);
                    pointList.Add(BC.TopGP.LB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }

                // Dim No 11
                if (DN.DimIDNo11 && BC.TopGP.RB != null)
                {
                    PointList TempList1 = Com.GetBoltPoints(BC.TopGP.RB.BoltM);
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "X"));
                    pointList.Add(Com.MaxP(TempList1, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }


                // Dim No 12
                if (DN.DimIDNo12)
                {

                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P2);
                    pointList.Add(BC.TopGP.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }

                // Dim No 12.1
                if (DN.DimIDNo12Dot1)
                {
                    BC.PC.DistTop += (BC.PC.DistInc / 3);
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P6);
                    pointList.Add(BC.TopGP.Points.P5);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        Com.SetMidDimText(xDim, "PROTECTED AREA NS & F/S");
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }
                #endregion

                #region Straight Left
                Vect = new Vector(-1, 0, 0);
                BC.PC.DistLeft = (BC.PC.DistInc * 2);

                // Dim No 2
                if (DN.DimIDNo2)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(MidPList, "Y"));
                    pointList.Add(BC.TopGP.Points.P2);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, BC.TopGP.Points.P2.X, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }

                }

                // Dim No 2.3, 2.2
                if (DN.DimIDNo2Dot3 || DN.DimIDNo2Dot2)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo2Dot3) // Dim No 2.3
                        pointList.Add(Com.MaxP(MidPList, "Y"));

                    pointList.Add(BC.TopGP.LB.IntPoint);

                    if (DN.DimIDNo2Dot2) // Dim No 2.2
                        pointList.Add(BC.TopGP.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, BC.TopGP.Points.P2.X, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }

                }



                // Dim No 2.1
                if (DN.DimIDNo2Dot1)
                {

                    pointList = new PointList();
                    pointList.Add(Com.MaxP(MidPList, "Y"));
                    pointList.Add(BC.TopGP.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, BC.TopGP.Points.P2.X, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }
                }


                #endregion

                if (DN.DimIDNo16 && BC.TopGP.LB.CutPoints != null)
                {
                    RadiusDimension Rd = new RadiusDimension(CView, BC.TopGP.LB.CutPoints.P4, BC.TopGP.LB.CutPoints.P3, BC.TopGP.LB.CutPoints.P5, -5);
                    Rd.Attributes.Placing.Placing = DimensionSetBaseAttributes.Placings.Fixed;
                    Rd.Insert();
                }

                // Com.DrawLineDotted(CView, BC.TopGP.LB.IntPoint, BC.TopGP.LB.RefPBrace);

                //Dim Code 8 // Angle Dimension
                if (DN.DimIDNo8)
                {
                    Point Temp = new Point(BC.TopGP.LB.IntPoint.X, BC.TopGP.LB.RefPBrace.Y, BC.TopGP.LB.IntPoint.Z);
                    AngleDimension angDimA = new AngleDimension(CView, BC.TopGP.LB.IntPoint, BC.TopGP.LB.RefPBrace, Temp, -120);
                    angDimA.Insert();
                }

            }
        }

        private void ApplyRightTopG()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            TSD.PointList TempList = new PointList();

            if (BC.TopGP?.LB != null)
            {

                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;

                PointList MidPList = Com.GetBoltPoints(BC.TopGP.RB.BoltM);
                TempList = Com.GetBoltPoints(BC.TopGP.RB.BoltM);
                TSG.Line YLine = new TSG.Line(BC.TopGP.Points.P4, BC.TopGP.Points.P5);
                TSG.Line XLine = new TSG.Line(BC.TopGP.RB.IntPoint, BC.TopGP.RB.RefPBrace);
                //Com.DrawLineDotted(CView, BC.TopGP.Points.P4, BC.TopGP.Points.P5);
                TSG.Line YLineR = new TSG.Line(BC.TopGP.RB.IntPoint, Com.MaxP(MidPList, "Y"));
                Vector LeftVect = YLineR.Direction;

                if (LeftVect.X > 0)
                    LeftVect = dc.ChangeVector(LeftVect);

                Vector RightVect = YLineR.Direction;
                if (RightVect.X < 0)
                    RightVect = dc.ChangeVector(RightVect);

                Vector TopVect = XLine.Direction;
                if (TopVect.Y < 0)
                    TopVect = dc.ChangeVector(TopVect);

                Vector BottVect = XLine.Direction;
                if (BottVect.Y > 0)
                    BottVect = dc.ChangeVector(BottVect);


                #region Diagonal Right
                TempList = dc.ChangePints(BC.TopGP.RB.BoltM, CView, RightVect);
                double DisRight = (BC.PC.DistRight * 1.5);
                // Dim Code 9.1, 9
                if (DN.DimIDNo9Dot1 || DN.DimIDNo9)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo9Dot1) //  // Dim Code 9.1
                        pointList.Add(Com.MinP(TempList, "Y"));

                    pointList.Add(BC.TopGP.RB.IntPointB);

                    if (DN.DimIDNo9) //  // Dim Code 9
                        pointList.Add(BC.TopGP.RB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, RightVect, DisRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, XLine, DisRight);
                        DisRight += BC.PC.DistInc;
                    }

                }


                // Dim Code 10, 10.1
                if (DN.DimIDNo10Dot1 || DN.DimIDNo10)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo10Dot1) //  // Dim Code 10.1
                        pointList.Add(BC.TopGP.Points.P4);

                    pointList.AddRange(TempList);

                    if (DN.DimIDNo9) //  // Dim Code 10
                        pointList.Add(BC.TopGP.RB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, RightVect, DisRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, XLine, DisRight);
                        DisRight += BC.PC.DistInc;
                    }

                }

                // Dim Code 27
                if (DN.DimIDNo27 && BC.TopGP.RB.CutPoints != null)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P5);
                    pointList.Add(BC.TopGP.RB.CutPoints.P3);
                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, (BC.PC.DistLeft * 1.5));

                }

                #endregion

                #region Diagonal Top
                BC.PC.DistTop = (BC.PC.DistInc * 3);
                TempList = dc.ChangePints(BC.TopGP.RB.BoltM, CView, TopVect);


                if (BC.TopGP.RB.CutPoints != null)
                {
                    // Dim No 4
                    if (DN.DimIDNo4)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.TopGP.RB.CutPoints.P1);
                        pointList.Add(BC.TopGP.RB.IntPoint);
                        pointList.Add(BC.TopGP.RB.CutPoints.P2);
                        xDim = dc.InsertDim(CView, pointList, TopVect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                        {
                            PL.DimPlacingDiag(xDim, YLine, BC.PC.DistTop);
                            BC.PC.DistTop += BC.PC.DistInc;
                        }
                    }

                    // Dim No 5
                    if (DN.DimIDNo5)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.TopGP.RB.CutPoints.P1);
                        pointList.Add(BC.TopGP.RB.CutPoints.P2);
                        xDim = dc.InsertDim(CView, pointList, TopVect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                        {
                            PL.DimPlacingDiag(xDim, YLine, BC.PC.DistTop);
                            BC.PC.DistTop += BC.PC.DistInc;
                        }
                    }
                }

                // Dim No 6
                if (DN.DimIDNo6)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.RB.IntPoint);
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, TopVect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }

                // Dim No 7
                if (DN.DimIDNo7)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, TopVect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }

                #endregion

                #region RD Dim

                TempList = Com.GetBoltPoints(BC.TopGP.RB.BoltM);
                BC.PC.DistTop = (BC.PC.DistInc);

                //RD Dim
                Vect = new Vector(0, 1, 0);

                // Dim No 1.6
                if (DN.DimIDNo1Dot6 && !dc.IsEqualPoints(BC.TopGP.LB.RefPBrace, BC.TopGP.RB.RefPBrace))
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(BC.TopGP.RB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }
                else
                    BC.PC.DistTop += BC.PC.DistInc;

                // Dim No 1.8
                if (DN.DimIDNo1Dot8)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(BC.TopGP.RB.IntPointB);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }


                // Dim No 1.5
                if (DN.DimIDNo1Dot5)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                // Dim No 1.2
                if (DN.DimIDNo1Dot2)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(BC.TopGP.RB.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                // Dim No 1.3
                if (DN.DimIDNo1Dot3)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(Com.MaxP(TempList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }


                #endregion

                #region Top Staright Dim

                Vect = new Vector(0, 1, 0);

                // Dim No 19,20
                if (DN.DimIDNo19 || DN.DimIDNo20)
                {

                    pointList = new PointList();
                    if (DN.DimIDNo19) // Dim No 19
                        pointList.Add(Com.MaxP(TempList, "Y"));

                    pointList.Add(BC.TopGP.RB.IntPointB);

                    if (DN.DimIDNo20) // Dim No 20
                        pointList.Add(BC.TopGP.RB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }

                // Dim No 19.1
                if (DN.DimIDNo19Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    pointList.Add(BC.TopGP.RB.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }

                // Dim No 18
                if (DN.DimIDNo18)
                {

                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P5);
                    pointList.Add(BC.TopGP.RB.IntPoint);
                    pointList.Add(BC.TopGP.RB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }

                // Dim No 21
                if (DN.DimIDNo21)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P5);
                    pointList.Add(BC.TopGP.RB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }


                // Dim No 22
                if (DN.DimIDNo22)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    pointList.Add(BC.TopGP.RB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }

                // Dim No 23
                if (DN.DimIDNo23)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.RB.IntPoint);
                    pointList.Add(BC.TopGP.RB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }


                #endregion

                #region Straight Right
                Vect = new Vector(1, 0, 0);
                BC.PC.DistRight = (BC.PC.DistInc * 2);

                // Dim No 2
                if (DN.DimIDNo2)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(MidPList, "Y"));
                    pointList.Add(BC.TopGP.Points.P3);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, BC.TopGP.Points.P3.X, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }

                }

                // Dim No 2.3, 2.2
                if (DN.DimIDNo2Dot3 || DN.DimIDNo2Dot2)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo2Dot3) // Dim No 2.3
                        pointList.Add(Com.MaxP(MidPList, "Y"));

                    pointList.Add(BC.TopGP.RB.IntPoint);

                    if (DN.DimIDNo2Dot2) // Dim No 2.2
                        pointList.Add(BC.TopGP.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, BC.TopGP.Points.P3.X, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }

                }

                // Dim No 2.1
                if (DN.DimIDNo2Dot1)
                {

                    pointList = new PointList();
                    pointList.Add(Com.MaxP(MidPList, "Y"));
                    pointList.Add(BC.TopGP.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, BC.TopGP.Points.P3.X, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }
                }


                #endregion

                if (DN.DimIDNo16 && BC.TopGP.RB.CutPoints != null)
                {
                    RadiusDimension Rd = new RadiusDimension(CView, BC.TopGP.RB.CutPoints.P4, BC.TopGP.RB.CutPoints.P3, BC.TopGP.RB.CutPoints.P5, -5);
                    Rd.Attributes.Placing.Placing = DimensionSetBaseAttributes.Placings.Fixed;
                    Rd.Insert();
                }


                //  Com.DrawLineDotted(CView, BC.TopGP.RB.IntPoint, BC.TopGP.RB.RefPBrace);

                //Dim Code 8 // Angle Dimension
                if (DN.DimIDNo8)
                {
                    Point Temp = new Point(BC.TopGP.RB.IntPoint.X, BC.TopGP.RB.RefPBrace.Y, BC.TopGP.RB.IntPoint.Z);
                    AngleDimension angDimA = new AngleDimension(CView, BC.TopGP.RB.IntPoint, BC.TopGP.RB.RefPBrace, Temp, -120);
                    angDimA.Insert();
                }

            }
        }

        private void ApplyLeftBottG()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            TSD.PointList TempList = new PointList();

            if (BC.BottGP?.LB != null)
            {

                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;

                PointList MidPList = Com.GetBoltPoints(BC.BottGP.LB.BoltM);
                TempList = Com.GetBoltPoints(BC.BottGP.LB.BoltM);
                TSG.Line YLine = new TSG.Line(BC.BottGP.Points.P6, BC.BottGP.Points.P1);
                TSG.Line XLine = new TSG.Line(BC.BottGP.LB.IntPoint, BC.BottGP.LB.RefPBrace);

                // Com.DrawLineDotted(CView, Com.MinP(MidPList, "X"), Com.MaxP(MidPList, "Y"));
                TSG.Line YLineR = new TSG.Line(BC.BottGP.LB.IntPoint, Com.MinP(MidPList, "Y"));
                Vector LeftVect = YLineR.Direction;



                if (LeftVect.X > 0)
                    LeftVect = dc.ChangeVector(LeftVect);

                Vector RightVect = YLineR.Direction;
                if (RightVect.X < 0)
                    RightVect = dc.ChangeVector(RightVect);

                Vector TopVect = XLine.Direction;
                if (TopVect.Y < 0)
                    TopVect = dc.ChangeVector(TopVect);

                Vector BottVect = XLine.Direction;
                if (BottVect.Y > 0)
                    BottVect = dc.ChangeVector(BottVect);

                #region Diagonal Left
                TempList = dc.ChangePints(BC.BottGP.LB.BoltM, CView, LeftVect);
                double DisLeft = (BC.PC.DistLeft * 1.5);
                // Dim Code 9.1, 9
                if (DN.DimIDNo9Dot1 || DN.DimIDNo9)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo9Dot1) //  // Dim Code 9.1
                        pointList.Add(Com.MaxP(TempList, "Y"));

                    pointList.Add(BC.BottGP.LB.IntPointB);

                    if (DN.DimIDNo9) //  // Dim Code 9
                        pointList.Add(BC.BottGP.LB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, XLine, DisLeft);
                        DisLeft += BC.PC.DistInc;
                    }

                }


                // Dim Code 10, 10.1
                if (DN.DimIDNo10Dot1 || DN.DimIDNo10)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo10Dot1) //  // Dim Code 10.1
                        pointList.Add(BC.BottGP.Points.P1);

                    pointList.AddRange(TempList);

                    if (DN.DimIDNo9) //  // Dim Code 10
                        pointList.Add(BC.BottGP.LB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, XLine, DisLeft);
                        DisLeft += BC.PC.DistInc;
                    }

                }

                // Dim Code 27
                if (DN.DimIDNo27 && BC.BottGP.LB.CutPoints != null)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P6);
                    pointList.Add(BC.BottGP.LB.CutPoints.P3);
                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, (BC.PC.DistRight * 1.5));

                }

                #endregion

                #region Diagonal Bottom
                BC.PC.DistBot = (BC.PC.DistInc * 3);
                TempList = dc.ChangePints(BC.BottGP.LB.BoltM, CView, BottVect);


                if (BC.BottGP.LB.CutPoints != null)
                {
                    // Dim No 4
                    if (DN.DimIDNo4)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.BottGP.LB.CutPoints.P1);
                        pointList.Add(BC.BottGP.LB.IntPoint);
                        pointList.Add(BC.BottGP.LB.CutPoints.P2);
                        xDim = dc.InsertDim(CView, pointList, BottVect, BC.PC.DistBot, StAtrr);
                        if (xDim != null)
                        {
                            PL.DimPlacingDiag(xDim, YLine, BC.PC.DistBot);
                            BC.PC.DistBot += BC.PC.DistInc;
                        }
                    }

                    // Dim No 5
                    if (DN.DimIDNo5)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.BottGP.LB.CutPoints.P1);
                        pointList.Add(BC.BottGP.LB.CutPoints.P2);
                        xDim = dc.InsertDim(CView, pointList, BottVect, BC.PC.DistBot, StAtrr);
                        if (xDim != null)
                        {
                            PL.DimPlacingDiag(xDim, YLine, BC.PC.DistBot);
                            BC.PC.DistBot += BC.PC.DistInc;
                        }
                    }
                }

                // Dim No 6
                if (DN.DimIDNo6)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.LB.IntPoint);
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, BottVect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }

                // Dim No 7
                if (DN.DimIDNo7)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, BottVect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }

                #endregion

                #region RD Dim

                TempList = Com.GetBoltPoints(BC.BottGP.LB.BoltM);
                BC.PC.DistBot = (BC.PC.DistInc);

                //RD Dim
                Vect = new Vector(0, -1, 0);

                // Dim No 1.6
                if (DN.DimIDNo1Dot6)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P2);
                    pointList.Add(BC.BottGP.LB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                // Dim No 1.7
                if (DN.DimIDNo1Dot7)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P2);
                    pointList.Add(BC.BottGP.LB.IntPointB);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                // Dim No 15
                if (BC.SCB != null && (DN.DimIDNo15 || DN.DimIDNo15Dot1))
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P2);
                    pointList.Add(BC.SCB.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }

                if (BC.PC.DistBot > 300)
                    BC.PC.DistBot = (BC.PC.DistInc * 3);

                // Dim No 1.4
                if (DN.DimIDNo1Dot4)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P2);
                    pointList.Add(Com.MinP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                // Dim No 1.1
                if (DN.DimIDNo1Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P2);
                    pointList.Add(BC.BottGP.LB.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                // Dim No 1
                if (DN.DimIDNo1)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P2);
                    pointList.Add(Com.MinP(TempList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }


                #endregion

                #region Bottom Staright Dim

                Vect = new Vector(0, -1, 0);

                // Dim No 19,20
                if (DN.DimIDNo19 || DN.DimIDNo20)
                {

                    pointList = new PointList();
                    if (DN.DimIDNo19) // Dim No 19
                        pointList.Add(Com.MinP(TempList, "Y"));

                    pointList.Add(BC.BottGP.LB.IntPointB);

                    if (DN.DimIDNo20) // Dim No 20
                        pointList.Add(BC.BottGP.LB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }

                // Dim No 19.1
                if (DN.DimIDNo19Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "Y"));
                    pointList.Add(BC.BottGP.LB.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }

                // Dim No 18
                if (DN.DimIDNo18)
                {

                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P6);
                    pointList.Add(BC.BottGP.LB.IntPoint);
                    pointList.Add(BC.BottGP.LB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }

                // Dim No 21
                if (DN.DimIDNo21)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P6);
                    pointList.Add(BC.BottGP.LB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }


                // Dim No 22
                if (DN.DimIDNo22)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "Y"));
                    pointList.Add(BC.BottGP.LB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }

                // Dim No 23
                if (DN.DimIDNo23)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.LB.IntPoint);
                    pointList.Add(BC.BottGP.LB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }

                // Dim No 11
                if (DN.DimIDNo11 && BC.BottGP.RB != null)
                {
                    PointList TempList1 = Com.GetBoltPoints(BC.BottGP.RB.BoltM);
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "X"));
                    pointList.Add(Com.MaxP(TempList1, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }


                // Dim No 12
                if (DN.DimIDNo12)
                {

                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P2);
                    pointList.Add(BC.BottGP.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }

                // Dim No 12.1
                if (DN.DimIDNo12Dot1)
                {
                    BC.PC.DistTop += (BC.PC.DistInc / 3);
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P6);
                    pointList.Add(BC.BottGP.Points.P5);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        Com.SetMidDimText(xDim, "PROTECTED AREA NS & F/S");
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }
                #endregion

                #region Straight Left
                Vect = new Vector(-1, 0, 0);
                BC.PC.DistLeft = (BC.PC.DistInc * 2);

                // Dim No 2
                if (DN.DimIDNo2)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(MidPList, "Y"));
                    pointList.Add(BC.BottGP.Points.P2);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, BC.BottGP.Points.P2.X, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }

                }

                // Dim No 2.3, 2.2
                if (DN.DimIDNo2Dot3 || DN.DimIDNo2Dot2)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo2Dot3) // Dim No 2.3
                        pointList.Add(Com.MinP(MidPList, "Y"));

                    pointList.Add(BC.BottGP.LB.IntPoint);

                    if (DN.DimIDNo2Dot2) // Dim No 2.2
                        pointList.Add(BC.BottGP.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, BC.BottGP.Points.P2.X, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }

                }

                // Dim No 2.1
                if (DN.DimIDNo2Dot1)
                {

                    pointList = new PointList();
                    pointList.Add(Com.MinP(MidPList, "Y"));
                    pointList.Add(BC.BottGP.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, BC.BottGP.Points.P2.X, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }
                }

                // Dim No 2.4
                if (DN.DimIDNo2Dot4)
                {

                    pointList = new PointList();
                    pointList.Add(BC.BottGP.LB.IntPoint);
                    pointList.Add(new Point(BC.BottGP.Points.P2.X, BC.Points.P1.Y));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, BC.BottGP.Points.P2.X, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }
                }

                // Dim No 3.1
                if (DN.DimIDNo3Dot1)
                {

                    pointList = new PointList();
                    pointList.Add(Com.MinP(MidPList, "Y"));
                    pointList.Add(new Point(BC.BottGP.Points.P2.X, BC.Points.P1.Y));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, BC.BottGP.Points.P2.X, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }
                }

                // Dim No 3
                if (DN.DimIDNo3)
                {

                    pointList = new PointList();
                    pointList.Add(Com.MaxP(MidPList, "Y"));
                    pointList.Add(new Point(BC.BottGP.Points.P2.X, BC.Points.P1.Y));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, BC.BottGP.Points.P2.X, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }
                }


                #endregion


                if (DN.DimIDNo16 && BC.BottGP.LB.CutPoints != null)
                {
                    RadiusDimension Rd = new RadiusDimension(CView, BC.BottGP.LB.CutPoints.P4, BC.BottGP.LB.CutPoints.P3, BC.BottGP.LB.CutPoints.P5, -5);
                    Rd.Attributes.Placing.Placing = DimensionSetBaseAttributes.Placings.Fixed;
                    Rd.Insert();
                }

                // Com.DrawLineDotted(CView, BC.BottGP.LB.IntPoint, BC.BottGP.LB.RefPBrace);

                //Dim Code 8 // Angle Dimension
                if (DN.DimIDNo8)
                {
                    Point Temp = new Point(BC.BottGP.LB.IntPoint.X, BC.BottGP.LB.RefPBrace.Y, BC.BottGP.LB.IntPoint.Z);
                    AngleDimension angDimA = new AngleDimension(CView, BC.BottGP.LB.IntPoint, BC.BottGP.LB.RefPBrace, Temp, -120);
                    angDimA.Insert();
                }

            }
        }

        private void ApplyRightBottG()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            TSD.PointList TempList = new PointList();

            if (BC.BottGP?.LB != null)
            {

                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;

                PointList MidPList = Com.GetBoltPoints(BC.BottGP.RB.BoltM);
                TempList = Com.GetBoltPoints(BC.BottGP.RB.BoltM);
                TSG.Line YLine = new TSG.Line(BC.BottGP.Points.P4, BC.BottGP.Points.P5);
                TSG.Line XLine = new TSG.Line(BC.BottGP.RB.IntPoint, BC.BottGP.RB.RefPBrace);
                //Com.DrawLineDotted(CView, Com.MinP(MidPList, "X"), Com.MinP(MidPList, "Y"));

                TSG.Line YLineR = new TSG.Line(BC.BottGP.RB.IntPoint, Com.MinP(MidPList, "Y"));
                Vector LeftVect = YLineR.Direction;



                if (LeftVect.X > 0)
                    LeftVect = dc.ChangeVector(LeftVect);

                Vector RightVect = YLineR.Direction;
                if (RightVect.X < 0)
                    RightVect = dc.ChangeVector(RightVect);

                Vector TopVect = XLine.Direction;
                if (TopVect.Y < 0)
                    TopVect = dc.ChangeVector(TopVect);

                Vector BottVect = XLine.Direction;
                if (BottVect.Y > 0)
                    BottVect = dc.ChangeVector(BottVect);


                #region Diagonal Left
                TempList = dc.ChangePints(BC.BottGP.RB.BoltM, CView, RightVect);
                double DisRight = (BC.PC.DistRight * 1.5);
                // Dim Code 9.1, 9
                if (DN.DimIDNo9Dot1 || DN.DimIDNo9)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo9Dot1) //  // Dim Code 9.1
                        pointList.Add(Com.MaxP(TempList, "Y"));

                    pointList.Add(BC.BottGP.RB.IntPointB);

                    if (DN.DimIDNo9) //  // Dim Code 9
                        pointList.Add(BC.BottGP.RB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, RightVect, DisRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, XLine, DisRight);
                        DisRight += BC.PC.DistInc;
                    }

                }


                // Dim Code 10, 10.1
                if (DN.DimIDNo10Dot1 || DN.DimIDNo10)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo10Dot1) //  // Dim Code 10.1
                        pointList.Add(BC.BottGP.Points.P4);

                    pointList.AddRange(TempList);

                    if (DN.DimIDNo9) //  // Dim Code 10
                        pointList.Add(BC.BottGP.RB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, RightVect, DisRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, XLine, DisRight);
                        DisRight += BC.PC.DistInc;
                    }

                }

                // Dim Code 27
                if (DN.DimIDNo27 && BC.BottGP.RB.CutPoints != null)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P5);
                    pointList.Add(BC.BottGP.RB.CutPoints.P3);
                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, (BC.PC.DistLeft * 1.5));

                }

                #endregion

                #region Diagonal Bottom
                BC.PC.DistBot = (BC.PC.DistInc * 3);
                TempList = dc.ChangePints(BC.BottGP.RB.BoltM, CView, BottVect);


                if (BC.BottGP.RB.CutPoints != null)
                {
                    // Dim No 4
                    if (DN.DimIDNo4)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.BottGP.RB.CutPoints.P1);
                        pointList.Add(BC.BottGP.RB.IntPoint);
                        pointList.Add(BC.BottGP.RB.CutPoints.P2);
                        xDim = dc.InsertDim(CView, pointList, BottVect, BC.PC.DistBot, StAtrr);
                        if (xDim != null)
                        {
                            PL.DimPlacingDiag(xDim, YLine, BC.PC.DistBot);
                            BC.PC.DistBot += BC.PC.DistInc;
                        }
                    }

                    // Dim No 5
                    if (DN.DimIDNo5)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.BottGP.RB.CutPoints.P1);
                        pointList.Add(BC.BottGP.RB.CutPoints.P2);
                        xDim = dc.InsertDim(CView, pointList, BottVect, BC.PC.DistBot, StAtrr);
                        if (xDim != null)
                        {
                            PL.DimPlacingDiag(xDim, YLine, BC.PC.DistBot);
                            BC.PC.DistBot += BC.PC.DistInc;
                        }
                    }
                }

                // Dim No 6
                if (DN.DimIDNo6)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.RB.IntPoint);
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, BottVect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }

                // Dim No 7
                if (DN.DimIDNo7)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, BottVect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }

                #endregion

                #region RD Dim

                TempList = Com.GetBoltPoints(BC.BottGP.RB.BoltM);
                BC.PC.DistBot = (BC.PC.DistInc);

                //RD Dim
                Vect = new Vector(0, -1, 0);

                // Dim No 1.3
                if (DN.DimIDNo1Dot3)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P2);
                    pointList.Add(Com.MaxP(TempList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                // Dim No 1.8
                if (DN.DimIDNo1Dot8)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P2);
                    pointList.Add(BC.BottGP.RB.IntPointB);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                // Dim No 1.5
                if (DN.DimIDNo1Dot5)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P2);
                    pointList.Add(Com.MinP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                // Dim No 1.2
                if (DN.DimIDNo1Dot2)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P2);
                    pointList.Add(BC.BottGP.RB.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                // Dim No 1.6
                if (DN.DimIDNo1Dot6 && !dc.IsEqualPoints(BC.BottGP.RB.RefPBrace, BC.BottGP.LB.RefPBrace))
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P2);
                    pointList.Add(BC.BottGP.RB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }
                else
                {
                    if (BC.PC.DistBot > 300)
                        BC.PC.DistBot += BC.PC.DistInc;
                }

                #endregion

                #region Bottom Staright Dim

                Vect = new Vector(0, -1, 0);

                // Dim No 19,20
                if (DN.DimIDNo19 || DN.DimIDNo20)
                {

                    pointList = new PointList();
                    if (DN.DimIDNo19) // Dim No 19
                        pointList.Add(Com.MinP(TempList, "Y"));

                    pointList.Add(BC.BottGP.RB.IntPointB);

                    if (DN.DimIDNo20) // Dim No 20
                        pointList.Add(BC.BottGP.RB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }

                // Dim No 19.1
                if (DN.DimIDNo19Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "Y"));
                    pointList.Add(BC.BottGP.RB.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }

                // Dim No 18
                if (DN.DimIDNo18)
                {

                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P5);
                    pointList.Add(BC.BottGP.RB.IntPoint);
                    pointList.Add(BC.BottGP.RB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }

                // Dim No 21
                if (DN.DimIDNo21)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P5);
                    pointList.Add(BC.BottGP.RB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }


                // Dim No 22
                if (DN.DimIDNo22)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "Y"));
                    pointList.Add(BC.BottGP.RB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }

                // Dim No 23
                if (DN.DimIDNo23)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.RB.IntPoint);
                    pointList.Add(BC.BottGP.RB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }


                #endregion

                #region Straight Right
                Vect = new Vector(1, 0, 0);
                BC.PC.DistRight = (BC.PC.DistInc * 2);

                // Dim No 2
                if (DN.DimIDNo2)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(MidPList, "Y"));
                    pointList.Add(BC.BottGP.Points.P3);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, BC.BottGP.Points.P3.X, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }

                }

                // Dim No 2.3, 2.2
                if (DN.DimIDNo2Dot3 || DN.DimIDNo2Dot2)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo2Dot3) // Dim No 2.3
                        pointList.Add(Com.MinP(MidPList, "Y"));

                    pointList.Add(BC.BottGP.RB.IntPoint);

                    if (DN.DimIDNo2Dot2) // Dim No 2.2
                        pointList.Add(BC.BottGP.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, BC.BottGP.Points.P3.X, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }

                }

                // Dim No 2.1
                if (DN.DimIDNo2Dot1)
                {

                    pointList = new PointList();
                    pointList.Add(Com.MinP(MidPList, "Y"));
                    pointList.Add(BC.BottGP.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, BC.BottGP.Points.P3.X, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }
                }

                // Dim No 2.4
                if (DN.DimIDNo2Dot4)
                {

                    pointList = new PointList();
                    pointList.Add(BC.BottGP.RB.IntPoint);
                    pointList.Add(new Point(BC.BottGP.Points.P3.X, BC.Points.P1.Y));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, BC.BottGP.Points.P3.X, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }
                }

                // Dim No 3.1
                if (DN.DimIDNo3Dot1)
                {

                    pointList = new PointList();
                    pointList.Add(Com.MinP(MidPList, "Y"));
                    pointList.Add(new Point(BC.BottGP.Points.P3.X, BC.Points.P1.Y));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, BC.BottGP.Points.P3.X, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }
                }

                // Dim No 3
                if (DN.DimIDNo3)
                {

                    pointList = new PointList();
                    pointList.Add(Com.MaxP(MidPList, "Y"));
                    pointList.Add(new Point(BC.BottGP.Points.P3.X, BC.Points.P1.Y));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, BC.BottGP.Points.P3.X, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }
                }

                // Dim No 28
                if (DN.DimIDNo28 && BC.TopGP != null)
                {

                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P4);
                    pointList.Add(BC.BottGP.Points.P4);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, BC.BottGP.Points.P3.X, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }
                }


                #endregion

                if (DN.DimIDNo16 && BC.BottGP.RB.CutPoints != null)
                {
                    RadiusDimension Rd = new RadiusDimension(CView, BC.BottGP.RB.CutPoints.P4, BC.BottGP.RB.CutPoints.P3, BC.BottGP.RB.CutPoints.P5, -5);
                    Rd.Attributes.Placing.Placing = DimensionSetBaseAttributes.Placings.Fixed;
                    Rd.Insert();
                }

                // Com.DrawLineDotted(CView, BC.BottGP.RB.IntPoint, BC.BottGP.RB.RefPBrace);

                //Dim Code 8 // Angle Dimension
                if (DN.DimIDNo8)
                {
                    Point Temp = new Point(BC.BottGP.RB.IntPoint.X, BC.BottGP.RB.RefPBrace.Y, BC.BottGP.RB.IntPoint.Z);
                    AngleDimension angDimA = new AngleDimension(CView, BC.BottGP.RB.IntPoint, BC.BottGP.RB.RefPBrace, Temp, -120);
                    angDimA.Insert();
                }

            }
        }

        private void AppyMidStiff()
        {
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            // Dim No 13, 13.1
            if (BC.SCT != null && (DN.DimIDNo13 || DN.DimIDNo1))
            {
                if (BC.SCM != null && (BC.SCB == null || BC.SCT == null))
                {
                    if (BC.SCT == null)
                    {

                        Vect = new Vector(0, 1, 0);
                        PointList pointList = new PointList();
                        pointList.Add(BC.Points.P1);
                        pointList.Add(BC.SCT.Points.P1);

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                            BC.PC.DistTop += BC.PC.DistInc;
                        }

                    }

                    if (BC.SCB == null)
                    {

                        Vect = new Vector(0, -1, 0);
                        PointList pointList = new PointList();
                        pointList.Add(BC.Points.P2);
                        pointList.Add(BC.SCT.Points.P2);

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceTopP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                            BC.PC.DistBot += BC.PC.DistInc;
                        }

                    }
                }
            }
        }

        private void ApplyTVDim()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);


            if (DN.DimIDNo17 || DN.DimIDNo17Dot1)
            {
                if (BCS.Stiffs?.Count > 0)
                {
                    foreach (PartClass PC in BCS.Stiffs)
                    {
                        BCS.PC.DistTop = (BCS.PC.DistInc * 2);
                        BCS.PC.DistBot = (BCS.PC.DistInc * 2);

                        if (PC.Points.CentP.Y > BCS.Points.CentP.Y)
                        {
                            Vect = new Vector(0, 1, 0);
                            pointList = new PointList();
                            pointList.Add(BCS.Points.P1);
                            pointList.Add(PC.Points.P1);
                            xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistTop, RdAtrr);
                            if (xDim != null)
                                PL.DimPlaceByTopY(xDim, BCS.PC);
                        }
                        else
                        {
                            Vect = new Vector(0, -1, 0);
                            pointList = new PointList();
                            pointList.Add(BCS.Points.P2);
                            pointList.Add(PC.Points.P2);
                            xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistBot, RdAtrr);
                            if (xDim != null)
                                PL.DimPlaceByBottomY(xDim, BCS.PC);
                        }

                        Ids.Add(PC.part.Identifier.ID);
                    }
                }



            }
        }

        private void AppySectionDim()
        {
            StraightDimensionSet xDim = null;
            PointList pointList = new PointList();
            Vector Vect = new Vector(0, 1, 0);

            // Dim No 29
            if (BCS.TopGP != null && DN.DimIDNo29)
            {
                Vect = new Vector(0, 1, 0);
                pointList = new PointList();
                pointList.Add(BCS.TopGP.Points.P1);
                pointList.Add(BCS.TopGP.Points.P4);
                xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistTop, StAtrr);
                if (xDim != null)
                    PL.DistPlaceTopP(xDim, BCS.PC.TopY, BCS.PC.DistTop);
            }

            // Dim No 29
            if (BCS.BottGP != null && DN.DimIDNo29)
            {
                Vect = new Vector(0, -1, 0);
                pointList = new PointList();
                pointList.Add(BCS.BottGP.Points.P2);
                pointList.Add(BCS.BottGP.Points.P3);
                xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistBot, StAtrr);
                if (xDim != null)
                    PL.DistPlaceBottP(xDim, BCS.PC.BottomY, BCS.PC.DistBot);
            }


            if (BCS.SCM != null)
            {
                Vect = new Vector(0, 1, 0);
                // Dim No 22, 22.1
                if (DN.DimIDNo24 || DN.DimIDNo24Dot1)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo24) // Dim No 24
                        pointList.Add(BCS.SCM.SCL.Points.P1);
                    pointList.Add(BCS.SCM.SCL.Points.P4);
                    if (DN.DimIDNo24Dot1) // Dim No 24.1
                        pointList.Add(new Point(BCS.Points.CentP.X, BCS.SCM.SCL.Points.P4.Y));
                    xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistInc, StAtrr);

                    pointList = new PointList();
                    if (DN.DimIDNo24) // Dim No 24
                        pointList.Add(BCS.SCM.SCR.Points.P4);
                    pointList.Add(BCS.SCM.SCR.Points.P1);
                    if (DN.DimIDNo24Dot1) //Dim No 24.1
                        pointList.Add(new Point(BCS.Points.CentP.X, BCS.SCM.SCR.Points.P1.Y));
                    xDim = dc.InsertDim(CView, pointList, Vect, (BCS.PC.DistInc * 2), StAtrr);

                }
            }

            if (BCS.SCT != null)
            {
                BCS.PC.DistLeft = BCS.PC.DistInc * 2;
                Vect = new Vector(-1, 0, 0);
                // Dim No 26
                if (DN.DimIDNo26 && BCS.SCT.SCL != null)
                {
                    pointList = new PointList();
                    pointList.Add(BCS.SCT.SCL.Points.P1);
                    pointList.Add(BCS.SCT.SCL.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BCS.PC.LeftX, BCS.PC.DistLeft);

                }
                BCS.PC.DistRight = BCS.PC.DistInc * 2;
                Vect = new Vector(1, 0, 0);
                // Dim No 26
                if (DN.DimIDNo26 && BCS.SCT.SCR != null)
                {
                    pointList = new PointList();
                    pointList.Add(BCS.SCT.SCR.Points.P4);
                    pointList.Add(BCS.SCT.SCR.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BCS.PC.RightX, BCS.PC.DistRight);

                }
            }

            if (BCS.SCM != null)
            {
                BCS.PC.DistLeft = BCS.PC.DistInc * 2;
                Vect = new Vector(-1, 0, 0);
                // Dim No 25
                if (DN.DimIDNo25 && BCS.SCM.SCL != null)
                {
                    pointList = new PointList();
                    pointList.Add(BCS.SCM.SCL.Points.P1);
                    pointList.Add(BCS.SCM.SCL.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BCS.PC.LeftX, BCS.PC.DistLeft);

                }
                BCS.PC.DistRight = BCS.PC.DistInc * 2;
                Vect = new Vector(1, 0, 0);
                // Dim No 25
                if (DN.DimIDNo25 && BCS.SCM.SCR != null)
                {
                    pointList = new PointList();
                    pointList.Add(BCS.SCM.SCR.Points.P4);
                    pointList.Add(BCS.SCM.SCR.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BCS.PC.RightX, BCS.PC.DistRight);

                }
            }

            if (BCS.SCB != null)
            {
                BCS.PC.DistLeft = BCS.PC.DistInc * 2;
                Vect = new Vector(-1, 0, 0);
                // Dim No 26
                if (DN.DimIDNo26 && BCS.SCB.SCL != null)
                {
                    pointList = new PointList();
                    pointList.Add(BCS.SCB.SCL.Points.P1);
                    pointList.Add(BCS.SCB.SCL.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BCS.PC.LeftX, BCS.PC.DistLeft);

                }
                BCS.PC.DistRight = BCS.PC.DistInc * 2;
                Vect = new Vector(1, 0, 0);
                // Dim No 26
                if (DN.DimIDNo26 && BCS.SCB.SCR != null)
                {
                    pointList = new PointList();
                    pointList.Add(BCS.SCB.SCR.Points.P4);
                    pointList.Add(BCS.SCB.SCR.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BCS.PC.RightX, BCS.PC.DistRight);

                }
            }

            if (BCS.SCT != null && BCS.SCM != null)
            {
                BCS.PC.DistRight = BCS.PC.DistInc;
                BCS.PC.DistLeft = BCS.PC.DistInc;

                Vect = new Vector(-1, 0, 0);
                // Dim No 25.1
                if (DN.DimIDNo25Dot1 && BCS.SCT.SCL != null)
                {
                    pointList = new PointList();
                    pointList.Add(BCS.SCT.SCL.Points.P2);
                    pointList.Add(BCS.SCM.SCL.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BCS.PC.LeftX, BCS.PC.DistLeft);

                }

                Vect = new Vector(1, 0, 0);
                // Dim No 25.1
                if (DN.DimIDNo25Dot1 && BCS.SCT.SCR != null)
                {
                    pointList = new PointList();
                    pointList.Add(BCS.SCT.SCR.Points.P3);
                    pointList.Add(BCS.SCM.SCR.Points.P4);
                    xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BCS.PC.RightX, BCS.PC.DistRight);

                }
            }

            if (BCS.SCB != null && BCS.SCM != null)
            {
                BCS.PC.DistRight = BCS.PC.DistInc;
                BCS.PC.DistLeft = BCS.PC.DistInc;
                Vect = new Vector(-1, 0, 0);
                // Dim No 25.2
                if (DN.DimIDNo25Dot2)
                {
                    pointList = new PointList();
                    pointList.Add(BCS.SCB.SCL.Points.P1);
                    pointList.Add(BCS.SCM.SCL.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BCS.PC.LeftX, BCS.PC.DistLeft);

                }

                Vect = new Vector(1, 0, 0);
                // Dim No 25.2
                if (DN.DimIDNo25Dot2 && BCS.SCB.SCR != null)
                {
                    pointList = new PointList();
                    pointList.Add(BCS.SCB.SCR.Points.P4);
                    pointList.Add(BCS.SCM.SCR.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BCS.PC.RightX, BCS.PC.DistRight);

                }
            }

        }

        private void TestDim()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;

            Vector Vect = new Vector(0, 1, 0);

            TSD.PointList TempList = new PointList();

            Point Temp = new Point(BC.TopGP.LB.IntPoint.X, BC.TopGP.LB.RefPBrace.Y, BC.TopGP.LB.IntPoint.Z);
            AngleDimension angDimA = new AngleDimension(CView, BC.TopGP.LB.IntPoint, BC.TopGP.LB.RefPBrace, Temp, -80);
            angDimA.Insert();

            Temp = new Point(BC.TopGP.RB.IntPoint.X, BC.TopGP.RB.RefPBrace.Y, BC.TopGP.RB.IntPoint.Z);
            angDimA = new AngleDimension(CView, BC.TopGP.RB.IntPoint, BC.TopGP.RB.RefPBrace, Temp, -80);
            angDimA.Insert();

            Temp = new Point(BC.BottGP.RB.IntPoint.X, BC.BottGP.RB.RefPBrace.Y, BC.BottGP.RB.IntPoint.Z);
            angDimA = new AngleDimension(CView, BC.BottGP.RB.IntPoint, BC.BottGP.RB.RefPBrace, Temp, -80);
            angDimA.Insert();

            Temp = new Point(BC.BottGP.LB.IntPoint.X, BC.BottGP.LB.RefPBrace.Y, BC.BottGP.LB.IntPoint.Z);
            angDimA = new AngleDimension(CView, BC.BottGP.LB.IntPoint, BC.BottGP.LB.RefPBrace, Temp, -80);
            angDimA.Insert();

        }

        #region Get Data

        private void GetBeamClassClass(TSD.View CView)
        {
            if (ViewName == "Front View")
            {
                BC = new BeamClass_BG21();
                BC.beam = MainBeam;
                List<TSM.Part> PartListC = BC.beam.GetAssembly().GetSecondaries().OfType<TSM.Part>().ToList();
                PartListC.Add(MainBeam);
                BC.Points = Com.GetPartPoints(BC.beam);

                List<TSM.BoltGroup> BoltDList = Com.EnumtoArray(BC.beam.GetBolts()).OfType<TSM.BoltGroup>().ToList();
                Point CentP = Com.CenterPoint(BC.beam.StartPoint, BC.beam.EndPoint);
                double Lenght = (BC.beam.GetSolid().MaximumPoint.X - BC.beam.GetSolid().MinimumPoint.X) / 6;
                double MinX = BC.beam.GetSolid().MinimumPoint.X + Lenght;
                double MaxX = BC.beam.GetSolid().MaximumPoint.X - Lenght;

                // List<TSM.Part> PartListF = (from p in PartListC where !Com.IsCode(p) select p).ToList();
                List<TSM.Part> PartListF = (from p in PartListC where !Ids.Contains(p.Identifier.ID) select p).ToList();
                ContourPlate TopGP = (from p in PartListF.OfType<ContourPlate>() where IsBG21(p) && (Com.CenterPoint(p).Y > BC.Points.CentP.Y) && !dc.IsPlateSideView(p) select p).FirstOrDefault();
                ContourPlate BottGP = (from p in PartListF.OfType<ContourPlate>() where IsBG21(p) && (Com.CenterPoint(p).Y < BC.Points.CentP.Y) && !dc.IsPlateSideView(p) select p).FirstOrDefault();

                if (TopGP != null)
                {
                    BC.TopGP = GetGussetClass(TopGP, "Top");
                    BC.SCT = GetStiffClass(TopGP, PartListF, "Top");
                    if (BC.SCM == null)
                        BC.SCM = GetStiffClass(TopGP, PartListF, "Middle");
                }

                if (BottGP != null)
                {
                    BC.BottGP = GetGussetClass(BottGP, "Bottom");
                    BC.SCB = GetStiffClass(BottGP, PartListF, "Bottom");
                    if (BC.SCM == null)
                        BC.SCM = GetStiffClass(BottGP, PartListF, "Middle");
                }

                List<Point> RefPoints = MainBeam.GetReferenceLine(false).OfType<Point>().ToList();

                double MinXP = (from p in RefPoints orderby p.X ascending select p.X).FirstOrDefault();
                double MaxXP = (from p in RefPoints orderby p.X descending select p.X).FirstOrDefault();

                MinXP -= 100;
                MaxXP += 100;

                TSM.Part LeftPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.X ascending select p).FirstOrDefault();
                TSM.Part RightPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.X descending select p).FirstOrDefault();
                TSM.Part TopPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.Y descending select p).FirstOrDefault();
                TSM.Part BottPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.Y ascending select p).FirstOrDefault();

                BC.PC = new PlacingClass();
                BC.PC.TopY = TopPart.GetSolid().MaximumPoint.Y;
                BC.PC.BottomY = BottPart.GetSolid().MinimumPoint.Y;



                BC.PC.LeftX = MainBeam.StartPoint.X;// Math.Round(CView.RestrictionBox.MinPoint.X);
                BC.PC.RightX = RightPart.GetSolid().MaximumPoint.X;

                if (BC.PC.LeftX > MinXP)
                    BC.PC.LeftX = (MinXP + 100);

                if (BC.PC.RightX < MaxXP)
                    BC.PC.RightX = (MaxXP - 100);

                double AvScale = 12;
                double AvDistInc = 100;
                double DistPerScale = AvDistInc / AvScale;
                double CScale = CView.Attributes.Scale;
                BC.PC.DistInc = CScale * DistPerScale;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;
            }

            if (ViewName == "Section View")
            {
                BCS = new BeamClass_BG21S();
                BCS.beam = MainBeam;
                List<TSM.Part> PartListC = BCS.beam.GetAssembly().GetSecondaries().OfType<TSM.Part>().ToList();

                BCS.Points = Com.GetPartPoints(BCS.beam);

                double MaxZ = CView.RestrictionBox.MinPoint.Z;
                List<TSM.Part> PartList = (from p in PartListC where Com.IsViewObj(p, CView) select p).ToList();
                // List<TSM.Part> PartList = (from p in PartListC where p.GetSolid().MaximumPoint.Z > MaxZ select p).ToList();
                Point CentP = Com.CenterPoint(BCS.beam.StartPoint, BCS.beam.EndPoint);

                List<TSM.Part> PartListF = (from p in PartList where !Ids.Contains(p.Identifier.ID) select p).ToList();
                //List<TSM.Part> PartListF = (from p in PartList where !Com.IsCode(p) select p).ToList();
                ContourPlate TopGP = (from p in PartListF.OfType<ContourPlate>() where IsBG21(p) && (Com.CenterPoint(p).Y > BCS.Points.CentP.Y) select p).FirstOrDefault();
                ContourPlate BottGP = (from p in PartListF.OfType<ContourPlate>() where IsBG21(p) && (Com.CenterPoint(p).Y < BCS.Points.CentP.Y) select p).FirstOrDefault();

                if (TopGP != null)
                {
                    BCS.TopGP = GetGussetClassS(TopGP, "Top");
                    BCS.SCT = GetStiffClassS(TopGP, PartListF, "Top");
                    if (BCS.SCM == null)
                        BCS.SCM = GetStiffClassS(TopGP, PartListF, "Middle");
                }

                if (BottGP != null)
                {
                    BCS.BottGP = GetGussetClassS(BottGP, "Bottom");
                    BCS.SCB = GetStiffClassS(BottGP, PartListF, "Bottom");
                    if (BCS.SCM == null)
                        BCS.SCM = GetStiffClassS(BottGP, PartListF, "Middle");
                }

                PartList.Add(MainBeam);
                List<Point> RefPoints = MainBeam.GetReferenceLine(false).OfType<Point>().ToList();

                TSM.Part LeftPart = (from p in PartList orderby p.GetSolid().MinimumPoint.X ascending select p).FirstOrDefault();
                TSM.Part RightPart = (from p in PartList orderby p.GetSolid().MaximumPoint.X descending select p).FirstOrDefault();
                TSM.Part TopPart = (from p in PartList orderby p.GetSolid().MaximumPoint.Y descending select p).FirstOrDefault();
                TSM.Part BottPart = (from p in PartList orderby p.GetSolid().MinimumPoint.Y ascending select p).FirstOrDefault();

                BCS.PC = new PlacingClass();
                BCS.PC.TopY = TopPart.GetSolid().MaximumPoint.Y;
                BCS.PC.BottomY = BottPart.GetSolid().MinimumPoint.Y;
                BCS.PC.LeftX = LeftPart.GetSolid().MinimumPoint.X; ;// Math.Round(CView.RestrictionBox.MinPoint.X);
                BCS.PC.RightX = RightPart.GetSolid().MaximumPoint.X;

                double AvScale = 12;
                double AvDistInc = 100;
                double DistPerScale = AvDistInc / AvScale;
                double CScale = CView.Attributes.Scale;
                BCS.PC.DistInc = CScale * DistPerScale;
                BCS.PC.DistBot = BCS.PC.DistInc;
                BCS.PC.DistTop = BCS.PC.DistInc;
                BCS.PC.DistLeft = BCS.PC.DistInc;
                BCS.PC.DistRight = BCS.PC.DistInc;
            }

            if (ViewName == "Top View" || ViewName == "Bottom View")
            {
                BCS = new BeamClass_BG21S();
                BCS.beam = MainBeam;
                List<TSM.Part> PartListC = BCS.beam.GetAssembly().GetSecondaries().OfType<TSM.Part>().ToList();

                BCS.Points = Com.GetPartPoints(BCS.beam);


                List<TSM.Part> Stiffs = (from p in PartListC where dc.IsPlateSideView(p) && !dc.IsHorzObj(p) select p).ToList();
                if (Stiffs != null && Stiffs.Count > 0)
                {
                    BCS.Stiffs = GetStiff(Stiffs);
                    TSM.Part Topstiff = null;
                    TSM.Part Bottstiff = null;
                    if (Stiffs.Count == 1)
                        Topstiff = Stiffs[0];
                    else
                    {
                        Topstiff = (from b in Stiffs where Com.CenterPoint(b).Y > BCS.Points.CentP.Y select b).FirstOrDefault();
                        Bottstiff = (from b in Stiffs where Com.CenterPoint(b).Y < BCS.Points.CentP.Y select b).FirstOrDefault();
                    }

                    if (Topstiff != null)
                    {
                        BCS.SCTop = new StiffClass();
                        BCS.SCTop.Stiff = Topstiff;
                        BCS.SCTop.Points = Com.GetPartPoints(Topstiff);
                    }

                    if (Bottstiff != null)
                    {
                        BCS.SCBot = new StiffClass();
                        BCS.SCBot.Stiff = Bottstiff;
                        BCS.SCBot.Points = Com.GetPartPoints(Bottstiff);
                    }

                }

                PartListC.Add(MainBeam);
                List<Point> RefPoints = MainBeam.GetReferenceLine(false).OfType<Point>().ToList();

                TSM.Part LeftPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.X ascending select p).FirstOrDefault();
                TSM.Part RightPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.X descending select p).FirstOrDefault();
                TSM.Part TopPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.Y descending select p).FirstOrDefault();
                TSM.Part BottPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.Y ascending select p).FirstOrDefault();

                BCS.PC = new PlacingClass();
                BCS.PC.TopY = TopPart.GetSolid().MaximumPoint.Y;
                BCS.PC.BottomY = BottPart.GetSolid().MinimumPoint.Y;
                BCS.PC.LeftX = LeftPart.GetSolid().MinimumPoint.X; ;// Math.Round(CView.RestrictionBox.MinPoint.X);
                BCS.PC.RightX = RightPart.GetSolid().MaximumPoint.X;

                double AvScale = 12;
                double AvDistInc = 100;
                double DistPerScale = AvDistInc / AvScale;
                double CScale = CView.Attributes.Scale;
                BCS.PC.DistInc = CScale * DistPerScale;
                BCS.PC.DistBot = BCS.PC.DistInc;
                BCS.PC.DistTop = BCS.PC.DistInc;
                BCS.PC.DistLeft = BCS.PC.DistInc;
                BCS.PC.DistRight = BCS.PC.DistInc;
            }

        }

        private GussetClassB GetGussetClass(ContourPlate GP, string Position)
        {
            GussetClassB GC = new GussetClassB();
            GC.GussetPlate = GP;
            GC.Points = GetGussetPoints(GP);

            List<BoltGroup> Bolts = Com.EnumtoArray(GP.GetBolts()).OfType<BoltGroup>().ToList();

            List<BoltGroup> LeftBolts = (from b in Bolts where Com.CenterPoint(b).X < GC.Points.CentP.X orderby (b as BoltArray).GetBoltDistY(0) select b).ToList();
            List<BoltGroup> RightBolts = (from b in Bolts where Com.CenterPoint(b).X > GC.Points.CentP.X orderby (b as BoltArray).GetBoltDistY(0) select b).ToList();

            if (LeftBolts != null && LeftBolts.Count > 0)
            {

                BoltGroup MidBolt = LeftBolts[0];

                GC.LB = new GussetBrace();

                if (MidBolt != null)
                {
                    GC.LB.BoltM = MidBolt;
                    TSM.Part brace = GetBrace(GP, Position, "Left");
                    if (brace != null)
                    {
                        GC.LB.Brace = brace;
                        // GC.LB.RefPBrace = dc.NearestPoint(GC.LB.Brace.StartPoint, GC.LB.Brace.EndPoint, MidBolt.FirstPosition);
                        GC.LB.RefPBrace = GetBraceRefPoint(brace);
                        GC.LB.IntPoint = GetIntSectPoint(GC.LB.BoltM, brace, Position, "Left");
                        if (Position == "Top")
                        {
                            if (GC.LB.RefPBrace != null && GC.LB.IntPoint != null)
                                GC.LB.IntPointB = Com.GetIntersectionPoint(GC.LB.RefPBrace, GC.LB.IntPoint, BC.Points.P1, BC.Points.P4);

                            GC.LB.Degree = GetDegree(GC.LB.IntPointB, GC.LB.IntPoint, BC.Points.P1);
                        }
                        else
                        {
                            if (GC.LB.RefPBrace != null && GC.LB.IntPoint != null)
                                GC.LB.IntPointB = Com.GetIntersectionPoint(GC.LB.RefPBrace, GC.LB.IntPoint, BC.Points.P2, BC.Points.P3);

                            GC.LB.Degree = GetDegree(GC.LB.IntPointB, GC.LB.IntPoint, BC.Points.P2);
                        }

                        GC.LB.CutPoints = GetCutPoints(GC.LB, GP, Position, "Left");
                    }
                }

            }


            if (RightBolts != null && RightBolts.Count > 0)
            {

                BoltGroup MidBolt = RightBolts[0];
                GC.RB = new GussetBrace();

                if (MidBolt != null)
                {
                    GC.RB.BoltM = MidBolt;
                    TSM.Part brace = GetBrace(GP, Position, "Right");
                    if (brace != null)
                    {
                        GC.RB.Brace = brace;
                        // GC.RB.RefPBrace = dc.NearestPoint(GC.RB.Brace.StartPoint, GC.RB.Brace.EndPoint, MidBolt.FirstPosition);
                        GC.RB.RefPBrace = GetBraceRefPoint(brace);
                        GC.RB.IntPoint = GetIntSectPoint(GC.RB.BoltM, brace, Position, "Right");
                        if (Position == "Top")
                        {
                            if (GC.RB.RefPBrace != null && GC.RB.IntPoint != null)
                                GC.RB.IntPointB = Com.GetIntersectionPoint(GC.RB.RefPBrace, GC.RB.IntPoint, BC.Points.P1, BC.Points.P4);

                            GC.RB.Degree = GetDegree(GC.RB.IntPointB, GC.RB.IntPoint, BC.Points.P4);
                        }
                        else
                        {
                            if (GC.RB.RefPBrace != null && GC.RB.IntPoint != null)
                                GC.RB.IntPointB = Com.GetIntersectionPoint(GC.RB.RefPBrace, GC.RB.IntPoint, BC.Points.P2, BC.Points.P3);

                            GC.RB.Degree = GetDegree(GC.RB.IntPointB, GC.RB.IntPoint, BC.Points.P3);
                        }

                        GC.RB.CutPoints = GetCutPoints(GC.RB, GP, Position, "Right");
                    }



                }



            }

            return GC;
        }

        private GussetClass GetGussetClassS(ContourPlate GP, string Position)
        {
            GussetClass GC = new GussetClass();
            GC.GussetPlate = GP;
            GC.Points = Com.GetPartPoints(GP);

            return GC;
        }

        private StiffClass GetStiffClass(ContourPlate GP, List<TSM.Part> PartListF, string Position)
        {
            StiffClass SC = null;
            TSM.Part Stiff = null;
            if (Position == "Top")
            {
                Stiff = (from p in PartListF where dc.IsPlateSideView(p) && (Com.CenterPoint(p).X > GP.GetSolid().MinimumPoint.X && Com.CenterPoint(p).X < GP.GetSolid().MaximumPoint.X) && (Com.CenterPoint(p).Y > BC.Points.P1.Y) select p).FirstOrDefault();
            }
            else if (Position == "Bottom")
            {
                Stiff = (from p in PartListF where dc.IsPlateSideView(p) && (Com.CenterPoint(p).X > GP.GetSolid().MinimumPoint.X && Com.CenterPoint(p).X < GP.GetSolid().MaximumPoint.X) && (Com.CenterPoint(p).Y < BC.Points.P2.Y) select p).FirstOrDefault();
            }

            else if (Position == "Middle")
            {
                Stiff = (from p in PartListF where dc.IsPlateSideView(p) && (Com.CenterPoint(p).X > GP.GetSolid().MinimumPoint.X && Com.CenterPoint(p).X < GP.GetSolid().MaximumPoint.X) && (Com.CenterPoint(p).Y < BC.Points.P1.Y && Com.CenterPoint(p).Y > BC.Points.P2.Y) select p).FirstOrDefault();
            }

            if (Stiff != null)
            {
                SC = new StiffClass();
                SC.Stiff = Stiff;
                SC.Points = Com.GetPartPoints(Stiff);
            }


            return SC;
        }

        private StiffClassS GetStiffClassS(ContourPlate GP, List<TSM.Part> PartListF, string Position)
        {
            StiffClassS SCS = null;
            TSM.Part StiffL = null;
            TSM.Part StiffR = null;

            Point GPCent = Com.CenterPoint(GP);
            if (Position == "Top")
            {
                StiffL = (from p in PartListF where !dc.IsPlateSideViewN(p) && (Com.CenterPoint(p).X < Com.CenterPoint(GP).X) && (Com.CenterPoint(p).Y > BCS.Points.P1.Y) select p).FirstOrDefault();
                StiffR = (from p in PartListF where !dc.IsPlateSideViewN(p) && (Com.CenterPoint(p).X > Com.CenterPoint(GP).X) && (Com.CenterPoint(p).Y > BCS.Points.P1.Y) select p).FirstOrDefault();
            }
            else if (Position == "Bottom")
            {
                StiffL = (from p in PartListF where !dc.IsPlateSideViewN(p) && (Com.CenterPoint(p).X < Com.CenterPoint(GP).X) && (Com.CenterPoint(p).Y < BCS.Points.P2.Y) select p).FirstOrDefault();
                StiffR = (from p in PartListF where !dc.IsPlateSideViewN(p) && (Com.CenterPoint(p).X > Com.CenterPoint(GP).X) && (Com.CenterPoint(p).Y < BCS.Points.P2.Y) select p).FirstOrDefault();
            }

            else if (Position == "Middle")
            {
                StiffL = (from p in PartListF where !dc.IsPlateSideViewN(p) && (Com.CenterPoint(p).X < Com.CenterPoint(GP).X) && (Com.CenterPoint(p).Y > BCS.Points.P2.Y && Com.CenterPoint(p).Y < BCS.Points.P1.Y) select p).FirstOrDefault();
                StiffR = (from p in PartListF where !dc.IsPlateSideViewN(p) && (Com.CenterPoint(p).X > Com.CenterPoint(GP).X) && (Com.CenterPoint(p).Y > BCS.Points.P2.Y && Com.CenterPoint(p).Y < BCS.Points.P1.Y) select p).FirstOrDefault();
            }

            if (StiffL != null)
            {
                if (SCS == null)
                    SCS = new StiffClassS();


                StiffClass SC = new StiffClass();
                SC.Stiff = StiffL;
                SC.Points = Com.GetPartPoints(StiffL);
                SCS.SCL = SC;
            }

            if (StiffR != null)
            {
                if (SCS == null)
                    SCS = new StiffClassS();


                StiffClass SC = new StiffClass();
                SC.Stiff = StiffR;
                SC.Points = Com.GetPartPoints(StiffR);
                SCS.SCR = SC;
            }


            return SCS;
        }

        private CutPoints GetCutPoints(GussetBrace GB, TSM.Part GP, string PosV, string PosH)
        {
            CutPoints cutPoints = null;
            try
            {
                List<BooleanPart> Cuts = Com.EnumtoArray(GP.GetBooleans()).OfType<BooleanPart>().Where(x => IsValidCut(x)).ToList();

                Point CentPG = Com.CenterPoint(GP);
                if (Cuts != null && Cuts.Count > 0)
                {
                    TSM.ContourPlate CutP = null;

                    PartPoints Points = GetGussetPoints(GP as ContourPlate);

                    if (PosH == "Left")
                        CutP = (from p in Cuts where Com.CenterPoint(p.OperativePart).X < CentPG.X select p.OperativePart).OfType<ContourPlate>().FirstOrDefault();
                    else
                        CutP = (from p in Cuts where Com.CenterPoint(p.OperativePart).X > CentPG.X select p.OperativePart).OfType<ContourPlate>().FirstOrDefault();

                    if (CutP != null)
                    {
                        cutPoints = new CutPoints();
                        double CVal = GetChampherVal(CutP);
                        PointList PtList = dc.ContPList(CutP);
                        if (PosV == "Top")
                        {
                            if (PosH == "Left")
                            {
                                cutPoints.P1 = Com.MaxP(PtList, "Y");
                                cutPoints.P2 = Com.MinP(PtList, "X");
                                Point P_1 = Com.MinP(PtList, "Y");
                                Point P_2 = Com.MaxP(PtList, "X");
                                cutPoints.P1 = Com.GetIntersectionPoint(Points.P1, Points.P6, cutPoints.P1, P_2);
                                cutPoints.P2 = Com.GetIntersectionPoint(Points.P1, Points.P6, cutPoints.P2, P_1);
                                cutPoints.P3 = Com.GetIntersectionPoint(P_1, P_2, GB.IntPoint, GB.RefPBrace);
                                if (CVal > 0)
                                {
                                    cutPoints.P4 = GetPoint(P_2, cutPoints.P1, CVal, "TL");
                                    cutPoints.P5 = GetPoint(P_1, cutPoints.P2, CVal, "TL");
                                    //Com.DrawLine(CView, cutPoints.P4, cutPoints.P5);
                                }
                            }
                            else
                            {
                                cutPoints.P1 = Com.MaxP(PtList, "Y");
                                cutPoints.P2 = Com.MaxP(PtList, "X");
                                Point P_1 = Com.MinP(PtList, "Y");
                                Point P_2 = Com.MinP(PtList, "X");
                                cutPoints.P1 = Com.GetIntersectionPoint(Points.P4, Points.P5, cutPoints.P1, P_2);
                                cutPoints.P2 = Com.GetIntersectionPoint(Points.P4, Points.P5, cutPoints.P2, P_1);
                                cutPoints.P3 = Com.GetIntersectionPoint(P_1, P_2, GB.IntPoint, GB.RefPBrace);
                                if (CVal > 0)
                                {
                                    cutPoints.P4 = GetPoint(P_1, cutPoints.P2, CVal, "TR");
                                    cutPoints.P5 = GetPoint(P_2, cutPoints.P1, CVal, "TR");
                                    //  Com.DrawLine(CView, cutPoints.P4, cutPoints.P5);
                                }
                            }
                        }
                        else
                        {

                            if (PosH == "Left")
                            {
                                cutPoints.P1 = Com.MinP(PtList, "Y");
                                cutPoints.P2 = Com.MinP(PtList, "X");
                                Point P_1 = Com.MaxP(PtList, "Y");
                                Point P_2 = Com.MaxP(PtList, "X");
                                cutPoints.P1 = Com.GetIntersectionPoint(Points.P1, Points.P6, cutPoints.P1, P_2);
                                cutPoints.P2 = Com.GetIntersectionPoint(Points.P1, Points.P6, cutPoints.P2, P_1);

                                cutPoints.P3 = Com.GetIntersectionPoint(P_1, P_2, GB.IntPoint, GB.RefPBrace);

                                if (CVal > 0)
                                {
                                    cutPoints.P4 = GetPoint(P_1, cutPoints.P2, CVal, "BL");
                                    cutPoints.P5 = GetPoint(P_2, cutPoints.P1, CVal, "BL");
                                    //  Com.DrawLine(CView, cutPoints.P4, cutPoints.P5);
                                }
                            }
                            else
                            {
                                cutPoints.P1 = Com.MinP(PtList, "Y");
                                cutPoints.P2 = Com.MaxP(PtList, "X");
                                Point P_1 = Com.MaxP(PtList, "Y");
                                Point P_2 = Com.MinP(PtList, "X");
                                cutPoints.P1 = Com.GetIntersectionPoint(Points.P4, Points.P5, cutPoints.P1, P_2);
                                cutPoints.P2 = Com.GetIntersectionPoint(Points.P4, Points.P5, cutPoints.P2, P_1);
                                cutPoints.P3 = Com.GetIntersectionPoint(P_1, P_2, GB.IntPoint, GB.RefPBrace);

                                if (CVal > 0)
                                {
                                    cutPoints.P4 = GetPoint(P_2, cutPoints.P1, CVal, "BR");
                                    cutPoints.P5 = GetPoint(P_1, cutPoints.P2, CVal, "BR");
                                    // Com.DrawLine(CView, cutPoints.P4, cutPoints.P5);
                                }
                            }

                        }
                    }
                }
            }
            catch (Exception ex)
            { }

            return cutPoints;

        }

        private double GetChampherVal(TSM.ContourPlate CutP)
        {
            double CVal = 0;
            ContourPoint CPoint = CutP.Contour.ContourPoints.OfType<ContourPoint>().ToList().Where(x => x.Chamfer != null && x.Chamfer.X > 0).FirstOrDefault();
            if (CPoint != null)
                CVal = CPoint.Chamfer.X;

            return CVal;
        }

        private Point GetPoint(Point P1, Point P2, double IncVal, string Pos)
        {
            double X = 0, Y = 0;
            double Dist = Distance.PointToPoint(P1, P2);
            if (Pos == "TL")
            {
                X = P1.X - ((Math.Abs(P1.X - P2.X) / Dist) * IncVal);
                Y = P1.Y + ((Math.Abs(P1.Y - P2.Y) / Dist) * IncVal);
            }
            else if (Pos == "TR")
            {
                X = P1.X + ((Math.Abs(P1.X - P2.X) / Dist) * IncVal);
                Y = P1.Y + ((Math.Abs(P1.Y - P2.Y) / Dist) * IncVal);
            }
            else if (Pos == "BL")
            {
                X = P1.X - ((Math.Abs(P1.X - P2.X) / Dist) * IncVal);
                Y = P1.Y - ((Math.Abs(P1.Y - P2.Y) / Dist) * IncVal);
            }
            else
            {
                X = P1.X + ((Math.Abs(P1.X - P2.X) / Dist) * IncVal);
                Y = P1.Y - ((Math.Abs(P1.Y - P2.Y) / Dist) * IncVal);
            }

            return new Point(X, Y);

        }

        private TSM.Part GetBrace(TSM.Part GP, string PosV, string PosH)
        {
            List<int> PartIds = BC.beam.GetAssembly().GetSecondaries().OfType<TSM.Part>().Select(x => x.Identifier.ID).ToList();
            PartIds.Add(MainBeam.Identifier.ID);
            TSM.Part brace = null;
            Point CentP = Com.CenterPoint(GP);
            double Tol = 100;

            Point MinP = new Point(GP.GetSolid().MinimumPoint.X - Tol, GP.GetSolid().MinimumPoint.Y, MainBeam.GetSolid().MinimumPoint.Z);
            Point MaxP = new Point(GP.GetSolid().MaximumPoint.X + Tol, GP.GetSolid().MaximumPoint.Y + Tol, MainBeam.GetSolid().MaximumPoint.Z);

            if (PosV == "Bottom")
            {
                MinP = new Point(GP.GetSolid().MinimumPoint.X - Tol, GP.GetSolid().MinimumPoint.Y - Tol, MainBeam.GetSolid().MinimumPoint.Z);
                MaxP = new Point(GP.GetSolid().MaximumPoint.X + Tol, GP.GetSolid().MaximumPoint.Y, MainBeam.GetSolid().MaximumPoint.Z);
            }
            ModelObjectEnumerator Enum = Com.MyModel.GetModelObjectSelector().GetObjectsByBoundingBox(MinP, MaxP);
            List<TSM.Part> AllAPrts = Com.EnumtoArray(Enum).OfType<TSM.Part>().ToList();
            List<Brep> breps = AllAPrts.OfType<TSM.Brep>().ToList().Where(x => !PartIds.Contains(x.Identifier.ID)).OrderByDescending(x => Com.GetPartNetLength(x)).ToList();
            if (breps != null && breps.Count > 0)
            {
                if (PosH == "Left")
                    breps = (from b in breps where Com.CenterPoint(b).X < CentP.X select b).ToList();
                else
                    breps = (from b in breps where Com.CenterPoint(b).X > CentP.X select b).ToList();

                List<int> Ids = breps.Select(x => x.Identifier.ID).ToList();
                foreach (Brep brep in breps)
                {
                    if (IsBrace(brep, GP, PosH))
                    {
                        brace = brep;
                        break;
                    }

                }
            }
            else
            {
                List<TSM.Part> parts = AllAPrts.Where(x => !PartIds.Contains(x.Identifier.ID)).OrderByDescending(x => Com.GetPartNetLength(x)).ToList();
                List<Beam> braces = parts.OfType<Beam>().OrderByDescending(x => Com.GetPartNetLength(x)).ToList();
                if (PosH == "Left")
                    braces = (from b in braces where Com.CenterPoint(b).X < CentP.X select b).ToList();
                else
                    braces = (from b in braces where Com.CenterPoint(b).X > CentP.X select b).ToList();

                List<int> Ids = braces.Select(x => x.Identifier.ID).ToList();
                foreach (Beam brep in braces)
                {
                    if (IsBrace(brep, GP, PosH))
                    {
                        brace = brep;
                        break;
                    }

                }
            }

            return brace;

        }

        private bool IsBrace(TSM.Brep b, TSM.Part GP, string PosH)
        {
            bool RetCheck = false;
            if (dc.IsEqualOrLess(b.StartPoint.Y, BC.Points.P1.Y) && dc.IsEqualOrGreater(b.StartPoint.Y, BC.Points.P2.Y))
            {
                if (b.StartPoint.X > GP.GetSolid().MinimumPoint.X && b.StartPoint.X < GP.GetSolid().MaximumPoint.X)
                {
                    if ((PosH == "Left" && b.StartPoint.X > b.EndPoint.X) || PosH == "Right" && b.StartPoint.X < b.EndPoint.X)
                        RetCheck = true;
                }

            }

            else if (dc.IsEqualOrLess(b.EndPoint.Y, BC.Points.P1.Y) && dc.IsEqualOrGreater(b.EndPoint.Y, BC.Points.P2.Y))
            {
                if (b.EndPoint.X > GP.GetSolid().MinimumPoint.X && b.EndPoint.X < GP.GetSolid().MaximumPoint.X)
                {
                    if ((PosH == "Left" && b.EndPoint.X > b.StartPoint.X) || PosH == "Right" && b.EndPoint.X < b.StartPoint.X)
                        RetCheck = true;
                }
            }



            return RetCheck;
        }

        private bool IsBrace(TSM.Beam b, TSM.Part GP, string PosH)
        {
            bool RetCheck = false;
            if (dc.IsEqualOrLess(b.StartPoint.Y, BC.Points.P1.Y) && dc.IsEqualOrGreater(b.StartPoint.Y, BC.Points.P2.Y))
            {
                if (b.StartPoint.X > GP.GetSolid().MinimumPoint.X && b.StartPoint.X < GP.GetSolid().MaximumPoint.X)
                {
                    if ((PosH == "Left" && b.StartPoint.X > b.EndPoint.X) || PosH == "Right" && b.StartPoint.X < b.EndPoint.X)
                        RetCheck = true;
                }

            }

            else if (dc.IsEqualOrLess(b.EndPoint.Y, BC.Points.P1.Y) && dc.IsEqualOrGreater(b.EndPoint.Y, BC.Points.P2.Y))
            {
                if (b.EndPoint.X > GP.GetSolid().MinimumPoint.X && b.EndPoint.X < GP.GetSolid().MaximumPoint.X)
                {
                    if ((PosH == "Left" && b.EndPoint.X > b.StartPoint.X) || PosH == "Right" && b.EndPoint.X < b.StartPoint.X)
                        RetCheck = true;
                }
            }



            return RetCheck;
        }

        private PartPoints GetGussetPoints(ContourPlate GP)
        {
            PartPoints RetP = new PartPoints();
            PointList pointList = Com.ContPList(GP);
            RetP.CentP = Com.CenterPoint(GP);


            if (pointList.Count > 4)
            {
                if (RetP.CentP.Y > BC.Points.CentP.Y)
                {

                    RetP.P1 = (from p in pointList.OfType<Point>() where p.X < RetP.CentP.X orderby p.Y descending select p).FirstOrDefault();
                    RetP.P2 = (from p in pointList.OfType<Point>() where p.X < RetP.CentP.X orderby p.Y ascending select p).FirstOrDefault();
                    RetP.P6 = (from p in pointList.OfType<Point>() where p.X < RetP.CentP.X && p.Y > RetP.P2.Y orderby p.Y ascending select p).FirstOrDefault();

                    RetP.P4 = (from p in pointList.OfType<Point>() where p.X > RetP.CentP.X orderby p.Y descending select p).FirstOrDefault();
                    RetP.P3 = (from p in pointList.OfType<Point>() where p.X > RetP.CentP.X orderby p.Y ascending select p).FirstOrDefault();
                    RetP.P5 = (from p in pointList.OfType<Point>() where p.X > RetP.CentP.X && p.Y > RetP.P3.Y orderby p.Y ascending select p).FirstOrDefault();
                }
                else
                {

                    RetP.P1 = (from p in pointList.OfType<Point>() where p.X < RetP.CentP.X orderby p.Y ascending select p).FirstOrDefault();
                    RetP.P2 = (from p in pointList.OfType<Point>() where p.X < RetP.CentP.X orderby p.Y descending select p).FirstOrDefault();
                    RetP.P6 = (from p in pointList.OfType<Point>() where p.X < RetP.CentP.X && p.Y < RetP.P2.Y orderby p.Y descending select p).FirstOrDefault();

                    RetP.P4 = (from p in pointList.OfType<Point>() where p.X > RetP.CentP.X orderby p.Y ascending select p).FirstOrDefault();
                    RetP.P3 = (from p in pointList.OfType<Point>() where p.X > RetP.CentP.X orderby p.Y descending select p).FirstOrDefault();
                    RetP.P5 = (from p in pointList.OfType<Point>() where p.X > RetP.CentP.X && p.Y < RetP.P3.Y orderby p.Y descending select p).FirstOrDefault();
                }
            }
            else
            {

                pointList = dc.GetVertPointList(GP);
                PointList pointListO = OtherCutPoint(GP);

                List<Point> pointListP = (from p in pointList.OfType<Point>().ToList() where !dc.IsPointinList(pointListO, p) select p).ToList();
                if (pointListP != null)
                    pointList = Com.PointToPointList(pointListP);


                if (RetP.CentP.Y > BC.Points.CentP.Y)
                {

                    RetP.P1 = (from p in pointList.OfType<Point>() where p.X < RetP.CentP.X orderby p.Y descending select p).FirstOrDefault();
                    RetP.P2 = (from p in pointList.OfType<Point>() where p.X < RetP.CentP.X orderby p.Y ascending select p).FirstOrDefault();
                    RetP.P6 = (from p in pointList.OfType<Point>() where p.X < RetP.CentP.X && p.Y > RetP.P2.Y orderby p.Y ascending select p).FirstOrDefault();

                    RetP.P4 = (from p in pointList.OfType<Point>() where p.X > RetP.CentP.X orderby p.Y descending select p).FirstOrDefault();
                    RetP.P3 = (from p in pointList.OfType<Point>() where p.X > RetP.CentP.X orderby p.Y ascending select p).FirstOrDefault();
                    RetP.P5 = (from p in pointList.OfType<Point>() where p.X > RetP.CentP.X && p.Y > RetP.P3.Y orderby p.Y ascending select p).FirstOrDefault();
                }
                else
                {

                    RetP.P1 = (from p in pointList.OfType<Point>() where p.X < RetP.CentP.X orderby p.Y ascending select p).FirstOrDefault();
                    RetP.P2 = (from p in pointList.OfType<Point>() where p.X < RetP.CentP.X orderby p.Y descending select p).FirstOrDefault();
                    RetP.P6 = (from p in pointList.OfType<Point>() where p.X < RetP.CentP.X && p.Y < RetP.P2.Y orderby p.Y descending select p).FirstOrDefault();

                    RetP.P4 = (from p in pointList.OfType<Point>() where p.X > RetP.CentP.X orderby p.Y ascending select p).FirstOrDefault();
                    RetP.P3 = (from p in pointList.OfType<Point>() where p.X > RetP.CentP.X orderby p.Y descending select p).FirstOrDefault();
                    RetP.P5 = (from p in pointList.OfType<Point>() where p.X > RetP.CentP.X && p.Y < RetP.P3.Y orderby p.Y descending select p).FirstOrDefault();
                }
            }

            return RetP;
        }

        private List<PartClass> GetStiff(List<TSM.Part> Stiffs)
        {
            List<PartClass> partClasses = new List<PartClass>();
            List<double> XVals = new List<double>();
            foreach (TSM.Part p in Stiffs)
            {
                PartClass PC = Com.GetPartClass(p);
                if (XVals.Where(x => Com.IsEqual(PC.Points.P1.X, x)).Count() == 0)
                {
                    partClasses.Add(PC);
                    XVals.Add(PC.Points.P1.X);
                }
            }


            return partClasses;
        }

        #endregion

        #region Helping Methods

        private PointList OtherCutPoint(ContourPlate GP)
        {
            PointList RetPlist = new PointList();
            List<ContourPlate> CutsP = Com.EnumtoArray(GP.GetBooleans()).OfType<BooleanPart>().Where(x => IsValidCut(x)).Select(o => o.OperativePart).OfType<ContourPlate>().ToList();
            if (CutsP != null && CutsP.Count > 0)
                CutsP.ForEach(x => RetPlist.AddRange(dc.GetVertexList(x.GetSolid())));


            return RetPlist;
        }

        private bool IsValidCut(BooleanPart Cut)
        {
            bool RetCheck = false;
            if (Cut.OperativePart is ContourPlate)
            {
                if ((Cut.OperativePart as ContourPlate).Contour.ContourPoints.Count > 3)
                    RetCheck = true;
            }
            return RetCheck;
        }

        private Point GetBraceRefPoint(TSM.Part Brace)
        {
            Point StartPoint = new Point();
            Point EndPoint = new Point();

            if (Brace is Beam)
            {
                StartPoint = (Brace as Beam).StartPoint;
                EndPoint = (Brace as Beam).EndPoint;
            }
            else if (Brace is Brep)
            {

                StartPoint = (Brace as Brep).StartPoint;
                EndPoint = (Brace as Brep).EndPoint;

            }

            Point RefP = StartPoint;
            List<Point> CentPlist = MainBeam.GetCenterLine(false).OfType<Point>().ToList();
            Point StartP = Com.MinP(CentPlist, "X");
            Point EndP = Com.MaxP(CentPlist, "X");

            double DistS = Distance.PointToLine(StartPoint, new TSG.Line(StartP, EndP));
            double DistE = Distance.PointToLine(EndPoint, new TSG.Line(StartP, EndP));

            if (DistE < DistS)
                RefP = EndPoint;

            return RefP;
        }

        private double GetDegree(Point P1, Point P2, Point P3)
        {
            double degree = 0;
            try
            {

                AngleDimension angDimA = new AngleDimension(CView, P1, P2, P3, 50);
                degree = angDimA.GetAngle();
            }
            catch (Exception ex)
            { }
            return degree;
        }

        private Point GetIntSectPoint(BoltGroup bolt, TSM.Part brace, string Position, string PosH)
        {
            Point StartPoint = new Point();
            Point EndPoint = new Point();

            if (brace is Beam)
            {
                StartPoint = (brace as Beam).StartPoint;
                EndPoint = (brace as Beam).EndPoint;
            }
            else if (brace is Brep)
            {

                StartPoint = (brace as Brep).StartPoint;
                EndPoint = (brace as Brep).EndPoint;

            }

            PointList PList = Com.GetBoltPoints(bolt);
            Point P1 = Com.MaxP(PList, "Y");
            Point P2 = Com.MinP(PList, "X");
            Point IntSectP = null;
            if (Position == "Top")
            {
                if (PosH == "Right")
                {
                    P1 = Com.MaxP(PList, "Y");
                    P2 = Com.MaxP(PList, "X");
                }
            }
            else
            {
                if (PosH == "Right")
                {
                    P1 = Com.MinP(PList, "Y");
                    P2 = Com.MaxP(PList, "X");
                }
                else
                {
                    P1 = Com.MinP(PList, "Y");
                    P2 = Com.MinP(PList, "X");
                }
            }

            if (PList.Count > 1)
                IntSectP = Com.GetIntersectionPoint(P1, P2, StartPoint, EndPoint);
            else if (PList.Count == 1)
                IntSectP = PList[0];

            return IntSectP;

        }

        private bool IsBG21(TSM.Part part)
        {
            if (Com.GetNote5(part).ToUpper().Contains("BG21"))
                return true;
            else
                return false;
        }
        #endregion

        #region Classes
        private class GussetClassB
        {
            public TSM.Part GussetPlate { get; set; }
            public PartPoints Points { get; set; }
            public GussetBrace LB { get; set; }
            public GussetBrace RB { get; set; }
            public bool IsGussetSlop = false;

        }

        private class GussetBrace
        {
            public BoltGroup BoltM { get; set; }
            public TSM.Part Brace { get; set; }
            public Point RefPBrace { get; set; }
            public Point IntPoint { get; set; }
            public Point IntPointB { get; set; }
            public CutPoints CutPoints { get; set; }
            public double Degree { get; set; }
        }


        private class StiffClassS
        {
            public StiffClass SCL { get; set; }
            public StiffClass SCR { get; set; }
        }

        private class BeamClass_BG21S
        {
            public Beam beam { get; set; }
            public GussetClass TopGP { get; set; }
            public GussetClass BottGP { get; set; }
            public PartPoints Points { get; set; }
            public PlacingClass PC { get; set; }
            public StiffClassS SCT { get; set; }
            public StiffClassS SCM { get; set; }
            public StiffClassS SCB { get; set; }
            public StiffClass SCTop { get; set; }
            public StiffClass SCBot { get; set; }
            public List<PartClass> Stiffs { get; set; }
        }

        private class BeamClass_BG21
        {
            public Beam beam { get; set; }
            public GussetClassB TopGP { get; set; }
            public GussetClassB BottGP { get; set; }
            public PartPoints Points { get; set; }
            public PlacingClass PC { get; set; }
            public StiffClass SCT { get; set; }
            public StiffClass SCM { get; set; }
            public StiffClass SCB { get; set; }
            
        }

        #endregion

    }








}
