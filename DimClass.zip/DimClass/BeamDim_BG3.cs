﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Tekla.Structures;
using Tekla.Structures.Drawing;
using Tekla.Structures.Geometry3d;
using Tekla.Structures.Model;
using TSD = Tekla.Structures.Drawing;
using TSM = Tekla.Structures.Model;
using VirtueleDrawingAutomation;
using TSDD = Tekla.Structures.Datatype;
using TSG = Tekla.Structures.Geometry3d;

namespace Auto_Detailing_Tool_Beam
{
    public class BeamDim_BG3
    {
        #region Global Variables
        DimCom dc = new DimCom();
        StraightDimensionSet.StraightDimensionSetAttributes StAtrr = new StraightDimensionSet.StraightDimensionSetAttributes("standard");
        StraightDimensionSet.StraightDimensionSetAttributes RdAtrr = new StraightDimensionSet.StraightDimensionSetAttributes("standard");

        public Beam MainBeam = null;
        VirtueleDrawingAutomation.Json.DrawingAttributeInfoJson.AttributeFiles dimAttrClass = null;
        List<TSD.StraightDimension> KnockDim = new List<StraightDimension>();
        BeamClass_BG3 BC = null;
        VirtueleDrawingAutomation.Json.AutoDimensionTypesJson.BG3Json DN = null;
        TSD.View CView = null;

        List<int> Ids = new List<int>();
        #endregion

        public List<int> ApplyDim(TSD.View CView, string ViewName, AutoDimensioningTypes autoDimensioningTypes, DrawingAttributeInfo drawingAttributeInfo, List<int> Ids)
        {
            try
            {
                Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane());
                //Set model everything to the view
                Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane(CView.DisplayCoordinateSystem));

                this.CView = CView;
                this.dimAttrClass = drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files;
                this.DN = autoDimensioningTypes.Bg3;
                StAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.StandardDimension);
                RdAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.RunningDimension);
                this.MainBeam = (Com.MyModel.SelectModelObject(new Identifier((CView.GetDrawing() as AssemblyDrawing).AssemblyIdentifier.ID)) as TSM.Assembly).GetMainPart() as TSM.Beam;
                this.MainBeam.Select();
                string ProType = Com.GetProType(MainBeam);
                BC = GetBeamClassClass(CView);

                //TestDim();
                if (ViewName == "Front View")
                {
                    while (BC.TopGP != null || BC.BottGP != null)
                    {
                        ApplyDimType(CView);
                        BC = GetBeamClassClass(CView);
                    }
                }



            }
            catch (Exception ex)
            { }
            Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane());
            return Ids;
        }

        private void ApplyDimType(TSD.View CView)
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            TSD.PointList TempList = new PointList();
            bool IsVertDim = false;
            Point RefP = null;

            #region Top Gusset
            if (BC.TopGP?.GussetPlate != null)
            {
                double deg = BC.TopGP.Degree;
                // BC.TopGP.GussetPlate
                if (BC.TopGP.BracePos == "Right")
                    ApplyTopRightG();
                else
                    ApplyTopLeftG();



                // Dim No 6
                if (DN.DimIDNo6)
                {
                    Vect = new Vector(1, 0, 0);
                    pointList = new PointList();
                    if (BC.TopGP != null)
                        pointList.Add(BC.TopGP.RefPBrace);

                    RefP = pointList[0];
                    pointList.Add(new Point(pointList[0].X, BC.Points.P1.Y));
                    pointList.Add(new Point(pointList[0].X, BC.Points.P2.Y));
                    xDim = dc.InsertDim(CView, pointList, Vect, (BC.PC.DistInc), StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, BC.TopGP.GussetPlate.GetSolid().MaximumPoint.X, 0);
                        IsVertDim = true;
                    }

                }

                Ids.Add(BC.TopGP.GussetPlate.Identifier.ID);
                // Com.SetCode(BC.TopGP.GussetPlate);

            }
            #endregion


            #region Bottom Gusset
            if (BC.BottGP?.GussetPlate != null)
            {

                double deg = BC.BottGP.Degree;

                if (BC.BottGP.BracePos == "Right")
                    ApplyBottRightG();
                else
                    ApplyBottLeftG();




                // Dim No 6
                if (DN.DimIDNo6)
                {
                    Vect = new Vector(-1, 0, 0);
                    pointList = new PointList();
                    if (BC.BottGP != null)
                        pointList.Add(BC.BottGP.RefPBrace);

                    if ((RefP != null && !dc.IsEqualPoints(pointList[0], RefP)) || !IsVertDim)
                    {
                        pointList.Add(new Point(pointList[0].X, BC.Points.P1.Y));
                        pointList.Add(new Point(pointList[0].X, BC.Points.P2.Y));
                        xDim = dc.InsertDim(CView, pointList, Vect, (BC.PC.DistInc), StAtrr);
                        if (xDim != null)
                            PL.DistPlaceLeftP(xDim, BC.BottGP.GussetPlate.GetSolid().MinimumPoint.X, 0);
                    }

                }

                Ids.Add(BC.BottGP.GussetPlate.Identifier.ID);
                //   Com.SetCode(BC.BottGP.GussetPlate);
            }
            #endregion




        }

        private void ApplyTopLeftG()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            TSD.PointList TempList = new PointList();

            if (BC.TopGP?.GussetPlate != null)
            {

                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;

                TSG.Line YLine = new TSG.Line(BC.TopGP.Points.P1, BC.TopGP.Points.P5);
                TSG.Line XLine = new TSG.Line(BC.TopGP.IntPoint, BC.TopGP.RefPBrace);

                // Com.DrawLineDotted(CView, BC.TopGP.Points.P1, BC.TopGP.Points.P5);

                Vector LeftVect = BC.TopGP.BoltM.GetCoordinateSystem().AxisY;

                if (LeftVect.X > 0)
                    LeftVect = dc.ChangeVector(LeftVect);

                Vector RightVect = BC.TopGP.BoltM.GetCoordinateSystem().AxisY;
                if (RightVect.X < 0)
                    RightVect = dc.ChangeVector(RightVect);

                Vector TopVect = BC.TopGP.BoltM.GetCoordinateSystem().AxisX;
                if (TopVect.Y < 0)
                    TopVect = dc.ChangeVector(TopVect);

                Vector BottVect = BC.TopGP.BoltM.GetCoordinateSystem().AxisX;
                if (BottVect.Y > 0)
                    BottVect = dc.ChangeVector(BottVect);


                if (BC.TopGP.Degree > 40)
                {
                    double Deg = BC.TopGP.Degree - 40;
                    BC.PC.DistTop = Deg * ((BC.PC.DistInc) / 20);

                    BC.PC.DistTop += (BC.PC.DistInc * 3);
                }
                else
                    BC.PC.DistTop = (BC.PC.DistInc * 3);

                #region Diagonal Top
                //BC.PC.DistTop += (BC.PC.DistInc * 2);
                TempList = dc.ChangePints(BC.TopGP.BoltM, CView, TopVect);
                // Dim No 3
                if (DN.DimIDNo3)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    pointList.Add(BC.TopGP.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, TopVect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }

                // Dim No 4
                if (DN.DimIDNo4)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, TopVect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistTop);

                    BC.PC.DistTop += BC.PC.DistInc;
                }

                #endregion

                #region Diagonal Right

                TempList = dc.ChangePints(BC.TopGP.BoltM, CView, LeftVect);
                // Dim No 13,16
                if (DN.DimIDNo13 || DN.DimIDNo16)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo16)// Dim No16
                        pointList.Add(Com.MinP(TempList, "Y"));

                    pointList.Add(BC.TopGP.IntPointB);
                    if (DN.DimIDNo13)// Dim No 13
                        pointList.Add(BC.TopGP.RefPBrace);

                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistRight);
                    }
                }

                // Dim No 7.2
                if (DN.DimIDNo7Dot2)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistRight);
                        Com.GroupDim(xDim);
                    }
                }


                TempList = dc.ChangePints(BC.TopGP.BoltM, CView, RightVect);

                // Dim No 7.1
                if (DN.DimIDNo7Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    pointList.Add(BC.TopGP.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistRight);

                    BC.PC.DistRight += (BC.PC.DistInc / 2);
                }

                // Dim No 7
                if (DN.DimIDNo7)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistRight);
                }

                // Dim No 17
                if (DN.DimIDNo17)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "Y"));
                    pointList.Add(BC.TopGP.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistRight);
                }

                if (DN.DimIDNo7Dot1 || DN.DimIDNo7 || DN.DimIDNo17)
                    BC.PC.DistRight += BC.PC.DistInc;

                #endregion

                #region Straight Left
                Vect = new Vector(-1, 0, 0);
                BC.PC.DistLeft = (BC.PC.DistInc);

                TempList = Com.GetBoltPoints(BC.TopGP.BoltM);

                // Dim No 22
                if (DN.DimIDNo22)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "Y"));
                    pointList.Add(BC.TopGP.Points.P2);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, BC.TopGP.Points.P2.X, BC.PC.DistLeft);
                    }
                }

                // Dim No 2.5
                if (DN.DimIDNo2Dot5)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "X"));
                    pointList.Add(BC.TopGP.IntPoint);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.TopGP.Points.P2.X, BC.PC.DistLeft);

                }

                if (DN.DimIDNo22 || DN.DimIDNo2Dot5)
                    BC.PC.DistLeft += BC.PC.DistInc;

                // Dim No 2.4
                if (DN.DimIDNo2Dot4 || DN.DimIDNo2Dot3)
                {

                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "X"));
                    if (DN.DimIDNo2Dot4)
                        pointList.Add(Com.MaxP(TempList, "Y"));
                    if (DN.DimIDNo2Dot3)
                        pointList.Add(BC.TopGP.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, BC.TopGP.Points.P2.X, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }

                }

                // Dim No 2.1
                if (DN.DimIDNo2Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.IntPoint);
                    pointList.Add(BC.TopGP.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.TopGP.Points.P2.X, BC.PC.DistLeft);

                    BC.PC.DistLeft += BC.PC.DistInc;
                }
                #endregion

                #region RD Dim

                BC.PC.DistTop = (BC.PC.DistInc * 2);
                //RD Dim
                Vect = new Vector(0, 1, 0);

                // Dim No 1.5, 1.1
                if (DN.DimIDNo1Dot5 || DN.DimIDNo1Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(BC.RDPoint);
                    pointList.Add(BC.TopGP.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }


                // Dim No 1.6 , 1.2
                if (DN.DimIDNo1Dot6 || DN.DimIDNo1Dot2)
                {
                    TempList = Com.GetBoltPoints(BC.TopGP.BoltM);
                    pointList = new PointList();
                    pointList.Add(BC.RDPoint);
                    pointList.Add(Com.MinP(TempList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                // Dim No 1.4
                if (DN.DimIDNo1Dot4)
                {
                    TempList = Com.GetBoltPoints(BC.TopGP.BoltM);
                    pointList = new PointList();
                    pointList.Add(BC.RDPoint);
                    pointList.Add(Com.MinP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                // Dim No 1
                if (DN.DimIDNo1)
                {
                    pointList = new PointList();
                    pointList.Add(BC.RDPoint);
                    pointList.Add(BC.TopGP.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }



                // Dim No 1.3
                if (DN.DimIDNo1Dot3)
                {
                    pointList = new PointList();
                    pointList.Add(BC.RDPoint);
                    pointList.Add(BC.TopGP.IntPointB);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }


                #endregion

                #region Top Straight Dim

                Vect = new Vector(0, 1, 0);
                // Dim No 11
                if (DN.DimIDNo11)
                {
                    TempList = Com.GetBoltPoints(BC.TopGP.BoltM);
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.RefPBrace);
                    pointList.Add(BC.TopGP.IntPointB);
                    pointList.Add(BC.TopGP.IntPoint);
                    pointList.Add(Com.MinP(TempList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                // Dim No 10
                if (DN.DimIDNo10)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P3);
                    pointList.Add(BC.TopGP.RefPBrace);
                    pointList.Add(BC.TopGP.IntPointB);
                    pointList.Add(BC.TopGP.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                // Dim No 9
                if (DN.DimIDNo9)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P3);
                    pointList.Add(BC.TopGP.RefPBrace);
                    pointList.Add(BC.TopGP.IntPoint);
                    pointList.Add(BC.TopGP.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                // Dim No 12
                if (DN.DimIDNo12)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P2);
                    pointList.Add(BC.TopGP.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                // Dim No 15
                if (DN.DimIDNo15)
                {
                    if (Ids.Count > 0)
                        BC.PC.DistTop += BC.PC.DistInc;

                    pointList = new PointList();
                    pointList.Add(new Point(BC.PC.LeftX, BC.Points.CentP.Y));
                    pointList.Add(BC.TopGP.RefPBrace);
                    pointList.Add(new Point(BC.PC.RightX, BC.Points.CentP.Y));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }

                #endregion

                // Com.DrawLineDotted(CView, BC.TopGP.IntPoint, BC.TopGP.RefPBrace);

                //Dim Code 5 // Angle Dimension
                if (DN.DimIDNo5)
                    Com.InsertAngleDim(CView, BC.TopGP.RefPBrace, BC.TopGP.IntPoint, "Top", 160);

            }
        }

        private void ApplyBottLeftG()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            TSD.PointList TempList = new PointList();

            if (BC.BottGP?.GussetPlate != null)
            {

                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;

                TSG.Line YLine = new TSG.Line(BC.BottGP.Points.P1, BC.BottGP.Points.P5);
                TSG.Line XLine = new TSG.Line(BC.BottGP.IntPoint, BC.BottGP.RefPBrace);
                Vector LeftVect = BC.BottGP.BoltM.GetCoordinateSystem().AxisY;

                if (LeftVect.X > 0)
                    LeftVect = dc.ChangeVector(LeftVect);

                Vector RightVect = BC.BottGP.BoltM.GetCoordinateSystem().AxisY;
                if (RightVect.X < 0)
                    RightVect = dc.ChangeVector(RightVect);

                Vector TopVect = BC.BottGP.BoltM.GetCoordinateSystem().AxisX;
                if (TopVect.Y < 0)
                    TopVect = dc.ChangeVector(TopVect);

                Vector BottVect = BC.BottGP.BoltM.GetCoordinateSystem().AxisX;
                if (BottVect.Y > 0)
                    BottVect = dc.ChangeVector(BottVect);

                if (BC.BottGP.Degree > 40)
                {
                    double Deg = BC.BottGP.Degree - 40;
                    BC.PC.DistBot = Deg * ((BC.PC.DistInc) / 20);

                    BC.PC.DistBot += (BC.PC.DistInc * 3);
                }
                else
                    BC.PC.DistBot = (BC.PC.DistInc * 3);

                #region Diagonal Top
                //BC.PC.DistBot += (BC.PC.DistInc * 2);
                TempList = dc.ChangePints(BC.BottGP.BoltM, CView, BottVect);
                // Dim No 3
                if (DN.DimIDNo3)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    pointList.Add(BC.BottGP.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, BottVect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }

                // Dim No 4
                if (DN.DimIDNo4)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, BottVect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }

                #endregion

                #region Diagonal Right

                TempList = dc.ChangePints(BC.BottGP.BoltM, CView, LeftVect);
                // Dim No 13,16
                if (DN.DimIDNo13 || DN.DimIDNo16)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo16)// Dim No16
                        pointList.Add(Com.MaxP(TempList, "Y"));

                    pointList.Add(BC.BottGP.IntPointB);
                    if (DN.DimIDNo13)// Dim No 13
                        pointList.Add(BC.BottGP.RefPBrace);

                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistRight);
                    }
                }

                // Dim No 7.2
                if (DN.DimIDNo7Dot2)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistRight);
                        Com.GroupDim(xDim);
                    }
                }

                TempList = dc.ChangePints(BC.BottGP.BoltM, CView, RightVect);

                // Dim No 7.1
                if (DN.DimIDNo7Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "Y"));
                    pointList.Add(BC.BottGP.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistRight);

                    BC.PC.DistRight += (BC.PC.DistInc / 2);
                }

                // Dim No 7
                if (DN.DimIDNo7)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistRight);
                }

                // Dim No 17
                if (DN.DimIDNo17)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    pointList.Add(BC.BottGP.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistRight);
                }

                if (DN.DimIDNo7Dot1 || DN.DimIDNo7 || DN.DimIDNo17)
                    BC.PC.DistRight += BC.PC.DistInc;

                #endregion

                #region Straight Left
                Vect = new Vector(-1, 0, 0);
                BC.PC.DistLeft = (BC.PC.DistInc);

                TempList = Com.GetBoltPoints(BC.BottGP.BoltM);

                // Dim No 22
                if (DN.DimIDNo22)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    pointList.Add(BC.BottGP.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.BottGP.Points.P2.X, BC.PC.DistLeft);

                }

                // Dim No 2.5
                if (DN.DimIDNo2Dot5)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "X"));
                    pointList.Add(BC.BottGP.IntPoint);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.BottGP.Points.P2.X, BC.PC.DistLeft);

                }

                if (DN.DimIDNo22 || DN.DimIDNo2Dot5)
                    BC.PC.DistLeft += BC.PC.DistInc;


                // Dim No 8.2
                if (DN.DimIDNo8Dot2)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.IntPoint);
                    pointList.Add(BC.BottGP.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, BC.BottGP.Points.P2.X, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }

                }


                // Dim No 8.1
                if (DN.DimIDNo8Dot1 || DN.DimIDNo8)
                {

                    pointList = new PointList();

                    pointList.Add(Com.MinP(TempList, "X"));
                    if (DN.DimIDNo8Dot1)
                        pointList.Add(Com.MinP(TempList, "Y"));
                    if (DN.DimIDNo8)
                        pointList.Add(BC.BottGP.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, BC.BottGP.Points.P2.X, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }

                }


                // Dim No 2.2
                if (DN.DimIDNo2Dot2)
                {

                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    pointList.Add(new Point(BC.BottGP.Points.P2.X, BC.Points.P1.Y));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.BottGP.Points.P2.X, BC.PC.DistLeft);

                    BC.PC.DistLeft += BC.PC.DistInc;
                }


                // Dim No 2
                if (DN.DimIDNo2)
                {

                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "X"));
                    pointList.Add(new Point(BC.BottGP.Points.P2.X, BC.Points.P1.Y));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.BottGP.Points.P2.X, BC.PC.DistLeft);

                    BC.PC.DistLeft += BC.PC.DistInc;
                }

                // Dim No 19
                if (DN.DimIDNo19)
                {

                    pointList = new PointList();
                    pointList.Add(BC.BottGP.IntPoint);
                    pointList.Add(new Point(BC.BottGP.Points.P2.X, BC.Points.P1.Y));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.BottGP.Points.P2.X, BC.PC.DistLeft);

                    BC.PC.DistLeft += BC.PC.DistInc;
                }

                // Dim No 18
                if (DN.DimIDNo18 && BC.TopGP?.GussetPlate != null)
                {

                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P5);
                    pointList.Add(BC.TopGP.Points.P5);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.BottGP.Points.P2.X, BC.PC.DistLeft);

                    BC.PC.DistLeft += BC.PC.DistInc;
                }

                #endregion

                #region RD Dim

                BC.PC.DistBot = (BC.PC.DistInc * 2);
                //RD Dim
                Vect = new Vector(0, -1, 0);

                // Dim No 1.5, 1.1
                if ((DN.DimIDNo1Dot5 || DN.DimIDNo1Dot1))
                {
                    if (BC.TopGP == null || !Com.IsEqualPoints(BC.BottGP.RefPBrace, BC.TopGP?.RefPBrace))
                    {
                        pointList = new PointList();
                        pointList.Add(BC.RDPoint);
                        pointList.Add(BC.BottGP.RefPBrace);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                            BC.PC.DistBot += BC.PC.DistInc;
                        }
                    }
                }

                // Dim No 1.6, 1.2
                if (DN.DimIDNo1Dot6 || DN.DimIDNo1Dot2)
                {
                    TempList = Com.GetBoltPoints(BC.BottGP.BoltM);
                    pointList = new PointList();
                    pointList.Add(BC.RDPoint);
                    pointList.Add(Com.MinP(TempList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }

                // Dim No 1.4
                if (DN.DimIDNo1Dot4)
                {
                    TempList = Com.GetBoltPoints(BC.BottGP.BoltM);
                    pointList = new PointList();
                    pointList.Add(BC.RDPoint);
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }

                // Dim No 1
                if (DN.DimIDNo1)
                {
                    pointList = new PointList();
                    pointList.Add(BC.RDPoint);
                    pointList.Add(BC.BottGP.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                // Dim No 1.3
                if (DN.DimIDNo1Dot3)
                {
                    pointList = new PointList();
                    pointList.Add(BC.RDPoint);
                    pointList.Add(BC.BottGP.IntPointB);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }


                #endregion

                #region Bottom Straight Dim

                Vect = new Vector(0, -1, 0);
                // Dim No 11
                if (DN.DimIDNo11)
                {
                    TempList = Com.GetBoltPoints(BC.BottGP.BoltM);
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.RefPBrace);
                    pointList.Add(BC.BottGP.IntPointB);
                    pointList.Add(BC.BottGP.IntPoint);
                    pointList.Add(Com.MinP(TempList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                // Dim No 9
                if (DN.DimIDNo9)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P3);
                    pointList.Add(BC.BottGP.RefPBrace);
                    pointList.Add(BC.BottGP.IntPoint);
                    pointList.Add(BC.BottGP.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                // Dim No 10
                if (DN.DimIDNo10)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P3);
                    pointList.Add(BC.BottGP.RefPBrace);
                    pointList.Add(BC.BottGP.IntPointB);
                    pointList.Add(BC.BottGP.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                // Dim No 12
                if (DN.DimIDNo12)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P3);
                    pointList.Add(BC.BottGP.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }


                // Dim No 15
                if (DN.DimIDNo15 && (BC.TopGP == null || (!dc.IsEqualPoints(BC.BottGP.RefPBrace, BC.TopGP.RefPBrace))))
                {
                    if (Ids.Count > 0)
                        BC.PC.DistBot += BC.PC.DistInc;

                    pointList = new PointList();
                    pointList.Add(new Point(BC.PC.LeftX, BC.Points.CentP.Y));
                    pointList.Add(BC.BottGP.RefPBrace);
                    pointList.Add(new Point(BC.PC.RightX, BC.Points.CentP.Y));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }



                #endregion

                // Com.DrawLineDotted(CView, BC.BottGP.IntPoint, BC.BottGP.RefPBrace);

                //Dim Code 5 // Angle Dimension
                if (DN.DimIDNo5)
                    Com.InsertAngleDim(CView, BC.BottGP.RefPBrace, BC.BottGP.IntPoint, "Bottom", 160);

            }
        }

        private void ApplyTopRightG()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            TSD.PointList TempList = new PointList();

            if (BC.TopGP?.GussetPlate != null)
            {

                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;

                TSG.Line YLine = new TSG.Line(BC.TopGP.Points.P1, BC.TopGP.Points.P5);
                TSG.Line XLine = new TSG.Line(BC.TopGP.IntPoint, BC.TopGP.RefPBrace);
                Vector LeftVect = BC.TopGP.BoltM.GetCoordinateSystem().AxisY;

                if (LeftVect.X > 0)
                    LeftVect = dc.ChangeVector(LeftVect);

                Vector RightVect = BC.TopGP.BoltM.GetCoordinateSystem().AxisY;
                if (RightVect.X < 0)
                    RightVect = dc.ChangeVector(RightVect);

                Vector TopVect = BC.TopGP.BoltM.GetCoordinateSystem().AxisX;
                if (TopVect.Y < 0)
                    TopVect = dc.ChangeVector(TopVect);

                Vector BottVect = BC.TopGP.BoltM.GetCoordinateSystem().AxisX;
                if (BottVect.Y > 0)
                    BottVect = dc.ChangeVector(BottVect);



                if (BC.TopGP.Degree > 40)
                {
                    double Deg = BC.TopGP.Degree - 40;
                    BC.PC.DistTop = Deg * ((BC.PC.DistInc) / 15);

                    BC.PC.DistTop += (BC.PC.DistInc * 3);
                }
                else
                    BC.PC.DistTop = (BC.PC.DistInc * 3);

                #region Diagonal Top
                //BC.PC.DistTop += (BC.PC.DistInc * 2);
                TempList = dc.ChangePints(BC.TopGP.BoltM, CView, TopVect);
                // Dim No 3
                if (DN.DimIDNo3)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    pointList.Add(BC.TopGP.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, TopVect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }

                // Dim No 4
                if (DN.DimIDNo4)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, TopVect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistTop);

                    BC.PC.DistTop += BC.PC.DistInc;
                }

                #endregion

                #region Diagonal Left

                TempList = dc.ChangePints(BC.TopGP.BoltM, CView, RightVect);
                // Dim No 13,16
                if (DN.DimIDNo13 || DN.DimIDNo16)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo16)// Dim No16
                        pointList.Add(Com.MinP(TempList, "Y"));

                    pointList.Add(BC.TopGP.IntPointB);
                    if (DN.DimIDNo13)// Dim No 13
                        pointList.Add(BC.TopGP.RefPBrace);

                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistRight);
                    }
                }


                // Dim No 7.2
                if (DN.DimIDNo7Dot2)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);
                        Com.GroupDim(xDim);
                    }
                }

                TempList = dc.ChangePints(BC.TopGP.BoltM, CView, LeftVect);

                // Dim No 7.1
                if (DN.DimIDNo7Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    pointList.Add(BC.TopGP.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);

                    BC.PC.DistLeft += (BC.PC.DistInc / 2);
                }

                // Dim No 7
                if (DN.DimIDNo7)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);
                }

                // Dim No 17
                if (DN.DimIDNo17)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "Y"));
                    pointList.Add(BC.TopGP.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);
                }

                if (DN.DimIDNo7Dot1 || DN.DimIDNo7 || DN.DimIDNo17)
                    BC.PC.DistLeft += BC.PC.DistInc;

                #endregion

                #region Straight Right
                Vect = new Vector(1, 0, 0);
                BC.PC.DistRight = (BC.PC.DistInc);

                TempList = Com.GetBoltPoints(BC.TopGP.BoltM);

                // Dim No 22
                if (DN.DimIDNo22)
                {

                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "Y"));
                    pointList.Add(BC.TopGP.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.TopGP.Points.P2.X, BC.PC.DistRight);

                }

                // Dim No 2.5
                if (DN.DimIDNo2Dot5)
                {

                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "X"));
                    pointList.Add(BC.TopGP.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.TopGP.Points.P2.X, BC.PC.DistRight);

                }

                if (DN.DimIDNo22 || DN.DimIDNo2Dot5)
                    BC.PC.DistRight += BC.PC.DistInc;

                // Dim No 2.4, 2.3
                if (DN.DimIDNo2Dot4 || DN.DimIDNo2Dot3)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "X"));
                    if (DN.DimIDNo2Dot4)
                        pointList.Add(Com.MaxP(TempList, "Y"));
                    if (DN.DimIDNo2Dot3)
                        pointList.Add(BC.TopGP.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, BC.TopGP.Points.P2.X, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }

                }

                // Dim No 2.1
                if (DN.DimIDNo2Dot1)
                {

                    pointList = new PointList();
                    pointList.Add(BC.TopGP.IntPoint);
                    pointList.Add(BC.TopGP.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.TopGP.Points.P2.X, BC.PC.DistRight);

                    BC.PC.DistRight += BC.PC.DistInc;
                }
                #endregion

                #region RD Dim

                BC.PC.DistTop = (BC.PC.DistInc * 2);
                //RD Dim
                Vect = new Vector(0, 1, 0);

                // Dim No 1.5
                if (DN.DimIDNo1Dot5 || DN.DimIDNo1Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(BC.RDPoint);
                    pointList.Add(BC.TopGP.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }

                // Dim No 1.6 , 1.2
                if (DN.DimIDNo1Dot6 || DN.DimIDNo1Dot2)
                {
                    TempList = Com.GetBoltPoints(BC.TopGP.BoltM);
                    pointList = new PointList();
                    pointList.Add(BC.RDPoint);
                    pointList.Add(Com.MaxP(TempList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }

                // Dim No 1.4
                if (DN.DimIDNo1Dot4)
                {
                    TempList = Com.GetBoltPoints(BC.TopGP.BoltM);
                    pointList = new PointList();
                    pointList.Add(BC.RDPoint);
                    pointList.Add(Com.MinP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }

                // Dim No 1
                if (DN.DimIDNo1)
                {
                    pointList = new PointList();
                    pointList.Add(BC.RDPoint);
                    pointList.Add(BC.TopGP.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }



                // Dim No 1.3
                if (DN.DimIDNo1Dot3)
                {
                    pointList = new PointList();
                    pointList.Add(BC.RDPoint);
                    pointList.Add(BC.TopGP.IntPointB);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }


                #endregion

                #region Top Straight Dim

                Vect = new Vector(0, 1, 0);
                // Dim No 11
                if (DN.DimIDNo11)
                {
                    TempList = Com.GetBoltPoints(BC.TopGP.BoltM);
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.RefPBrace);
                    pointList.Add(BC.TopGP.IntPointB);
                    pointList.Add(BC.TopGP.IntPoint);
                    pointList.Add(Com.MaxP(TempList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                // Dim No 10
                if (DN.DimIDNo10)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P3);
                    pointList.Add(BC.TopGP.RefPBrace);
                    pointList.Add(BC.TopGP.IntPointB);
                    pointList.Add(BC.TopGP.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                // Dim No 9
                if (DN.DimIDNo9)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P3);
                    pointList.Add(BC.TopGP.RefPBrace);
                    pointList.Add(BC.TopGP.IntPoint);
                    pointList.Add(BC.TopGP.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                // Dim No 12
                if (DN.DimIDNo12)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P2);
                    pointList.Add(BC.TopGP.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                // Dim No 15
                if (DN.DimIDNo15)
                {
                    if(Ids.Count > 0)
                        BC.PC.DistTop += BC.PC.DistInc;

                    pointList = new PointList();
                    pointList.Add(new Point(BC.PC.LeftX, BC.Points.CentP.Y));
                    pointList.Add(BC.TopGP.RefPBrace);
                    pointList.Add(new Point(BC.PC.RightX, BC.Points.CentP.Y));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                #endregion

                // Com.DrawLineDotted(CView, BC.TopGP.IntPoint, BC.TopGP.RefPBrace);

                //Dim Code 5 // Angle Dimension
                if (DN.DimIDNo5)
                    Com.InsertAngleDim(CView, BC.TopGP.RefPBrace, BC.TopGP.IntPoint, "Top", 160);

            }
        }

        private void ApplyBottRightG()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            TSD.PointList TempList = new PointList();

            if (BC.BottGP?.GussetPlate != null)
            {

                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;

                TSG.Line YLine = new TSG.Line(BC.BottGP.Points.P1, BC.BottGP.Points.P5);
                TSG.Line XLine = new TSG.Line(BC.BottGP.IntPoint, BC.BottGP.RefPBrace);
                Vector LeftVect = BC.BottGP.BoltM.GetCoordinateSystem().AxisY;

                if (LeftVect.X > 0)
                    LeftVect = dc.ChangeVector(LeftVect);

                Vector RightVect = BC.BottGP.BoltM.GetCoordinateSystem().AxisY;
                if (RightVect.X < 0)
                    RightVect = dc.ChangeVector(RightVect);

                Vector TopVect = BC.BottGP.BoltM.GetCoordinateSystem().AxisX;
                if (TopVect.Y < 0)
                    TopVect = dc.ChangeVector(TopVect);

                Vector BottVect = BC.BottGP.BoltM.GetCoordinateSystem().AxisX;
                if (BottVect.Y > 0)
                    BottVect = dc.ChangeVector(BottVect);

                if (BC.BottGP.Degree > 40)
                {
                    double Deg = BC.BottGP.Degree - 40;
                    BC.PC.DistBot = Deg * ((BC.PC.DistInc) / 15);

                    BC.PC.DistBot += (BC.PC.DistInc * 3);
                }
                else
                    BC.PC.DistBot = (BC.PC.DistInc * 3);

                #region Diagonal Top
                //BC.PC.DistBot += (BC.PC.DistInc * 2);
                TempList = dc.ChangePints(BC.BottGP.BoltM, CView, BottVect);
                // Dim No 3
                if (DN.DimIDNo3)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    pointList.Add(BC.BottGP.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, BottVect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }

                // Dim No 4
                if (DN.DimIDNo4)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, BottVect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }

                #endregion

                #region Diagonal Left

                TempList = dc.ChangePints(BC.BottGP.BoltM, CView, RightVect);
                // Dim No 13,16
                if (DN.DimIDNo13 || DN.DimIDNo16)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo16)// Dim No16
                        pointList.Add(Com.MaxP(TempList, "Y"));

                    pointList.Add(BC.BottGP.IntPointB);
                    if (DN.DimIDNo13)// Dim No 13
                        pointList.Add(BC.BottGP.RefPBrace);

                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistRight);
                    }
                }

                // Dim No 7.2
                if (DN.DimIDNo7Dot2)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);
                        Com.GroupDim(xDim);
                    }
                }


                TempList = dc.ChangePints(BC.BottGP.BoltM, CView, LeftVect);

                // Dim No 7.1
                if (DN.DimIDNo7Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "Y"));
                    pointList.Add(BC.BottGP.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);

                    BC.PC.DistLeft += (BC.PC.DistInc / 2);
                }

                // Dim No 7
                if (DN.DimIDNo7)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);
                }

                // Dim No 17
                if (DN.DimIDNo17)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    pointList.Add(BC.BottGP.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);
                }

                if (DN.DimIDNo7Dot1 || DN.DimIDNo7 || DN.DimIDNo17)
                    BC.PC.DistLeft += BC.PC.DistInc;

                #endregion

                #region Straight Right
                Vect = new Vector(1, 0, 0);
                BC.PC.DistRight = (BC.PC.DistInc);

                TempList = Com.GetBoltPoints(BC.BottGP.BoltM);

                // Dim No 22
                if (DN.DimIDNo22)
                {

                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    pointList.Add(BC.BottGP.Points.P2);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.BottGP.Points.P2.X, BC.PC.DistRight);

                }

                // Dim No 2.5
                if (DN.DimIDNo2Dot5)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "X"));
                    pointList.Add(BC.BottGP.IntPoint);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.BottGP.Points.P2.X, BC.PC.DistRight);

                }

                if (DN.DimIDNo22 || DN.DimIDNo2Dot5)
                    BC.PC.DistRight += BC.PC.DistInc;


                // Dim No 8.2
                if (DN.DimIDNo8Dot2)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.IntPoint);
                    pointList.Add(BC.BottGP.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, BC.BottGP.Points.P2.X, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }


                }

                // Dim No 8.1
                if (DN.DimIDNo8Dot1 || DN.DimIDNo8)
                {

                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "X"));
                    if (DN.DimIDNo8Dot1)
                        pointList.Add(Com.MinP(TempList, "Y"));
                    if (DN.DimIDNo8)
                        pointList.Add(BC.BottGP.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, BC.BottGP.Points.P2.X, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }

                }


                // Dim No 2.2
                if (DN.DimIDNo2Dot2)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    pointList.Add(new Point(BC.BottGP.Points.P2.X, BC.Points.P1.Y));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, BC.BottGP.Points.P2.X, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }
                }


                // Dim No 2
                if (DN.DimIDNo2)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "X"));
                    pointList.Add(new Point(BC.BottGP.Points.P2.X, BC.Points.P1.Y));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, BC.BottGP.Points.P2.X, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }
                }

                // Dim No 19
                if (DN.DimIDNo19)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.IntPoint);
                    pointList.Add(new Point(BC.BottGP.Points.P2.X, BC.Points.P1.Y));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, BC.BottGP.Points.P2.X, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }
                }

                // Dim No 2
                if (DN.DimIDNo18 && BC.TopGP?.GussetPlate != null)
                {

                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P5);
                    pointList.Add(BC.TopGP.Points.P5);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, BC.BottGP.Points.P2.X, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }
                }

                #endregion

                #region RD Dim

                BC.PC.DistBot = (BC.PC.DistInc * 2);
                //RD Dim
                Vect = new Vector(0, -1, 0);

                // Dim No 1.5, 1.1
                if (DN.DimIDNo1Dot5 || DN.DimIDNo1Dot1)
                {
                    if (BC.TopGP == null || !Com.IsEqualPoints(BC.BottGP.RefPBrace, BC.TopGP.RefPBrace))
                    {
                        pointList = new PointList();
                        pointList.Add(BC.RDPoint);
                        pointList.Add(BC.BottGP.RefPBrace);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                            BC.PC.DistBot += BC.PC.DistInc;
                        }
                    }
                }

                // Dim No 1.2 , 1.6
                if (DN.DimIDNo1Dot2 || DN.DimIDNo1Dot6)
                {
                    TempList = Com.GetBoltPoints(BC.BottGP.BoltM);
                    pointList = new PointList();
                    pointList.Add(BC.RDPoint);
                    pointList.Add(Com.MaxP(TempList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                // Dim No 1.4
                if (DN.DimIDNo1Dot4)
                {
                    TempList = Com.GetBoltPoints(BC.BottGP.BoltM);
                    pointList = new PointList();
                    pointList.Add(BC.RDPoint);
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                // Dim No 1
                if (DN.DimIDNo1)
                {
                    pointList = new PointList();
                    pointList.Add(BC.RDPoint);
                    pointList.Add(BC.BottGP.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }



                // Dim No 1.3
                if (DN.DimIDNo1Dot3)
                {
                    pointList = new PointList();
                    pointList.Add(BC.RDPoint);
                    pointList.Add(BC.BottGP.IntPointB);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }


                #endregion

                #region Bottom Straight Dim

                Vect = new Vector(0, -1, 0);
                // Dim No 11
                if (DN.DimIDNo11)
                {
                    TempList = Com.GetBoltPoints(BC.BottGP.BoltM);
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.RefPBrace);
                    pointList.Add(BC.BottGP.IntPointB);
                    pointList.Add(BC.BottGP.IntPoint);
                    pointList.Add(Com.MaxP(TempList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                // Dim No 9
                if (DN.DimIDNo9)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P3);
                    pointList.Add(BC.BottGP.RefPBrace);
                    pointList.Add(BC.BottGP.IntPoint);
                    pointList.Add(BC.BottGP.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                // Dim No 10
                if (DN.DimIDNo10)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P3);
                    pointList.Add(BC.BottGP.RefPBrace);
                    pointList.Add(BC.BottGP.IntPointB);
                    pointList.Add(BC.BottGP.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                // Dim No 12
                if (DN.DimIDNo12)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P3);
                    pointList.Add(BC.BottGP.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                // Dim No 15
                if (DN.DimIDNo15 && (BC.TopGP == null || (!dc.IsEqualPoints(BC.BottGP.RefPBrace, BC.TopGP.RefPBrace))))
                {
                    if (Ids.Count > 0)
                        BC.PC.DistBot += BC.PC.DistInc;

                    pointList = new PointList();
                    pointList.Add(new Point(BC.PC.LeftX, BC.Points.CentP.Y));
                    pointList.Add(BC.BottGP.RefPBrace);
                    pointList.Add(new Point(BC.PC.RightX, BC.Points.CentP.Y));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }


                #endregion

                // Com.DrawLineDotted(CView, BC.BottGP.IntPoint, BC.BottGP.RefPBrace);

                //Dim Code 5 // Angle Dimension
                if (DN.DimIDNo5)
                    Com.InsertAngleDim(CView, BC.BottGP.RefPBrace, BC.BottGP.IntPoint, "Bottom", 160);

            }
        }

        private void TestDim()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;

            Vector Vect = new Vector(0, 1, 0);

            TSD.PointList TempList = new PointList();

            if (BC.TopGP?.GussetPlate != null && BC.BottGP?.GussetPlate != null)
            {
                Point P1 = BC.TopGP.RefPBrace;
                Point P2 = BC.TopGP.IntPointB;
                Point P3 = BC.Points.P2;
                double result = Math.Atan2(P3.Y - P1.Y, P3.X - P1.X) -
                Math.Atan2(P2.Y - P1.Y, P2.X - P1.X);


                Point WP = BC.TopGP.RefPBrace;
                Point Temp = new Point(WP.X, WP.Y - 100, WP.Z);
                AngleDimension angDimA = new AngleDimension(CView, P1, P2, P3, 50);
                double degree = angDimA.GetAngle();

                angDimA.Insert();
                //BC.PC.DistLeft = (BC.PC.DistInc * 6);
                //Vect = new Vector(-1, 0, 0);

                //pointList = new PointList();
                //pointList.Add(BC.TopGP.Points.P1);
                //pointList.Add(BC.BottGP.Points.P1);
                //xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                //if (xDim != null)
                //    PL.DistPlaceLeftP(xDim, BC.BottGP.Points.P2.X, BC.PC.DistLeft);
            }


        }

        #region Get Data


        private BeamClass_BG3 GetBeamClassClass(TSD.View CView)
        {
            BC = new BeamClass_BG3();
            BC.beam = MainBeam;
            List<TSM.Part> PartListC = BC.beam.GetAssembly().GetSecondaries().OfType<TSM.Part>().ToList();
            PartListC.Add(MainBeam);
            BC.Points = Com.GetPartPoints(BC.beam);

            List<TSM.BoltGroup> BoltDList = Com.EnumtoArray(BC.beam.GetBolts()).OfType<TSM.BoltGroup>().ToList();
            Point CentP = Com.CenterPoint(BC.beam.StartPoint, BC.beam.EndPoint);
            double Lenght = (BC.beam.GetSolid().MaximumPoint.X - BC.beam.GetSolid().MinimumPoint.X) / 6;
            double MinX = BC.beam.GetSolid().MinimumPoint.X + Lenght;
            double MaxX = BC.beam.GetSolid().MaximumPoint.X - Lenght;

            List<TSM.Part> PartListF = (from p in PartListC where !Ids.Contains(p.Identifier.ID) select p).ToList();
            ContourPlate TopGP = (from p in PartListF.OfType<ContourPlate>() where IsBG3(p) && (Com.CenterPoint(p).Y > BC.Points.CentP.Y) && !dc.IsPlateSideView(p) orderby Com.CenterPoint(p).X ascending select p).FirstOrDefault();

            ContourPlate BottGP = null;
            if (TopGP != null)
            {
                BC.TopGP = GetGussetClass(TopGP, "Top");

                BottGP = (from p in PartListF.OfType<ContourPlate>() where IsBG3(p) && (BC.TopGP.Points.CentP.X > p.GetSolid().MinimumPoint.X && BC.TopGP.Points.CentP.X < p.GetSolid().MaximumPoint.X) && (Com.CenterPoint(p).Y < BC.Points.CentP.Y) && !dc.IsPlateSideView(p) orderby Com.CenterPoint(p).X ascending select p).FirstOrDefault();
            }
            else
            {
                BottGP = (from p in PartListF.OfType<ContourPlate>() where IsBG3(p) && (Com.CenterPoint(p).Y < BC.Points.CentP.Y) && !dc.IsPlateSideView(p) select p).FirstOrDefault();
            }


            if (BottGP != null)
                BC.BottGP = GetGussetClass(BottGP, "Bottom");

            List<Point> RefPoints = MainBeam.GetReferenceLine(false).OfType<Point>().ToList();

            double MinXP = (from p in RefPoints orderby p.X ascending select p.X).FirstOrDefault();
            double MaxXP = (from p in RefPoints orderby p.X descending select p.X).FirstOrDefault();

            MinXP -= 100;
            MaxXP += 100;

            BC.RDPoint = new Point(BC.Points.P1.X, BC.Points.CentP.Y);

            TSM.Part LeftPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.X ascending select p).FirstOrDefault();
            TSM.Part RightPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.X descending select p).FirstOrDefault();
            TSM.Part TopPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.Y descending select p).FirstOrDefault();
            TSM.Part BottPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.Y ascending select p).FirstOrDefault();

            BC.PC = new PlacingClass();
            BC.PC.TopY = TopPart.GetSolid().MaximumPoint.Y;
            BC.PC.BottomY = BottPart.GetSolid().MinimumPoint.Y;

            BC.PC.LeftX = LeftPart.GetSolid().MinimumPoint.X;// Math.Round(CView.RestrictionBox.MinPoint.X);
            BC.PC.RightX = RightPart.GetSolid().MaximumPoint.X;

            if (BC.PC.LeftX > MinXP)
                BC.PC.LeftX = (MinXP + 100);

            if (BC.PC.RightX < MaxXP)
                BC.PC.RightX = (MaxXP - 100);

            double AvScale = 12;
            double AvDistInc = 100;
            double DistPerScale = AvDistInc / AvScale;
            double CScale = CView.Attributes.Scale;
            BC.PC.DistInc = CScale * DistPerScale;
            BC.PC.DistBot = BC.PC.DistInc;
            BC.PC.DistTop = BC.PC.DistInc;
            BC.PC.DistLeft = BC.PC.DistInc;
            BC.PC.DistRight = BC.PC.DistInc;


            return BC;

        }

        private GussetClass GetGussetClass(ContourPlate GP, string Position)
        {
            GussetClass GC = new GussetClass();
            GC.GussetPlate = GP;


            BoltGroup MidBolt = Com.EnumtoArray(GP.GetBolts()).OfType<BoltGroup>().FirstOrDefault();

            if (MidBolt != null)
            {
                GC.BoltM = MidBolt;
                Beam brace = GetBrace(GC.BoltM, GP);
                if (brace != null)
                {
                    GC.Brace = brace;

                    GC.IntPoint = GetIntSectPoint(GC.BoltM, brace, Position);
                    if (Position == "Top")
                    {
                        // GC.RefPBrace = dc.NearestPoint(GC.Brace.StartPoint, GC.Brace.EndPoint, MidBolt.FirstPosition);

                        GC.RefPBrace = GetBraceRefPoint(brace);

                        if (GC.Brace.StartPoint.Y > GC.Brace.EndPoint.Y)
                            GC.RefPBrace = GC.Brace.EndPoint;

                        if (GC.RefPBrace != null && GC.IntPoint != null)
                            GC.IntPointB = Com.GetIntersectionPoint(GC.RefPBrace, GC.IntPoint, BC.Points.P1, BC.Points.P4);

                        GC.BracePos = GetBracePos(GC);

                        if (GC.BracePos == "Left")
                            GC.Degree = GetDegree(GC.IntPointB, GC.IntPoint, BC.Points.P1);
                        else
                            GC.Degree = GetDegree(GC.IntPointB, GC.IntPoint, BC.Points.P4);


                    }
                    else
                    {
                        GC.RefPBrace = GetBraceRefPoint(brace);

                        if (GC.Brace.StartPoint.Y < GC.Brace.EndPoint.Y)
                            GC.RefPBrace = GC.Brace.EndPoint;

                        if (GC.RefPBrace != null && GC.IntPoint != null)
                            GC.IntPointB = Com.GetIntersectionPoint(GC.RefPBrace, GC.IntPoint, BC.Points.P2, BC.Points.P3);


                        GC.BracePos = GetBracePos(GC);

                        if (GC.BracePos == "Left")
                            GC.Degree = GetDegree(GC.IntPointB, GC.IntPoint, BC.Points.P2);
                        else
                            GC.Degree = GetDegree(GC.IntPointB, GC.IntPoint, BC.Points.P3);


                    }
                }
            }

            GC.Points = GetGussetPoints(GP, GC.BracePos);

            return GC;
        }


        private string GetBracePos(GussetClass GC)
        {
            Point CentP = Com.CenterPoint(GC.Brace.StartPoint, GC.Brace.EndPoint);
            if (GC.IntPoint.X > GC.RefPBrace.X)
                return "Right";
            else
                return "Left";
        }

        private Beam GetBrace(BoltGroup BoltL, TSM.Part GP)
        {

            Beam brace = (from b in Com.GetBoltParts(BoltL).OfType<TSM.Beam>() where b.Identifier.ID != GP.Identifier.ID && (b.Name.ToLower().Contains("brace") || (dc.IsMainPart(b) && !dc.IsPlate(b))) select b).FirstOrDefault();
            if (brace == null)
            {
                List<TSM.Part> PartList = (from b in Com.GetBoltParts(BoltL).OfType<TSM.Part>() where b.Identifier.ID != GP.Identifier.ID select b).ToList();

                foreach (TSM.Part part in PartList)
                {

                    BoltGroup bolt2 = Com.EnumtoArray(part.GetBolts()).OfType<BoltGroup>().Where(x => x.Identifier.ID != BoltL.Identifier.ID).FirstOrDefault();
                    if (bolt2 != null)
                    {
                        brace = (from b in Com.GetBoltParts(bolt2).OfType<TSM.Beam>() where b.Identifier.ID != GP.Identifier.ID && (b.Name.ToLower().Contains("brace") || (dc.IsMainPart(b) && !dc.IsPlate(b))) select b).FirstOrDefault();
                    }

                }

                if (brace == null)
                {
                    foreach (TSM.Part part in PartList)
                    {
                        if (dc.IsMainPart(part) && dc.IsPlate(part))
                        {

                            List<TSM.Part> PartLists = Com.EnumtoArray(part.GetWelds()).OfType<TSM.Weld>().Select(x => x.MainObject).OfType<TSM.Part>().ToList();
                            PartLists.AddRange(Com.EnumtoArray(part.GetWelds()).OfType<TSM.Weld>().Select(x => x.SecondaryObject).OfType<TSM.Part>().ToList());

                            brace = (from b in PartLists.OfType<Beam>() where IsBrace(b) select b).FirstOrDefault();
                            if (brace == null)
                            {
                                PartLists = (from b in PartLists where !dc.IsMainPart(b) select b.GetAssembly().GetMainPart()).OfType<TSM.Part>().ToList();
                                brace = (from b in PartLists.OfType<Beam>() where IsBrace(b) select b).FirstOrDefault();
                                if (brace != null)
                                    break;
                            }


                        }

                    }
                }

                if (brace == null)
                {
                    foreach (TSM.Part part in PartList)
                    {
                        if (dc.IsMainPart(part) && dc.IsPlate(part))
                        {

                            List<BoltGroup> BoltsList = Com.EnumtoArray(part.GetBolts()).OfType<TSM.BoltGroup>().ToList();
                            if (BoltsList != null && BoltsList.Count > 0)
                            {
                                List<TSM.Part> PartLists = new List<TSM.Part>();

                                BoltsList.ForEach(x => PartLists.AddRange(Com.GetBoltParts(x)));

                                brace = (from b in PartLists.OfType<Beam>() where IsBrace(b) select b).FirstOrDefault();
                                if (brace == null)
                                {
                                    PartLists = (from b in PartLists where !dc.IsMainPart(b) select b.GetAssembly().GetMainPart()).OfType<TSM.Part>().ToList();
                                    brace = (from b in PartLists.OfType<Beam>() where IsBrace(b) select b).FirstOrDefault();
                                    if (brace != null)
                                        break;
                                }
                            }


                        }

                    }
                }
            }

            return brace;

        }

        private PartPoints GetGussetPoints(ContourPlate GP, string Position)
        {


            PartPoints RetP = new PartPoints();
            PointList pointList = Com.ContPList(GP);
            RetP.CentP = Com.CenterPoint(GP);

            double MinY = GP.GetSolid().MinimumPoint.Y + 25;
            double MaxY = GP.GetSolid().MaximumPoint.Y - 25;
            if (Position == "Left")
            {
                if (RetP.CentP.Y > BC.Points.CentP.Y)
                {

                    RetP.P2 = (from p in pointList.OfType<Point>() where p.Y < MinY orderby p.X ascending select p).FirstOrDefault();
                    RetP.P3 = (from p in pointList.OfType<Point>() where p.Y < MinY orderby p.X descending select p).FirstOrDefault();

                    RetP.P1 = (from p in pointList.OfType<Point>() where p.Y > MinY orderby p.X ascending select p).FirstOrDefault();
                    RetP.P4 = (from p in pointList.OfType<Point>() where p.Y > MinY orderby p.X descending select p).FirstOrDefault();

                    RetP.P5 = (from p in pointList.OfType<Point>() where p.Y > RetP.P4.Y orderby p.X descending select p).FirstOrDefault();

                }
                else
                {
                    RetP.P2 = (from p in pointList.OfType<Point>() where p.Y > MaxY orderby p.X ascending select p).FirstOrDefault();
                    RetP.P3 = (from p in pointList.OfType<Point>() where p.Y > MaxY orderby p.X descending select p).FirstOrDefault();
                    RetP.P1 = (from p in pointList.OfType<Point>() where p.Y < MaxY orderby p.X ascending select p).FirstOrDefault();
                    RetP.P4 = (from p in pointList.OfType<Point>() where p.Y < MaxY orderby p.X descending select p).FirstOrDefault();


                    RetP.P5 = (from p in pointList.OfType<Point>() where p.Y < RetP.P4.Y orderby p.X descending select p).FirstOrDefault();
                }
            }

            else
            {
                if (RetP.CentP.Y > BC.Points.CentP.Y)
                {
                    RetP.P2 = (from p in pointList.OfType<Point>() where p.Y < MinY orderby p.X descending select p).FirstOrDefault();
                    RetP.P3 = (from p in pointList.OfType<Point>() where p.Y < MinY orderby p.X ascending select p).FirstOrDefault();
                    RetP.P1 = (from p in pointList.OfType<Point>() where p.Y > MinY orderby p.X descending select p).FirstOrDefault();
                    RetP.P4 = (from p in pointList.OfType<Point>() where p.Y > MinY orderby p.X ascending select p).FirstOrDefault();

                    RetP.P5 = (from p in pointList.OfType<Point>() where p.Y > RetP.P4.Y orderby p.X ascending select p).FirstOrDefault();

                }
                else
                {

                    RetP.P2 = (from p in pointList.OfType<Point>() where p.Y > MaxY orderby p.X descending select p).FirstOrDefault();
                    RetP.P3 = (from p in pointList.OfType<Point>() where p.Y > MaxY orderby p.X ascending select p).FirstOrDefault();
                    RetP.P1 = (from p in pointList.OfType<Point>() where p.Y < MaxY orderby p.X descending select p).FirstOrDefault();
                    RetP.P4 = (from p in pointList.OfType<Point>() where p.Y < MaxY orderby p.X ascending select p).FirstOrDefault();


                    RetP.P5 = (from p in pointList.OfType<Point>() where p.Y < RetP.P4.Y orderby p.X ascending select p).FirstOrDefault();

                }
            }
            return RetP;
        }

        #endregion

        #region Helping Methods

        private double GetDegree(Point P1, Point P2, Point P3)
        {
            double degree = 0;
            try
            {

                AngleDimension angDimA = new AngleDimension(CView, P1, P2, P3, 50);
                degree = angDimA.GetAngle();
            }
            catch (Exception ex)
            { }
            return degree;
        }

        private bool IsBrace(Beam b)
        {
            bool RetCheck = false;
            if (b.Name.ToLower().Contains("brace") || (dc.IsMainPart(b) && !dc.IsPlate(b)))
            {
                if ((b.StartPoint.Y < BC.Points.P1.Y && b.StartPoint.Y > BC.Points.P2.Y) || (b.EndPoint.Y < BC.Points.P1.Y && b.EndPoint.Y > BC.Points.P2.Y))
                    RetCheck = true;
            }

            return RetCheck;
        }

        private Point GetBraceRefPoint(Beam Brace)
        {
            Point RefP = Brace.StartPoint;
            List<Point> CentPlist = MainBeam.GetCenterLine(false).OfType<Point>().ToList();
            Point StartP = Com.MinP(CentPlist, "X");
            Point EndP = Com.MaxP(CentPlist, "X");

            double DistS = Distance.PointToLine(Brace.StartPoint, new TSG.Line(StartP, EndP));
            double DistE = Distance.PointToLine(Brace.EndPoint, new TSG.Line(StartP, EndP));

            if (DistE < DistS)
                RefP = Brace.EndPoint;

            return RefP;
        }

        private Point GetIntSectPoint(BoltGroup bolt, Beam brace, string Position)
        {
            Vector Vect = bolt.GetCoordinateSystem().AxisX;
            PointList PtList = new PointList();
            Point IntSectP = null;
            if (Position == "Top")
            {
                if (Vect.Y > 0)
                    Vect = Com.ChangeVector(Vect);
            }
            else
            {
                if (Vect.Y < 0)
                    Vect = Com.ChangeVector(Vect);
            }

            PtList = dc.ChangePints(bolt, CView, Vect);
            if (PtList.Count > 1)
                IntSectP = Com.GetIntersectionPoint(PtList[0], PtList[1], brace.StartPoint, brace.EndPoint);
            else if (PtList.Count == 1)
                IntSectP = PtList[0];

            return IntSectP;

        }

        private bool IsBG3(TSM.Part part)
        {
            if (Com.GetNote5(part).ToUpper().Contains("BG3"))
                return true;
            else
                return false;
        }
        #endregion

    }

    public class BeamClass_BG3
    {
        public Beam beam { get; set; }
        public GussetClass TopGP { get; set; }
        public GussetClass BottGP { get; set; }
        public PartPoints Points { get; set; }
        public PlacingClass PC { get; set; }

        public Point RDPoint { get; set; }
    }


}
