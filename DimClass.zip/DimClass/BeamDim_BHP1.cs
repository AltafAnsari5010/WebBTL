﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Tekla.Structures;
using Tekla.Structures.Drawing;
using Tekla.Structures.Geometry3d;
using Tekla.Structures.Model;
using TSD = Tekla.Structures.Drawing;
using TSM = Tekla.Structures.Model;
using VirtueleDrawingAutomation;
using TSDD = Tekla.Structures.Datatype;
using TSG = Tekla.Structures.Geometry3d;

namespace Auto_Detailing_Tool_Beam
{
    public class BeamDim_BHP1
    {
        #region Global Variables
        DimCom dc = new DimCom();
        StraightDimensionSet.StraightDimensionSetAttributes StAtrr = new StraightDimensionSet.StraightDimensionSetAttributes("standard");
        StraightDimensionSet.StraightDimensionSetAttributes RdAtrr = new StraightDimensionSet.StraightDimensionSetAttributes("standard");

        public Beam MainBeam = null;
        VirtueleDrawingAutomation.Json.DrawingAttributeInfoJson.AttributeFiles dimAttrClass = null;
        List<TSD.StraightDimension> KnockDim = new List<StraightDimension>();
        BeamClass_BHP1 BC = null;

        VirtueleDrawingAutomation.Json.AutoDimensionTypesJson.BHP1Json DN = null;
        string Position = "Left";
        TSD.View CView = null;
        string ViewName = "";
        public Point BoltPS = null;

        #endregion

        public void ApplyDim(TSD.View CView, string ViewName, AutoDimensioningTypes autoDimensioningTypes, DrawingAttributeInfo drawingAttributeInfo, string Position)
        {
            try
            {
                Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane());
                //Set model everything to the view
                Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane(CView.DisplayCoordinateSystem));

                this.CView = CView;
                this.dimAttrClass = drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files;
                this.DN = autoDimensioningTypes.Bhp1;
                this.Position = Position;
                StAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.StandardDimension);
                RdAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.RunningDimension);
                this.MainBeam = (Com.MyModel.SelectModelObject(new Identifier((CView.GetDrawing() as AssemblyDrawing).AssemblyIdentifier.ID)) as TSM.Assembly).GetMainPart() as TSM.Beam;
                this.MainBeam.Select();
                string ProType = Com.GetProType(MainBeam);
                this.ViewName = ViewName;
                GetBeamClassClass(CView);

                if (Position == "Left")
                {
                    if (ViewName == "Front View")
                        ApplyDimTypeLeft(CView);
                    else if (ViewName == "Section View")
                        AppySectionDim();
                }

                else if (Position == "Right")
                {
                    if (ViewName == "Front View")
                        ApplyDimTypeRight(CView);
                    else if (ViewName == "Section View")
                        AppySectionDim();
                }
            }
            catch (Exception ex)
            { }

            Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane());
        }


        private void ApplyDimTypeLeft(TSD.View CView)
        {

            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(-1, 0, 0);
            TSD.PointList TempList = new PointList();
            if (BC.CutTop != null)
            {
                Vect = new Vector(-1, 0, 0);
                // Dim No 4
                if (DN.DimIDNo4)
                {
                    pointList = new PointList();
                    pointList.Add(BC.CutTop.P1);
                    pointList.Add(BC.CutTop.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                }

                Vect = new Vector(0, 1, 0);
                // Dim No 5
                if (DN.DimIDNo5)
                {
                    pointList = new PointList();
                    pointList.Add(BC.CutTop.P1);
                    pointList.Add(BC.CutTop.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                }

            }

            if (BC.CutBott != null)
            {
                Vect = new Vector(-1, 0, 0);
                // Dim No 4
                if (DN.DimIDNo4)
                {
                    pointList = new PointList();
                    pointList.Add(BC.CutBott.P1);
                    pointList.Add(BC.CutBott.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                }

                Vect = new Vector(0, -1, 0);
                // Dim No 5
                if (DN.DimIDNo5)
                {
                    pointList = new PointList();
                    pointList.Add(BC.CutBott.P1);
                    pointList.Add(BC.CutBott.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                }

            }

            if (DN.DimIDNo4 || BC.CutBott != null || BC.CutTop != null)
                BC.PC.DistLeft += BC.PC.DistInc;

            if (DN.DimIDNo5 || BC.CutBott != null)
                BC.PC.DistBot += BC.PC.DistInc;

            if (DN.DimIDNo5 || BC.CutTop != null)
                BC.PC.DistTop += BC.PC.DistInc;

            Vect = new Vector(-1, 0, 0);
            if (BC.BoltsE != null)
            {
                if (DN.DimIDNo15 || DN.DimIDNo14)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo15)
                        pointList.Add(Com.MinPofX(BC.BoltsE, "Y", Com.MaxP(BC.BoltsE, "X").X));

                    pointList.Add(BC.Points.P6);
                    if (DN.DimIDNo14 && BC.HP?.HPBotom != null)
                        pointList.Add(Com.MaxPofX(BC.HP.HPBotom.BoltPList, "Y", Com.MaxP(BC.HP.HPBotom.BoltPList, "X").X));

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);

                }

                // Dim No 1
                if (DN.DimIDNo1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxPofX(BC.BoltsE, "Y", Com.MaxP(BC.BoltsE, "X").X));
                    pointList.Add(BC.Points.P5);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                }

                if (DN.DimIDNo15 || DN.DimIDNo14 || DN.DimIDNo1)
                    BC.PC.DistLeft += BC.PC.DistInc;


                TempList = dc.ChangePints(BC.BoltsE, CView, Vect);
                // Dim No 2
                if (DN.DimIDNo2)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByLeftX(xDim, BC.PC);
                }

                // Dim No 2.1
                if (DN.DimIDNo2Dot1)
                {
                    if (TempList.Count > 2)
                    {
                        pointList = new PointList();
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                        {
                            PL.DimPlaceByLeftX(xDim, BC.PC);
                            Com.GroupDim(xDim);
                        }
                    }
                }

                Vect = new Vector(0, 1, 0);
                TempList = dc.ChangePints(BC.BoltsE, CView, Vect);
                // Dim No 6
                if (DN.DimIDNo6)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);


                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(Com.MinP(TempList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);

                }
                else if (DN.DimIDNo6Dot1)  // Dim No 6.1
                {
                    BC.PC.DistTop += BC.PC.DistInc;
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);
                }

            }

            // Dim No 9 Elevation Dim
            if (DN.DimIDNo9)
            {


                Vect = new Vector(-1, 0, 0);
                StraightDimensionSet.StraightDimensionSetAttributes ElAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.ElevationDimension);
                ElAtrr.DimensionType = DimensionSetBaseAttributes.DimensionTypes.Elevation;
                ElAtrr.Arrowhead.Head = ArrowheadTypes.FilledArrow;
                pointList = new PointList();

                if (MainBeam.StartPoint.X > MainBeam.EndPoint.X)
                {
                    pointList.Add(MainBeam.EndPoint);
                    pointList.Add(MainBeam.EndPoint);

                }
                else
                {
                    pointList.Add(MainBeam.StartPoint);
                    pointList.Add(MainBeam.StartPoint);
                }

                BC.PC.DistLeft = BC.PC.DistLeft - (BC.Points.P1.X - pointList[0].X);
                xDim = dc.InsertDimm(CView, pointList, Vect, (-BC.PC.DistLeft), ElAtrr);
                if (xDim != null)
                {
                    xDim.Distance = (-BC.PC.DistLeft);
                    xDim.Modify();
                }
                BC.PC.DistLeft += BC.PC.DistInc;

            }
            Vect = new Vector(-1, 0, 0);

            PartClass HP = BC.HP?.HPBotom;

            if (HP != null)
            {
                BC.PC.DistLeft = BC.PC.DistInc;
                TempList = dc.ChangePints(HP.BoltPList, CView, Vect);
                // Dim No 3.1
                if (DN.DimIDNo3Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "Y"));
                    pointList.Add(HP.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByLeftX(xDim, BC.PC);
                }

                BC.PC.DistLeft = (BC.PC.DistInc * 3);

                // Dim No 13
                if (DN.DimIDNo13 && BC.BoltsE != null)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinPofX(BC.BoltsE, "Y", Com.MaxP(BC.BoltsE, "X").X));
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByLeftX(xDim, BC.PC);
                }

                // Dim No 3
                if (DN.DimIDNo3)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByLeftX(xDim, BC.PC);
                }

                // Dim No 3.2
                if (DN.DimIDNo3Dot2)
                {
                    if (TempList.Count > 2)
                    {
                        pointList = new PointList();
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                        {
                            PL.DimPlaceByLeftX(xDim, BC.PC);
                            Com.GroupDim(xDim);
                        }
                    }
                }

                Vect = new Vector(0, -1, 0);
                TempList = dc.ChangePints(HP.BoltPList, CView, Vect);
                // Dim No 7
                if (DN.DimIDNo7)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    pointList.Add(BC.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);


                    pointList = new PointList();
                    pointList.Add(BC.Points.P2);
                    pointList.Add(Com.MinP(TempList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);

                }
                else if (DN.DimIDNo7Dot1)  // Dim No 7.1
                {
                    BC.PC.DistBot += BC.PC.DistInc;
                    pointList = new PointList();
                    pointList.Add(BC.Points.P2);
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);

                    BC.PC.DistBot -= BC.PC.DistInc;
                }

                // Dim No 5.1
                if (DN.DimIDNo5Dot1 && BC.CutBott != null)
                {
                    BC.PC.DistBot -= BC.PC.DistInc;
                    pointList = new PointList();
                    pointList.Add(BC.Points.P6);
                    pointList.Add(HP.Points.P4);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);
                }

                // Dim No 16
                if (DN.DimIDNo16)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P2);
                    pointList.Add(HP.Points.P4);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);
                }

                Vect = new Vector(1, 0, 0);
                // Dim No 17
                if (DN.DimIDNo17)
                {
                    pointList = new PointList();
                    pointList.Add(HP.Points.P5);
                    pointList.Add(HP.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, HP.Points.P4.X, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;

                    }
                }

                // Dim No 18
                if (DN.DimIDNo18)
                {
                    pointList = new PointList();
                    pointList.Add(HP.Points.P5);
                    pointList.Add(new Point(HP.Points.P4.X, BC.Points.P5.Y));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, HP.Points.P4.X, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;

                    }
                }


            }

        }

        private void ApplyDimTypeRight(TSD.View CView)
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(1, 0, 0);
            TSD.PointList TempList = new PointList();
            if (BC.CutTop != null)
            {
                Vect = new Vector(1, 0, 0);
                // Dim No 4
                if (DN.DimIDNo4)
                {
                    pointList = new PointList();
                    pointList.Add(BC.CutTop.P1);
                    pointList.Add(BC.CutTop.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                }

                Vect = new Vector(0, 1, 0);
                // Dim No 5
                if (DN.DimIDNo5)
                {
                    pointList = new PointList();
                    pointList.Add(BC.CutTop.P1);
                    pointList.Add(BC.CutTop.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                }

            }

            if (BC.CutBott != null)
            {
                Vect = new Vector(1, 0, 0);
                // Dim No 4
                if (DN.DimIDNo4)
                {
                    pointList = new PointList();
                    pointList.Add(BC.CutBott.P1);
                    pointList.Add(BC.CutBott.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                }

                Vect = new Vector(0, -1, 0);
                // Dim No 5
                if (DN.DimIDNo5)
                {
                    pointList = new PointList();
                    pointList.Add(BC.CutBott.P1);
                    pointList.Add(BC.CutBott.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                }

            }

            if (DN.DimIDNo4 || BC.CutBott != null || BC.CutTop != null)
                BC.PC.DistRight += BC.PC.DistInc;

            if (DN.DimIDNo5 || BC.CutBott != null)
                BC.PC.DistBot += BC.PC.DistInc;

            if (DN.DimIDNo5 || BC.CutTop != null)
                BC.PC.DistTop += BC.PC.DistInc;

            Vect = new Vector(1, 0, 0);
            if (BC.BoltsE != null)
            {
                if (DN.DimIDNo15 || DN.DimIDNo14)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo15)
                        pointList.Add(Com.MinPofX(BC.BoltsE, "Y", Com.MinP(BC.BoltsE, "X").X));

                    pointList.Add(BC.Points.P7);
                    if (DN.DimIDNo14 && BC.HP?.HPBotom != null)
                        pointList.Add(Com.MaxPofX(BC.HP.HPBotom.BoltPList, "Y", Com.MinP(BC.HP.HPBotom.BoltPList, "X").X));

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);

                }

                // Dim No 1
                if (DN.DimIDNo1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxPofX(BC.BoltsE, "Y", Com.MinP(BC.BoltsE, "X").X));
                    pointList.Add(BC.Points.P8);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                }

                if (DN.DimIDNo15 || DN.DimIDNo14 || DN.DimIDNo1)
                    BC.PC.DistRight += BC.PC.DistInc;


                TempList = dc.ChangePints(BC.BoltsE, CView, Vect);
                // Dim No 2
                if (DN.DimIDNo2)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByRightX(xDim, BC.PC);
                }

                // Dim No 2.1
                if (DN.DimIDNo2Dot1)
                {
                    if (TempList.Count > 2)
                    {
                        pointList = new PointList();
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                        {
                            PL.DimPlaceByRightX(xDim, BC.PC);
                            Com.GroupDim(xDim);
                        }
                    }
                }

                Vect = new Vector(0, 1, 0);
                TempList = dc.ChangePints(BC.BoltsE, CView, Vect);
                // Dim No 6
                if (DN.DimIDNo6)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P4);
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);


                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(Com.MinP(TempList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);

                }
                else if (DN.DimIDNo6Dot1)  // Dim No 6.1
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "X"));
                    pointList.Add(BC.Points.P4);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);

                    BC.PC.DistTop += BC.PC.DistInc;
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);
                }

            }


            Vect = new Vector(1, 0, 0);

            PartClass HP = BC.HP?.HPBotom;

            if (HP != null)
            {
                BC.PC.DistRight = BC.PC.DistInc;
                TempList = dc.ChangePints(HP.BoltPList, CView, Vect);
                // Dim No 3.1
                if (DN.DimIDNo3Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "Y"));
                    pointList.Add(HP.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByRightX(xDim, BC.PC);
                }

                BC.PC.DistRight = (BC.PC.DistInc * 3);

                // Dim No 13
                if (DN.DimIDNo13 && BC.BoltsE != null)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinPofX(BC.BoltsE, "Y", Com.MinP(BC.BoltsE, "X").X));
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByRightX(xDim, BC.PC);
                }

                // Dim No 3
                if (DN.DimIDNo3)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByRightX(xDim, BC.PC);
                }

                // Dim No 3.2
                if (DN.DimIDNo3Dot2)
                {
                    if (TempList.Count > 2)
                    {
                        pointList = new PointList();
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                        {
                            PL.DimPlaceByRightX(xDim, BC.PC);
                            Com.GroupDim(xDim);
                        }
                    }
                }

                Vect = new Vector(0, -1, 0);
                TempList = dc.ChangePints(HP.BoltPList, CView, Vect);
                // Dim No 7
                if (DN.DimIDNo7)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    pointList.Add(BC.Points.P4);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);


                    pointList = new PointList();
                    pointList.Add(BC.Points.P2);
                    pointList.Add(Com.MinP(TempList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);

                }
                else if (DN.DimIDNo7Dot1)  // Dim No 7.1
                {
                    BC.PC.DistBot += BC.PC.DistInc;
                    pointList = new PointList();
                    pointList.Add(BC.Points.P2);
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);


                }

                // Dim No 5.1
                if (DN.DimIDNo5Dot1 && BC.CutBott != null)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P7);
                    pointList.Add(HP.Points.P4);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);
                }

                // Dim No 16
                if (DN.DimIDNo16)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P3);
                    pointList.Add(HP.Points.P4);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);
                }

                Vect = new Vector(-1, 0, 0);
                // Dim No 17
                if (DN.DimIDNo17)
                {
                    pointList = new PointList();
                    pointList.Add(HP.Points.P5);
                    pointList.Add(HP.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, HP.Points.P4.X, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;

                    }
                }

                // Dim No 18
                if (DN.DimIDNo18)
                {
                    pointList = new PointList();
                    pointList.Add(HP.Points.P5);
                    pointList.Add(new Point(HP.Points.P4.X, BC.Points.P5.Y));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, HP.Points.P4.X, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;

                    }
                }


            }


        }

        private void AppySectionDim()
        {
            StraightDimensionSet xDim = null;
            PointList pointList = new PointList();
            Vector Vect = new Vector(0, 1, 0);
            PointList TempList = new PointList();

            if (BC.HP != null)
            {
                if (BC.HP.HPTop != null)
                {
                    Vect = new Vector(0, 1, 0);
                    PartPoints Points = BC.HP.HPTop.Points;
                    if (DN.DimIDNo8 || DN.DimIDNo8Dot1)
                    {
                        pointList = new PointList();
                        if (DN.DimIDNo8)
                            pointList.Add(Points.P1);
                        pointList.Add(MainBeam.StartPoint);
                        if (DN.DimIDNo8Dot1)
                            pointList.Add(Points.P4);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByTopY(xDim, BC.PC);

                    }
                }

                if (BC.HP.HPBotom != null)
                {
                    Vect = new Vector(0, -1, 0);
                    PartPoints Points = BC.HP.HPBotom.Points;
                    if (DN.DimIDNo8 || DN.DimIDNo8Dot1)
                    {
                        pointList = new PointList();
                        if (DN.DimIDNo8)
                            pointList.Add(Points.P2);
                        pointList.Add(MainBeam.StartPoint);
                        if (DN.DimIDNo8Dot1)
                            pointList.Add(Points.P3);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByBottomY(xDim, BC.PC);

                    }
                }
            }
        }

        #region Get Data

        private void GetBeamClassClass(TSD.View CView)
        {
            if (ViewName == "Front View")
            {
                BC = new BeamClass_BHP1();
                BC.beam = MainBeam;
                BC.Points = Com.GetPartPoints(MainBeam);
                List<TSM.Part> PartListC = BC.beam.GetAssembly().GetSecondaries().OfType<TSM.Part>().ToList();

                GetHaunchPlateProperties(PartListC);
                GetEndProperties(PartListC);

                PartListC.Add(MainBeam);

                TSM.Part LeftPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.X ascending select p).FirstOrDefault();
                TSM.Part RightPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.X descending select p).FirstOrDefault();
                TSM.Part TopPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.Y descending select p).FirstOrDefault();
                TSM.Part BottPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.Y ascending select p).FirstOrDefault();

                BC.PC = new PlacingClass();
                BC.PC.TopY = TopPart.GetSolid().MaximumPoint.Y;
                BC.PC.BottomY = BottPart.GetSolid().MinimumPoint.Y;


                BC.PC.LeftX = LeftPart.GetSolid().MinimumPoint.X;// Math.Round(CView.RestrictionBox.MinPoint.X);
                BC.PC.RightX = RightPart.GetSolid().MaximumPoint.X;

                double AvScale = 12;
                double AvDistInc = 100;
                double DistPerScale = AvDistInc / AvScale;
                double CScale = CView.Attributes.Scale;
                BC.PC.DistInc = CScale * DistPerScale;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;
            }
            else if (ViewName == "Section View")
            {
                BC = new BeamClass_BHP1();
                BC.beam = MainBeam;
                BC.Points = Com.GetPartPoints(MainBeam);
                List<TSM.Part> PartListC = BC.beam.GetAssembly().GetSecondaries().OfType<TSM.Part>().ToList();

                double MaxZ = CView.RestrictionBox.MinPoint.Z;
                //List<TSM.Part> PartList = (from p in PartListC where p.GetSolid().MaximumPoint.Z > MaxZ select p).ToList();
                List<TSM.Part> PartList = (from p in PartListC where Com.IsViewObj(p, CView) select p).ToList();
                Point CentP = Com.CenterPoint(MainBeam.StartPoint, MainBeam.EndPoint);

                TSM.Part HPT = (from p in PartList where dc.IsPlateSideViewN(p) && Com.CenterPoint(p).Y > BC.Points.P1.Y select p).FirstOrDefault();
                TSM.Part HPB = (from p in PartList where dc.IsPlateSideViewN(p) && Com.CenterPoint(p).Y < BC.Points.P2.Y select p).FirstOrDefault();
                if (HPT != null)
                {
                    BC.HP = new HaunchPlateClass();
                    BC.HP.HPTop = new PartClass();
                    BC.HP.HPTop.part = HPT;
                    BC.HP.HPTop.Points = Com.GetPartPoints(HPT);
                }

                if (HPB != null)
                {
                    if (BC.HP == null)
                        BC.HP = new HaunchPlateClass();

                    BC.HP.HPBotom = new PartClass();
                    BC.HP.HPBotom.part = HPB;
                    BC.HP.HPBotom.Points = Com.GetPartPoints(HPB);
                }

                PartListC.Add(MainBeam);
                List<Point> RefPoints = MainBeam.GetReferenceLine(false).OfType<Point>().ToList();
                PartList.Add(MainBeam);
                TSM.Part LeftPart = (from p in PartList orderby p.GetSolid().MinimumPoint.X ascending select p).FirstOrDefault();
                TSM.Part RightPart = (from p in PartList orderby p.GetSolid().MaximumPoint.X descending select p).FirstOrDefault();
                TSM.Part TopPart = (from p in PartList orderby p.GetSolid().MaximumPoint.Y descending select p).FirstOrDefault();
                TSM.Part BottPart = (from p in PartList orderby p.GetSolid().MinimumPoint.Y ascending select p).FirstOrDefault();

                BC.PC = new PlacingClass();
                BC.PC.TopY = TopPart.GetSolid().MaximumPoint.Y;
                BC.PC.BottomY = BottPart.GetSolid().MinimumPoint.Y;
                BC.PC.LeftX = LeftPart.GetSolid().MinimumPoint.X;// Math.Round(CView.RestrictionBox.MinPoint.X);
                BC.PC.RightX = RightPart.GetSolid().MaximumPoint.X;

                double AvScale = 12;
                double AvDistInc = 100;
                double DistPerScale = AvDistInc / AvScale;
                double CScale = CView.Attributes.Scale;
                BC.PC.DistInc = CScale * DistPerScale;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;
            }


        }

        private void GetHaunchPlateProperties(List<TSM.Part> PartListC)
        {

            TSM.Part HPTop = null;
            TSM.Part HPBott = null;

            Point CentP = Com.CenterPoint(BC.beam.StartPoint, BC.beam.EndPoint);
            double Lenght = (BC.beam.GetSolid().MaximumPoint.X - BC.beam.GetSolid().MinimumPoint.X) / 8;
            double MinX = BC.beam.GetSolid().MinimumPoint.X + Lenght;
            double MaxX = BC.beam.GetSolid().MaximumPoint.X - Lenght;

            if (Position == "Left")
            {

                HPTop = (from p in PartListC where !dc.IsPlateSideViewN(p) && (p.GetSolid().MaximumPoint.X < CentP.X && p.GetSolid().MinimumPoint.X <= MinX) && Com.CenterPoint(p).Y > BC.Points.P1.Y select p).FirstOrDefault();
                HPBott = (from p in PartListC where !dc.IsPlateSideViewN(p) && (p.GetSolid().MaximumPoint.X < CentP.X && p.GetSolid().MinimumPoint.X <= MinX) && Com.CenterPoint(p).Y < BC.Points.P2.Y select p).FirstOrDefault();

            }
            else
            {
                HPTop = (from p in PartListC where !dc.IsPlateSideViewN(p) && (p.GetSolid().MinimumPoint.X > CentP.X && p.GetSolid().MaximumPoint.X >= MaxX) && Com.CenterPoint(p).Y > BC.Points.P1.Y select p).FirstOrDefault();
                HPBott = (from p in PartListC where !dc.IsPlateSideViewN(p) && (p.GetSolid().MinimumPoint.X > CentP.X && p.GetSolid().MaximumPoint.X >= MaxX) && Com.CenterPoint(p).Y < BC.Points.P2.Y select p).FirstOrDefault();
            }

            if (HPTop != null)
            {
                if (BC.HP == null)
                    BC.HP = new HaunchPlateClass();


                PartPoints Points = Com.GetPartPoints(HPTop);

                PointList VertList = dc.GetVertexList(HPTop.GetSolid());
                BC.HP.HPTop = new PartClass();
                BC.HP.HPTop.part = HPTop;
                BC.HP.HPTop.Points = new PartPoints();
                BC.HP.HPTop.BoltPList = Com.GetPartBoltPoint(HPTop);
                if (Position == "Left")
                {
                    BC.HP.HPTop.Points.P1 = Points.P1;
                    BC.HP.HPTop.Points.P2 = Points.P2;



                    BC.HP.HPTop.Points.P3 = Points.P3;
                    BC.HP.HPTop.Points.P4 = (from p in VertList.OfType<Point>() where p.Y > Points.P3.Y && p.X > Points.CentP.X orderby p.Y ascending select p).FirstOrDefault();
                    BC.HP.HPTop.Points.P5 = (from p in VertList.OfType<Point>() where p.Y == Points.P1.Y orderby p.X descending select p).FirstOrDefault();


                }
                else
                {
                    BC.HP.HPTop.Points.P1 = Points.P4;
                    BC.HP.HPTop.Points.P2 = Points.P3;
                    BC.HP.HPTop.Points.P3 = Points.P2;
                    BC.HP.HPTop.Points.P4 = (from p in VertList.OfType<Point>() where p.Y > BC.HP.HPTop.Points.P3.Y && p.X < Points.CentP.X orderby p.Y ascending select p).FirstOrDefault();
                    BC.HP.HPTop.Points.P5 = (from p in VertList.OfType<Point>() where p.Y == BC.HP.HPTop.Points.P1.Y orderby p.X ascending select p).FirstOrDefault();
                }

            }

            if (HPBott != null)
            {
                if (BC.HP == null)
                    BC.HP = new HaunchPlateClass();


                PartPoints Points = Com.GetPartPoints(HPBott);

                PointList VertList = dc.GetVertexList(HPBott.GetSolid());
                BC.HP.HPBotom = new PartClass();
                BC.HP.HPBotom.part = HPBott;
                BC.HP.HPBotom.Points = new PartPoints();
                BC.HP.HPBotom.BoltPList = Com.GetPartBoltPoint(HPBott);
                if (Position == "Left")
                {
                    BC.HP.HPBotom.Points.P1 = Points.P2;
                    BC.HP.HPBotom.Points.P2 = Points.P1;
                    BC.HP.HPBotom.Points.P3 = Points.P4;
                    BC.HP.HPBotom.Points.P4 = (from p in VertList.OfType<Point>() where p.Y < BC.HP.HPBotom.Points.P3.Y && p.X > Points.CentP.X orderby p.Y descending select p).FirstOrDefault();
                    BC.HP.HPBotom.Points.P5 = (from p in VertList.OfType<Point>() where p.Y == BC.HP.HPBotom.Points.P1.Y orderby p.X descending select p).FirstOrDefault();
                }
                else
                {
                    BC.HP.HPBotom.Points.P1 = Points.P3;
                    BC.HP.HPBotom.Points.P2 = Points.P4;
                    BC.HP.HPBotom.Points.P3 = Points.P1;
                    BC.HP.HPBotom.Points.P4 = (from p in VertList.OfType<Point>() where p.Y < BC.HP.HPBotom.Points.P3.Y && p.X < Points.CentP.X orderby p.Y descending select p).FirstOrDefault();
                    BC.HP.HPBotom.Points.P5 = (from p in VertList.OfType<Point>() where p.Y == BC.HP.HPBotom.Points.P1.Y orderby p.X ascending select p).FirstOrDefault();
                }

            }


        }

        private void GetEndProperties(List<TSM.Part> PartListC)
        {


            Point CentP = Com.CenterPoint(BC.beam.StartPoint, BC.beam.EndPoint);
            double Lenght = (BC.beam.GetSolid().MaximumPoint.X - BC.beam.GetSolid().MinimumPoint.X) / 8;
            double MinX = BC.beam.GetSolid().MinimumPoint.X + Lenght;
            double MaxX = BC.beam.GetSolid().MaximumPoint.X - Lenght;

            List<BoltGroup> BoltsE = null;
            ContourPlate BoolTop = null;
            ContourPlate BoolBott = null;
            List<BoltGroup> Bolts = Com.EnumtoArray(MainBeam.GetBolts()).OfType<BoltGroup>().ToList();
            List<BooleanPart> Bools = Com.EnumtoArray(MainBeam.GetBooleans()).OfType<BooleanPart>().ToList();

            List<ContourPlate> OParts = Bools.Select(x => x.OperativePart).OfType<ContourPlate>().ToList();

            double BHeigh = Com.GetPartHeight(MainBeam);

            if (Position == "Left")
            {
                BoltsE = (from p in Bolts where (p.GetSolid().MaximumPoint.X < CentP.X && p.GetSolid().MinimumPoint.X <= MinX) select p).ToList();
                if (OParts != null)
                {
                    BoolTop = (from p in OParts where (p.GetSolid().MaximumPoint.X < CentP.X && p.GetSolid().MinimumPoint.X <= MinX) && Com.CenterPoint(p).Y > BC.Points.CentP.Y select p).FirstOrDefault();
                    BoolBott = (from p in OParts where (p.GetSolid().MaximumPoint.X < CentP.X && p.GetSolid().MinimumPoint.X <= MinX) && Com.CenterPoint(p).Y < BC.Points.CentP.Y select p).FirstOrDefault();
                }
            }
            else
            {
                BoltsE = (from p in Bolts where (p.GetSolid().MinimumPoint.X > CentP.X && p.GetSolid().MaximumPoint.X >= MaxX) select p).ToList();
                if (OParts != null)
                {
                    BoolTop = (from p in OParts where (p.GetSolid().MinimumPoint.X > CentP.X && p.GetSolid().MaximumPoint.X >= MaxX) && Com.CenterPoint(p).Y > BC.Points.CentP.Y select p).FirstOrDefault();
                    BoolBott = (from p in OParts where (p.GetSolid().MinimumPoint.X > CentP.X && p.GetSolid().MaximumPoint.X >= MaxX) && Com.CenterPoint(p).Y < BC.Points.CentP.Y select p).FirstOrDefault();
                }
            }

            if (BoltsE != null)
                BC.BoltsE = Com.GetBoltPoints(BoltsE);

            BC.Points.P5 = BC.Points.P1;
            BC.Points.P6 = BC.Points.P2;
            BC.Points.P7 = BC.Points.P3;
            BC.Points.P8 = BC.Points.P4;

            if (BoolTop != null)
            {
                BC.CutTop = new CutPoints();

                PointList ContList = dc.ContPList(BoolTop);
                ContList = ReviseList(ContList, "Top");
                if (Position == "Left")
                {
                    BC.CutTop.P1 = Com.MinPofX(ContList, "Y", Com.MinP(ContList, "X").X);
                    BC.CutTop.P2 = Com.MaxPofY(ContList, "X", Com.MaxP(ContList, "Y").Y);
                    if (!Com.IsEqual(BC.CutTop.P1.Y, BC.CutTop.P2.Y))
                    {
                        BC.Points.P1 = BC.CutTop.P1;
                        BC.Points.P5 = BC.CutTop.P2;
                    }
                    else
                        BC.CutTop = null;
                }
                else
                {
                    BC.CutTop.P1 = Com.MinPofX(ContList, "Y", Com.MaxP(ContList, "X").X);
                    BC.CutTop.P2 = Com.MinPofY(ContList, "X", Com.MaxP(ContList, "Y").Y);

                    if (!Com.IsEqual(BC.CutTop.P1.Y, BC.CutTop.P2.Y))
                    {
                        BC.Points.P4 = BC.CutTop.P1;
                        BC.Points.P8 = BC.CutTop.P2;
                    }
                    else
                        BC.CutTop = null;


                }

            }

            if (BoolBott != null)
            {
                BC.CutBott = new CutPoints();

                PointList ContList = dc.ContPList(BoolBott);
                ContList = ReviseList(ContList, "Bottom");
                if (Position == "Left")
                {
                    BC.CutBott.P1 = Com.MaxPofX(ContList, "Y", Com.MinP(ContList, "X").X);
                    BC.CutBott.P2 = Com.MaxPofY(ContList, "X", Com.MinP(ContList, "Y").Y);

                    if (!Com.IsEqual(BC.CutBott.P1.Y, BC.CutBott.P2.Y))
                    {
                        BC.Points.P2 = BC.CutBott.P1;
                        BC.Points.P6 = BC.CutBott.P2;
                    }
                    else
                        BC.CutBott = null;


                }
                else
                {
                    BC.CutBott.P1 = Com.MaxPofX(ContList, "Y", Com.MaxP(ContList, "X").X);
                    BC.CutBott.P2 = Com.MinPofY(ContList, "X", Com.MinP(ContList, "Y").Y);

                    if (!Com.IsEqual(BC.CutBott.P1.Y, BC.CutBott.P2.Y))
                    {
                        BC.Points.P3 = BC.CutBott.P1;
                        BC.Points.P7 = BC.CutBott.P2;
                    }
                    else
                        BC.CutBott = null;

                }

            }


        }

        private PointList ReviseList(PointList Plist, string VPos)
        {
            PointList pointList = new PointList();
            if (Plist.Count > 0)
            {
                foreach (Point p in Plist)
                {
                    Point P1 = p;

                    if (VPos == "Top" && P1.Y > BC.Points.P1.Y)
                        P1 = new Point(P1.X, BC.Points.P1.Y);

                    else if (VPos == "Bottom" && P1.Y < BC.Points.P2.Y)
                        P1 = new Point(P1.X, BC.Points.P2.Y);

                    if (Position == "Left" && P1.X < BC.Points.P1.X)
                        P1 = new Point(BC.Points.P1.X, P1.Y);

                    if (Position == "Right" && P1.X > BC.Points.P4.X)
                        P1 = new Point(BC.Points.P4.X, P1.Y);


                    pointList.Add(P1);
                }


            }
            return pointList;
        }

        #endregion

        #region Helping Methods
        private double GetPartWidth(TSM.Part part)
        {
            return (part.GetSolid().MaximumPoint.X - part.GetSolid().MinimumPoint.X);
        }

        #endregion

        private class HaunchPlateClass
        {
            public PartClass HPTop { get; set; }
            public PartClass HPBotom { get; set; }
            public PointList TopBoltP { get; set; }

        }

        private class BeamClass_BHP1
        {
            public Beam beam { get; set; }
            public HaunchPlateClass HP { get; set; }
            public PointList BoltsE { get; set; }
            public CutPoints CutTop { get; set; }
            public CutPoints CutBott { get; set; }
            public PartPoints Points { get; set; }
            public PlacingClass PC { get; set; }
        }


    }

}
