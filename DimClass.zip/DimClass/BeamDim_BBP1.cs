﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Tekla.Structures;
using Tekla.Structures.Drawing;
using Tekla.Structures.Geometry3d;
using Tekla.Structures.Model;
using TSD = Tekla.Structures.Drawing;
using TSM = Tekla.Structures.Model;
using VirtueleDrawingAutomation;
using TSDD = Tekla.Structures.Datatype;
using TSG = Tekla.Structures.Geometry3d;

namespace Auto_Detailing_Tool_Beam
{
    public class BeamDim_BBP1
    {
        #region Global Variables
        DimCom dc = new DimCom();
        StraightDimensionSet.StraightDimensionSetAttributes StAtrr = new StraightDimensionSet.StraightDimensionSetAttributes("standard");
        StraightDimensionSet.StraightDimensionSetAttributes RdAtrr = new StraightDimensionSet.StraightDimensionSetAttributes("standard");

        public Beam MainBeam = null;
        VirtueleDrawingAutomation.Json.DrawingAttributeInfoJson.AttributeFiles dimAttrClass = null;
        List<TSD.StraightDimension> KnockDim = new List<StraightDimension>();
        BeamClass_BBP1 BC = null;
        VirtueleDrawingAutomation.Json.AutoDimensionTypesJson.BBP1Json DN = null;
        TSD.View CView = null;

        List<int> Ids = new List<int>();
        string ViewName = "";

        #endregion

        public List<int> ApplyDim(TSD.View CView, string ViewName, AutoDimensioningTypes autoDimensioningTypes, DrawingAttributeInfo drawingAttributeInfo, List<int> Ids)
        {
            try
            {
                this.Ids = Ids;
                Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane());
                //Set model everything to the view
                Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane(CView.DisplayCoordinateSystem));

                this.CView = CView;
                this.dimAttrClass = drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files;
                this.DN = autoDimensioningTypes.Bbp1;
                StAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.StandardDimension);
                RdAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.RunningDimension);
                this.MainBeam = (Com.MyModel.SelectModelObject(new Identifier((CView.GetDrawing() as AssemblyDrawing).AssemblyIdentifier.ID)) as TSM.Assembly).GetMainPart() as TSM.Beam;
                this.MainBeam.Select();
                this.ViewName = ViewName;

                string ProType = Com.GetProType(MainBeam);
                GetBeamClassClass();

                //TestDim();
                if (ViewName == "Front View")
                {
                    while (BC.BPC != null)
                    {
                        ApplyDimTypeFV();
                        GetBeamClassClass();
                    }
                }
                else if (ViewName == "Top View" || ViewName == "Bottom View")
                {
                    while (BC.BT != null || BC.BB != null)
                    {
                        ApplyDimTypeTop();
                        ApplyDimTypeBott();

                        GetBeamClassClass();
                    }
                }
                else
                if (ViewName == "Section View")
                    ApplyDimSection();


                Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane());
            }
            catch (Exception ex)
            { }

            return Ids;
        }

        private void ApplyDimTypeFV()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            TSD.PointList TempList = new PointList();

            if (BC.BPC != null)
            {
                Vect = new Vector(-1, 0, 0);

                if (BC.BPC.IsFrontBolt)
                {
                    // Dim No 9
                    if (DN.DimIDNo9)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.BPC.BPC.Points.P1);

                        if (BC.BPCN != null)
                            pointList.Add(Com.MaxP(BC.BPCN.BPC.BoltPList, "X"));
                        else
                            pointList.Add(Com.MaxP(BC.BPC.BPC.BoltPList, "X"));

                        pointList.Add(BC.BPC.BPC.Points.P2);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceLeftP(xDim, BC.BPC.BPC.Points.P1.X, BC.PC.DistLeft);
                    }
                }

                Vect = new Vector(1, 0, 0);
                // Dim No 12
                if (DN.DimIDNo12)
                {
                    if (BC.BPCN != null)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.BPCN.BPC.Points.P4);
                        pointList.Add(BC.BPCN.BPC.Points.P3);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceRightP(xDim, BC.BPCN.BPC.Points.P4.X, BC.PC.DistRight);
                    }
                    else
                    {
                        pointList = new PointList();
                        pointList.Add(BC.BPC.BPC.Points.P4);
                        pointList.Add(BC.BPC.BPC.Points.P3);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceRightP(xDim, BC.BPC.BPC.Points.P4.X, BC.PC.DistRight);
                    }


                }

                Vect = new Vector(0, 1, 0);
                // Dim No 17
                if (DN.DimIDNo17 && BC.BPCN != null)
                {

                    pointList = new PointList();
                    pointList.Add(BC.BPC.BPC.Points.P4);
                    pointList.Add(BC.BPCN.BPC.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }

                // Dim No 1 ,1.1 // Rd Dim
                if (DN.DimIDNo1 || DN.DimIDNo1Dot1)
                {
                    if (DN.DimIDNo1Dot1 && BC.PC.DistTop == BC.PC.DistInc)
                        BC.PC.DistTop += BC.PC.DistInc;

                    pointList = new PointList();
                    pointList.Add(new Point(BC.Points.P1.X, BC.Points.CentP.Y));
                    pointList.Add(BC.BPC.BPC.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);

                    if (BC.BPCN != null)
                    {
                        pointList = new PointList();
                        pointList.Add(new Point(BC.Points.P1.X, BC.Points.CentP.Y));
                        pointList.Add(BC.BPCN.BPC.Points.P1);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                        if (xDim != null)
                            PL.DimPlaceByTopY(xDim, BC.PC);
                    }


                }


                // Dim No 11
                if (DN.DimIDNo11 && BC.BPC.BPC.BoltPList != null)
                {

                    pointList = new PointList();
                    pointList.Add(Com.MaxP(BC.BPC.BPC.BoltPList, "X"));
                    pointList.Add(BC.BPC.BPC.Points.P4);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);

                    if (BC.BPCN != null)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MinP(BC.BPCN.BPC.BoltPList, "X"));
                        pointList.Add(BC.BPCN.BPC.Points.P1);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                    }


                }

                // Dim No 20
                if (DN.DimIDNo20)
                {
                    if (BC.BPC.STL != null)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.BPC.STL.Points.P4);
                        pointList.Add(BC.BPC.STL.Points.P1);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                    }

                    if (BC.BPCN?.STR != null)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.BPCN.STR.Points.P1);
                        pointList.Add(BC.BPCN.STR.Points.P4);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);

                    }


                }

                // Dim No 10.3
                if (Ids.Count == 0 && DN.DimIDNo10Dot3)
                {
                    pointList = new PointList();
                    pointList.Add(new Point(BC.Points.P1.X, BC.Points.CentP.Y));
                    pointList.Add(BC.BPC.BPC.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);

                }

                if (DN.DimIDNo11 || DN.DimIDNo20 || DN.DimIDNo10Dot3)
                    BC.PC.DistTop += BC.PC.DistInc;

                // Dim No 11.1
                if (DN.DimIDNo11Dot1 && BC.BPCN != null && BC.BPC.BPC.BoltPList != null)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(BC.BPC.BPC.BoltPList, "X"));
                    pointList.Add(Com.MinP(BC.BPCN.BPC.BoltPList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);

                }

                // Dim No 10, 10.2
                if ((DN.DimIDNo10 || DN.DimIDNo10Dot2) && BC.BPC.BPC.BoltPList != null)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo10Dot2)
                    {
                        pointList.Add(BC.BPC.BPC.Points.P1);
                        pointList.Add(Com.MinP(BC.BPC.BPC.BoltPList, "X"));
                    }

                    if (DN.DimIDNo10)
                        pointList.AddRange(BC.BPC.BPC.BoltPList);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);

                    if (BC.BPCN != null)
                    {
                        pointList = new PointList();
                        if (DN.DimIDNo10Dot2)
                        {
                            pointList.Add(BC.BPCN.BPC.Points.P4);
                            pointList.Add(Com.MaxP(BC.BPCN.BPC.BoltPList, "X"));
                        }

                        if (DN.DimIDNo10)
                            pointList.AddRange(BC.BPCN.BPC.BoltPList);

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                    }



                }

                if (DN.DimIDNo10 || DN.DimIDNo10Dot2 || DN.DimIDNo11Dot1)
                    BC.PC.DistTop += BC.PC.DistInc;

                // Dim No 10.1
                if (DN.DimIDNo10Dot1 && BC.BPC.BPC.BoltPList != null)
                {
                    if (BC.BPC.BPC.BoltPList.Count > 0)
                    {
                        pointList = new PointList();
                        pointList.AddRange(BC.BPC.BPC.BoltPList);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                            Com.GroupDim(xDim);
                        }
                    }

                    if (BC.BPCN != null && BC.BPCN.BPC.BoltPList.Count > 0)
                    {
                        pointList = new PointList();
                        pointList.AddRange(BC.BPCN.BPC.BoltPList);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                            Com.GroupDim(xDim);
                        }
                    }

                    BC.PC.DistTop += BC.PC.DistInc;
                }

                // Dim No 2
                if (DN.DimIDNo2)
                {

                    pointList = new PointList();
                    pointList.Add(BC.BPC.BPC.Points.P1);
                    pointList.Add(BC.BPC.BPC.Points.P4);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);

                    if (BC.BPCN != null)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.BPCN.BPC.Points.P1);
                        pointList.Add(BC.BPCN.BPC.Points.P4);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                    }

                    BC.PC.DistTop += BC.PC.DistInc;
                }



                // Dim No 6 Elevation Dim
                if (DN.DimIDNo6 && Ids.Count == 0)
                {
                    BC.PC.DistLeft += BC.PC.DistInc;
                    Vect = new Vector(-1, 0, 0);
                    StraightDimensionSet.StraightDimensionSetAttributes ElAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.ElevationDimension);
                    ElAtrr.DimensionType = DimensionSetBaseAttributes.DimensionTypes.Elevation;
                    ElAtrr.Arrowhead.Head = ArrowheadTypes.FilledArrow;
                    pointList = new PointList();

                    if (MainBeam.StartPoint.X > MainBeam.EndPoint.X)
                    {
                        pointList.Add(MainBeam.EndPoint);
                        pointList.Add(MainBeam.EndPoint);

                    }
                    else
                    {
                        pointList.Add(MainBeam.StartPoint);
                        pointList.Add(MainBeam.StartPoint);
                    }

                    BC.PC.DistLeft = BC.PC.DistLeft - (BC.Points.P1.X - pointList[0].X);
                    xDim = dc.InsertDimm(CView, pointList, Vect, (-BC.PC.DistLeft), ElAtrr);
                    if (xDim != null)
                    {
                        xDim.Distance = (-BC.PC.DistLeft);
                        xDim.Modify();
                    }
                    BC.PC.DistLeft += BC.PC.DistInc;

                }


                Ids.Add(BC.BPC.BPC.part.Identifier.ID);

                if (BC.BPC.BPC1 != null)
                    Ids.Add(BC.BPC.BPC1.part.Identifier.ID);

                if (BC.BPCN?.BPC != null)
                    Ids.Add(BC.BPCN.BPC.part.Identifier.ID);

                if (BC.BPCN?.BPC1 != null)
                    Ids.Add(BC.BPCN.BPC1.part.Identifier.ID);
            }

        }


        #region Top / Bottom View

        private void ApplyDimTypeTop()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            TSD.PointList TempList = new PointList();

            if (BC.BT != null)
            {
                #region Left Dim
                Vect = new Vector(-1, 0, 0);
                Point CentP = new Point(BC.BT.BPC.Points.P1.X, BC.Points.CentP.Y);


                // Dim No 25.2
                if (DN.DimIDNo25Dot2 && BC.BT.BPC.BoltPList != null)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BT.BPC.Points.P2);
                    pointList.Add(Com.MaxP(BC.BT.BPC.BoltPList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, BC.BT.BPC.Points.P1.X, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }
                }


                // Dim No 25, 25.1
                if (DN.DimIDNo25 || DN.DimIDNo25Dot1)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo25)
                        pointList.Add(BC.BT.BPC.Points.P1);

                    pointList.Add(BC.BT.BPC.Points.P2);

                    if (DN.DimIDNo25Dot1)
                        pointList.Add(CentP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, BC.BT.BPC.Points.P1.X, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }
                }

                // Dim No 28.1
                if (DN.DimIDNo28Dot1 && BC.BT.BPC.BoltPList != null)
                {
                    pointList = new PointList();
                    pointList.Add(CentP);
                    pointList.Add(Com.MaxP(BC.BT.BPC.BoltPList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, BC.BT.BPC.Points.P1.X, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }
                }


                // Dim No 28
                if (DN.DimIDNo28 && BC.BT.BPC.BoltPList != null && BC.BB?.BPC.BoltPList != null)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(BC.BT.BPC.BoltPList, "X"));
                    pointList.Add(Com.MaxP(BC.BB.BPC.BoltPList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, BC.BT.BPC.Points.P1.X, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }
                }

                #endregion


                #region Right Dim

                if (BC.BTN != null)
                {
                    Vect = new Vector(1, 0, 0);
                    CentP = new Point(BC.BTN.BPC.Points.P4.X, BC.Points.CentP.Y);


                    // Dim No 25.2
                    if (DN.DimIDNo25Dot2 && BC.BT.BPC.BoltPList != null)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.BTN.BPC.Points.P3);
                        pointList.Add(Com.MinP(BC.BT.BPC.BoltPList, "X"));
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceRightP(xDim, BC.BTN.BPC.Points.P4.X, BC.PC.DistRight);
                            BC.PC.DistRight += BC.PC.DistInc;
                        }
                    }


                    // Dim No 25, 25.1
                    if (DN.DimIDNo25 || DN.DimIDNo25Dot1)
                    {
                        pointList = new PointList();
                        if (DN.DimIDNo25)
                            pointList.Add(BC.BTN.BPC.Points.P4);

                        pointList.Add(BC.BTN.BPC.Points.P3);

                        if (DN.DimIDNo25Dot1)
                            pointList.Add(CentP);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceRightP(xDim, BC.BTN.BPC.Points.P4.X, BC.PC.DistRight);
                            BC.PC.DistRight += BC.PC.DistInc;
                        }
                    }

                    // Dim No 28.1
                    if (DN.DimIDNo28Dot1 && BC.BT.BPC.BoltPList != null)
                    {
                        pointList = new PointList();
                        pointList.Add(CentP);
                        pointList.Add(Com.MinP(BC.BTN.BPC.BoltPList, "X"));
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceRightP(xDim, BC.BTN.BPC.Points.P4.X, BC.PC.DistRight);
                            BC.PC.DistRight += BC.PC.DistInc;
                        }
                    }


                    // Dim No 28
                    if (DN.DimIDNo28 && BC.BTN.BPC.BoltPList != null && BC.BBN?.BPC.BoltPList != null)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MinP(BC.BTN.BPC.BoltPList, "X"));
                        pointList.Add(Com.MinP(BC.BBN.BPC.BoltPList, "X"));
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceRightP(xDim, BC.BTN.BPC.Points.P4.X, BC.PC.DistRight);
                            BC.PC.DistRight += BC.PC.DistInc;
                        }
                    }
                }

                #endregion


                #region Top Dim
                Vect = new Vector(0, 1, 0);
                // Dim No 17
                if (DN.DimIDNo17 && BC.BTN != null)
                {

                    pointList = new PointList();
                    pointList.Add(BC.BT.BPC.Points.P4);
                    pointList.Add(BC.BTN.BPC.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);

                    }
                }


                // Dim No 20
                if (DN.DimIDNo20)
                {
                    if (BC.BT.STL != null)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.BT.STL.Points.P4);
                        pointList.Add(BC.BT.STL.Points.P1);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                    }

                    if (BC.BTN?.STR != null)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.BTN.STR.Points.P1);
                        pointList.Add(BC.BTN.STR.Points.P4);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);

                    }
                    else if (BC.BT.STR != null)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.BT.STR.Points.P1);
                        pointList.Add(BC.BT.STR.Points.P4);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                    }
                }


                if (DN.DimIDNo20 || (DN.DimIDNo17 && BC.BTN != null))
                    BC.PC.DistTop += BC.PC.DistInc;

                // Dim No 21 ,21.1 // Rd Dim
                if (DN.DimIDNo21 || DN.DimIDNo21Dot1)
                {
                    if (DN.DimIDNo21 && BC.PC.DistTop == BC.PC.DistInc)
                        BC.PC.DistTop += BC.PC.DistInc;

                    pointList = new PointList();
                    pointList.Add(new Point(BC.Points.P1.X, BC.Points.CentP.Y));
                    pointList.Add(BC.BT.BPC.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);

                    if (BC.BTN != null)
                    {
                        pointList = new PointList();
                        pointList.Add(new Point(BC.Points.P1.X, BC.Points.CentP.Y));
                        pointList.Add(BC.BTN.BPC.Points.P1);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                        if (xDim != null)
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                    }

                    BC.PC.DistTop += BC.PC.DistInc;
                }

                // Dim No 22 ,22.1 // Rd Dim
                if ((DN.DimIDNo22 || DN.DimIDNo22Dot1) && BC.BT.BPC.BoltPList != null)
                {
                    if (DN.DimIDNo22 && BC.PC.DistTop == BC.PC.DistInc)
                        BC.PC.DistTop += BC.PC.DistInc;

                    pointList = new PointList();
                    pointList.Add(new Point(BC.Points.P1.X, BC.Points.CentP.Y));
                    pointList.AddRange(BC.BT.BPC.BoltPList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);

                    if (BC.BTN != null)
                    {
                        pointList = new PointList();
                        pointList.Add(new Point(BC.Points.P1.X, BC.Points.CentP.Y));
                        pointList.AddRange(BC.BTN.BPC.BoltPList);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                        if (xDim != null)
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                    }

                    BC.PC.DistTop += BC.PC.DistInc;

                }

                // Dim No 27.1
                if (DN.DimIDNo27Dot1 && BC.BT.BPC.BoltPList != null)
                {

                    pointList = new PointList();
                    pointList.Add(Com.MinP(BC.BT.BPC.BoltPList, "X"));
                    pointList.Add(BC.BT.BPC.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);



                    if (BC.BTN != null)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MinP(BC.BTN.BPC.BoltPList, "X"));
                        pointList.Add(BC.BTN.BPC.Points.P1);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                            xDim.Attributes.ShortDimension = DimensionSetBaseAttributes.ShortDimensionTypes.Inside;
                            xDim.Modify();
                        }


                    }


                }


                // Dim No 27.2
                if (DN.DimIDNo27Dot2 && BC.BT.BPC.BoltPList != null)
                {

                    pointList = new PointList();
                    pointList.Add(Com.MaxP(BC.BT.BPC.BoltPList, "X"));
                    pointList.Add(BC.BT.BPC.Points.P4);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        if (BC.BTN != null)
                        {
                            xDim.Attributes.ShortDimension = DimensionSetBaseAttributes.ShortDimensionTypes.Inside;
                            xDim.Modify();
                        }
                    }

                    if (BC.BTN != null)
                    {

                        pointList = new PointList();
                        pointList.Add(Com.MaxP(BC.BTN.BPC.BoltPList, "X"));
                        pointList.Add(BC.BTN.BPC.Points.P4);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                    }


                }


                // Dim No 27.
                if (DN.DimIDNo27 && BC.BT.BPC.BoltPList != null)
                {

                    pointList = new PointList();
                    pointList.AddRange(BC.BT.BPC.BoltPList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);

                    if (BC.BTN != null)
                    {
                        pointList = new PointList();
                        pointList.AddRange(BC.BTN.BPC.BoltPList);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                    }
                }

                if ((DN.DimIDNo27 || DN.DimIDNo27Dot1) && BC.BT.BPC.BoltPList != null)
                    BC.PC.DistTop += BC.PC.DistInc;

                #endregion


                Ids.Add(BC.BT.BPC.part.Identifier.ID);

                if (BC.BT.BPC1 != null)
                    Ids.Add(BC.BT.BPC1.part.Identifier.ID);

                if (BC.BTN?.BPC != null)
                    Ids.Add(BC.BTN.BPC.part.Identifier.ID);

                if (BC.BTN?.BPC1 != null)
                    Ids.Add(BC.BTN.BPC1.part.Identifier.ID);
            }

        }

        private void ApplyDimTypeBott()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            TSD.PointList TempList = new PointList();

            if (BC.BB != null)
            {
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;

                #region Left Dim
                Vect = new Vector(-1, 0, 0);
                Point CentP = new Point(BC.BB.BPC.Points.P1.X, BC.Points.CentP.Y);


                // Dim No 25, 25.1
                if (DN.DimIDNo25 || DN.DimIDNo25Dot1)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo25)
                        pointList.Add(BC.BB.BPC.Points.P2);

                    pointList.Add(BC.BB.BPC.Points.P1);

                    if (DN.DimIDNo25Dot1)
                        pointList.Add(CentP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, BC.BB.BPC.Points.P1.X, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }
                }

                // Dim No 25.2
                if (DN.DimIDNo25Dot2 && BC.BB.BPC.BoltPList != null)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BB.BPC.Points.P1);
                    pointList.Add(Com.MaxP(BC.BB.BPC.BoltPList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, BC.BB.BPC.Points.P1.X, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }
                }

                // Dim No 28.1
                if (DN.DimIDNo28Dot1 && BC.BB.BPC.BoltPList != null)
                {
                    pointList = new PointList();
                    pointList.Add(CentP);
                    pointList.Add(Com.MaxP(BC.BB.BPC.BoltPList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, BC.BB.BPC.Points.P1.X, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }
                }

                #endregion


                #region Right Dim

                if (BC.BBN != null)
                {
                    Vect = new Vector(1, 0, 0);
                    CentP = new Point(BC.BBN.BPC.Points.P4.X, BC.Points.CentP.Y);


                    // Dim No 25, 25.1
                    if (DN.DimIDNo25 || DN.DimIDNo25Dot1)
                    {
                        pointList = new PointList();
                        if (DN.DimIDNo25)
                            pointList.Add(BC.BBN.BPC.Points.P3);

                        pointList.Add(BC.BBN.BPC.Points.P4);

                        if (DN.DimIDNo25Dot1)
                            pointList.Add(CentP);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceRightP(xDim, BC.BBN.BPC.Points.P4.X, BC.PC.DistRight);
                            BC.PC.DistRight += BC.PC.DistInc;
                        }
                    }


                    // Dim No 25.2
                    if (DN.DimIDNo25Dot2 && BC.BBN.BPC.BoltPList != null)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.BBN.BPC.Points.P4);
                        pointList.Add(Com.MinP(BC.BB.BPC.BoltPList, "X"));
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceRightP(xDim, BC.BBN.BPC.Points.P4.X, BC.PC.DistRight);
                            BC.PC.DistRight += BC.PC.DistInc;
                        }
                    }




                    // Dim No 28.1
                    if (DN.DimIDNo28Dot1 && BC.BBN.BPC.BoltPList != null)
                    {
                        pointList = new PointList();
                        pointList.Add(CentP);
                        pointList.Add(Com.MinP(BC.BBN.BPC.BoltPList, "X"));
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceRightP(xDim, BC.BBN.BPC.Points.P4.X, BC.PC.DistRight);
                            BC.PC.DistRight += BC.PC.DistInc;
                        }
                    }

                }

                #endregion


                #region Bottom Dim
                Vect = new Vector(0, -1, 0);
                // Dim No 17
                if (DN.DimIDNo17 && BC.BBN != null)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BB.BPC.Points.P3);
                    pointList.Add(BC.BBN.BPC.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);

                    }
                }

                // Dim No 20
                if (DN.DimIDNo20)
                {
                    if (BC.BB.STL != null)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.BB.STL.Points.P3);
                        pointList.Add(BC.BB.STL.Points.P2);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                    }

                    if (BC.BBN?.STR != null)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.BBN.STR.Points.P2);
                        pointList.Add(BC.BBN.STR.Points.P3);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);

                    }
                    else if (BC.BB.STR != null)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.BB.STR.Points.P2);
                        pointList.Add(BC.BB.STR.Points.P3);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                    }


                }


                if ((DN.DimIDNo17 && BC.BBN != null) || DN.DimIDNo20)
                    BC.PC.DistBot += (BC.PC.DistInc * 1.5);


                // Dim No 21 ,21.1 // Rd Dim
                if (DN.DimIDNo21 || DN.DimIDNo21Dot1)
                {
                    if (DN.DimIDNo21 && BC.PC.DistBot == BC.PC.DistInc)
                        BC.PC.DistBot += BC.PC.DistInc;

                    pointList = new PointList();
                    pointList.Add(new Point(BC.Points.P1.X, BC.Points.CentP.Y));
                    pointList.Add(BC.BB.BPC.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);

                    if (BC.BBN != null)
                    {
                        pointList = new PointList();
                        pointList.Add(new Point(BC.Points.P1.X, BC.Points.CentP.Y));
                        pointList.Add(new Point(BC.Points.P1.X, BC.Points.CentP.Y));
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                        if (xDim != null)
                            PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                    }

                    BC.PC.DistBot += BC.PC.DistInc;

                }

                // Dim No 22 ,22.1 // Rd Dim
                if ((DN.DimIDNo22 || DN.DimIDNo22Dot1) && BC.BB.BPC.BoltPList != null)
                {
                    if (DN.DimIDNo22 && BC.PC.DistTop == BC.PC.DistInc)
                        BC.PC.DistBot += BC.PC.DistInc;

                    pointList = new PointList();
                    pointList.Add(new Point(BC.Points.P1.X, BC.Points.CentP.Y));
                    pointList.AddRange(BC.BB.BPC.BoltPList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);

                    if (BC.BBN != null && BC.BBN.BPC.BoltPList != null)
                    {
                        pointList = new PointList();
                        pointList.Add(new Point(BC.Points.P1.X, BC.Points.CentP.Y));
                        pointList.AddRange(BC.BBN.BPC.BoltPList);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                        if (xDim != null)
                            PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                    }

                    BC.PC.DistBot += BC.PC.DistInc;

                }

                // Dim No 27.1
                if (DN.DimIDNo27Dot1 && BC.BB.BPC.BoltPList != null)
                {

                    pointList = new PointList();
                    pointList.Add(Com.MinP(BC.BB.BPC.BoltPList, "X"));
                    pointList.Add(BC.BB.BPC.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);

                    if (BC.BBN != null && BC.BBN.BPC.BoltPList != null)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MinP(BC.BBN.BPC.BoltPList, "X"));
                        pointList.Add(BC.BBN.BPC.Points.P2);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                            xDim.Attributes.ShortDimension = DimensionSetBaseAttributes.ShortDimensionTypes.Inside;
                            xDim.Modify();
                        }
                    }


                }


                // Dim No 27.2
                if (DN.DimIDNo27Dot2 && BC.BB.BPC.BoltPList != null)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(BC.BB.BPC.BoltPList, "X"));
                    pointList.Add(BC.BB.BPC.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        if (BC.BBN != null)
                        {
                            xDim.Attributes.ShortDimension = DimensionSetBaseAttributes.ShortDimensionTypes.Inside;
                            xDim.Modify();
                        }
                    }

                    if (BC.BBN != null)
                    {

                        pointList = new PointList();
                        pointList.Add(Com.MaxP(BC.BBN.BPC.BoltPList, "X"));
                        pointList.Add(BC.BBN.BPC.Points.P3);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                    }


                }

                // Dim No 27.
                if (DN.DimIDNo27 && BC.BB.BPC.BoltPList != null)
                {

                    pointList = new PointList();
                    pointList.AddRange(BC.BB.BPC.BoltPList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);




                    if (BC.BBN != null && BC.BBN.BPC.BoltPList != null)
                    {
                        pointList = new PointList();
                        pointList.AddRange(BC.BBN.BPC.BoltPList);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                    }
                }


                if ((DN.DimIDNo27 || DN.DimIDNo27Dot1) && BC.BB.BPC.BoltPList != null)
                    BC.PC.DistBot += BC.PC.DistInc;

                #endregion

                Ids.Add(BC.BB.BPC.part.Identifier.ID);

                if (BC.BB.BPC1 != null)
                    Ids.Add(BC.BB.BPC1.part.Identifier.ID);

                if (BC.BBN?.BPC != null)
                    Ids.Add(BC.BBN.BPC.part.Identifier.ID);

                if (BC.BBN?.BPC1 != null)
                    Ids.Add(BC.BBN.BPC1.part.Identifier.ID);
            }

        }

        #endregion

        private void ApplyDimSection()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            TSD.PointList TempList = new PointList();

            bool IsTypeA = false;

            if (BC.BL?.BG != null || BC.BR?.BG != null)
                IsTypeA = true;

            if (BC.BL != null)
            {

                if (!IsTypeA)
                {
                    Vect = new Vector(0, 1, 0);
                    // Dim No 18, 18.1
                    if (DN.DimIDNo18 || DN.DimIDNo18Dot1)
                    {
                        pointList = new PointList();
                        if (DN.DimIDNo18Dot1)
                            pointList.Add(BC.BL.BB.Points.P1);
                        pointList.Add(BC.BL.BB.Points.P5);
                        if (DN.DimIDNo18)
                            pointList.Add(BC.BL.BB.Points.P4);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                    }

                    Vect = new Vector(-1, 0, 0);
                    // Dim No 19, 19.1
                    if (DN.DimIDNo19 || DN.DimIDNo19Dot1)
                    {
                        pointList = new PointList();
                        if (DN.DimIDNo19)
                            pointList.Add(BC.BL.BB.Points.P1);

                        pointList.Add(BC.BL.BB.Points.P4);
                        if (DN.DimIDNo19Dot1)
                            pointList.Add(BC.BL.BB.Points.P2);

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                            BC.PC.DistLeft += BC.PC.DistInc;
                        }
                    }

                    // Dim No 12
                    if (DN.DimIDNo12)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.BL.BB.Points.P1);
                        pointList.Add(BC.BL.BB.Points.P2);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                            BC.PC.DistLeft += BC.PC.DistInc;
                        }
                    }




                }
                else
                {

                    #region Top Dim
                    Solid solid = null;
                    if (BC.BL.BG is BoltGroup)
                        solid = (BC.BL.BG as BoltGroup).GetSolid();
                    if (BC.BL.BG is Beam)
                        solid = (BC.BL.BG as Beam).GetSolid();

                    Point BoltP = new Point(solid.MaximumPoint.X, Com.CenterPoint(solid).Y);

                    Vect = new Vector(0, 1, 0);

                    // Dim No 5
                    if (DN.DimIDNo5)
                    {
                        pointList = new PointList();
                        pointList.Add(MainBeam.StartPoint);
                        pointList.Add(BC.BL.BB.Points.P3);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                            BC.PC.DistTop += BC.PC.DistInc;
                        }
                    }


                    // Dim No 8, 8.1
                    if (DN.DimIDNo8 || DN.DimIDNo8Dot1)
                    {
                        pointList = new PointList();
                        if (DN.DimIDNo8Dot1)
                            pointList.Add(BC.BL.BB.Points.P1);
                        pointList.Add(BC.BL.BB.Points.P5);
                        if (DN.DimIDNo8)
                            pointList.Add(BoltP);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                            BC.PC.DistTop += BC.PC.DistInc;
                        }
                    }

                    // Dim No 4.1
                    if (DN.DimIDNo4Dot1)
                    {
                        pointList = new PointList();
                        pointList.Add(MainBeam.StartPoint);
                        pointList.Add(BC.BL.BB.Points.P1);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                            BC.PC.DistTop += BC.PC.DistInc;
                        }
                    }


                    // Dim No 4
                    if (DN.DimIDNo4 && BC.BR != null)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.BL.BB.Points.P1);
                        pointList.Add(BC.BR.BB.Points.P1);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                            BC.PC.DistTop += BC.PC.DistInc;
                        }
                    }

                    #endregion

                    #region Bottom Dim
                    Vect = new Vector(0, -1, 0);

                    // Dim No 7, 7.1
                    if (DN.DimIDNo7 || DN.DimIDNo7Dot1)
                    {
                        pointList = new PointList();
                        if (DN.DimIDNo7Dot1)
                            pointList.Add(BC.BL.BB.Points.P1);

                        pointList.Add(BC.Points.P1);

                        if (DN.DimIDNo7)
                            pointList.Add(BC.BL.BB.Points.P3);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceBottP(xDim, BC.Points.P1.Y, BC.PC.DistBot);
                            BC.PC.DistBot += BC.PC.DistInc;
                        }
                    }


                    // Dim No 7.2
                    if (DN.DimIDNo7Dot2)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.BL.BB.Points.P1);
                        pointList.Add(BC.BL.BB.Points.P3);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceBottP(xDim, BC.Points.P1.Y, BC.PC.DistBot);
                            BC.PC.DistBot += BC.PC.DistInc;
                        }
                    }

                    #endregion

                    #region Left Dim
                    Vect = new Vector(-1, 0, 0);

                    // Dim No 9
                    if (DN.DimIDNo9)
                    {
                        pointList = new PointList();

                        pointList.Add(BC.BL.BB.Points.P1);
                        pointList.Add(BoltP);
                        pointList.Add(BC.BL.BB.Points.P2);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                            BC.PC.DistLeft += BC.PC.DistInc;
                        }
                    }

                    // Dim No 12.1, 12.2
                    if (DN.DimIDNo12Dot1 || DN.DimIDNo12Dot2)
                    {
                        pointList = new PointList();
                        if (DN.DimIDNo12Dot1)
                            pointList.Add(BC.BL.BB.Points.P1);

                        pointList.Add(BC.BL.BB.Points.P4);
                        if (DN.DimIDNo12Dot2)
                            pointList.Add(BC.BL.BB.Points.P2);

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                            BC.PC.DistLeft += BC.PC.DistInc;
                        }
                    }

                    // Dim No 12
                    if (DN.DimIDNo12)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.BL.BB.Points.P1);
                        pointList.Add(BC.BL.BB.Points.P2);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                            BC.PC.DistLeft += BC.PC.DistInc;
                        }
                    }


                    #endregion

                }

                if (DN.DimIDNo16 && BC.BL.BB.part is PolyBeam)
                {

                    ContourPoint CP = (BC.BL.BB.part as PolyBeam).Contour.ContourPoints.OfType<ContourPoint>().Where(x => x.Chamfer != null && x.Chamfer.X > 0).FirstOrDefault();
                    PointList Plist = dc.GetRadialChampherPointList(CP, BC.BL.BB.part);
                    RadiusDimension Rd = new RadiusDimension(CView, Plist[0], Plist[1], Plist[2], -5);
                    Rd.Attributes.Placing.Placing = DimensionSetBaseAttributes.Placings.Fixed;
                    Rd.Insert();

                }

                Ids.Add(BC.BL.BB.part.Identifier.ID);
                if (BC.BL.ST != null)
                    Ids.Add(BC.BL.ST.part.Identifier.ID);
            }

            if (BC.BR != null)
            {
                if (!IsTypeA)
                {
                    Vect = new Vector(0, 1, 0);
                    // Dim No 18, 18.1
                    if (DN.DimIDNo18 || DN.DimIDNo18Dot1)
                    {
                        pointList = new PointList();
                        if (DN.DimIDNo18Dot1)
                            pointList.Add(BC.BR.BB.Points.P1);
                        pointList.Add(BC.BR.BB.Points.P5);
                        if (DN.DimIDNo18)
                            pointList.Add(BC.BR.BB.Points.P4);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                    }

                    Vect = new Vector(1, 0, 0);
                    // Dim No 19, 19.1
                    if (DN.DimIDNo19 || DN.DimIDNo19Dot1)
                    {
                        pointList = new PointList();
                        if (DN.DimIDNo19)
                            pointList.Add(BC.BR.BB.Points.P1);

                        pointList.Add(BC.BR.BB.Points.P4);
                        if (DN.DimIDNo19Dot1)
                            pointList.Add(BC.BR.BB.Points.P2);

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                            BC.PC.DistRight += BC.PC.DistInc;
                        }
                    }

                    // Dim No 12
                    if (DN.DimIDNo12)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.BR.BB.Points.P1);
                        pointList.Add(BC.BR.BB.Points.P2);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                            BC.PC.DistRight += BC.PC.DistInc;
                        }
                    }

                }
                else
                {
                    BC.PC.DistTop = BC.PC.DistInc;

                    #region Top Dim

                    Solid solid = null;
                    if (BC.BR.BG is BoltGroup)
                        solid = (BC.BR.BG as BoltGroup).GetSolid();
                    if (BC.BR.BG is Beam)
                        solid = (BC.BR.BG as Beam).GetSolid();

                    Point BoltP = new Point(solid.MinimumPoint.X, Com.CenterPoint(solid).Y);

                    Vect = new Vector(0, 1, 0);

                    // Dim No 5
                    if (DN.DimIDNo5)
                    {
                        pointList = new PointList();
                        pointList.Add(MainBeam.StartPoint);
                        pointList.Add(BC.BR.BB.Points.P3);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                            BC.PC.DistTop += BC.PC.DistInc;
                        }
                    }


                    // Dim No 8, 8.1
                    if (DN.DimIDNo8 || DN.DimIDNo8Dot1)
                    {
                        pointList = new PointList();
                        if (DN.DimIDNo8Dot1)
                            pointList.Add(BC.BR.BB.Points.P1);
                        pointList.Add(BC.BR.BB.Points.P5);
                        if (DN.DimIDNo8)
                            pointList.Add(BoltP);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                            BC.PC.DistTop += BC.PC.DistInc;
                        }
                    }

                    // Dim No 4.1
                    if (DN.DimIDNo4Dot1)
                    {
                        pointList = new PointList();
                        pointList.Add(MainBeam.StartPoint);
                        pointList.Add(BC.BR.BB.Points.P1);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                            BC.PC.DistTop += BC.PC.DistInc;
                        }
                    }

                    #endregion

                    #region Bottom Dim
                    Vect = new Vector(0, -1, 0);

                    // Dim No 7, 7.1
                    if (DN.DimIDNo7 || DN.DimIDNo7Dot1)
                    {
                        pointList = new PointList();
                        if (DN.DimIDNo7Dot1)
                            pointList.Add(BC.BR.BB.Points.P1);

                        pointList.Add(BC.Points.P4);

                        if (DN.DimIDNo7)
                            pointList.Add(BC.BR.BB.Points.P3);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceBottP(xDim, BC.Points.P4.Y, BC.PC.DistBot);
                            BC.PC.DistBot += BC.PC.DistInc;
                        }
                    }


                    // Dim No 7.2
                    if (DN.DimIDNo7Dot2)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.BR.BB.Points.P1);
                        pointList.Add(BC.BR.BB.Points.P3);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceBottP(xDim, BC.Points.P4.Y, BC.PC.DistBot);
                            BC.PC.DistBot += BC.PC.DistInc;
                        }
                    }

                    #endregion

                    #region Right Dim
                    Vect = new Vector(1, 0, 0);

                    // Dim No 9
                    if (DN.DimIDNo9)
                    {
                        pointList = new PointList();

                        pointList.Add(BC.BR.BB.Points.P1);
                        pointList.Add(BoltP);
                        pointList.Add(BC.BR.BB.Points.P2);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceLeftP(xDim, BC.PC.RightX, BC.PC.DistRight);
                            BC.PC.DistRight += BC.PC.DistInc;
                        }
                    }

                    // Dim No 12.1, 12.2
                    if (DN.DimIDNo12Dot1 || DN.DimIDNo12Dot2)
                    {
                        pointList = new PointList();
                        if (DN.DimIDNo12Dot1)
                            pointList.Add(BC.BR.BB.Points.P1);

                        pointList.Add(BC.BR.BB.Points.P4);
                        if (DN.DimIDNo12Dot2)
                            pointList.Add(BC.BR.BB.Points.P2);

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceLeftP(xDim, BC.PC.RightX, BC.PC.DistRight);
                            BC.PC.DistRight += BC.PC.DistInc;
                        }
                    }

                    // Dim No 12
                    if (DN.DimIDNo12)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.BR.BB.Points.P1);
                        pointList.Add(BC.BR.BB.Points.P2);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceLeftP(xDim, BC.PC.RightX, BC.PC.DistRight);
                            BC.PC.DistRight += BC.PC.DistInc;
                        }
                    }

                    #endregion

                }


                if (DN.DimIDNo16 && BC.BR.BB.part is PolyBeam)
                {

                    ContourPoint CP = (BC.BR.BB.part as PolyBeam).Contour.ContourPoints.OfType<ContourPoint>().Where(x => x.Chamfer != null && x.Chamfer.X > 0).FirstOrDefault();
                    PointList Plist = dc.GetRadialChampherPointList(CP, BC.BR.BB.part);
                    RadiusDimension Rd = new RadiusDimension(CView, Plist[2], Plist[1], Plist[0], -5);
                    Rd.Attributes.Placing.Placing = DimensionSetBaseAttributes.Placings.Fixed;
                    Rd.Insert();

                }

                Ids.Add(BC.BR.BB.part.Identifier.ID);
                if (BC.BR.ST != null)
                    Ids.Add(BC.BR.ST.part.Identifier.ID);
            }
        }

        #region Get Data

        private void GetBeamClassClass()
        {
            BC = new BeamClass_BBP1();
            BC.beam = MainBeam;
            BC.Points = Com.GetPartPoints(BC.beam);
            List<TSM.Part> PartListC = BC.beam.GetAssembly().GetSecondaries().OfType<TSM.Part>().ToList();

            Point CentP = Com.CenterPoint(BC.beam.StartPoint, BC.beam.EndPoint);
            double Lenght = (BC.beam.GetSolid().MaximumPoint.X - BC.beam.GetSolid().MinimumPoint.X) / 10;
            double MinX = BC.beam.GetSolid().MinimumPoint.X;
            double MaxX = BC.beam.GetSolid().MaximumPoint.X;


            if (ViewName == "Front View")
            {
                List<TSM.Part> PartListF = (from p in PartListC where !Ids.Contains(p.Identifier.ID) select p).ToList();

                GetBentPlateClass(PartListF);
            }
            else if (ViewName == "Top View" || ViewName == "Bottom View")
            {
                List<TSM.Part> PartListF = (from p in PartListC where !Ids.Contains(p.Identifier.ID) && Com.CenterPoint(p).Y > BC.Points.CentP.Y select p).ToList();

                BC.BT = GetBentPlateClassTop(PartListF, "Top");

                PartListF = (from p in PartListC where !Ids.Contains(p.Identifier.ID) && Com.CenterPoint(p).Y < BC.Points.CentP.Y select p).ToList();

                BC.BB = GetBentPlateClassTop(PartListF, "Bottom");
            }
            else if (ViewName == "Section View")
            {

                List<TSM.Part> PartList = (from p in PartListC where Com.IsViewObj(p, CView) && Com.CenterPoint(p).X > BC.Points.CentP.X select p).ToList();

                GetBentClassS(PartList, "Right");

                PartList = (from p in PartListC where Com.IsViewObj(p, CView) && Com.CenterPoint(p).X < BC.Points.CentP.X select p).ToList();

                GetBentClassS(PartList, "Left");
            }

            PartListC.Add(MainBeam);

            TSM.Part LeftPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.X ascending select p).FirstOrDefault();
            TSM.Part RightPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.X descending select p).FirstOrDefault();
            TSM.Part TopPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.Y descending select p).FirstOrDefault();
            TSM.Part BottPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.Y ascending select p).FirstOrDefault();

            BC.PC = new PlacingClass();
            BC.PC.TopY = TopPart.GetSolid().MaximumPoint.Y;
            BC.PC.BottomY = BottPart.GetSolid().MinimumPoint.Y;

            BC.PC.LeftX = LeftPart.GetSolid().MinimumPoint.X;// Math.Round(CView.RestrictionBox.MinPoint.X);
            BC.PC.RightX = RightPart.GetSolid().MaximumPoint.X;
            if (ViewName == "Section View")
            {
                if (BC.BL != null)
                    BC.PC.LeftX = BC.BL.BB.part.GetSolid().MinimumPoint.X;

                if (BC.BR != null)
                    BC.PC.RightX = BC.BR.BB.part.GetSolid().MaximumPoint.X;
            }

            double AvScale = 12;
            double AvDistInc = 100;
            double DistPerScale = AvDistInc / AvScale;
            double CScale = CView.Attributes.Scale;
            BC.PC.DistInc = CScale * DistPerScale;
            BC.PC.DistBot = BC.PC.DistInc;
            BC.PC.DistTop = BC.PC.DistInc;
            BC.PC.DistLeft = BC.PC.DistInc;
            BC.PC.DistRight = BC.PC.DistInc;

        }

        private void GetBentPlateClass(List<TSM.Part> PartListF)
        {
            TSM.Part BentPlate = null;
            TSM.Part BentPlate1 = null;

            TSM.Part STL = null;
            TSM.Part STR = null;


            double MinX = BC.beam.GetSolid().MinimumPoint.X;
            double MaxX = BC.beam.GetSolid().MaximumPoint.X;

            BentPlate = (from p in PartListF where Com.GetNote5(p).ToUpper().Contains("BBP1") orderby Com.CenterPoint(p).X ascending select p).FirstOrDefault();


            if (BentPlate != null)
            {
                BC.BPC = new BentPlateClass();

                BentPlate1 = (from p in PartListF where Com.GetNote5(p).ToUpper().Contains("BBP1") && p.Identifier.ID != BentPlate.Identifier.ID && (Com.IsEqualPoints(BentPlate.GetSolid().MinimumPoint, p.GetSolid().MinimumPoint) || Com.IsEqualPoints(BentPlate.GetSolid().MaximumPoint, p.GetSolid().MaximumPoint)) orderby Com.CenterPoint(p).X ascending select p).FirstOrDefault();

                BC.BPC.BPC = Com.GetPartClass(BentPlate);

                MinX = BentPlate.GetSolid().MinimumPoint.X;
                double MinXL = BentPlate.GetSolid().MaximumPoint.X - 50;
                double MaxXL = BentPlate.GetSolid().MinimumPoint.X + 50;
                MaxX = BentPlate.GetSolid().MaximumPoint.X;


                STL = (from p in PartListF where !p.Name.ToUpper().Contains("STUD") && (Com.CenterPoint(p).X >= MinX && Com.CenterPoint(p).X <= MaxXL && Com.CenterPoint(p).Y > BC.Points.P1.Y && Com.CenterPoint(p).X < BC.BPC.BPC.Points.CentP.X) && !dc.IsHorzObj(p) orderby Com.CenterPoint(p).X ascending select p).FirstOrDefault();

                STR = (from p in PartListF where !p.Name.ToUpper().Contains("STUD") && (Com.CenterPoint(p).X >= MinXL && Com.CenterPoint(p).X <= MaxX && Com.CenterPoint(p).Y > BC.Points.P1.Y && Com.CenterPoint(p).X > BC.BPC.BPC.Points.CentP.X) && !dc.IsHorzObj(p) orderby Com.CenterPoint(p).X ascending select p).FirstOrDefault();

                if (BC.BPC.BPC?.BoltPList != null && BC.BPC.BPC?.BoltPList.Count > 0)
                {
                    BoltGroup BoltG = (from b in Com.EnumtoArray(BentPlate.GetBolts()).OfType<BoltGroup>() orderby Com.CenterPoint(b).Y descending select b).FirstOrDefault();

                    double Yval = BentPlate.GetSolid().MinimumPoint.Y + ((BentPlate.GetSolid().MaximumPoint.Y - BentPlate.GetSolid().MinimumPoint.Y) / 3);

                    if (Com.CenterPoint(BoltG).Y > Yval)
                    {
                        BC.BPC.IsFrontBolt = true;
                        BC.BPC.BPC.BoltPList = Com.GetBoltPoints(BoltG);
                    }
                    else
                        BC.BPC.BPC.BoltPList = null;

                }

                if (!BC.BPC.IsFrontBolt && BC.BPC.BPC.BoltPList == null)
                {
                    BC.BPC.BPC.BoltPList = GetStudPoints(BC.BPC.BPC);
                    if (BC.BPC.BPC.BoltPList != null)
                        BC.BPC.IsFrontBolt = true;

                }



                if (BentPlate1 != null)
                    BC.BPC.BPC1 = Com.GetPartClass(BentPlate1);

                if (STL != null)
                    BC.BPC.STL = Com.GetPartClass(STL);

                if (STR != null)
                    BC.BPC.STR = Com.GetPartClass(STR);


                GetBentPlateClass(PartListF, BentPlate);
            }

        }

        private PointList GetStudPoints(PartClass BPC)
        {
            PointList PTList = null;
            List<TSM.Beam> StudList = BC.beam.GetAssembly().GetSecondaries().OfType<TSM.Beam>().ToList().Where(x => x.Name.ToLower().Contains("stud")).ToList();
            if (StudList != null && StudList.Count > 0)
            {
                List<Point> Points = (from b in StudList where b.StartPoint.X > BPC.Points.P1.X && b.StartPoint.X < BPC.Points.P4.X select b.StartPoint).ToList();
                if (Points != null && Points.Count > 0)
                {
                    PTList = new PointList();
                    PTList = Com.PointToPointList(Points);
                }
            }
            return PTList;
        }

        private void GetBentPlateClass(List<TSM.Part> PartListF, TSM.Part BentPlateN)
        {
            TSM.Part BentPlate = null;
            TSM.Part BentPlate1 = null;

            TSM.Part STL = null;
            TSM.Part STR = null;


            double MinX = BC.beam.GetSolid().MinimumPoint.X;
            double MaxX = BC.beam.GetSolid().MaximumPoint.X;

            double MinXB = BentPlateN.GetSolid().MaximumPoint.X + 50;
            double MinXB1 = BentPlateN.GetSolid().MaximumPoint.X;
            BentPlate = (from p in PartListF where Com.GetNote5(p).ToUpper().Contains("BBP1") && p.GetSolid().MinimumPoint.X < MinXB && p.GetSolid().MinimumPoint.X > MinXB1 orderby Com.CenterPoint(p).X ascending select p).FirstOrDefault();
            if (BentPlate != null)
            {

                BC.BPCN = new BentPlateClass();

                BentPlate1 = (from p in PartListF where Com.GetNote5(p).ToUpper().Contains("BBP1") && p.Identifier.ID != BentPlate.Identifier.ID && (Com.IsEqualPoints(BentPlate.GetSolid().MinimumPoint, p.GetSolid().MinimumPoint) || Com.IsEqualPoints(BentPlate.GetSolid().MaximumPoint, p.GetSolid().MaximumPoint)) && p.GetSolid().MinimumPoint.X < MinXB && p.GetSolid().MinimumPoint.X > MinXB1 orderby Com.CenterPoint(p).X ascending select p).FirstOrDefault();

                BC.BPCN.BPC = Com.GetPartClass(BentPlate);

                MinX = BentPlate.GetSolid().MinimumPoint.X;
                MaxX = BentPlate.GetSolid().MaximumPoint.X;


                STL = (from p in PartListF where (Com.CenterPoint(p).X >= MinX && Com.CenterPoint(p).X <= MaxX && Com.CenterPoint(p).Y > BC.Points.P1.Y && Com.CenterPoint(p).X < BC.BPCN.BPC.Points.CentP.X) && !dc.IsHorzObj(p) orderby Com.CenterPoint(p).X ascending select p).FirstOrDefault();

                STR = (from p in PartListF where (Com.CenterPoint(p).X >= MinX && Com.CenterPoint(p).X <= MaxX && Com.CenterPoint(p).Y > BC.Points.P1.Y && Com.CenterPoint(p).X > BC.BPCN.BPC.Points.CentP.X) && !dc.IsHorzObj(p) orderby Com.CenterPoint(p).X ascending select p).FirstOrDefault();

                if (BC.BPCN.BPC?.BoltPList != null && BC.BPCN.BPC?.BoltPList.Count > 0)
                {
                    BoltGroup BoltG = (from b in Com.EnumtoArray(BentPlate.GetBolts()).OfType<BoltGroup>() orderby Com.CenterPoint(b).Y descending select b).FirstOrDefault();

                    double Yval = BentPlate.GetSolid().MinimumPoint.Y + ((BentPlate.GetSolid().MaximumPoint.Y - BentPlate.GetSolid().MinimumPoint.Y) / 3);

                    BC.BPCN.BPC.BoltPList = Com.GetBoltPoints(BoltG);

                }

                if (BentPlate1 != null)
                    BC.BPCN.BPC1 = Com.GetPartClass(BentPlate1);

                if (STL != null)
                    BC.BPCN.STL = Com.GetPartClass(STL);

                if (STR != null)
                    BC.BPCN.STR = Com.GetPartClass(STR);
            }

        }

        private BentPlateClass GetBentPlateClassTop(List<TSM.Part> PartListF, string PosV)
        {

            BentPlateClass BP = null;
            if (PartListF.Count > 0)
            {
                TSM.Part BentPlate = null;

                TSM.Part STL = null;
                TSM.Part STR = null;


                double MinX = BC.beam.GetSolid().MinimumPoint.X;
                double MaxX = BC.beam.GetSolid().MaximumPoint.X;

                BentPlate = (from p in PartListF where (Com.GetNote5(p).ToUpper().Contains("BBP1") && Com.CenterPoint(p).Y > BC.Points.CentP.Y) orderby Com.CenterPoint(p).X ascending select p).FirstOrDefault();


                if (PosV == "Bottom")
                {
                    if (BC.BT != null)
                    {
                        double MinXX = BC.BT.BPC.part.GetSolid().MinimumPoint.X;
                        double MaxXX = BC.BT.BPC.part.GetSolid().MaximumPoint.X;

                        BentPlate = (from p in PartListF where (Com.CenterPoint(p).X >= MinXX && Com.CenterPoint(p).X <= MaxXX && Com.CenterPoint(p).Y < BC.Points.CentP.Y) && Com.GetNote5(p).ToUpper().Contains("BBP1") orderby Com.CenterPoint(p).X ascending select p).FirstOrDefault();
                    }
                    else
                        BentPlate = (from p in PartListF where (Com.GetNote5(p).ToUpper().Contains("BBP1") && Com.CenterPoint(p).Y < BC.Points.CentP.Y) orderby Com.CenterPoint(p).X ascending select p).FirstOrDefault();
                }


                if (BentPlate != null)
                {
                    BP = new BentPlateClass();

                    BP.BPC = Com.GetPartClass(BentPlate);

                    double MinXL = BentPlate.GetSolid().MaximumPoint.X - 50;
                    double MaxXL = BentPlate.GetSolid().MinimumPoint.X + 50;

                    MinX = BentPlate.GetSolid().MinimumPoint.X;
                    MaxX = BentPlate.GetSolid().MaximumPoint.X;


                    STL = (from p in PartListF where !p.Name.ToUpper().Contains("STUD") && (Com.CenterPoint(p).X >= MinX && Com.CenterPoint(p).X <= MaxXL && Com.CenterPoint(p).X < BP.BPC.Points.CentP.X) && !dc.IsHorzObj(p) orderby Com.CenterPoint(p).X ascending select p).FirstOrDefault();

                    STR = (from p in PartListF where !p.Name.ToUpper().Contains("STUD") && (Com.CenterPoint(p).X >= MinXL && Com.CenterPoint(p).X <= MaxX && Com.CenterPoint(p).X > BP.BPC.Points.CentP.X) && !dc.IsHorzObj(p) orderby Com.CenterPoint(p).X ascending select p).FirstOrDefault();

                    if (BP.BPC?.BoltPList != null && BP.BPC?.BoltPList.Count > 0)
                    {
                        List<BoltGroup> Bolts = (from b in Com.EnumtoArray(BentPlate.GetBolts()).OfType<BoltGroup>() where b.GetSolid().MaximumPoint.Y < BC.Points.P1.Y select b).ToList();

                        BoltGroup BoltG = (from b in Com.EnumtoArray(BentPlate.GetBolts()).OfType<BoltGroup>() where b.GetSolid().MaximumPoint.Y < BC.Points.P1.Y select b).FirstOrDefault();

                        if (PosV == "Bottom")
                            Bolts = (from b in Com.EnumtoArray(BentPlate.GetBolts()).OfType<BoltGroup>() where b.GetSolid().MinimumPoint.Y > BC.Points.P2.Y select b).ToList();

                        double Yval = BentPlate.GetSolid().MinimumPoint.Y + ((BentPlate.GetSolid().MaximumPoint.Y - BentPlate.GetSolid().MinimumPoint.Y) / 3);

                        if (Bolts != null && Bolts.Count > 0)
                            BP.BPC.BoltPList = Com.GetBoltPoints(Bolts);
                        else
                            BP.BPC.BoltPList = null;
                    }

                    if (STL != null)
                        BP.STL = Com.GetPartClass(STL);

                    if (STR != null)
                        BP.STR = Com.GetPartClass(STR);



                }
            }

            if (BP != null)
            {
                if (PosV == "Bottom")
                    BC.BBN = GetBentPlateClassTop(PartListF, BP.BPC.part, PosV);
                else
                    BC.BTN = GetBentPlateClassTop(PartListF, BP.BPC.part, PosV);
            }


            return BP;
        }

        private BentPlateClass GetBentPlateClassTop(List<TSM.Part> PartListF, TSM.Part BentPlateN, string PosV)
        {

            BentPlateClass BP = null;
            TSM.Part BentPlate = null;

            TSM.Part STL = null;
            TSM.Part STR = null;


            double MinX = BC.beam.GetSolid().MinimumPoint.X;
            double MaxX = BC.beam.GetSolid().MaximumPoint.X;

            double MinXB = BentPlateN.GetSolid().MaximumPoint.X + 50;
            double MinXB1 = BentPlateN.GetSolid().MaximumPoint.X;


            BentPlate = (from p in PartListF where (Com.GetNote5(p).ToUpper().Contains("BBP1") && Com.CenterPoint(p).Y > BC.Points.CentP.Y) && p.GetSolid().MinimumPoint.X < MinXB && p.GetSolid().MinimumPoint.X > MinXB1 orderby Com.CenterPoint(p).X ascending select p).FirstOrDefault();

            if (PosV == "Bottom")
                BentPlate = (from p in PartListF where (Com.GetNote5(p).ToUpper().Contains("BBP1") && Com.CenterPoint(p).Y < BC.Points.CentP.Y) && p.GetSolid().MinimumPoint.X < MinXB && p.GetSolid().MinimumPoint.X > MinXB1 orderby Com.CenterPoint(p).X ascending select p).FirstOrDefault();


            if (BentPlate != null)
            {

                BP = new BentPlateClass();


                BP.BPC = Com.GetPartClass(BentPlate);

                MinX = BentPlate.GetSolid().MinimumPoint.X;
                MaxX = BentPlate.GetSolid().MaximumPoint.X;


                STL = (from p in PartListF where !p.Name.ToUpper().Contains("STUD") && (Com.CenterPoint(p).X >= MinX && Com.CenterPoint(p).X <= MaxX && Com.CenterPoint(p).X < BP.BPC.Points.CentP.X) && !dc.IsHorzObj(p) orderby Com.CenterPoint(p).X ascending select p).FirstOrDefault();

                STR = (from p in PartListF where !p.Name.ToUpper().Contains("STUD") && (Com.CenterPoint(p).X >= MinX && Com.CenterPoint(p).X <= MaxX && Com.CenterPoint(p).X > BP.BPC.Points.CentP.X) && !dc.IsHorzObj(p) orderby Com.CenterPoint(p).X ascending select p).FirstOrDefault();

                if (BP.BPC?.BoltPList != null && BP.BPC?.BoltPList.Count > 0)
                {
                    List<BoltGroup> Bolts = (from b in Com.EnumtoArray(BentPlate.GetBolts()).OfType<BoltGroup>() where b.GetSolid().MaximumPoint.Y < BC.Points.P1.Y select b).ToList();

                    if (PosV == "Bottom")
                        Bolts = (from b in Com.EnumtoArray(BentPlate.GetBolts()).OfType<BoltGroup>() where b.GetSolid().MinimumPoint.Y > BC.Points.P2.Y select b).ToList();

                    double Yval = BentPlate.GetSolid().MinimumPoint.Y + ((BentPlate.GetSolid().MaximumPoint.Y - BentPlate.GetSolid().MinimumPoint.Y) / 3);

                    if (Bolts != null && Bolts.Count > 0)
                        BP.BPC.BoltPList = Com.GetBoltPoints(Bolts);
                    else
                        BP.BPC.BoltPList = null;

                }

                if (STL != null)
                    BP.STL = Com.GetPartClass(STL);

                if (STR != null)
                    BP.STR = Com.GetPartClass(STR);
            }

            return BP;

        }

        private void GetBentClassS(List<TSM.Part> PartListF, string PosH)
        {
            BentPlateClassS BP = null;

            TSM.Part BentPlate = PartListF.Where(x => Com.GetNote5(x).ToUpper().Contains("BBP1")).FirstOrDefault();
            if (BentPlate != null)
            {
                BP = new BentPlateClassS();
                BP.BB = Com.GetPartClass(BentPlate);
                List<Point> VList = Com.GetVertxPointsD(BentPlate).OfType<Point>().Where(x => x.Z > CView.RestrictionBox.MinPoint.Z).ToList();
                PointList VertPlist = Com.PointToPointList(VList);
                if (PosH == "Left")
                {
                    BP.BB.Points.P1 = Com.MinPofY(VertPlist, "X", Com.MaxP(VertPlist, "Y").Y);
                    BP.BB.Points.P2 = Com.MinPofY(VertPlist, "X", Com.MinP(VertPlist, "Y").Y);
                    BP.BB.Points.P3 = Com.MaxPofY(VertPlist, "X", Com.MinP(VertPlist, "Y").Y);
                    BP.BB.Points.P4 = Com.MaxPofX(VertPlist, "Y", Com.MaxP(VertPlist, "X").X);
                    BP.BB.Points.P5 = Com.MaxPofY(VertPlist, "X", Com.MaxP(VertPlist, "Y").Y);
                }
                else
                {
                    BP.BB.Points.P1 = Com.MaxPofY(VertPlist, "X", Com.MaxP(VertPlist, "Y").Y);
                    BP.BB.Points.P2 = Com.MaxPofY(VertPlist, "X", Com.MinP(VertPlist, "Y").Y);
                    BP.BB.Points.P3 = Com.MinPofY(VertPlist, "X", Com.MinP(VertPlist, "Y").Y);
                    BP.BB.Points.P4 = Com.MaxPofX(VertPlist, "Y", Com.MinP(VertPlist, "X").X);
                    BP.BB.Points.P5 = Com.MinPofY(VertPlist, "X", Com.MaxP(VertPlist, "Y").Y);
                }

                BP.BG = (from b in Com.EnumtoArray(BentPlate.GetBolts()).OfType<BoltGroup>().ToList() where b.BoltStandard.ToUpper().Contains("STUD") && IsInsideView(b) orderby Com.CenterPoint(b).Y descending select b).FirstOrDefault();

                if (BP.BG == null)
                    BP.BG = (from b in PartListF.OfType<Beam>() where b.Name.ToUpper().Contains("STUD") orderby Com.CenterPoint(b).Y descending select b).FirstOrDefault();

                TSM.Part Stiff = PartListF.OfType<TSM.ContourPlate>().FirstOrDefault();
                if (Stiff != null)
                    BP.ST = Com.GetPartClass(Stiff);

                if (PosH == "Left")
                    BC.BL = BP;
                else
                    BC.BR = BP;
            }

        }

        private bool IsInsideView(BoltGroup b)
        {
            double MinZ = CView.RestrictionBox.MinPoint.Z;
            double maxZ = CView.RestrictionBox.MaxPoint.Z;
            double MinZB = b.GetSolid().MinimumPoint.Z;
            double maxZB = b.GetSolid().MaximumPoint.Z;

            if ((MinZ >= MinZB && MinZ <= maxZB) || (maxZ >= MinZB && maxZ <= maxZB))
                return true;
            else
                return false;


        }

        #endregion

        #region Helping Methods


        #endregion

        private class BentPlateClass
        {
            public PartClass BPC { get; set; }
            public PartClass BPC1 { get; set; }
            public PartClass STL { get; set; }
            public PartClass STR { get; set; }
            public bool IsFrontBolt = false;
        }

        private class BentPlateClassS
        {
            public PartClass BB { get; set; }
            public PartClass ST { get; set; }
            public TSM.ModelObject BG { get; set; }

        }

        private class BeamClass_BBP1
        {
            public Beam beam { get; set; }
            public BentPlateClass BPC { get; set; }
            public BentPlateClass BPCN { get; set; } // Next Bent Plate not More than 50 mm
            public PartPoints Points { get; set; }
            public PlacingClass PC { get; set; }


            public BentPlateClass BT { get; set; }
            public BentPlateClass BTN { get; set; } // Next Bent Plate not More than 50 mm

            public BentPlateClass BB { get; set; }
            public BentPlateClass BBN { get; set; } // Next Bent Plate not More than 50 mm


            public BentPlateClassS BL { get; set; }
            public BentPlateClassS BR { get; set; }

        }
    }

}
