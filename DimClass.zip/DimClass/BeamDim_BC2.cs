﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Tekla.Structures;
using Tekla.Structures.Drawing;
using Tekla.Structures.Geometry3d;
using Tekla.Structures.Model;
using TSD = Tekla.Structures.Drawing;
using TSM = Tekla.Structures.Model;
using VirtueleDrawingAutomation;
using TSDD = Tekla.Structures.Datatype;
using TSG = Tekla.Structures.Geometry3d;

namespace Auto_Detailing_Tool_Beam
{
    public class BeamDim_BC2
    {
        #region Global Variables
        DimCom dc = new DimCom();
        StraightDimensionSet.StraightDimensionSetAttributes StAtrr = new StraightDimensionSet.StraightDimensionSetAttributes("standard");
        StraightDimensionSet.StraightDimensionSetAttributes RdAtrr = new StraightDimensionSet.StraightDimensionSetAttributes("standard");

        public Beam MainBeam = null;
        VirtueleDrawingAutomation.Json.DrawingAttributeInfoJson.AttributeFiles dimAttrClass = null;
        List<TSD.StraightDimension> KnockDim = new List<StraightDimension>();
        BeamClass_BC2 BC = null;

        VirtueleDrawingAutomation.Json.AutoDimensionTypesJson.BC2Json DN = null;
        string Position = "Left";
        TSD.View CView = null;
        string ViewName = "";
        public Point LeftEnd = null;
        public Point RightEnd = null;
        #endregion

        public void ApplyDim(TSD.View CView, string ViewName, AutoDimensioningTypes autoDimensioningTypes, DrawingAttributeInfo drawingAttributeInfo, string Position)
        {
            try
            {
                Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane());
                //Set model everything to the view
                Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane(CView.DisplayCoordinateSystem));

                this.CView = CView;
                this.dimAttrClass = drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files;
                this.DN = autoDimensioningTypes.Bc2;
                this.Position = Position;
                StAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.StandardDimension);
                RdAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.RunningDimension);
                this.MainBeam = (Com.MyModel.SelectModelObject(new Identifier((CView.GetDrawing() as AssemblyDrawing).AssemblyIdentifier.ID)) as TSM.Assembly).GetMainPart() as TSM.Beam;
                this.MainBeam.Select();
                string ProType = Com.GetProType(MainBeam);
                this.ViewName = ViewName;

                if (this.Position == "Left")
                {
                    LeftEnd = null;
                    RightEnd = null;
                }

                GetBeamClassClass(CView);

                if (this.Position == "Left")
                {
                    if (ViewName == "Front View")
                        ApplyDimTypeLeft();
                    else
                    if (ViewName == "Section View")
                        AppySectionDim();
                    if (ViewName == "Detail View")
                        ApplyDimTypeLeftD();
                }
                else if (this.Position == "Right")
                {
                    if (ViewName == "Front View")
                        ApplyDimTypeRight();
                    else
                    if (ViewName == "Section View")
                        AppySectionDim();
                    if (ViewName == "Detail View")
                        ApplyDimTypeRightD();
                }
            }
            catch (Exception ex)
            { }

            Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane());
        }

        #region Front View

        private void ApplyDimTypeLeft()
        {

            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(-1, 0, 0);
            TSD.PointList TempList = new PointList();

            if (BC.CutTop != null)
            {
                Vect = new Vector(0, 1, 0);
                // Dim No 26
                if (DN.DimIDNo26)
                {
                    pointList = new PointList();
                    pointList.Add(BC.CutTop.P1);
                    pointList.Add(BC.CutTop.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                }

            }

            if (BC.CutBott != null)
            {
                //Vect = new Vector(0, -1, 0);
                //// Dim No 8
                //if (DN.DimIDNo8)
                //{
                //    pointList = new PointList();
                //    pointList.Add(BC.CutBott.P1);
                //    pointList.Add(BC.CutBott.P2);
                //    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                //    if (xDim != null)
                //        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                //}

            }

            //if (DN.DimIDNo4 || BC.CutBott != null || BC.CutTop != null)
            //    BC.PC.DistLeft += BC.PC.DistInc;



            if (DN.DimIDNo6 || BC.CutTop != null)
                BC.PC.DistTop += BC.PC.DistInc;


            TSG.Line XLine = new TSG.Line(BC.Angle.Points.P1, BC.Angle.Points.P4);
            TSG.Line YLine = new TSG.Line(BC.Angle.Points.P1, BC.Angle.Points.P2);

            Vector LeftVect = XLine.Direction;

            if (LeftVect.X > 0)
                LeftVect = dc.ChangeVector(LeftVect);

            Vector RightVect = XLine.Direction;
            if (RightVect.X < 0)
                RightVect = dc.ChangeVector(RightVect);

            Vector TopVect = YLine.Direction;
            if (TopVect.Y < 0)
                TopVect = dc.ChangeVector(TopVect);

            Vector BottVect = YLine.Direction;
            if (BottVect.Y > 0)
                BottVect = dc.ChangeVector(BottVect);

            // Dim No 1
            if (DN.DimIDNo1)
            {
                pointList = new PointList();
                pointList.Add(BC.Angle.Points.P1);
                pointList.Add(BC.Points.P1);
                xDim = dc.InsertDim(CView, pointList, TopVect, BC.PC.DistTop, StAtrr);
                if (xDim != null)
                {
                    PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                    BC.PC.DistTop += BC.PC.DistInc;
                }
            }

            if (BC.BoltsE != null)
            {

                // Dim No 19, 19.1
                if ((DN.DimIDNo19 || DN.DimIDNo19Dot1) && BC.IsFrontBolt)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo19)
                        pointList.Add(BC.Angle.Points.P1);
                    pointList.Add(Com.MinP(BC.BoltsE, "Y"));
                    if (DN.DimIDNo19Dot1)
                        pointList.Add(BC.Angle.Points.P4);
                    xDim = dc.InsertDim(CView, pointList, TopVect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }

                Point MinXP = Com.MinP(dc.GetVertexList(MainBeam.GetSolid()), "X");

                Vect = new Vector(0, 1, 0);
                // Dim 25 // Rd Dim
                if (DN.DimIDNo25 && BC.IsFrontBolt)
                {
                    BC.PC.DistTop += BC.PC.DistInc;
                    pointList = new PointList();
                    pointList.Add(MinXP);
                    pointList.Add(Com.MaxP(BC.BoltsE, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }
                else if (DN.DimIDNo25Dot1 && BC.IsFrontBolt)
                {
                    pointList = new PointList();
                    pointList.Add(MinXP);
                    pointList.Add(Com.MaxP(BC.BoltsE, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                    pointList = new PointList();
                    pointList.Add(MinXP);
                    pointList.Add(Com.MaxP(BC.BoltsE, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }

                Vect = new Vector(-1, 0, 0);

                BC.PC.DistLeft = (BC.PC.DistInc * 2);
                // Dim No 2.2
                if (DN.DimIDNo2 || DN.DimIDNo3)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo2)
                    {
                        pointList.Add(BC.Points.P5);
                        pointList.Add(Com.MaxP(BC.BoltsE, "Y"));
                    }

                    if (DN.DimIDNo3)
                        pointList.AddRange(BC.BoltsE);

                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                }

                // Dim No 3.1
                if (DN.DimIDNo3Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(BC.BoltsE, "Y"));

                    pointList.Add(BC.Angle.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                }

                if (DN.DimIDNo2 || DN.DimIDNo3 || DN.DimIDNo3Dot1)
                    BC.PC.DistLeft += BC.PC.DistInc;

                // Dim No 11
                if (DN.DimIDNo11)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(BC.BoltsE, "Y"));
                    pointList.Add(MainBeam.StartPoint);
                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                }

                // Dim No 3.2
                if (DN.DimIDNo3Dot2)
                {
                    if (BC.BoltsE.Count > 2)
                    {
                        pointList = new PointList();
                        pointList.AddRange(BC.BoltsE);
                        xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                            Com.GroupDim(xDim);
                        }
                    }
                }

                if (DN.DimIDNo11 || DN.DimIDNo3Dot2)
                    BC.PC.DistLeft += BC.PC.DistInc;

                // Dim No 10
                if (DN.DimIDNo10)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(BC.BoltsE, "Y"));
                    pointList.Add(MainBeam.StartPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }
                }

                // Dim No 10.1
                if (DN.DimIDNo10Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(BC.BoltsE, "Y"));
                    pointList.Add(MainBeam.StartPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }
                }

                // Dim No 4
                if (DN.DimIDNo4)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Angle.Points.P2);
                    pointList.Add(BC.Angle.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, BottVect, BC.PC.DistInc, StAtrr);
                    if (xDim != null)
                        BC.PC.DistBot += (BC.PC.DistInc * 0.5);
                }

                Vect = new Vector(0, -1, 0);
                // Dim 25 // Rd Dim
                if (DN.DimIDNo27 && BC.IsFrontBolt)
                {
                    BC.PC.DistBot += BC.PC.DistInc;
                    pointList = new PointList();
                    pointList.Add(MinXP);
                    pointList.Add(Com.MinP(BC.BoltsE, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }
                else if (DN.DimIDNo27Dot1 && BC.IsFrontBolt)
                {
                    pointList = new PointList();
                    pointList.Add(MinXP);
                    pointList.Add(Com.MinP(BC.BoltsE, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                    pointList = new PointList();
                    pointList.Add(MinXP);
                    pointList.Add(Com.MinP(BC.BoltsE, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }

                // Dim No 28
                if (DN.DimIDNo28)
                {
                    pointList = new PointList();
                    pointList.Add(MinXP);
                    pointList.Add(Com.MaxP(dc.GetVertexList(MainBeam.GetSolid()), "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }


            }

            // Dim No 13 Elevation Dim
            if (DN.DimIDNo13)
            {

                Vect = new Vector(-1, 0, 0);
                StraightDimensionSet.StraightDimensionSetAttributes ElAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.ElevationDimension);
                ElAtrr.DimensionType = DimensionSetBaseAttributes.DimensionTypes.Elevation;
                ElAtrr.Arrowhead.Head = ArrowheadTypes.FilledArrow;
                pointList = new PointList();

                if (MainBeam.StartPoint.X > MainBeam.EndPoint.X)
                {
                    pointList.Add(MainBeam.EndPoint);
                    pointList.Add(MainBeam.EndPoint);

                }
                else
                {
                    pointList.Add(MainBeam.StartPoint);
                    pointList.Add(MainBeam.StartPoint);
                }

                BC.PC.DistLeft = BC.PC.DistLeft - (BC.Points.P1.X - pointList[0].X);
                xDim = dc.InsertDimm(CView, pointList, Vect, (-BC.PC.DistLeft), ElAtrr);
                if (xDim != null)
                {
                    xDim.Distance = (-BC.PC.DistLeft);
                    xDim.Modify();
                }
                BC.PC.DistLeft += BC.PC.DistInc;

            }


            // Dim No 29 Angle Dimension
            if (DN.DimIDNo29)
                Com.InsertAngleDim(CView, Com.MinP(BC.BoltsE, "Y"), Com.MaxP(BC.BoltsE, "Y"), "Top", 70);

            // Dim No 9 Angle Dimension
            if (DN.DimIDNo9)
                Com.InsertAngleDim(CView, BC.Angle.Points.P1, BC.Angle.Points.P2, "Bottom", 70);

        }

        private void ApplyDimTypeRight()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(1, 0, 0);
            TSD.PointList TempList = new PointList();

            if (BC.CutTop != null)
            {
                Vect = new Vector(0, 1, 0);
                // Dim No 26
                if (DN.DimIDNo26)
                {
                    pointList = new PointList();
                    pointList.Add(BC.CutTop.P1);
                    pointList.Add(BC.CutTop.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                }

            }

            if (BC.CutBott != null)
            {
                //Vect = new Vector(0, -1, 0);
                //// Dim No 8
                //if (DN.DimIDNo8)
                //{
                //    pointList = new PointList();
                //    pointList.Add(BC.CutBott.P1);
                //    pointList.Add(BC.CutBott.P2);
                //    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                //    if (xDim != null)
                //        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                //}

            }

            //if (DN.DimIDNo4 || BC.CutBott != null || BC.CutTop != null)
            //    BC.PC.DistLeft += BC.PC.DistInc;



            if (DN.DimIDNo6 || BC.CutTop != null)
                BC.PC.DistTop += BC.PC.DistInc;


            TSG.Line XLine = new TSG.Line(BC.Angle.Points.P1, BC.Angle.Points.P4);
            TSG.Line YLine = new TSG.Line(BC.Angle.Points.P4, BC.Angle.Points.P3);

            Vector LeftVect = XLine.Direction;

            if (LeftVect.X > 0)
                LeftVect = dc.ChangeVector(LeftVect);

            Vector RightVect = XLine.Direction;
            if (RightVect.X < 0)
                RightVect = dc.ChangeVector(RightVect);

            Vector TopVect = YLine.Direction;
            if (TopVect.Y < 0)
                TopVect = dc.ChangeVector(TopVect);

            Vector BottVect = YLine.Direction;
            if (BottVect.Y > 0)
                BottVect = dc.ChangeVector(BottVect);

            // Dim No 1
            if (DN.DimIDNo1)
            {
                pointList = new PointList();
                pointList.Add(BC.Angle.Points.P4);
                pointList.Add(BC.Points.P4);
                xDim = dc.InsertDim(CView, pointList, TopVect, BC.PC.DistTop, StAtrr);
                if (xDim != null)
                {
                    PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                    BC.PC.DistTop += BC.PC.DistInc;
                }
            }

            if (BC.BoltsE != null)
            {

                // Dim No 19, 19.1
                if ((DN.DimIDNo19 || DN.DimIDNo19Dot1) && BC.IsFrontBolt)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo19)
                        pointList.Add(BC.Angle.Points.P4);
                    pointList.Add(Com.MinP(BC.BoltsE, "Y"));
                    if (DN.DimIDNo19Dot1)
                        pointList.Add(BC.Angle.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, TopVect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }

                Point MaxXP = Com.MaxP(dc.GetVertexList(MainBeam.GetSolid()), "X");
                Point MinXP = Com.MinP(dc.GetVertexList(MainBeam.GetSolid()), "X");
                Vect = new Vector(0, 1, 0);

                // Dim No 25,25.1  RD Dim
                if ((DN.DimIDNo25 || DN.DimIDNo25Dot1) && BC.IsFrontBolt)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(BC.BoltsE, "Y"));
                    pointList.Add(MaxXP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                    if(DN.DimIDNo25)
                        BC.PC.DistTop += BC.PC.DistInc;

                    pointList = new PointList();
                    pointList.Add(MinXP);
                    pointList.Add(Com.MaxP(BC.BoltsE, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }

                Vect = new Vector(1, 0, 0);

                BC.PC.DistRight = (BC.PC.DistInc);
                // Dim No 2.2
                if (DN.DimIDNo2 || DN.DimIDNo3)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo2)
                    {
                        pointList.Add(BC.Points.P8);
                        pointList.Add(Com.MaxP(BC.BoltsE, "Y"));
                    }

                    if (DN.DimIDNo3)
                        pointList.AddRange(BC.BoltsE);

                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                }

                // Dim No 3.1
                if (DN.DimIDNo3Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(BC.BoltsE, "Y"));

                    pointList.Add(BC.Angle.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                }

                if (DN.DimIDNo2 || DN.DimIDNo3 || DN.DimIDNo3Dot1)
                    BC.PC.DistRight += BC.PC.DistInc;

                // Dim No 11
                if (DN.DimIDNo11)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(BC.BoltsE, "Y"));
                    pointList.Add(MainBeam.EndPoint);
                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                }

                // Dim No 3.2
                if (DN.DimIDNo3Dot2)
                {
                    if (BC.BoltsE.Count > 2)
                    {
                        pointList = new PointList();
                        pointList.AddRange(BC.BoltsE);
                        xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                            Com.GroupDim(xDim);
                        }
                    }
                }

                if (DN.DimIDNo11 || DN.DimIDNo3Dot2)
                    BC.PC.DistRight += BC.PC.DistInc;

                // Dim No 10
                if (DN.DimIDNo10)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(BC.BoltsE, "Y"));
                    pointList.Add(MainBeam.EndPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }
                }

                // Dim No 10.1
                if (DN.DimIDNo10Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(BC.BoltsE, "Y"));
                    pointList.Add(MainBeam.EndPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }
                }

                // Dim No 4
                if (DN.DimIDNo4)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Angle.Points.P2);
                    pointList.Add(BC.Angle.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, BottVect, BC.PC.DistInc, StAtrr);
                    if (xDim != null)
                        BC.PC.DistBot += (BC.PC.DistInc * 0.5);
                }


                Vect = new Vector(0, -1, 0);
                // Dim No 27,27.1  RD Dim
                if ((DN.DimIDNo27Dot1 || DN.DimIDNo27) && BC.IsFrontBolt)
                {
                    pointList = new PointList();

                    pointList.Add(Com.MinP(BC.BoltsE, "Y"));
                    pointList.Add(MaxXP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                    pointList = new PointList();
                    pointList.Add(MinXP);
                    pointList.Add(Com.MinP(BC.BoltsE, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }



            }


            if (DN.DimIDNo30 && LeftEnd != null && RightEnd != null)
            {
                BC.PC.DistTop += BC.PC.DistInc;

                Vect = new Vector(0, 1, 0);
                pointList = new PointList();
                pointList.Add(LeftEnd);
                pointList.Add(RightEnd);
                xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                if (xDim != null)
                    PL.DimPlaceByTopY(xDim, BC.PC);
            }

            // Dim No 29 Angle Dimension
            if (DN.DimIDNo29)
                Com.InsertAngleDim(CView, Com.MinP(BC.BoltsE, "Y"), Com.MaxP(BC.BoltsE, "Y"), "Top", 70);

            // Dim No 9 Angle Dimension
            if (DN.DimIDNo9)
                Com.InsertAngleDim(CView, BC.Angle.Points.P4, BC.Angle.Points.P3, "Bottom", 70);


        }

        #endregion

        #region Detail View

        private void ApplyDimTypeLeftD()
        {

            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(-1, 0, 0);
            TSD.PointList TempList = new PointList();

            Point MinXP = Com.MinP(dc.GetVertexList(MainBeam.GetSolid()), "X");

            if (BC.CutTop != null)
            {
                Vect = new Vector(0, 1, 0);
                // Dim No 8
                if (DN.DimIDNo8)
                {
                    pointList = new PointList();
                    pointList.Add(BC.CutTop.P1);
                    pointList.Add(BC.CutTop.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                }




                Vect = new Vector(-1, 0, 0);
                // Dim No 7
                if (DN.DimIDNo7)
                {
                    pointList = new PointList();
                    pointList.Add(BC.CutTop.P1);
                    pointList.Add(BC.CutTop.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                }


            }

            if (BC.CutBott != null)
            {
                Vect = new Vector(0, -1, 0);
                // Dim No 6
                if (DN.DimIDNo6)
                {
                    pointList = new PointList();
                    pointList.Add(BC.CutBott.P1);
                    pointList.Add(BC.CutBott.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                }

                Vect = new Vector(-1, 0, 0);
                // Dim No 5
                if (DN.DimIDNo5)
                {
                    pointList = new PointList();
                    pointList.Add(BC.CutBott.P1);
                    pointList.Add(BC.CutBott.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                }

            }

            if (DN.DimIDNo8Dot1)
            {
                if (BC.Direction == "Left")
                {
                    Vect = new Vector(0, -1, 0);
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(MinXP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                }
                else
                {
                    Vect = new Vector(0, 1, 0);
                    pointList = new PointList();
                    pointList.Add(BC.Points.P2);
                    pointList.Add(MinXP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                }
            }



            if ((DN.DimIDNo7 || DN.DimIDNo5) || BC.CutBott != null || BC.CutTop != null)
                BC.PC.DistLeft += BC.PC.DistInc;



            if (DN.DimIDNo8 || DN.DimIDNo8Dot1 || BC.CutTop != null)
                BC.PC.DistTop += BC.PC.DistInc;

            if (DN.DimIDNo6 || BC.CutBott != null)
                BC.PC.DistBot += BC.PC.DistInc;


            TSG.Line XLine = new TSG.Line(BC.Angle.Points.P1, BC.Angle.Points.P4);
            TSG.Line YLine = new TSG.Line(BC.Angle.Points.P1, BC.Angle.Points.P2);

            Vector LeftVect = XLine.Direction;

            if (LeftVect.X > 0)
                LeftVect = dc.ChangeVector(LeftVect);

            Vector RightVect = XLine.Direction;
            if (RightVect.X < 0)
                RightVect = dc.ChangeVector(RightVect);

            Vector TopVect = YLine.Direction;
            if (TopVect.Y < 0)
                TopVect = dc.ChangeVector(TopVect);

            Vector BottVect = YLine.Direction;
            if (BottVect.Y > 0)
                BottVect = dc.ChangeVector(BottVect);


            if (BC.DPC != null)
            {
                if (DN.DimIDNo20 || DN.DimIDNo20Dot1)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo20)
                        pointList.Add(BC.DPC.Points.P1);
                    pointList.Add(BC.Angle.Points.P4);
                    if (DN.DimIDNo20Dot1)
                        pointList.Add(BC.DPC.Points.P4);
                    xDim = dc.InsertDim(CView, pointList, TopVect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);
                }


                if (DN.DimIDNo21)
                {
                    pointList = new PointList();
                    pointList.Add(BC.DPC.Points.P1);
                    pointList.Add(BC.DPC.Points.P4);
                    xDim = dc.InsertDim(CView, pointList, TopVect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);
                }


                if (DN.DimIDNo23Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Angle.Points.P4);
                    pointList.Add(BC.DPC.Points.P4);
                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);

                    pointList = new PointList();
                    pointList.Add(BC.Angle.Points.P3);
                    pointList.Add(BC.DPC.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                }

                if (DN.DimIDNo23)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Angle.Points.P4);
                    pointList.Add(BC.Angle.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                }

                if (DN.DimIDNo23Dot1 || DN.DimIDNo23)
                    BC.PC.DistRight += BC.PC.DistInc;

                if (DN.DimIDNo22)
                {
                    pointList = new PointList();
                    pointList.Add(BC.DPC.Points.P4);
                    pointList.Add(BC.DPC.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                }

                if (BC.BoltsE != null)
                {
                    Vect = new Vector(-1, 0, 0);

                    // Dim No 3.3
                    if (DN.DimIDNo3Dot3)
                    {
                        pointList = new PointList();

                        pointList.Add(Com.MaxP(BC.BoltsE, "Y"));
                        pointList.Add(BC.DPC.Points.P1);
                        xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);


                        pointList = new PointList();

                        pointList.Add(Com.MinP(BC.BoltsE, "Y"));
                        pointList.Add(BC.DPC.Points.P2);
                        xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                    }


                }


            }

            // Dim No 29 Angle Dimension
            if (DN.DimIDNo29 && BC.BoltsE != null && BC.IsFrontBolt)
                Com.InsertAngleDim(CView, Com.MaxP(BC.BoltsE, "Y"), Com.MinP(BC.BoltsE, "Y"), "Bottom", 35);

            // Dim No 9 Angle Dimension
            if (DN.DimIDNo9Dot1)
                Com.InsertAngleDim(CView, BC.Points.P1, BC.Points.P2, "Bottom", 55);

        }

        private void ApplyDimTypeRightD()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(1, 0, 0);
            TSD.PointList TempList = new PointList();

            Point MaxXP = Com.MaxP(dc.GetVertexList(MainBeam.GetSolid()), "X");

            if (BC.CutTop != null)
            {
                Vect = new Vector(0, 1, 0);
                // Dim No 8
                if (DN.DimIDNo8)
                {
                    pointList = new PointList();
                    pointList.Add(BC.CutTop.P1);
                    pointList.Add(BC.CutTop.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                }




                Vect = new Vector(1, 0, 0);
                // Dim No 7
                if (DN.DimIDNo7)
                {
                    pointList = new PointList();
                    pointList.Add(BC.CutTop.P1);
                    pointList.Add(BC.CutTop.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                }


            }

            if (BC.CutBott != null)
            {
                Vect = new Vector(0, -1, 0);
                // Dim No 6
                if (DN.DimIDNo6)
                {
                    pointList = new PointList();
                    pointList.Add(BC.CutBott.P1);
                    pointList.Add(BC.CutBott.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                }



                Vect = new Vector(1, 0, 0);
                // Dim No 5
                if (DN.DimIDNo5)
                {
                    pointList = new PointList();
                    pointList.Add(BC.CutBott.P1);
                    pointList.Add(BC.CutBott.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                }

            }


            if (DN.DimIDNo8Dot1)
            {
                if (BC.Direction == "Right")
                {
                    Vect = new Vector(0, -1, 0);
                    pointList = new PointList();
                    pointList.Add(BC.Points.P3);
                    pointList.Add(MaxXP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                }
                else
                {
                    Vect = new Vector(0, 1, 0);
                    pointList = new PointList();
                    pointList.Add(BC.Points.P4);
                    pointList.Add(MaxXP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                }
            }


            if ((DN.DimIDNo7 || DN.DimIDNo5) || BC.CutBott != null || BC.CutTop != null)
                BC.PC.DistRight += BC.PC.DistInc;



            if (DN.DimIDNo8 || DN.DimIDNo8Dot1 || BC.CutTop != null)
                BC.PC.DistTop += BC.PC.DistInc;

            if (DN.DimIDNo6 || BC.CutBott != null)
                BC.PC.DistBot += BC.PC.DistInc;

            TSG.Line XLine = new TSG.Line(BC.Angle.Points.P1, BC.Angle.Points.P4);
            TSG.Line YLine = new TSG.Line(BC.Angle.Points.P4, BC.Angle.Points.P3);

            Vector LeftVect = XLine.Direction;

            if (LeftVect.X > 0)
                LeftVect = dc.ChangeVector(LeftVect);

            Vector RightVect = XLine.Direction;
            if (RightVect.X < 0)
                RightVect = dc.ChangeVector(RightVect);

            Vector TopVect = YLine.Direction;
            if (TopVect.Y < 0)
                TopVect = dc.ChangeVector(TopVect);

            Vector BottVect = YLine.Direction;
            if (BottVect.Y > 0)
                BottVect = dc.ChangeVector(BottVect);

            if (BC.DPC != null)
            {
                if (DN.DimIDNo20 || DN.DimIDNo20Dot1)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo20)
                        pointList.Add(BC.DPC.Points.P4);
                    pointList.Add(BC.Angle.Points.P1);
                    if (DN.DimIDNo20Dot1)
                        pointList.Add(BC.DPC.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, TopVect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);
                }


                if (DN.DimIDNo21)
                {
                    pointList = new PointList();
                    pointList.Add(BC.DPC.Points.P4);
                    pointList.Add(BC.DPC.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, TopVect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);
                }


                if (DN.DimIDNo23Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Angle.Points.P1);
                    pointList.Add(BC.DPC.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);

                    pointList = new PointList();
                    pointList.Add(BC.Angle.Points.P2);
                    pointList.Add(BC.DPC.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                }

                if (DN.DimIDNo23)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Angle.Points.P1);
                    pointList.Add(BC.Angle.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                }

                if (DN.DimIDNo23Dot1 || DN.DimIDNo23)
                    BC.PC.DistLeft += BC.PC.DistInc;

                if (DN.DimIDNo22)
                {
                    pointList = new PointList();
                    pointList.Add(BC.DPC.Points.P1);
                    pointList.Add(BC.DPC.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                }


                if (BC.BoltsE != null)
                {
                    Vect = new Vector(1, 0, 0);

                    // Dim No 3.3
                    if (DN.DimIDNo3Dot3)
                    {
                        pointList = new PointList();

                        pointList.Add(Com.MaxP(BC.BoltsE, "Y"));
                        pointList.Add(BC.DPC.Points.P4);
                        xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);


                        pointList = new PointList();

                        pointList.Add(Com.MinP(BC.BoltsE, "Y"));
                        pointList.Add(BC.DPC.Points.P3);
                        xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                    }




                }



            }



            // Dim No 29 Angle Dimension
            if (BC.BoltsE != null && DN.DimIDNo29 && BC.IsFrontBolt)
                Com.InsertAngleDim(CView, Com.MaxP(BC.BoltsE, "Y"), Com.MinP(BC.BoltsE, "Y"), "Bottom", 35);

            // Dim No 9 Angle Dimension
            if (DN.DimIDNo9Dot1)
                Com.InsertAngleDim(CView, BC.Points.P4, BC.Points.P3, "Bottom", 55);


        }

        #endregion

        private void AppySectionDim()
        {
            StraightDimensionSet xDim = null;
            PointList pointList = new PointList();
            Vector Vect = new Vector(0, 1, 0);
            PointList TempList = new PointList();


            Point BPoint = GetBeamPoint();

            Vect = new Vector(0, 1, 0);

            xDim = null;
            if (DN.DimIDNo24)
            {
                if (BC.SCL?.DPC != null)
                {
                    pointList = new PointList();
                    pointList.Add(BC.SCL.DPC.Points.P4);
                    pointList.Add(BC.SCL.DPC.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                }

                if (BC.SCR?.DPC != null)
                {
                    pointList = new PointList();
                    pointList.Add(BC.SCR.DPC.Points.P1);
                    pointList.Add(BC.SCR.DPC.Points.P4);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                }

            }

            if (xDim != null)
                BC.PC.DistTop += BC.PC.DistInc;

            double WBH = Com.GetPartWebThickness(MainBeam) / 2;

            if ((DN.DimIDNo18 || DN.DimIDNo18Dot1))
            {
                if (BC.SCL.IsFrontBolt)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo18)
                        pointList.Add(Com.MinP(BC.SCL.Bolts, "Y"));

                    pointList.Add(new Point(BPoint.X - WBH, BPoint.Y));

                    if (DN.DimIDNo18Dot1)
                        pointList.Add(BPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);
                }

                if (BC.SCR.IsFrontBolt)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo18)
                        pointList.Add(Com.MinP(BC.SCR.Bolts, "Y"));

                    pointList.Add(new Point(BPoint.X + WBH, BPoint.Y));

                    if (DN.DimIDNo18Dot1)
                        pointList.Add(BPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);
                }
            }


            if ((DN.DimIDNo12 || DN.DimIDNo12Dot2))
            {
                if (BC.SCL?.Angle != null && BC.SCL.IsFrontBolt)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo12Dot2)
                        pointList.Add(BC.SCL.Angle.Points.P1);

                    pointList.Add(Com.MinP(BC.SCL.Bolts, "Y"));

                    if (DN.DimIDNo12)
                        pointList.Add(BPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);
                }

                if (BC.SCR?.Angle != null && BC.SCR.IsFrontBolt)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo12Dot2)
                        pointList.Add(BC.SCR.Angle.Points.P4);

                    pointList.Add(Com.MinP(BC.SCR.Bolts, "Y"));

                    if (DN.DimIDNo12)
                        pointList.Add(BPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);
                }
            }

            if (DN.DimIDNo12Dot1 && (BC.SCR != null && BC.SCL != null && BC.SCR.IsFrontBolt && BC.SCL.IsFrontBolt))
            {
                pointList = new PointList();
                pointList.Add(Com.MinP(BC.SCL.Bolts, "Y"));
                pointList.Add(Com.MinP(BC.SCR.Bolts, "Y"));
                xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                if (xDim != null)
                    PL.DimPlaceByTopY(xDim, BC.PC);
            }


            #region Left Dim
            Vect = new Vector(-1, 0, 0);
            if (BC.SCL?.Angle != null)
            {
                // Dim No 3
                if (DN.DimIDNo3)
                {
                    pointList = new PointList();
                    pointList.AddRange(BC.SCL.Bolts);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                }

                // Dim No 3.1
                if (DN.DimIDNo3Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(BC.SCL.Bolts, "Y"));
                    pointList.Add(BC.SCL.Angle.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);


                    pointList = new PointList();
                    pointList.Add(Com.MaxP(BC.SCL.Bolts, "Y"));
                    pointList.Add(BC.SCL.Angle.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                }

                if (DN.DimIDNo3 || DN.DimIDNo3Dot1)
                    BC.PC.DistLeft += BC.PC.DistInc;

                // Dim No 3.2
                if (DN.DimIDNo3Dot2 && BC.SCL.Bolts.Count > 2)
                {
                    pointList = new PointList();
                    pointList.AddRange(BC.SCL.Bolts);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                        Com.GroupDim(xDim);
                    }
                }
            }
            #endregion

            #region Right Dim
            Vect = new Vector(1, 0, 0);
            if (BC.SCR?.Angle != null)
            {
                // Dim No3
                if (DN.DimIDNo3)
                {
                    pointList = new PointList();
                    pointList.AddRange(BC.SCR.Bolts);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                }

                // Dim No 3.1
                if (DN.DimIDNo3Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(BC.SCR.Bolts, "Y"));
                    pointList.Add(BC.SCR.Angle.Points.P4);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);

                    pointList = new PointList();
                    pointList.Add(Com.MinP(BC.SCR.Bolts, "Y"));
                    pointList.Add(BC.SCR.Angle.Points.P3);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);


                }

                if (DN.DimIDNo3 || DN.DimIDNo3Dot1)
                    BC.PC.DistRight += BC.PC.DistInc;

                // Dim No 3.2
                if (DN.DimIDNo3Dot2 && BC.SCR.Bolts.Count > 2)
                {
                    pointList = new PointList();
                    pointList.AddRange(BC.SCR.Bolts);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                        Com.GroupDim(xDim);
                    }
                }

            }
            #endregion


        }

        #region Get Data

        private void GetBeamClassClass(TSD.View CView)
        {
            if (ViewName == "Front View")
            {
                BC = new BeamClass_BC2();
                BC.beam = MainBeam;
                BC.Points = Com.GetPartPoints(MainBeam);
                List<TSM.Part> PartListC = BC.beam.GetAssembly().GetSecondaries().OfType<TSM.Part>().ToList();

                GetEndProperties(PartListC);

                if (Position == "Left")
                {
                    if (dc.IsLess(BC.Points.P1.X, BC.Points.P2.X))
                        BC.Direction = "Left";
                    else
                        BC.Direction = "Right";
                }
                else
                {

                    if (dc.IsLess(BC.Points.P4.X, BC.Points.P3.X))
                        BC.Direction = "Left";
                    else
                        BC.Direction = "Right";
                }


                PartListC.Add(MainBeam);

                TSM.Part LeftPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.X ascending select p).FirstOrDefault();
                TSM.Part RightPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.X descending select p).FirstOrDefault();
                TSM.Part TopPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.Y descending select p).FirstOrDefault();
                TSM.Part BottPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.Y ascending select p).FirstOrDefault();

                BC.PC = new PlacingClass();
                BC.PC.TopY = TopPart.GetSolid().MaximumPoint.Y;
                BC.PC.BottomY = BottPart.GetSolid().MinimumPoint.Y;


                BC.PC.LeftX = LeftPart.GetSolid().MinimumPoint.X;// Math.Round(CView.RestrictionBox.MinPoint.X);
                BC.PC.RightX = RightPart.GetSolid().MaximumPoint.X;

                double AvScale = 12;
                double AvDistInc = 100;
                double DistPerScale = AvDistInc / AvScale;
                double CScale = CView.Attributes.Scale;
                BC.PC.DistInc = CScale * DistPerScale;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;
            }

            else if (ViewName == "Section View")
            {
                BC = new BeamClass_BC2();
                BC.beam = MainBeam;
                BC.Points = Com.GetPartPoints(MainBeam);
                List<TSM.Part> PartListC = BC.beam.GetAssembly().GetSecondaries().OfType<TSM.Part>().ToList();

                double Minz = CView.RestrictionBox.MinPoint.Z;
                double MaxZ = CView.RestrictionBox.MaxPoint.Z + 100;
                List<TSM.Part> PartList = (from p in PartListC where Com.IsViewObj(p, CView) select p).ToList();
                Point CentP = Com.CenterPoint(MainBeam.StartPoint, MainBeam.EndPoint);


                BC.SCL = GetEndPropertiesS(PartList, "Left");
                BC.SCR = GetEndPropertiesS(PartList, "Right");

                Minz = CView.RestrictionBox.MinPoint.Z - 150;
                MaxZ = CView.RestrictionBox.MaxPoint.Z + 150;
                PointList VertList = dc.GetVertexList(MainBeam.GetSolid());
                List<Point> PList = VertList.OfType<Point>().Where(x => x.Z > Minz).ToList();
                Point BeamPoint = GetBeamPoint();
                if (Com.IsEqualPoints(BeamPoint, MainBeam.StartPoint))
                    PList = VertList.OfType<Point>().Where(x => x.Z < MaxZ).ToList();


                BC.Points.P1 = Com.MaxPofX(PList, "Y", Com.MinP(PList, "X").X);
                BC.Points.P2 = Com.MinPofX(PList, "Y", Com.MinP(PList, "X").X);
                BC.Points.P3 = Com.MinPofX(PList, "Y", Com.MaxP(PList, "X").X);
                BC.Points.P4 = Com.MaxPofX(PList, "Y", Com.MaxP(PList, "X").X);


                PartList.Add(MainBeam);
                TSM.Part LeftPart = (from p in PartList orderby p.GetSolid().MinimumPoint.X ascending select p).FirstOrDefault();
                TSM.Part RightPart = (from p in PartList orderby p.GetSolid().MaximumPoint.X descending select p).FirstOrDefault();
                TSM.Part TopPart = (from p in PartList orderby p.GetSolid().MaximumPoint.Y descending select p).FirstOrDefault();
                TSM.Part BottPart = (from p in PartList orderby p.GetSolid().MinimumPoint.Y ascending select p).FirstOrDefault();

                BC.PC = new PlacingClass();
                BC.PC.TopY = TopPart.GetSolid().MaximumPoint.Y;
                BC.PC.BottomY = BottPart.GetSolid().MinimumPoint.Y;
                BC.PC.LeftX = LeftPart.GetSolid().MinimumPoint.X;// Math.Round(CView.RestrictionBox.MinPoint.X);
                BC.PC.RightX = RightPart.GetSolid().MaximumPoint.X;

                double AvScale = 12;
                double AvDistInc = 100;
                double DistPerScale = AvDistInc / AvScale;
                double CScale = CView.Attributes.Scale;
                BC.PC.DistInc = CScale * DistPerScale;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;
            }

            else if (ViewName == "Detail View")
            {
                BC = new BeamClass_BC2();
                BC.beam = MainBeam;
                BC.Points = Com.GetPartPoints(MainBeam);

                List<TSM.Part> PartListC = BC.beam.GetAssembly().GetSecondaries().OfType<TSM.Part>().ToList();

                double Minz = CView.RestrictionBox.MinPoint.Z - 100;
                double MaxZ = CView.RestrictionBox.MaxPoint.Z + 100;

                double MinX = CView.RestrictionBox.MinPoint.X - 100;
                double MaxX = CView.RestrictionBox.MaxPoint.X + 100;
                List<TSM.Part> PartList = (from p in PartListC where (p.GetSolid().MaximumPoint.X > MinX && p.GetSolid().MinimumPoint.X < MaxX) select p).ToList();

                GetEndPropertiesD(PartList);

                if (Position == "Left")
                {
                    if (dc.IsLess(BC.Points.P1.X, BC.Points.P2.X))
                        BC.Direction = "Left";
                    else
                        BC.Direction = "Right";
                }
                else
                {

                    if (dc.IsLess(BC.Points.P4.X, BC.Points.P3.X))
                        BC.Direction = "Left";
                    else
                        BC.Direction = "Right";
                }

                PartList.Add(MainBeam);

                TSM.Part LeftPart = (from p in PartList orderby p.GetSolid().MinimumPoint.X ascending select p).FirstOrDefault();
                TSM.Part RightPart = (from p in PartList orderby p.GetSolid().MaximumPoint.X descending select p).FirstOrDefault();
                TSM.Part TopPart = (from p in PartList orderby p.GetSolid().MaximumPoint.Y descending select p).FirstOrDefault();
                TSM.Part BottPart = (from p in PartList orderby p.GetSolid().MinimumPoint.Y ascending select p).FirstOrDefault();

                BC.PC = new PlacingClass();
                BC.PC.TopY = TopPart.GetSolid().MaximumPoint.Y;
                BC.PC.BottomY = BottPart.GetSolid().MinimumPoint.Y;

                if (Position == "Left")
                {
                    BC.PC.LeftX = LeftPart.GetSolid().MinimumPoint.X;
                    BC.PC.RightX = CView.RestrictionBox.MaxPoint.X;
                }
                else
                {
                    BC.PC.RightX = RightPart.GetSolid().MaximumPoint.X;
                    BC.PC.LeftX = CView.RestrictionBox.MinPoint.X;

                }



                double AvScale = 12;
                double AvDistInc = 100;
                double DistPerScale = AvDistInc / AvScale;
                double CScale = CView.Attributes.Scale;
                BC.PC.DistInc = CScale * DistPerScale;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;
            }
        }

        private void GetEndProperties(List<TSM.Part> PartListC)
        {
            PartListC = (from p in PartListC orderby p.GetSolid().MaximumPoint.Z descending select p).ToList();

            Point CentP = Com.CenterPoint(BC.beam.StartPoint, BC.beam.EndPoint);
            double Lenght = (BC.beam.GetSolid().MaximumPoint.X - BC.beam.GetSolid().MinimumPoint.X) / 8;
            double MinX = BC.beam.GetSolid().MinimumPoint.X + Lenght;
            double MaxX = BC.beam.GetSolid().MaximumPoint.X - Lenght;


            TSM.Beam Angle = null;
            TSM.Part DoublerPlate = null;

            BooleanPart BoolTop = null;
            BooleanPart BoolBott = null;

            List<BooleanPart> Bools = Com.EnumtoArray(MainBeam.GetBooleans()).OfType<BooleanPart>().ToList();

            double BHeigh = Com.GetPartHeight(MainBeam);

            if (Position == "Left")
            {
                Angle = (from p in PartListC.OfType<Beam>() where Com.GetPartProfileType(p) == "L" && !dc.IsPlateSideViewN(p) && (p.GetSolid().MaximumPoint.X < CentP.X && p.GetSolid().MinimumPoint.X <= MinX) select p).FirstOrDefault();
                DoublerPlate = (from p in PartListC where Com.GetPartProfileType(p) != "L" && !dc.IsPlateSideViewN(p) && (p.GetSolid().MaximumPoint.X < CentP.X && p.GetSolid().MinimumPoint.X <= MinX) select p).FirstOrDefault();
                BoolTop = (from p in Bools where (p.OperativePart.GetSolid().MaximumPoint.X < CentP.X && p.OperativePart.GetSolid().MinimumPoint.X <= MinX) && Com.CenterPoint(p.OperativePart).Y > BC.Points.CentP.Y select p).FirstOrDefault();
                BoolBott = (from p in Bools where (p.OperativePart.GetSolid().MaximumPoint.X < CentP.X && p.OperativePart.GetSolid().MinimumPoint.X <= MinX) && Com.CenterPoint(p.OperativePart).Y < BC.Points.CentP.Y select p).FirstOrDefault();
            }
            else
            {
                Angle = (from p in PartListC.OfType<Beam>() where Com.GetPartProfileType(p) == "L" && !dc.IsPlateSideViewN(p) && (p.GetSolid().MinimumPoint.X > CentP.X && p.GetSolid().MaximumPoint.X >= MaxX) select p).FirstOrDefault();
                DoublerPlate = (from p in PartListC where Com.GetPartProfileType(p) != "L" && !dc.IsPlateSideViewN(p) && (p.GetSolid().MinimumPoint.X > CentP.X && p.GetSolid().MaximumPoint.X >= MaxX) select p).FirstOrDefault();
                BoolTop = (from p in Bools where (p.OperativePart.GetSolid().MinimumPoint.X > CentP.X && p.OperativePart.GetSolid().MaximumPoint.X >= MaxX) && Com.CenterPoint(p.OperativePart).Y > BC.Points.CentP.Y select p).FirstOrDefault();
                BoolBott = (from p in Bools where (p.OperativePart.GetSolid().MinimumPoint.X > CentP.X && p.OperativePart.GetSolid().MaximumPoint.X >= MaxX) && Com.CenterPoint(p.OperativePart).Y < BC.Points.CentP.Y select p).FirstOrDefault();
            }


            if (Angle != null)
            {
                BC.Angle = Com.GetPartClass(Angle);
                BC.Angle.Points = dc.GetSlopBeamEdgesPListByCenterC(Angle);
                BC.BoltsE = Com.GetPartBoltPoint(Angle);
                if (BC.BoltsE != null)
                {
                    if (Position == "Left")
                    {
                        BoltGroup BoltL = (from b in Com.EnumtoArray(Angle.GetBolts()).OfType<BoltGroup>() orderby Com.CenterPoint(b).X ascending select b).FirstOrDefault();
                        if (BoltL != null)
                            LeftEnd = Com.MaxP(Com.GetBoltPoints(BoltL), "Y");

                        BC.BoltsG = (from b in Com.EnumtoArray(Angle.GetBolts()).OfType<BoltGroup>() orderby Com.CenterPoint(b).X descending select b).FirstOrDefault();
                        double Xval = Angle.GetSolid().MinimumPoint.X + ((Angle.GetSolid().MaximumPoint.X - Angle.GetSolid().MinimumPoint.X) / 3);
                        if (Com.CenterPoint(BC.BoltsG).X > Xval)
                            BC.IsFrontBolt = true;


                        BC.BoltsE = Com.GetBoltPoints(BC.BoltsG);
                        // Com.CenterPoint(BC.BoltsG).
                    }
                    else
                    {

                        BoltGroup BoltRight = (from b in Com.EnumtoArray(Angle.GetBolts()).OfType<BoltGroup>() orderby Com.CenterPoint(b).X descending select b).FirstOrDefault();
                        if (BoltRight != null)
                            RightEnd = Com.MaxP(Com.GetBoltPoints(BoltRight), "Y");

                        BC.BoltsG = (from b in Com.EnumtoArray(Angle.GetBolts()).OfType<BoltGroup>() orderby Com.CenterPoint(b).X ascending select b).FirstOrDefault();
                        double Xval = Angle.GetSolid().MaximumPoint.X - ((Angle.GetSolid().MaximumPoint.X - Angle.GetSolid().MinimumPoint.X) / 3);
                        if (Com.CenterPoint(BC.BoltsG).X < Xval)
                            BC.IsFrontBolt = true;

                        BC.BoltsE = Com.GetBoltPoints(BC.BoltsG);
                    }


                }
            }


            if (DoublerPlate != null)
                BC.DPC = Com.GetPartClass(DoublerPlate);


            PointList PList = Com.GetVertxPointsD(MainBeam);
            BC.Points.P1 = Com.MinPofY(PList, "X", Com.MaxP(PList, "Y").Y);
            BC.Points.P2 = Com.MinPofY(PList, "X", Com.MinP(PList, "Y").Y);
            BC.Points.P2 = Com.MaxPofY(PList, "X", Com.MinP(PList, "Y").Y);
            BC.Points.P4 = Com.MaxPofY(PList, "X", Com.MaxP(PList, "Y").Y);

            BC.Points.P5 = BC.Points.P1;
            BC.Points.P6 = BC.Points.P2;
            BC.Points.P7 = BC.Points.P3;
            BC.Points.P8 = BC.Points.P4;

            PointList VertList = dc.GetVertexList(MainBeam.GetSolid());

            if (BoolTop != null)
            {
                BC.CutTop = new CutPoints();
                if (BoolTop.OperativePart is ContourPlate)
                {
                    PointList ContList = dc.ContPList(BoolTop.OperativePart);
                    ContList = ReviseList(ContList, "Top");
                    if (Position == "Left")
                    {
                        BC.CutTop.P1 = Com.MinPofX(ContList, "Y", Com.MinP(ContList, "X").X);
                        BC.CutTop.P2 = Com.MaxPofY(ContList, "X", Com.MaxP(ContList, "Y").Y);
                        BC.CutTop.P1 = (from p in VertList.OfType<Point>() where dc.IsEqual(p.Y, BC.CutTop.P1.Y) orderby p.X ascending select p).FirstOrDefault();
                        // BC.CutTop.P1 = Com.MinPofX(ContList, "Y", Com.MinP(ContList, "X").X);

                        // Com.DrawLineDotted(CView, BC.CutTop.P1, BC.CutTop.P2);
                        if (!Com.IsEqual(BC.CutTop.P1.Y, BC.CutTop.P2.Y))
                        {
                            BC.Points.P1 = BC.CutTop.P1;
                            BC.Points.P5 = BC.CutTop.P2;
                        }
                        else
                            BC.CutTop = null;
                    }
                    else
                    {
                        BC.CutTop.P1 = Com.MinPofX(ContList, "Y", Com.MaxP(ContList, "X").X);
                        BC.CutTop.P2 = Com.MinPofY(ContList, "X", Com.MaxP(ContList, "Y").Y);

                        BC.CutTop.P1 = (from p in VertList.OfType<Point>() where dc.IsEqual(p.Y, BC.CutTop.P1.Y) orderby p.X descending select p).FirstOrDefault();
                        //Com.DrawLineDotted(CView, BC.CutTop.P1, BC.CutTop.P2);
                        if (!Com.IsEqual(BC.CutTop.P1.Y, BC.CutTop.P2.Y))
                        {
                            BC.Points.P4 = BC.CutTop.P1;
                            BC.Points.P8 = BC.CutTop.P2;
                        }
                        else
                            BC.CutTop = null;

                    }
                }
            }

            if (BoolBott != null)
            {
                BC.CutBott = new CutPoints();
                if (BoolBott.OperativePart is ContourPlate)
                {
                    PointList ContList = dc.ContPList(BoolBott.OperativePart);
                    ContList = ReviseList(ContList, "Bottom");
                    if (Position == "Left")
                    {
                        BC.CutBott.P1 = Com.MaxPofX(ContList, "Y", Com.MinP(ContList, "X").X);
                        BC.CutBott.P2 = Com.MaxPofY(ContList, "X", Com.MinP(ContList, "Y").Y);

                        BC.CutBott.P1 = (from p in VertList.OfType<Point>() where dc.IsEqual(p.Y, BC.CutBott.P1.Y) orderby p.X ascending select p).FirstOrDefault();
                        if (!Com.IsEqual(BC.CutBott.P1.Y, BC.CutBott.P2.Y))
                        {
                            BC.Points.P2 = BC.CutBott.P1;
                            BC.Points.P6 = BC.CutBott.P2;
                        }
                        else
                            BC.CutBott = null;

                    }
                    else
                    {
                        BC.CutBott.P1 = Com.MaxPofX(ContList, "Y", Com.MaxP(ContList, "X").X);
                        BC.CutBott.P2 = Com.MinPofY(ContList, "X", Com.MinP(ContList, "Y").Y);
                        BC.CutBott.P1 = (from p in VertList.OfType<Point>() where dc.IsEqual(p.Y, BC.CutBott.P1.Y) orderby p.X descending select p).FirstOrDefault();
                        //  Com.DrawLineDotted(CView, BC.CutBott.P1, BC.CutBott.P2);
                        if (!Com.IsEqual(BC.CutBott.P1.Y, BC.CutBott.P2.Y))
                        {
                            BC.Points.P3 = BC.CutBott.P1;
                            BC.Points.P7 = BC.CutBott.P2;
                        }
                        else
                            BC.CutBott = null;
                    }
                }
            }


        }

        private void GetEndPropertiesD(List<TSM.Part> PartListC)
        {
            PartListC = (from p in PartListC orderby p.GetSolid().MaximumPoint.Z descending select p).ToList();

            Point CentP = Com.CenterPoint(BC.beam.StartPoint, BC.beam.EndPoint);
            double Lenght = (BC.beam.GetSolid().MaximumPoint.X - BC.beam.GetSolid().MinimumPoint.X) / 8;
            double MinX = BC.beam.GetSolid().MinimumPoint.X + Lenght;
            double MaxX = BC.beam.GetSolid().MaximumPoint.X - Lenght;


            TSM.Beam Angle = null;
            TSM.Part DoublerPlate = null;

            BooleanPart BoolTop = null;
            BooleanPart BoolBott = null;

            List<BooleanPart> Bools = Com.EnumtoArray(MainBeam.GetBooleans()).OfType<BooleanPart>().ToList();

            double BHeigh = Com.GetPartHeight(MainBeam);


            Angle = (from p in PartListC.OfType<Beam>() where Com.GetPartProfileType(p) == "L" && !dc.IsPlateSideViewN(p) select p).FirstOrDefault();
            DoublerPlate = (from p in PartListC where Com.GetPartProfileType(p) != "L" && !dc.IsPlateSideViewN(p) select p).FirstOrDefault();



            if (Angle != null)
            {

                if (Angle.GetSolid().MaximumPoint.X < CentP.X && Angle.GetSolid().MinimumPoint.X <= MinX)
                    Position = "Left";
                else
                    Position = "Right";

                BC.Angle = Com.GetPartClass(Angle);
                BC.Angle.Points = dc.GetSlopBeamEdgesPListByCenterC(Angle);
                BC.BoltsE = Com.GetPartBoltPoint(Angle);
                if (BC.BoltsE != null)
                {
                    if (Position == "Left")
                    {

                        BC.BoltsG = (from b in Com.EnumtoArray(Angle.GetBolts()).OfType<BoltGroup>() orderby Com.CenterPoint(b).X descending select b).FirstOrDefault();
                        double Xval = Angle.GetSolid().MinimumPoint.X + ((Angle.GetSolid().MaximumPoint.X - Angle.GetSolid().MinimumPoint.X) / 3);
                        if (Com.CenterPoint(BC.BoltsG).X > Xval)
                            BC.IsFrontBolt = true;


                        BC.BoltsE = Com.GetBoltPoints(BC.BoltsG);
                        // Com.CenterPoint(BC.BoltsG).
                    }
                    else
                    {
                        BC.BoltsG = (from b in Com.EnumtoArray(Angle.GetBolts()).OfType<BoltGroup>() orderby Com.CenterPoint(b).X ascending select b).FirstOrDefault();
                        double Xval = Angle.GetSolid().MaximumPoint.X - ((Angle.GetSolid().MaximumPoint.X - Angle.GetSolid().MinimumPoint.X) / 3);
                        if (Com.CenterPoint(BC.BoltsG).X < Xval)
                            BC.IsFrontBolt = true;

                        BC.BoltsE = Com.GetBoltPoints(BC.BoltsG);
                    }


                }
            }


            if (Position == "Left")
            {
                BoolTop = (from p in Bools where (p.OperativePart.GetSolid().MaximumPoint.X < CentP.X && p.OperativePart.GetSolid().MinimumPoint.X <= MinX) && Com.CenterPoint(p.OperativePart).Y > BC.Points.CentP.Y select p).FirstOrDefault();
                BoolBott = (from p in Bools where (p.OperativePart.GetSolid().MaximumPoint.X < CentP.X && p.OperativePart.GetSolid().MinimumPoint.X <= MinX) && Com.CenterPoint(p.OperativePart).Y < BC.Points.CentP.Y select p).FirstOrDefault();
            }
            else
            {
                BoolTop = (from p in Bools where (p.OperativePart.GetSolid().MinimumPoint.X > CentP.X && p.OperativePart.GetSolid().MaximumPoint.X >= MaxX) && Com.CenterPoint(p.OperativePart).Y > BC.Points.CentP.Y select p).FirstOrDefault();
                BoolBott = (from p in Bools where (p.OperativePart.GetSolid().MinimumPoint.X > CentP.X && p.OperativePart.GetSolid().MaximumPoint.X >= MaxX) && Com.CenterPoint(p.OperativePart).Y < BC.Points.CentP.Y select p).FirstOrDefault();
            }


            if (DoublerPlate != null)
            {
                BC.DPC = Com.GetPartClass(DoublerPlate);
                BC.DPC.Points = dc.GetSlopBeamEdgesPListByCenterC(DoublerPlate);
            }


            PointList PList = Com.GetVertxPointsD(MainBeam);
            BC.Points.P1 = Com.MinPofY(PList, "X", Com.MaxP(PList, "Y").Y);
            BC.Points.P2 = Com.MinPofY(PList, "X", Com.MinP(PList, "Y").Y);
            BC.Points.P2 = Com.MaxPofY(PList, "X", Com.MinP(PList, "Y").Y);
            BC.Points.P4 = Com.MaxPofY(PList, "X", Com.MaxP(PList, "Y").Y);

            BC.Points.P5 = BC.Points.P1;
            BC.Points.P6 = BC.Points.P2;
            BC.Points.P7 = BC.Points.P3;
            BC.Points.P8 = BC.Points.P4;

            PointList VertList = dc.GetVertexList(MainBeam.GetSolid());

            if (BoolTop != null)
            {
                BC.CutTop = new CutPoints();
                if (BoolTop.OperativePart is ContourPlate)
                {
                    PointList ContList = dc.ContPList(BoolTop.OperativePart);
                    ContList = ReviseList(ContList, "Top");
                    if (Position == "Left")
                    {
                        BC.CutTop.P1 = Com.MinPofX(ContList, "Y", Com.MinP(ContList, "X").X);
                        BC.CutTop.P2 = Com.MaxPofY(ContList, "X", Com.MaxP(ContList, "Y").Y);
                        BC.CutTop.P1 = (from p in VertList.OfType<Point>() where dc.IsEqual(p.Y, BC.CutTop.P1.Y) orderby p.X ascending select p).FirstOrDefault();
                        // BC.CutTop.P1 = Com.MinPofX(ContList, "Y", Com.MinP(ContList, "X").X);

                        // Com.DrawLineDotted(CView, BC.CutTop.P1, BC.CutTop.P2);

                        BC.Points.P1 = BC.CutTop.P1;
                        BC.Points.P5 = BC.CutTop.P2;
                    }
                    else
                    {
                        BC.CutTop.P1 = Com.MinPofX(ContList, "Y", Com.MaxP(ContList, "X").X);
                        BC.CutTop.P2 = Com.MinPofY(ContList, "X", Com.MaxP(ContList, "Y").Y);

                        BC.CutTop.P1 = (from p in VertList.OfType<Point>() where dc.IsEqual(p.Y, BC.CutTop.P1.Y) orderby p.X descending select p).FirstOrDefault();
                        //Com.DrawLineDotted(CView, BC.CutTop.P1, BC.CutTop.P2);
                        BC.Points.P4 = BC.CutTop.P1;
                        BC.Points.P8 = BC.CutTop.P2;
                    }
                }
            }

            if (BoolBott != null)
            {
                BC.CutBott = new CutPoints();
                if (BoolBott.OperativePart is ContourPlate)
                {
                    PointList ContList = dc.ContPList(BoolBott.OperativePart);
                    ContList = ReviseList(ContList, "Bottom");
                    if (Position == "Left")
                    {
                        BC.CutBott.P1 = Com.MaxPofX(ContList, "Y", Com.MinP(ContList, "X").X);
                        BC.CutBott.P2 = Com.MaxPofY(ContList, "X", Com.MinP(ContList, "Y").Y);

                        BC.CutBott.P1 = (from p in VertList.OfType<Point>() where dc.IsEqual(p.Y, BC.CutBott.P1.Y) orderby p.X ascending select p).FirstOrDefault();
                        //  Com.DrawLineDotted(CView, BC.CutBott.P1, BC.CutBott.P2);
                        BC.Points.P2 = BC.CutBott.P1;
                        BC.Points.P6 = BC.CutBott.P2;
                    }
                    else
                    {
                        BC.CutBott.P1 = Com.MaxPofX(ContList, "Y", Com.MaxP(ContList, "X").X);
                        BC.CutBott.P2 = Com.MinPofY(ContList, "X", Com.MinP(ContList, "Y").Y);
                        BC.CutBott.P1 = (from p in VertList.OfType<Point>() where dc.IsEqual(p.Y, BC.CutBott.P1.Y) orderby p.X descending select p).FirstOrDefault();
                        //  Com.DrawLineDotted(CView, BC.CutBott.P1, BC.CutBott.P2);

                        BC.Points.P3 = BC.CutBott.P1;
                        BC.Points.P7 = BC.CutBott.P2;
                    }
                }
            }


        }

        private SecClass GetEndPropertiesS(List<TSM.Part> PartListC, string PosV)
        {
            SecClass SC = null;
            if (PosV == "Left")
                PartListC = (from p in PartListC where Com.CenterPoint(p).X < MainBeam.StartPoint.X orderby p.GetSolid().MaximumPoint.Z descending select p).ToList();
            else
                PartListC = (from p in PartListC where Com.CenterPoint(p).X > MainBeam.StartPoint.X orderby p.GetSolid().MaximumPoint.Z descending select p).ToList();


            if (PartListC != null && PartListC.Count > 0)
            {
                TSM.Beam Angle = null;
                TSM.Part DPC = null;


                double BHeigh = Com.GetPartHeight(MainBeam);

                if (PosV == "Left")
                {
                    Angle = (from p in PartListC.OfType<Beam>() where Com.GetPartProfileType(p) == "L" select p).FirstOrDefault();
                    DPC = (from p in PartListC where Com.GetPartProfileType(p) != "L" select p).FirstOrDefault();
                }
                else
                {
                    Angle = (from p in PartListC.OfType<Beam>() where Com.GetPartProfileType(p) == "L" select p).FirstOrDefault();
                    DPC = (from p in PartListC where Com.GetPartProfileType(p) != "L" select p).FirstOrDefault();

                }

                if (Angle != null || DPC != null)
                {
                    SC = new SecClass();

                    if (Angle != null)
                    {
                        SC.Angle = Com.GetPartClass(Angle);
                        PointList VertList = dc.GetVertexList(Angle.GetSolid());
                        SC.Angle.Points.P2 = Com.MinPofX(VertList, "Y", Com.MinP(VertList, "X").X);
                        SC.Angle.Points.P3 = Com.MinPofX(VertList, "Y", Com.MaxP(VertList, "X").X);

                        SC.Bolts = Com.GetPartBoltPoint(Angle);


                        BoltGroup BoltsG = null;

                        if (PosV == "Left")
                        {
                            BoltsG = (from b in Com.EnumtoArray(Angle.GetBolts()).OfType<BoltGroup>() orderby Com.CenterPoint(b).X ascending select b).FirstOrDefault();

                            double Xval = Angle.GetSolid().MaximumPoint.X - ((Angle.GetSolid().MaximumPoint.X - Angle.GetSolid().MinimumPoint.X) / 4);
                            if (Com.CenterPoint(BoltsG).X < Xval)
                                SC.IsFrontBolt = true;
                        }
                        else
                        {
                            BoltsG = (from b in Com.EnumtoArray(Angle.GetBolts()).OfType<BoltGroup>() orderby Com.CenterPoint(b).X descending select b).FirstOrDefault();
                            double Xval = Angle.GetSolid().MinimumPoint.X + ((Angle.GetSolid().MaximumPoint.X - Angle.GetSolid().MinimumPoint.X) / 4);
                            if (Com.CenterPoint(BoltsG).X > Xval)
                                SC.IsFrontBolt = true;
                        }

                        if (BoltsG != null)
                            SC.Bolts = Com.GetBoltPoints(BoltsG);
                    }

                    if (DPC != null)
                        SC.DPC = Com.GetPartClass(DPC);

                }
            }

            return SC;

        }

        private PointList ReviseList(PointList Plist, string VPos)
        {
            PointList pointList = new PointList();
            if (Plist.Count > 0)
            {
                foreach (Point p in Plist)
                {
                    Point P1 = p;

                    if (VPos == "Top" && P1.Y > BC.Points.P1.Y)
                        P1 = new Point(P1.X, BC.Points.P1.Y);

                    else if (VPos == "Bottom" && P1.Y < BC.Points.P2.Y)
                        P1 = new Point(P1.X, BC.Points.P2.Y);

                    if (Position == "Left" && P1.X < BC.Points.P1.X)
                        P1 = new Point(BC.Points.P1.X, P1.Y);

                    if (Position == "Right" && P1.X > BC.Points.P4.X)
                        P1 = new Point(BC.Points.P4.X, P1.Y);


                    pointList.Add(P1);
                }


            }
            return pointList;
        }

        #endregion

        #region Helping Methods
        private double GetPartWidth(TSM.Part part)
        {
            return (part.GetSolid().MaximumPoint.X - part.GetSolid().MinimumPoint.X);
        }

        private Point GetBeamPoint()
        {
            Point CentP = Com.CenterPoint(CView.RestrictionBox.MinPoint, CView.RestrictionBox.MaxPoint);
            double StartDist = Distance.PointToPoint(CentP, MainBeam.StartPoint);
            double EndDist = Distance.PointToPoint(CentP, MainBeam.EndPoint);

            if (StartDist < EndDist)
                return MainBeam.StartPoint;
            else
                return MainBeam.EndPoint;
        }

        #endregion

        private class SecClass
        {
            public PartClass Angle { get; set; }
            public PointList Bolts { get; set; }
            public PartClass DPC { get; set; }
            public bool IsFrontBolt = false;
        }

        private class BeamClass_BC2
        {
            public Beam beam { get; set; }
            public PartClass Angle { get; set; }
            public PartClass DPC { get; set; }
            public PointList BoltsE { get; set; }
            public BoltGroup BoltsG { get; set; }
            public bool IsFrontBolt = false;
            public CutPoints CutTop { get; set; }
            public CutPoints CutBott { get; set; }
            public PartPoints Points { get; set; }
            public PlacingClass PC { get; set; }
            public string Direction { get; set; }
            public SecClass SCL { get; set; }
            public SecClass SCR { get; set; }
        }

    }

}
