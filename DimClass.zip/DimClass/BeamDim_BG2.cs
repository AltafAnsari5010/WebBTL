﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Tekla.Structures;
using Tekla.Structures.Drawing;
using Tekla.Structures.Geometry3d;
using Tekla.Structures.Model;
using TSD = Tekla.Structures.Drawing;
using TSM = Tekla.Structures.Model;
using VirtueleDrawingAutomation;
using TSDD = Tekla.Structures.Datatype;
using TSG = Tekla.Structures.Geometry3d;

namespace Auto_Detailing_Tool_Beam
{
    public class BeamDim_BG2
    {
        #region Global Variables
        DimCom dc = new DimCom();
        StraightDimensionSet.StraightDimensionSetAttributes StAtrr = new StraightDimensionSet.StraightDimensionSetAttributes("standard");
        StraightDimensionSet.StraightDimensionSetAttributes RdAtrr = new StraightDimensionSet.StraightDimensionSetAttributes("standard");

        public Beam MainBeam = null;
        VirtueleDrawingAutomation.Json.DrawingAttributeInfoJson.AttributeFiles dimAttrClass = null;
        List<TSD.StraightDimension> KnockDim = new List<StraightDimension>();
        BeamClass_BG2 BC = null;
        VirtueleDrawingAutomation.Json.AutoDimensionTypesJson.BG2Json DN = null;
        TSD.View CView = null;
        List<int> Ids = new List<int>();
        string ViewName = "";
        #endregion

        public List<int> ApplyDim(TSD.View CView, string ViewName, AutoDimensioningTypes autoDimensioningTypes, DrawingAttributeInfo drawingAttributeInfo, List<int> Ids)
        {
            try
            {

                this.Ids = Ids;
                Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane());
                //Set model everything to the view
                Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane(CView.DisplayCoordinateSystem));

                this.CView = CView;
                this.dimAttrClass = drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files;
                this.DN = autoDimensioningTypes.Bg2;
                StAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.StandardDimension);
                RdAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.RunningDimension);
                this.MainBeam = (Com.MyModel.SelectModelObject(new Identifier((CView.GetDrawing() as AssemblyDrawing).AssemblyIdentifier.ID)) as TSM.Assembly).GetMainPart() as TSM.Beam;
                this.MainBeam.Select();
                string ProType = Com.GetProType(MainBeam);
                this.ViewName = ViewName;
                GetBeamClassClass(CView);


                if (ViewName == "Top View" || ViewName == "Bottom View")
                {
                    while (BC.TopGP != null || BC.BottGP != null)
                    {
                        ApplyDimType(CView);
                        GetBeamClassClass(CView);
                    }

                }
                else if (ViewName == "Front View")
                {
                    while (BC.GPTV != null)
                    {
                        ApplyTBV();
                        GetBeamClassClass(CView);
                    }
                }
                else if (ViewName == "Section View")
                    ApplyDimSection();



            }
            catch (Exception ex)
            { }

            Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane());

            return Ids;
        }

        private void ApplyDimType(TSD.View CView)
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            TSD.PointList TempList = new PointList();
            bool IsVertDim = false;
            Point RefP = null;

            #region Top Gusset
            if (BC.TopGP?.GussetPlate != null)
            {
                double deg = BC.TopGP.Degree;

                if (BC.TopGP.BracePos == "Right")
                    ApplyTopRightG();
                else if (BC.TopGP.BracePos == "Left")
                    ApplyTopLeftG();

                Ids.Add(BC.TopGP.GussetPlate.Identifier.ID);
                // Com.SetCode(BC.TopGP.GussetPlate);

            }
            #endregion

            #region Bottom Gusset
            if (BC.BottGP?.GussetPlate != null)
            {

                double deg = BC.BottGP.Degree;

                if (BC.BottGP.BracePos == "Right")
                    ApplyBottRightG();
                else if (BC.BottGP.BracePos == "Left")
                    ApplyBottLeftG();

                Ids.Add(BC.BottGP.GussetPlate.Identifier.ID);
                //   Com.SetCode(BC.BottGP.GussetPlate);


            }
            #endregion

        }

        private void ApplyTopLeftG()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            TSD.PointList TempList = new PointList();

            if (BC.TopGP?.GussetPlate != null)
            {

                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;

                TSG.Line YLine = new TSG.Line(BC.TopGP.Points.P5, BC.TopGP.Points.P1);
                //TSG.Line XLine = new TSG.Line(BC.TopGP.Points.P4, BC.TopGP.Points.P5);
                TSG.Line XLine = new TSG.Line(BC.TopGP.IntPoint, BC.TopGP.RefPBrace);

                Vector LeftVect = BC.TopGP.BoltM.GetCoordinateSystem().AxisY;

                if (LeftVect.X > 0)
                    LeftVect = dc.ChangeVector(LeftVect);

                Vector RightVect = BC.TopGP.BoltM.GetCoordinateSystem().AxisY;
                if (RightVect.X < 0)
                    RightVect = dc.ChangeVector(RightVect);

                Vector TopVect = BC.TopGP.BoltM.GetCoordinateSystem().AxisX;
                if (TopVect.Y < 0)
                    TopVect = dc.ChangeVector(TopVect);

                Vector BottVect = BC.TopGP.BoltM.GetCoordinateSystem().AxisX;
                if (BottVect.Y > 0)
                    BottVect = dc.ChangeVector(BottVect);



                #region Diagonal Right
                BC.PC.DistRight = (BC.PC.DistInc);
                TempList = BC.TopGP.BoltMP;
                // Dim No 7, 7.1
                if (DN.DimIDNo7 || DN.DimIDNo7Dot1)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo7)// Dim No 7
                        pointList.Add(Com.MinP(TempList, "Y"));

                    pointList.Add(BC.TopGP.IntPointB);
                    if (DN.DimIDNo7Dot1)// Dim No 7.1
                        pointList.Add(BC.TopGP.RefPBrace);

                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistRight);
                        BC.PC.DistRight += (BC.PC.DistInc * 1.25);
                    }
                }


                // Dim No 3.1 , 3, 16
                if (DN.DimIDNo3Dot1 || DN.DimIDNo3 || DN.DimIDNo16)
                {

                    pointList = new PointList();
                    if (DN.DimIDNo3Dot1)
                    {
                        pointList.Add(Com.MaxP(TempList, "Y"));
                        pointList.Add(BC.TopGP.Points.P1);
                    }
                    if (DN.DimIDNo3)
                        pointList.AddRange(TempList);

                    if (DN.DimIDNo16)
                    {
                        pointList.Add(Com.MinP(TempList, "Y"));
                        pointList.Add(BC.TopGP.RefPBrace);
                    }

                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }
                }

                // Dim No 3.2
                if (DN.DimIDNo3Dot2)
                {
                    if (TempList.Count > 2)
                    {
                        pointList = new PointList();
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                        {
                            PL.DimPlacingDiag(xDim, XLine, BC.PC.DistRight);
                            Com.GroupDim(xDim);
                        }
                    }
                }

                #endregion

                #region Straight Left

                Point CentLP = new Point(BC.TopGP.Points.P2.X, BC.Points.CentP.Y);

                Vect = new Vector(-1, 0, 0);
                BC.PC.DistLeft = (BC.PC.DistInc);


                double LeftX = BC.TopGP.Points.P2.X;
                //if (BC.BottGP != null && BC.BottGP.BracePos == "Right" && BC.BottGP.Points.P2.X > LeftX)
                //    LeftX = BC.BottGP.Points.P2.X;

                TempList = Com.GetBoltPoints(BC.TopGP.BoltM);

                // Dim No 6.2, 6.4
                if (DN.DimIDNo6Dot2 || DN.DimIDNo6Dot4)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo6Dot2)
                        pointList.Add(Com.MinP(TempList, "Y"));

                    pointList.Add(BC.TopGP.Points.P2);

                    if (DN.DimIDNo6Dot4)
                        pointList.Add(CentLP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, LeftX, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }

                }

                // Dim No 6.3
                if (DN.DimIDNo6Dot3)
                {

                    pointList = new PointList();
                    pointList.Add(CentLP);
                    pointList.Add(Com.MinP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, LeftX, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }

                }

                // Dim No 6.1, 6.5
                if (DN.DimIDNo6Dot1 || DN.DimIDNo6Dot5)
                {

                    pointList = new PointList();
                    if (DN.DimIDNo6Dot1)
                        pointList.Add(Com.MaxP(BC.TopGP.BoltMP, "Y"));
                    pointList.Add(BC.TopGP.IntPointB);
                    if (DN.DimIDNo6Dot5)
                        pointList.Add(CentLP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, LeftX, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }

                }

                // Dim No 6
                if (DN.DimIDNo6)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.IntPoint);
                    pointList.Add(CentLP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, LeftX, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }

                }

                // Dim No 12
                if (DN.DimIDNo12 && BC.BottGP != null)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P5);
                    pointList.Add(BC.BottGP.Points.P5);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, LeftX, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }

                }


                #endregion

                #region RD Dim

                BC.PC.DistTop = (BC.PC.DistInc * 3);
                //RD Dim
                Vect = new Vector(0, 1, 0);

                // Dim No 4.1
                if (DN.DimIDNo4Dot1)
                {
                    pointList = new PointList();
                    pointList.AddRange(BC.TopGP.BoltMP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                // Dim No 4
                if (DN.DimIDNo4)
                {
                    if (BC.TopGP.BoltMP.Count > 2)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MinP(BC.TopGP.BoltMP, "Y"));
                        pointList.Add(Com.MaxP(BC.TopGP.BoltMP, "Y"));
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                            BC.PC.DistTop += BC.PC.DistInc;
                        }
                    }

                }

                // Dim No 2.2
                if (DN.DimIDNo2Dot2)
                {
                    pointList = new PointList();
                    pointList.Add(BC.RDPoint);
                    pointList.Add(BC.TopGP.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                // Dim No 2.3
                if (DN.DimIDNo2Dot3)
                {
                    pointList = new PointList();
                    pointList.Add(BC.RDPoint);
                    pointList.Add(BC.TopGP.IntPointB);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                // Dim No 2.1
                if (DN.DimIDNo2Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(BC.RDPoint);
                    pointList.Add(Com.MinP(BC.TopGP.BoltMP, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                // Dim No 2.4, 2
                if (DN.DimIDNo2Dot4 || DN.DimIDNo2)
                {
                    pointList = new PointList();
                    pointList.Add(BC.RDPoint);
                    pointList.Add(BC.TopGP.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                #endregion

                #region Top Straight Dim

                Vect = new Vector(0, 1, 0);

                // Dim No 11
                if (DN.DimIDNo11)
                {

                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P4);
                    pointList.Add(BC.TopGP.RefPBrace);
                    pointList.Add(Com.MaxP(BC.TopGP.BoltMP, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }
                // Dim No 9
                if (DN.DimIDNo9)
                {

                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P4);
                    pointList.Add(Com.MaxP(BC.TopGP.BoltMP, "Y"));
                    pointList.Add(BC.TopGP.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }
                // Dim No 22
                if (DN.DimIDNo22)
                {

                    pointList = new PointList();
                    pointList.Add(BC.TopGP.IntPointB);
                    pointList.Add(BC.TopGP.RefPBrace);
                    pointList.Add(Com.MaxP(BC.TopGP.BoltMP, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                // Dim No 10
                if (DN.DimIDNo10)
                {

                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P4);
                    pointList.Add(BC.TopGP.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                // Dim No 8
                if (DN.DimIDNo8)
                {
                    if (Ids.Count > 0)
                        BC.PC.DistTop += BC.PC.DistInc;

                    pointList = new PointList();
                    pointList.Add(BC.Points.P5);
                    pointList.Add(BC.TopGP.RefPBrace);
                    pointList.Add(BC.Points.P6);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                #endregion

                // Com.DrawLineDotted(CView, BC.TopGP.IntPoint, BC.TopGP.RefPBrace);

                //Dim Code 5 // Angle Dimension
                if (DN.DimIDNo5)
                {
                    double Dist = CalcDistAngel(BC.TopGP.RefPBrace, BC.TopGP.IntPoint);
                    Com.InsertAngleDim(CView, BC.TopGP.RefPBrace, BC.TopGP.IntPoint, "Top", Dist);
                }



            }
        }

        private void ApplyBottLeftG()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            TSD.PointList TempList = new PointList();

            if (BC.BottGP?.GussetPlate != null)
            {

                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;

                TSG.Line YLine = new TSG.Line(BC.BottGP.Points.P5, BC.BottGP.Points.P1);
                //TSG.Line XLine = new TSG.Line(BC.BottGP.Points.P4, BC.BottGP.Points.P5);
                TSG.Line XLine = new TSG.Line(BC.BottGP.IntPoint, BC.BottGP.RefPBrace);

                Vector LeftVect = BC.BottGP.BoltM.GetCoordinateSystem().AxisY;

                if (LeftVect.X > 0)
                    LeftVect = dc.ChangeVector(LeftVect);

                Vector RightVect = BC.BottGP.BoltM.GetCoordinateSystem().AxisY;
                if (RightVect.X < 0)
                    RightVect = dc.ChangeVector(RightVect);

                Vector TopVect = BC.BottGP.BoltM.GetCoordinateSystem().AxisX;
                if (TopVect.Y < 0)
                    TopVect = dc.ChangeVector(TopVect);

                Vector BottVect = BC.BottGP.BoltM.GetCoordinateSystem().AxisX;
                if (BottVect.Y > 0)
                    BottVect = dc.ChangeVector(BottVect);



                #region Diagonal Right
                BC.PC.DistRight = (BC.PC.DistInc);
                TempList = BC.BottGP.BoltMP;
                // Dim No 7, 7.1
                if (DN.DimIDNo7 || DN.DimIDNo7Dot1)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo7)// Dim No 7
                        pointList.Add(Com.MaxP(TempList, "Y"));

                    pointList.Add(BC.BottGP.IntPointB);
                    if (DN.DimIDNo7Dot1)// Dim No 7.1
                        pointList.Add(BC.BottGP.RefPBrace);

                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistRight);
                        BC.PC.DistRight += (BC.PC.DistInc * 1.25);
                    }
                }


                // Dim No 3.1 , 3, 16
                if (DN.DimIDNo3Dot1 || DN.DimIDNo3 || DN.DimIDNo16)
                {

                    pointList = new PointList();
                    if (DN.DimIDNo3Dot1)
                    {
                        pointList.Add(Com.MinP(TempList, "Y"));
                        pointList.Add(BC.BottGP.Points.P1);
                    }
                    if (DN.DimIDNo3)
                        pointList.AddRange(TempList);

                    if (DN.DimIDNo16)
                    {
                        pointList.Add(Com.MaxP(TempList, "Y"));
                        pointList.Add(BC.BottGP.RefPBrace);
                    }

                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }
                }

                // Dim No 3.2
                if (DN.DimIDNo3Dot2)
                {
                    if (TempList.Count > 2)
                    {
                        pointList = new PointList();
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                        {
                            PL.DimPlacingDiag(xDim, XLine, BC.PC.DistRight);
                            Com.GroupDim(xDim);
                        }
                    }
                }

                #endregion

                #region Straight Right

                Point CentLP = new Point(BC.BottGP.Points.P3.X, BC.Points.CentP.Y);

                Vect = new Vector(1, 0, 0);
                BC.PC.DistRight = (BC.PC.DistInc * 2);

                double RightX = BC.BottGP.Points.P3.X;
                //if (BC.BottGP != null && BC.BottGP.BracePos == "Right" && BC.BottGP.Points.P2.X > RightX)
                //    RightX = BC.BottGP.Points.P2.X;

                TempList = Com.GetBoltPoints(BC.BottGP.BoltM);

                // Dim No 6.2, 6.4
                if (DN.DimIDNo6Dot2 || DN.DimIDNo6Dot4)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo6Dot2)
                        pointList.Add(Com.MaxP(TempList, "Y"));

                    pointList.Add(BC.BottGP.Points.P3);

                    if (DN.DimIDNo6Dot4)
                        pointList.Add(CentLP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, RightX, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }

                }



                // Dim No 6.3
                if (DN.DimIDNo6Dot3)
                {

                    pointList = new PointList();
                    pointList.Add(CentLP);
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, RightX, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }

                }



                // Dim No 6.1, 6.5
                if (DN.DimIDNo6Dot1 || DN.DimIDNo6Dot5)
                {

                    pointList = new PointList();
                    if (DN.DimIDNo6Dot1)
                        pointList.Add(Com.MinP(BC.BottGP.BoltMP, "Y"));
                    pointList.Add(BC.BottGP.IntPointB);
                    if (DN.DimIDNo6Dot5)
                        pointList.Add(CentLP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, RightX, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }

                }

                // Dim No 6
                if (DN.DimIDNo6)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.IntPoint);
                    pointList.Add(CentLP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, RightX, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }

                }


                #endregion

                #region RD Dim

                BC.PC.DistBot = (BC.PC.DistInc * 3);
                //RD Dim
                Vect = new Vector(0, -1, 0);

                // Dim No 4.1
                if (DN.DimIDNo4Dot1)
                {
                    pointList = new PointList();
                    pointList.AddRange(BC.BottGP.BoltMP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                // Dim No 4
                if (DN.DimIDNo4)
                {
                    if (BC.BottGP.BoltMP.Count > 2)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MinP(BC.BottGP.BoltMP, "Y"));
                        pointList.Add(Com.MaxP(BC.BottGP.BoltMP, "Y"));
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                            BC.PC.DistBot += BC.PC.DistInc;
                        }
                    }

                }

                bool IsRefRD = (BC.TopGP == null) || (BC.TopGP != null && !dc.IsEqualPoints(BC.TopGP.RefPBrace, BC.BottGP.RefPBrace));

                if (!IsRefRD)
                    BC.PC.DistBot += BC.PC.DistInc;

                // Dim No 2.2
                if (DN.DimIDNo2Dot2 && IsRefRD)
                {
                    pointList = new PointList();
                    pointList.Add(BC.RDPoint);
                    pointList.Add(BC.BottGP.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                // Dim No 2.3
                if (DN.DimIDNo2Dot3)
                {
                    pointList = new PointList();
                    pointList.Add(BC.RDPoint);
                    pointList.Add(BC.BottGP.IntPointB);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                // Dim No 2.1
                if (DN.DimIDNo2Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(BC.RDPoint);
                    pointList.Add(Com.MaxP(BC.BottGP.BoltMP, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                // Dim No 2.4, 2
                if (DN.DimIDNo2Dot4 || DN.DimIDNo2)
                {
                    pointList = new PointList();
                    pointList.Add(BC.RDPoint);
                    pointList.Add(BC.BottGP.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                #endregion

                #region Bottom Straight Dim

                Vect = new Vector(0, -1, 0);

                // Dim No 11
                if (DN.DimIDNo11)
                {

                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P4);
                    pointList.Add(BC.BottGP.RefPBrace);
                    pointList.Add(Com.MinP(BC.BottGP.BoltMP, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }
                // Dim No 9
                if (DN.DimIDNo9)
                {

                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P4);
                    pointList.Add(Com.MinP(BC.BottGP.BoltMP, "Y"));
                    pointList.Add(BC.BottGP.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }
                // Dim No 22
                if (DN.DimIDNo22)
                {

                    pointList = new PointList();
                    pointList.Add(BC.BottGP.IntPointB);
                    pointList.Add(BC.BottGP.RefPBrace);
                    pointList.Add(Com.MinP(BC.BottGP.BoltMP, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                // Dim No 10
                if (DN.DimIDNo10)
                {

                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P4);
                    pointList.Add(BC.BottGP.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                // Dim No 8
                if (DN.DimIDNo8 && BC.TopGP == null)
                {
                    if (Ids.Count > 0)
                        BC.PC.DistBot += BC.PC.DistInc;

                    pointList = new PointList();
                    pointList.Add(BC.Points.P5);
                    pointList.Add(BC.BottGP.RefPBrace);
                    pointList.Add(BC.Points.P6);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                #endregion

                //  Com.DrawLineDotted(CView, BC.BottGP.IntPoint, BC.BottGP.RefPBrace);

                //Dim Code 5 // Angle Dimension
                if (DN.DimIDNo5)
                {
                    double Dist = CalcDistAngel(BC.BottGP.RefPBrace, BC.BottGP.IntPoint);
                    Com.InsertAngleDim(CView, BC.BottGP.RefPBrace, BC.BottGP.IntPoint, "Bottom", Dist);
                }

            }


        }

        private void ApplyTopRightG()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            TSD.PointList TempList = new PointList();

            if (BC.TopGP?.GussetPlate != null)
            {

                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;

                TSG.Line YLine = new TSG.Line(BC.TopGP.Points.P5, BC.TopGP.Points.P1);
                //TSG.Line XLine = new TSG.Line(BC.TopGP.Points.P4, BC.TopGP.Points.P5);
                TSG.Line XLine = new TSG.Line(BC.TopGP.IntPoint, BC.TopGP.RefPBrace);

                Vector LeftVect = BC.TopGP.BoltM.GetCoordinateSystem().AxisY;

                if (LeftVect.X > 0)
                    LeftVect = dc.ChangeVector(LeftVect);

                Vector RightVect = BC.TopGP.BoltM.GetCoordinateSystem().AxisY;
                if (RightVect.X < 0)
                    RightVect = dc.ChangeVector(RightVect);

                Vector TopVect = BC.TopGP.BoltM.GetCoordinateSystem().AxisX;
                if (TopVect.Y < 0)
                    TopVect = dc.ChangeVector(TopVect);

                Vector BottVect = BC.TopGP.BoltM.GetCoordinateSystem().AxisX;
                if (BottVect.Y > 0)
                    BottVect = dc.ChangeVector(BottVect);



                #region Diagonal Left
                BC.PC.DistLeft = (BC.PC.DistInc * 1.25);
                TempList = dc.ChangePints(BC.TopGP.BoltMP, CView, RightVect);
                // Dim No 7, 7.1
                if (DN.DimIDNo7 || DN.DimIDNo7Dot1)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo7)// Dim No 7
                        pointList.Add(Com.MinP(TempList, "Y"));

                    pointList.Add(BC.TopGP.IntPointB);
                    if (DN.DimIDNo7Dot1)// Dim No 7.1
                        pointList.Add(BC.TopGP.RefPBrace);

                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }
                }


                // Dim No 3.1 , 3, 16
                if (DN.DimIDNo3Dot1 || DN.DimIDNo3 || DN.DimIDNo16)
                {

                    pointList = new PointList();
                    if (DN.DimIDNo3Dot1)
                    {
                        pointList.Add(Com.MaxP(TempList, "Y"));
                        pointList.Add(BC.TopGP.Points.P1);
                    }
                    if (DN.DimIDNo3)
                        pointList.AddRange(TempList);

                    if (DN.DimIDNo16)
                    {
                        pointList.Add(Com.MinP(TempList, "Y"));
                        pointList.Add(BC.TopGP.RefPBrace);
                    }

                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }
                }

                // Dim No 3.2
                if (DN.DimIDNo3Dot2)
                {
                    if (TempList.Count > 2)
                    {
                        pointList = new PointList();
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                        {
                            PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);
                            Com.GroupDim(xDim);
                        }
                    }
                }

                #endregion

                #region Straight Right

                Point CentLP = new Point(BC.TopGP.Points.P2.X, BC.Points.CentP.Y);

                Vect = new Vector(1, 0, 0);
                BC.PC.DistRight = (BC.PC.DistInc);


                double RightX = BC.TopGP.Points.P2.X;
                if (BC.BottGP != null && BC.BottGP.BracePos == "Right" && BC.BottGP.Points.P2.X > RightX)
                    RightX = BC.BottGP.Points.P2.X;

                TempList = Com.GetBoltPoints(BC.TopGP.BoltM);

                // Dim No 6.2, 6.4
                if (DN.DimIDNo6Dot2 || DN.DimIDNo6Dot4)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo6Dot2)
                        pointList.Add(Com.MinP(TempList, "Y"));

                    pointList.Add(BC.TopGP.Points.P2);

                    if (DN.DimIDNo6Dot4)
                        pointList.Add(CentLP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, RightX, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }

                }



                // Dim No 6.3
                if (DN.DimIDNo6Dot3)
                {

                    pointList = new PointList();
                    pointList.Add(CentLP);
                    pointList.Add(Com.MinP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, RightX, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }

                }



                // Dim No 6.1, 6.5
                if (DN.DimIDNo6Dot1 || DN.DimIDNo6Dot5)
                {

                    pointList = new PointList();
                    if (DN.DimIDNo6Dot1)
                        pointList.Add(Com.MaxP(BC.TopGP.BoltMP, "Y"));
                    pointList.Add(BC.TopGP.IntPointB);
                    if (DN.DimIDNo6Dot5)
                        pointList.Add(CentLP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, RightX, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }

                }

                // Dim No 6
                if (DN.DimIDNo6)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.IntPoint);
                    pointList.Add(CentLP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, RightX, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }

                }

                // Dim No 12
                if (DN.DimIDNo12 && BC.BottGP != null)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P5);
                    pointList.Add(BC.BottGP.Points.P5);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, RightX, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }

                }


                #endregion

                #region RD Dim

                BC.PC.DistTop = (BC.PC.DistInc * 3);
                //RD Dim
                Vect = new Vector(0, 1, 0);

                // Dim No 4.1
                if (DN.DimIDNo4Dot1)
                {
                    pointList = new PointList();
                    pointList.AddRange(BC.TopGP.BoltMP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                // Dim No 4
                if (DN.DimIDNo4)
                {
                    if (BC.TopGP.BoltMP.Count > 2)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MinP(BC.TopGP.BoltMP, "Y"));
                        pointList.Add(Com.MaxP(BC.TopGP.BoltMP, "Y"));
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                            BC.PC.DistTop += BC.PC.DistInc;
                        }
                    }

                }

                // Dim No 2.2
                if (DN.DimIDNo2Dot2)
                {
                    pointList = new PointList();
                    pointList.Add(BC.RDPoint);
                    pointList.Add(BC.TopGP.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                // Dim No 2.3
                if (DN.DimIDNo2Dot3)
                {
                    pointList = new PointList();
                    pointList.Add(BC.RDPoint);
                    pointList.Add(BC.TopGP.IntPointB);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                // Dim No 2.1
                if (DN.DimIDNo2Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(BC.RDPoint);
                    pointList.Add(Com.MinP(BC.TopGP.BoltMP, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                // Dim No 2.4, 2
                if (DN.DimIDNo2Dot4 || DN.DimIDNo2)
                {
                    pointList = new PointList();
                    pointList.Add(BC.RDPoint);
                    pointList.Add(BC.TopGP.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                #endregion

                #region Top Straight Dim

                Vect = new Vector(0, 1, 0);

                // Dim No 11
                if (DN.DimIDNo11)
                {

                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P4);
                    pointList.Add(BC.TopGP.RefPBrace);
                    pointList.Add(Com.MaxP(BC.TopGP.BoltMP, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }
                // Dim No 9
                if (DN.DimIDNo9)
                {

                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P4);
                    pointList.Add(Com.MaxP(BC.TopGP.BoltMP, "Y"));
                    pointList.Add(BC.TopGP.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }
                // Dim No 22
                if (DN.DimIDNo22)
                {

                    pointList = new PointList();
                    pointList.Add(BC.TopGP.IntPointB);
                    pointList.Add(BC.TopGP.RefPBrace);
                    pointList.Add(Com.MaxP(BC.TopGP.BoltMP, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                // Dim No 10
                if (DN.DimIDNo10)
                {

                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P4);
                    pointList.Add(BC.TopGP.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                // Dim No 8
                if (DN.DimIDNo8)
                {

                    pointList = new PointList();
                    pointList.Add(BC.Points.P5);
                    pointList.Add(BC.TopGP.RefPBrace);
                    pointList.Add(BC.Points.P6);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                #endregion

                //Com.DrawLineDotted(CView, BC.TopGP.IntPoint, BC.TopGP.RefPBrace);

                //Dim Code 5 // Angle Dimension
                if (DN.DimIDNo5)
                {
                    double Dist = CalcDistAngel(BC.TopGP.RefPBrace, BC.TopGP.IntPoint);
                    Com.InsertAngleDim(CView, BC.TopGP.RefPBrace, BC.TopGP.IntPoint, "Top", Dist);
                }
            }

        }

        private void ApplyBottRightG()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            TSD.PointList TempList = new PointList();


            if (BC.BottGP?.GussetPlate != null)
            {

                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;

                TSG.Line YLine = new TSG.Line(BC.BottGP.Points.P5, BC.BottGP.Points.P1);
                //TSG.Line XLine = new TSG.Line(BC.BottGP.Points.P4, BC.BottGP.Points.P5);
                TSG.Line XLine = new TSG.Line(BC.BottGP.IntPoint, BC.BottGP.RefPBrace);

                Vector LeftVect = BC.BottGP.BoltM.GetCoordinateSystem().AxisY;

                if (LeftVect.X > 0)
                    LeftVect = dc.ChangeVector(LeftVect);

                Vector RightVect = BC.BottGP.BoltM.GetCoordinateSystem().AxisY;
                if (RightVect.X < 0)
                    RightVect = dc.ChangeVector(RightVect);

                Vector TopVect = BC.BottGP.BoltM.GetCoordinateSystem().AxisX;
                if (TopVect.Y < 0)
                    TopVect = dc.ChangeVector(TopVect);

                Vector BottVect = BC.BottGP.BoltM.GetCoordinateSystem().AxisX;
                if (BottVect.Y > 0)
                    BottVect = dc.ChangeVector(BottVect);



                #region Diagonal Left
                BC.PC.DistLeft = (BC.PC.DistInc * 1.25);
                TempList = dc.ChangePints(BC.BottGP.BoltMP, CView, RightVect);
                // Dim No 7, 7.1
                if (DN.DimIDNo7 || DN.DimIDNo7Dot1)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo7)// Dim No 7
                        pointList.Add(Com.MaxP(TempList, "Y"));

                    pointList.Add(BC.BottGP.IntPointB);
                    if (DN.DimIDNo7Dot1)// Dim No 7.1
                        pointList.Add(BC.BottGP.RefPBrace);

                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }
                }


                // Dim No 3.1 , 3, 16
                if (DN.DimIDNo3Dot1 || DN.DimIDNo3 || DN.DimIDNo16)
                {

                    pointList = new PointList();
                    if (DN.DimIDNo3Dot1)
                    {
                        pointList.Add(Com.MinP(TempList, "Y"));
                        pointList.Add(BC.BottGP.Points.P1);
                    }
                    if (DN.DimIDNo3)
                        pointList.AddRange(TempList);

                    if (DN.DimIDNo16)
                    {
                        pointList.Add(Com.MaxP(TempList, "Y"));
                        pointList.Add(BC.BottGP.RefPBrace);
                    }

                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }
                }

                // Dim No 3.2
                if (DN.DimIDNo3Dot2)
                {
                    if (TempList.Count > 2)
                    {
                        pointList = new PointList();
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                        {
                            PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);
                            Com.GroupDim(xDim);
                        }
                    }
                }

                #endregion

                #region Straight Left

                Point CentLP = new Point(BC.BottGP.Points.P3.X, BC.Points.CentP.Y);

                Vect = new Vector(-1, 0, 0);
                BC.PC.DistLeft = (BC.PC.DistInc);

                double LeftX = BC.BottGP.Points.P3.X;
                //if (BC.BottGP != null && BC.BottGP.BracePos == "Right" && BC.BottGP.Points.P2.X > RightX)
                //    RightX = BC.BottGP.Points.P2.X;

                TempList = Com.GetBoltPoints(BC.BottGP.BoltM);

                // Dim No 6.2, 6.4
                if (DN.DimIDNo6Dot2 || DN.DimIDNo6Dot4)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo6Dot2)
                        pointList.Add(Com.MaxP(TempList, "Y"));

                    pointList.Add(BC.BottGP.Points.P3);

                    if (DN.DimIDNo6Dot4)
                        pointList.Add(CentLP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, LeftX, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }

                }



                // Dim No 6.3
                if (DN.DimIDNo6Dot3)
                {

                    pointList = new PointList();
                    pointList.Add(CentLP);
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, LeftX, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }

                }



                // Dim No 6.1, 6.5
                if (DN.DimIDNo6Dot1 || DN.DimIDNo6Dot5)
                {

                    pointList = new PointList();
                    if (DN.DimIDNo6Dot1)
                        pointList.Add(Com.MinP(BC.BottGP.BoltMP, "Y"));
                    pointList.Add(BC.BottGP.IntPointB);
                    if (DN.DimIDNo6Dot5)
                        pointList.Add(CentLP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, LeftX, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }

                }

                // Dim No 6
                if (DN.DimIDNo6)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.IntPoint);
                    pointList.Add(CentLP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, LeftX, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }

                }


                #endregion

                #region RD Dim

                BC.PC.DistBot = (BC.PC.DistInc * 3);
                //RD Dim
                Vect = new Vector(0, -1, 0);

                // Dim No 4.1
                if (DN.DimIDNo4Dot1)
                {
                    pointList = new PointList();
                    pointList.AddRange(BC.BottGP.BoltMP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                // Dim No 4
                if (DN.DimIDNo4)
                {
                    if (BC.BottGP.BoltMP.Count > 2)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MinP(BC.BottGP.BoltMP, "Y"));
                        pointList.Add(Com.MaxP(BC.BottGP.BoltMP, "Y"));
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                            BC.PC.DistBot += BC.PC.DistInc;
                        }
                    }

                }
                bool IsRefRD = (BC.TopGP == null) || (BC.TopGP != null && !dc.IsEqualPoints(BC.TopGP.RefPBrace, BC.BottGP.RefPBrace));
                if (!IsRefRD)
                    BC.PC.DistBot += BC.PC.DistInc;

                // Dim No 2.2
                if (DN.DimIDNo2Dot2 && IsRefRD)
                {
                    pointList = new PointList();
                    pointList.Add(BC.RDPoint);
                    pointList.Add(BC.BottGP.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                // Dim No 2.3
                if (DN.DimIDNo2Dot3)
                {
                    pointList = new PointList();
                    pointList.Add(BC.RDPoint);
                    pointList.Add(BC.BottGP.IntPointB);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                // Dim No 2.1
                if (DN.DimIDNo2Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(BC.RDPoint);
                    pointList.Add(Com.MaxP(BC.BottGP.BoltMP, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                // Dim No 2.4, 2
                if (DN.DimIDNo2Dot4 || DN.DimIDNo2)
                {
                    pointList = new PointList();
                    pointList.Add(BC.RDPoint);
                    pointList.Add(BC.BottGP.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                #endregion

                #region Bottom Straight Dim

                Vect = new Vector(0, -1, 0);

                // Dim No 11
                if (DN.DimIDNo11)
                {

                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P4);
                    pointList.Add(BC.BottGP.RefPBrace);
                    pointList.Add(Com.MinP(BC.BottGP.BoltMP, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }
                // Dim No 9
                if (DN.DimIDNo9)
                {

                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P4);
                    pointList.Add(Com.MinP(BC.BottGP.BoltMP, "Y"));
                    pointList.Add(BC.BottGP.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }
                // Dim No 22
                if (DN.DimIDNo22)
                {

                    pointList = new PointList();
                    pointList.Add(BC.BottGP.IntPointB);
                    pointList.Add(BC.BottGP.RefPBrace);
                    pointList.Add(Com.MinP(BC.BottGP.BoltMP, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                // Dim No 10
                if (DN.DimIDNo10)
                {

                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P4);
                    pointList.Add(BC.BottGP.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                // Dim No 8
                if (DN.DimIDNo8 && BC.TopGP == null)
                {

                    pointList = new PointList();
                    pointList.Add(BC.Points.P5);
                    pointList.Add(BC.BottGP.RefPBrace);
                    pointList.Add(BC.Points.P6);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                #endregion

                //  Com.DrawLineDotted(CView, BC.BottGP.IntPoint, BC.BottGP.RefPBrace);

                //Dim Code 5 // Angle Dimension
                if (DN.DimIDNo5)
                {
                    double Dist = CalcDistAngel(BC.BottGP.RefPBrace, BC.BottGP.IntPoint);
                    Com.InsertAngleDim(CView, BC.BottGP.RefPBrace, BC.BottGP.IntPoint, "Bottom", Dist);
                }



            }

        }

        private double CalcDistAngel(Point StartP, Point EndP)
        {
            double Dv = 12 / 0.20;
            double ScalM = (12 - CView.Attributes.Scale) * 5;
            double ScaleD = 0.20 - ((12 - CView.Attributes.Scale) / Dv);


            double Dist = (Distance.PointToPoint(StartP, EndP) * ScaleD);
            Dist += ScalM;
            return Dist;
        }

        // Apply Dim in Front View
        private void ApplyTBV()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            TSD.PointList TempList = new PointList();
            List<double> XVals = new List<double>();
            if (BC.GPTV != null)
            {
                GussetClassTV GCE = null;
                int i = 0;
                foreach (GussetClassTV GCT in BC.GPTV)
                {
                    BC.PC.DistTop = (BC.PC.DistInc * 2);
                    BC.PC.DistBot = (BC.PC.DistInc * 2);
                    bool IsSameGP = false;
                    if (GCT.GussetPlate != null)
                    {
                        IsSameGP = (GCE != null && Com.IsEqualPoints(GCE.GussetPlate.Points.P1, GCT.GussetPlate.Points.P1) && Com.IsEqualPoints(GCE.GussetPlate.Points.P4, GCT.GussetPlate.Points.P4));
                        if (!IsSameGP)
                        {
                            // DIm No 1, 1.1
                            if (DN.DimIDNo1 || DN.DimIDNo1Dot1)
                            {
                                if (i % 2 == 0)
                                {
                                    Vect = new Vector(1, 0, 0);
                                    pointList = new PointList();
                                    if (DN.DimIDNo1)
                                        pointList.Add(new Point(GCT.GussetPlate.Points.P4.X, BC.Points.P4.Y));

                                    pointList.Add(GCT.GussetPlate.Points.P4);

                                    if (DN.DimIDNo1Dot1)
                                        pointList.Add(GCT.GussetPlate.Points.P3);


                                }
                                else
                                {
                                    Vect = new Vector(-1, 0, 0);
                                    pointList = new PointList();
                                    if (DN.DimIDNo1)
                                        pointList.Add(new Point(GCT.GussetPlate.Points.P1.X, BC.Points.P1.Y));

                                    pointList.Add(GCT.GussetPlate.Points.P1);

                                    if (DN.DimIDNo1Dot1)
                                        pointList.Add(GCT.GussetPlate.Points.P2);
                                }

                                xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);


                            }



                            GCE = GCT;
                        }
                    }

                    if (!IsSameGP)
                    {

                        if (i % 2 == 0)
                        {
                            Vect = new Vector(0, 1, 0);
                            // Dim No 18, 18.1
                            if (GCT.StiffNS != null && (DN.DimIDNo18))
                            {
                                if (!IsExist(XVals, GCT.StiffNS.Points.P1.X))
                                {
                                    pointList = new PointList();
                                    pointList.Add(BC.Points.P1);
                                    pointList.Add(GCT.StiffNS.Points.P1);
                                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                                    if (xDim != null)
                                        PL.DistPlaceTopP(xDim, BC.Points.P1.Y, BC.PC.DistTop);
                                }

                                XVals.Add(GCT.StiffNS.Points.P1.X);
                            }

                            // Dim No 19, 19.1
                            if (GCT.StiffFS != null && (DN.DimIDNo19))
                            {
                                if (!IsExist(XVals, GCT.StiffFS.Points.P1.X))
                                {
                                    pointList = new PointList();
                                    pointList.Add(BC.Points.P1);
                                    pointList.Add(GCT.StiffFS.Points.P1);
                                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                                    if (xDim != null)
                                        PL.DistPlaceTopP(xDim, BC.Points.P1.Y, BC.PC.DistTop);
                                }

                                XVals.Add(GCT.StiffFS.Points.P1.X);
                            }


                            // Dim No 18.1, 19.1
                            if (DN.DimIDNo18Dot1 || DN.DimIDNo19Dot1)
                            {
                                pointList = new PointList();
                                pointList.Add(BC.Points.P1);
                                if (GCT.StiffNS != null && DN.DimIDNo18Dot1 && !IsExist(XVals, GCT.StiffNS.Points.P1.X))
                                    pointList.Add(GCT.StiffNS.Points.P1);
                                if (GCT.StiffFS != null && DN.DimIDNo19Dot1 && !IsExist(XVals, GCT.StiffFS.Points.P1.X))
                                    pointList.Add(GCT.StiffFS.Points.P1);
                                xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistInc, RdAtrr);
                                if (xDim != null)
                                    PL.DistPlaceTopP(xDim, BC.Points.P1.Y, BC.PC.DistTop);

                                if (GCT.StiffFS != null)
                                    XVals.Add(GCT.StiffFS.Points.P1.X);
                                if (GCT.StiffNS != null)
                                    XVals.Add(GCT.StiffNS.Points.P1.X);
                            }

                            Vect = new Vector(0, -1, 0);
                            // Dim No 23
                            if (DN.DimIDNo23 && GCT.StiffNS != null && GCT.StiffFS != null)
                            {

                                pointList = new PointList();
                                pointList.Add(GCT.StiffNS.Points.P1);
                                pointList.Add(GCT.StiffFS.Points.P1);
                                xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                                if (xDim != null)
                                    PL.DistPlaceBottP(xDim, BC.Points.P2.Y, BC.PC.DistInc);


                            }
                        }
                        else
                        {
                            Vect = new Vector(0, -1, 0);
                            // Dim No 18, 18.1
                            if (GCT.StiffNS != null && (DN.DimIDNo18))
                            {
                                if (!IsExist(XVals, GCT.StiffNS.Points.P1.X))
                                {
                                    pointList = new PointList();
                                    pointList.Add(BC.Points.P2);
                                    pointList.Add(GCT.StiffNS.Points.P2);
                                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                                    if (xDim != null)
                                        PL.DistPlaceBottP(xDim, BC.Points.P2.Y, BC.PC.DistBot);
                                }

                                XVals.Add(GCT.StiffNS.Points.P1.X);
                            }

                            // Dim No 19, 19.1
                            if (GCT.StiffFS != null && (DN.DimIDNo19))
                            {
                                if (!IsExist(XVals, GCT.StiffFS.Points.P1.X))
                                {
                                    pointList = new PointList();
                                    pointList.Add(BC.Points.P2);
                                    pointList.Add(GCT.StiffFS.Points.P2);
                                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                                    if (xDim != null)
                                        PL.DistPlaceBottP(xDim, BC.Points.P2.Y, BC.PC.DistBot);
                                }


                                XVals.Add(GCT.StiffFS.Points.P1.X);
                            }


                            // Dim No 18.1, 19.1
                            if (DN.DimIDNo18Dot1 || DN.DimIDNo19Dot1)
                            {
                                pointList = new PointList();
                                pointList.Add(BC.Points.P2);
                                if (GCT.StiffNS != null && DN.DimIDNo18Dot1 && !IsExist(XVals, GCT.StiffNS.Points.P1.X))
                                    pointList.Add(GCT.StiffNS.Points.P2);
                                if (GCT.StiffFS != null && DN.DimIDNo19Dot1 && !IsExist(XVals, GCT.StiffFS.Points.P1.X))
                                    pointList.Add(GCT.StiffFS.Points.P2);
                                xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                                if (xDim != null)
                                    PL.DistPlaceBottP(xDim, BC.Points.P2.Y, BC.PC.DistBot);

                                if (GCT.StiffFS != null)
                                    XVals.Add(GCT.StiffFS.Points.P1.X);
                                if (GCT.StiffNS != null)
                                    XVals.Add(GCT.StiffNS.Points.P1.X);
                            }

                            Vect = new Vector(0, 1, 0);
                            // Dim No 23
                            if (DN.DimIDNo23 && GCT.StiffNS != null && GCT.StiffFS != null)
                            {

                                pointList = new PointList();
                                pointList.Add(GCT.StiffNS.Points.P1);
                                pointList.Add(GCT.StiffFS.Points.P1);
                                xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistInc, StAtrr);
                                if (xDim != null)
                                    PL.DistPlaceTopP(xDim, BC.Points.P1.Y, BC.PC.DistInc);

                            }

                        }





                        i++;
                    }
                    Ids.Add(GCT.GussetPlate.part.Identifier.ID);

                }

            }

            // Dim No 17 Elevation Dim
            if (DN.DimIDNo17)
            {

                BC.PC.DistLeft += BC.PC.DistInc;
                Vect = new Vector(-1, 0, 0);
                StraightDimensionSet.StraightDimensionSetAttributes ElAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.ElevationDimension);
                ElAtrr.DimensionType = DimensionSetBaseAttributes.DimensionTypes.Elevation;
                ElAtrr.Arrowhead.Head = ArrowheadTypes.FilledArrow;
                pointList = new PointList();

                if (MainBeam.StartPoint.X > MainBeam.EndPoint.X)
                {
                    pointList.Add(MainBeam.EndPoint);
                    pointList.Add(MainBeam.EndPoint);

                }
                else
                {
                    pointList.Add(MainBeam.StartPoint);
                    pointList.Add(MainBeam.StartPoint);
                }

                BC.PC.DistLeft = BC.PC.DistLeft - (BC.Points.P1.X - pointList[0].X);
                xDim = dc.InsertDimm(CView, pointList, Vect, (-BC.PC.DistLeft), ElAtrr);
                if (xDim != null)
                {
                    xDim.Distance = (-BC.PC.DistLeft);
                    xDim.Modify();
                }
                BC.PC.DistLeft += BC.PC.DistInc;

            }

        }

        private void ApplyDimSection()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            TSD.PointList TempList = new PointList();

            // Dim No 20, 20.1
            if (DN.DimIDNo20 || DN.DimIDNo20Dot1)
            {
                if (BC.LeftStiff != null)
                {
                    pointList = new PointList();

                    if (DN.DimIDNo20) // Dim No 20
                        pointList.Add(BC.LeftStiff.Points.P1);

                    pointList.Add(BC.LeftStiff.Points.P4);

                    if (DN.DimIDNo20Dot1) // Dim No 20.1
                        pointList.Add(MainBeam.StartPoint);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);
                }


                if (BC.RightStiff != null)
                {
                    pointList = new PointList();

                    if (DN.DimIDNo20) // Dim No 20
                        pointList.Add(BC.RightStiff.Points.P4);

                    pointList.Add(BC.RightStiff.Points.P1);

                    if (DN.DimIDNo20Dot1) // Dim No 23.1
                        pointList.Add(MainBeam.StartPoint);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);
                }
            }

            if (BC.LeftStiff != null)
            {
                Vect = new Vector(-1, 0, 0);
                // Dim No 21.1
                if (DN.DimIDNo21Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(BC.LeftStiff.Points.P1);
                    pointList.Add(BC.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);


                    pointList = new PointList();
                    pointList.Add(BC.LeftStiff.Points.P2);
                    pointList.Add(BC.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                }

                // Dim No 21
                if (DN.DimIDNo21)
                {
                    pointList = new PointList();
                    pointList.Add(BC.LeftStiff.Points.P1);
                    pointList.Add(BC.LeftStiff.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                }

                Ids.Add(BC.LeftStiff.part.Identifier.ID);
            }

            if (BC.RightStiff != null)
            {
                Vect = new Vector(1, 0, 0);
                // Dim No 21.1
                if (DN.DimIDNo21Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(BC.RightStiff.Points.P4);
                    pointList.Add(BC.Points.P4);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);


                    pointList = new PointList();
                    pointList.Add(BC.RightStiff.Points.P3);
                    pointList.Add(BC.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                }

                // Dim No 21
                if (DN.DimIDNo21)
                {
                    pointList = new PointList();
                    pointList.Add(BC.RightStiff.Points.P4);
                    pointList.Add(BC.RightStiff.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                }

                Ids.Add(BC.RightStiff.part.Identifier.ID);
            }


        }

        private void TestDim()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;

            Vector Vect = new Vector(0, 1, 0);

            TSD.PointList TempList = new PointList();

            if (BC.TopGP?.GussetPlate != null && BC.BottGP?.GussetPlate != null)
            {



                Point WP = BC.TopGP.IntPoint;
                Point Temp = new Point(WP.X, WP.Y + 100, WP.Z);
                AngleDimension angDimA = new AngleDimension(CView, WP, BC.TopGP.RefPBrace, Temp, -800);
                angDimA.Insert();



                WP = BC.BottGP.IntPoint;
                Temp = new Point(WP.X, BC.BottGP.RefPBrace.Y, WP.Z);
                angDimA = new AngleDimension(CView, WP, BC.BottGP.RefPBrace, Temp, 800);
                angDimA.Insert();


                //BC.PC.DistLeft = (BC.PC.DistInc * 6);
                //Vect = new Vector(-1, 0, 0);

                //pointList = new PointList();
                //pointList.Add(BC.TopGP.Points.P1);
                //pointList.Add(BC.BottGP.Points.P1);
                //xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                //if (xDim != null)
                //    PL.DistPlaceLeftP(xDim, BC.BottGP.Points.P2.X, BC.PC.DistLeft);
            }


        }

        private bool IsExist(List<double> DList, double Dval)
        {
            if ((from d in DList where Com.IsEqual(d, Dval) select d).Count() > 0)
                return true;
            else
                return false;
        }

        #region Get Data
        private void GetBeamClassClass(TSD.View CView)
        {
            if (ViewName == "Top View" || ViewName == "Bottom View")
            {
                BC = new BeamClass_BG2();
                BC.beam = MainBeam;
                List<TSM.Part> PartListC = BC.beam.GetAssembly().GetSecondaries().OfType<TSM.Part>().ToList();

                BC.Points = Com.GetPartPoints(BC.beam);

                List<TSM.BoltGroup> BoltDList = Com.EnumtoArray(BC.beam.GetBolts()).OfType<TSM.BoltGroup>().ToList();
                Point CentP = Com.CenterPoint(BC.beam.StartPoint, BC.beam.EndPoint);
                double Lenght = (BC.beam.GetSolid().MaximumPoint.X - BC.beam.GetSolid().MinimumPoint.X) / 10;
                double MinX = BC.beam.GetSolid().MinimumPoint.X + Lenght;
                double MaxX = BC.beam.GetSolid().MaximumPoint.X - Lenght;

                //List<TSM.Part> PartListF = (from p in PartListC where !Com.IsCode(p) select p).ToList();
                List<TSM.Part> PartListF = (from p in PartListC where !Ids.Contains(p.Identifier.ID) select p).ToList();
                ContourPlate TopGP = (from p in PartListF.OfType<ContourPlate>() where IsBG2(p) && (Com.CenterPoint(p).Y > BC.Points.CentP.Y) && !dc.IsPlateSideView(p) orderby Com.CenterPoint(p).X ascending select p).FirstOrDefault();

                ContourPlate BottGP = null;
                if (TopGP != null)
                {
                    BC.TopGP = GetGussetClass(TopGP, "Top");
                    BottGP = (from p in PartListF.OfType<ContourPlate>() where IsBG2(p) && (BC.TopGP.Points.CentP.X > p.GetSolid().MinimumPoint.X && BC.TopGP.Points.CentP.X < p.GetSolid().MaximumPoint.X) && (Com.CenterPoint(p).Y < BC.Points.CentP.Y) && !dc.IsPlateSideView(p) orderby Com.CenterPoint(p).X ascending select p).FirstOrDefault();
                }
                else
                {
                    BottGP = (from p in PartListF.OfType<ContourPlate>() where IsBG2(p) && (Com.CenterPoint(p).Y < BC.Points.CentP.Y) && !dc.IsPlateSideView(p) select p).FirstOrDefault();
                }

                if (BottGP != null)
                {
                    BC.BottGP = GetGussetClass(BottGP, "Bottom");
                    BC.BottGP.StiffList = GetStiffClass(BottGP, PartListF);
                }
                else if (TopGP != null)
                    BC.TopGP.StiffList = GetStiffClass(TopGP, PartListF);

                BC.RDPoint = new Point(BC.Points.P1.X, BC.Points.CentP.Y);

                PartListC.Add(MainBeam);
                TSM.Part LeftPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.X ascending select p).FirstOrDefault();
                TSM.Part RightPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.X descending select p).FirstOrDefault();
                TSM.Part TopPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.Y descending select p).FirstOrDefault();
                TSM.Part BottPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.Y ascending select p).FirstOrDefault();

                BC.Points.P5 = Com.MinP(Com.GetVertxPointsD(LeftPart), "X");
                BC.Points.P6 = Com.MaxP(Com.GetVertxPointsD(RightPart), "X");


                BC.PC = new PlacingClass();
                BC.PC.TopY = TopPart.GetSolid().MaximumPoint.Y;
                BC.PC.BottomY = BottPart.GetSolid().MinimumPoint.Y;
                BC.PC.LeftX = LeftPart.GetSolid().MinimumPoint.X;// Math.Round(CView.RestrictionBox.MinPoint.X);
                BC.PC.RightX = RightPart.GetSolid().MaximumPoint.X;

                double AvScale = 12;
                double AvDistInc = 100;
                double DistPerScale = AvDistInc / AvScale;
                double CScale = CView.Attributes.Scale;
                BC.PC.DistInc = CScale * DistPerScale;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;

            }

            else if (ViewName == "Front View")
            {
                BC = new BeamClass_BG2();
                BC.beam = MainBeam;
                BC.Points = Com.GetPartPoints(BC.beam);
                List<TSM.Part> PartListC = BC.beam.GetAssembly().GetSecondaries().OfType<TSM.Part>().ToList();
                List<TSM.Part> PartListF = (from p in PartListC where !Ids.Contains(p.Identifier.ID) select p).ToList();

                GetGussetClassTV(PartListF);

                BC.RDPoint = new Point(BC.Points.P1.X, BC.Points.CentP.Y);

                PartListC.Add(MainBeam);
                TSM.Part LeftPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.X ascending select p).FirstOrDefault();
                TSM.Part RightPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.X descending select p).FirstOrDefault();
                TSM.Part TopPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.Y descending select p).FirstOrDefault();
                TSM.Part BottPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.Y ascending select p).FirstOrDefault();

                BC.PC = new PlacingClass();
                BC.PC.TopY = TopPart.GetSolid().MaximumPoint.Y;
                BC.PC.BottomY = BottPart.GetSolid().MinimumPoint.Y;
                BC.PC.LeftX = LeftPart.GetSolid().MinimumPoint.X;// Math.Round(CView.RestrictionBox.MinPoint.X);
                BC.PC.RightX = RightPart.GetSolid().MaximumPoint.X;

                double AvScale = 12;
                double AvDistInc = 100;
                double DistPerScale = AvDistInc / AvScale;
                double CScale = CView.Attributes.Scale;
                BC.PC.DistInc = CScale * DistPerScale;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;
            }
            else if (ViewName == "Section View")
            {
                BC = new BeamClass_BG2();
                BC.beam = MainBeam;
                BC.Points = Com.GetPartPoints(BC.beam);
                List<TSM.Part> PartListC = BC.beam.GetAssembly().GetSecondaries().OfType<TSM.Part>().ToList();
                PartListC = (from p in PartListC where !Ids.Contains(p.Identifier.ID) select p).ToList();
                double MaxZ = CView.RestrictionBox.MinPoint.Z;
                List<TSM.Part> PartList = (from p in PartListC where Com.IsViewObj(p, CView) select p).ToList();
                //List<TSM.Part> PartList = (from p in PartListC where p.GetSolid().MaximumPoint.Z > MaxZ select p).ToList();

                TSM.Part LeftSt = (from p in PartList where !Com.HasBolt(p) && Com.GetProType(p) != "L" && !dc.IsPlateSideViewN(p) && Com.CenterPoint(p).X < BC.Points.CentP.X select p).FirstOrDefault();
                TSM.Part RightSt = (from p in PartList where !Com.HasBolt(p) && Com.GetProType(p) != "L" && !dc.IsPlateSideViewN(p) && Com.CenterPoint(p).X > BC.Points.CentP.X select p).FirstOrDefault();

                if (LeftSt != null)
                    BC.LeftStiff = Com.GetPartClass(LeftSt);

                if (RightSt != null)
                    BC.RightStiff = Com.GetPartClass(RightSt);

                PartList.Add(MainBeam);
                TSM.Part LeftPart = (from p in PartList orderby p.GetSolid().MinimumPoint.X ascending select p).FirstOrDefault();
                TSM.Part RightPart = (from p in PartList orderby p.GetSolid().MaximumPoint.X descending select p).FirstOrDefault();
                TSM.Part TopPart = (from p in PartList orderby p.GetSolid().MaximumPoint.Y descending select p).FirstOrDefault();
                TSM.Part BottPart = (from p in PartList orderby p.GetSolid().MinimumPoint.Y ascending select p).FirstOrDefault();

                BC.PC = new PlacingClass();
                BC.PC.TopY = TopPart.GetSolid().MaximumPoint.Y;
                BC.PC.BottomY = BottPart.GetSolid().MinimumPoint.Y;
                BC.PC.LeftX = MainBeam.StartPoint.X;// Math.Round(CView.RestrictionBox.MinPoint.X);
                BC.PC.RightX = RightPart.GetSolid().MaximumPoint.X;

                double AvScale = 12;
                double AvDistInc = 100;
                double DistPerScale = AvDistInc / AvScale;
                double CScale = CView.Attributes.Scale;
                BC.PC.DistInc = CScale * DistPerScale;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;

            }

        }

        private GussetClass GetGussetClass(ContourPlate GP, string Position)
        {
            GussetClass GC = new GussetClass();
            GC.GussetPlate = GP;
            Point CentP = Com.CenterPoint(GP);
            BoltGroup MidBolt = Com.EnumtoArray(GP.GetBolts()).OfType<BoltGroup>().FirstOrDefault();

            if (MidBolt != null)
            {
                GC.BoltM = MidBolt;
                GC.BoltMP = Com.GetBoltPoints(MidBolt);
                Beam brace = GetBrace(GC.BoltM, GP);
                if (brace != null)
                {
                    GC.Brace = brace;
                    GC.IntPoint = GetIntSectPoint(GC.BoltM, brace, Position);

                    double WebThickH = Com.GetPartWebThickness(MainBeam) / 2;

                    if (Position == "Top")
                    {
                        // GC.RefPBrace = dc.NearestPoint(GC.Brace.StartPoint, GC.Brace.EndPoint, MidBolt.FirstPosition);

                        GC.RefPBrace = GetBraceRefPoint(brace);

                        if (GC.Brace.StartPoint.Y > GC.Brace.EndPoint.Y)
                            GC.RefPBrace = GC.Brace.EndPoint;


                        TSD.Line line1 = Com.DrawLineDotted1(CView, new Point(BC.Points.P1.X, BC.Points.CentP.Y + WebThickH), new Point(BC.Points.P4.X, BC.Points.CentP.Y + WebThickH));
                        TSD.Line line2 = Com.DrawLineDotted1(CView, GC.RefPBrace, GC.IntPoint);

                        if (GC.RefPBrace != null && GC.IntPoint != null)
                            GC.IntPointB = Com.GetIntersectionPointN(GC.RefPBrace, GC.IntPoint, new Point(BC.Points.P1.X, BC.Points.CentP.Y + WebThickH), new Point(BC.Points.P4.X, BC.Points.CentP.Y + WebThickH));

                        GC.BracePos = GetBracePos(GC);

                        if (GC.BracePos == "Left")
                            GC.Degree = GetDegree(GC.IntPointB, GC.IntPoint, BC.Points.P1);
                        else
                            GC.Degree = GetDegree(GC.IntPointB, GC.IntPoint, BC.Points.P4);

                        line1.Delete();
                        line2.Delete();
                    }
                    else
                    {
                        GC.RefPBrace = GetBraceRefPoint(brace);

                        if (GC.Brace.StartPoint.Y < GC.Brace.EndPoint.Y)
                            GC.RefPBrace = GC.Brace.EndPoint;

                        TSD.Line line1 = Com.DrawLineDotted1(CView, new Point(BC.Points.P2.X, BC.Points.CentP.Y - WebThickH), new Point(BC.Points.P3.X, BC.Points.CentP.Y - WebThickH));
                        TSD.Line line2 = Com.DrawLineDotted1(CView, GC.RefPBrace, GC.IntPoint);

                        if (GC.RefPBrace != null && GC.IntPoint != null)
                            GC.IntPointB = Com.GetIntersectionPointN(GC.RefPBrace, GC.IntPoint, new Point(BC.Points.P2.X, BC.Points.CentP.Y - WebThickH), new Point(BC.Points.P3.X, BC.Points.CentP.Y - WebThickH));


                        GC.BracePos = GetBracePos(GC);

                        if (GC.BracePos == "Left")
                            GC.Degree = GetDegree(GC.IntPointB, GC.IntPoint, BC.Points.P2);
                        else
                            GC.Degree = GetDegree(GC.IntPointB, GC.IntPoint, BC.Points.P3);

                        line1.Delete();
                        line2.Delete();
                    }
                }
            }

            GC.Points = GetGussetPoints(GP, GC.BracePos);




            return GC;
        }

        private void GetGussetClassTV(List<TSM.Part> PartListF)
        {
            List<TSM.Part> GussetPlates = (from p in PartListF where IsBG2(p) select p).ToList();
            if (GussetPlates != null && GussetPlates.Count > 0)
            {
                BC.GPTV = new List<GussetClassTV>();
                foreach (TSM.Part part in GussetPlates)
                {
                    GussetClassTV GCT = new GussetClassTV();
                    GCT.GussetPlate = Com.GetPartClass(part);
                    PartPoints Points = Com.GetPartPoints(part);

                    double ThickH = Com.GetPlateThickness(part) / 2;

                    TSM.Part StiffNS = (from p in PartListF where !dc.IsHorzObj(p) && (Com.CenterPoint(p).Y > BC.Points.P2.Y && Com.CenterPoint(p).Y < BC.Points.P1.Y) && p.GetSolid().MinimumPoint.X < Points.P1.X && dc.IsEqualOrGreater(p.GetSolid().MaximumPoint.X, (Points.P1.X - ThickH)) select p).FirstOrDefault();

                    TSM.Part StiffFS = (from p in PartListF where !dc.IsHorzObj(p) && (Com.CenterPoint(p).Y > BC.Points.P2.Y && Com.CenterPoint(p).Y < BC.Points.P1.Y) && p.GetSolid().MaximumPoint.X > Points.P4.X && dc.IsEqualOrLess(p.GetSolid().MinimumPoint.X, (Points.P4.X + ThickH)) select p).FirstOrDefault();

                    if (StiffNS != null)
                        GCT.StiffNS = Com.GetPartClass(StiffNS);

                    if (StiffFS != null)
                        GCT.StiffFS = Com.GetPartClass(StiffFS);

                    BC.GPTV.Add(GCT);
                }
            }

        }

        private string GetBracePos(GussetClass GC)
        {
            Point CentP = Com.CenterPoint(GC.Brace.StartPoint, GC.Brace.EndPoint);
            if (GC.IntPoint.X > GC.RefPBrace.X)
                return "Right";
            else
                return "Left";
        }

        private Beam GetBrace(BoltGroup BoltL, TSM.Part GP)
        {

            Beam brace = (from b in Com.GetBoltParts(BoltL).OfType<TSM.Beam>() where b.Identifier.ID != GP.Identifier.ID && (b.Name.ToLower().Contains("brace") || (dc.IsMainPart(b) && !dc.IsPlate(b))) select b).FirstOrDefault();
            if (brace == null)
            {
                List<TSM.Part> PartList = (from b in Com.GetBoltParts(BoltL).OfType<TSM.Part>() where b.Identifier.ID != GP.Identifier.ID select b).ToList();

                foreach (TSM.Part part in PartList)
                {

                    BoltGroup bolt2 = Com.EnumtoArray(part.GetBolts()).OfType<BoltGroup>().Where(x => x.Identifier.ID != BoltL.Identifier.ID).FirstOrDefault();
                    if (bolt2 != null)
                    {
                        brace = (from b in Com.GetBoltParts(bolt2).OfType<TSM.Beam>() where b.Identifier.ID != GP.Identifier.ID && (b.Name.ToLower().Contains("brace") || (dc.IsMainPart(b) && !dc.IsPlate(b))) select b).FirstOrDefault();
                    }

                }

                if (brace == null)
                {
                    foreach (TSM.Part part in PartList)
                    {
                        if (dc.IsMainPart(part) && dc.IsPlate(part))
                        {

                            List<TSM.Part> PartLists = Com.EnumtoArray(part.GetWelds()).OfType<TSM.Weld>().Select(x => x.MainObject).OfType<TSM.Part>().ToList();
                            PartLists.AddRange(Com.EnumtoArray(part.GetWelds()).OfType<TSM.Weld>().Select(x => x.SecondaryObject).OfType<TSM.Part>().ToList());

                            brace = (from b in PartLists.OfType<Beam>() where IsBrace(b) select b).FirstOrDefault();
                            if (brace == null)
                            {
                                PartLists = (from b in PartLists where !dc.IsMainPart(b) select b.GetAssembly().GetMainPart()).OfType<TSM.Part>().ToList();
                                brace = (from b in PartLists.OfType<Beam>() where IsBrace(b) select b).FirstOrDefault();
                                if (brace != null)
                                    break;
                            }


                        }

                    }
                }

                if (brace == null)
                {
                    foreach (TSM.Part part in PartList)
                    {
                        if (dc.IsMainPart(part) && dc.IsPlate(part))
                        {

                            List<BoltGroup> BoltsList = Com.EnumtoArray(part.GetBolts()).OfType<TSM.BoltGroup>().ToList();
                            if (BoltsList != null && BoltsList.Count > 0)
                            {
                                List<TSM.Part> PartLists = new List<TSM.Part>();

                                BoltsList.ForEach(x => PartLists.AddRange(Com.GetBoltParts(x)));

                                brace = (from b in PartLists.OfType<Beam>() where IsBrace(b) select b).FirstOrDefault();
                                if (brace == null)
                                {
                                    PartLists = (from b in PartLists where !dc.IsMainPart(b) select b.GetAssembly().GetMainPart()).OfType<TSM.Part>().ToList();
                                    brace = (from b in PartLists.OfType<Beam>() where IsBrace(b) select b).FirstOrDefault();
                                    if (brace != null)
                                        break;
                                }
                            }


                        }

                    }
                }
            }

            return brace;

        }

        private PartPoints GetGussetPoints(ContourPlate GP, string Position)
        {


            PartPoints RetP = new PartPoints();
            PointList pointList = Com.ContPList(GP);
            RetP.CentP = Com.CenterPoint(GP);

            double MinY = GP.GetSolid().MinimumPoint.Y + 25;
            double MaxY = GP.GetSolid().MaximumPoint.Y - 25;
            if (Position == "Left")
            {
                if (RetP.CentP.Y > BC.Points.CentP.Y)
                {

                    RetP.P2 = (from p in pointList.OfType<Point>() where p.Y < MinY orderby p.X ascending select p).FirstOrDefault();
                    RetP.P3 = (from p in pointList.OfType<Point>() where p.Y < MinY orderby p.X descending select p).FirstOrDefault();

                    RetP.P1 = (from p in pointList.OfType<Point>() where p.Y > MinY orderby p.X ascending select p).FirstOrDefault();
                    RetP.P4 = (from p in pointList.OfType<Point>() where p.Y > MinY orderby p.X descending select p).FirstOrDefault();

                    RetP.P5 = (from p in pointList.OfType<Point>() where p.Y > RetP.P4.Y orderby p.X descending select p).FirstOrDefault();

                }
                else
                {
                    RetP.P2 = (from p in pointList.OfType<Point>() where p.Y > MaxY orderby p.X ascending select p).FirstOrDefault();
                    RetP.P3 = (from p in pointList.OfType<Point>() where p.Y > MaxY orderby p.X descending select p).FirstOrDefault();
                    RetP.P1 = (from p in pointList.OfType<Point>() where p.Y < MaxY orderby p.X ascending select p).FirstOrDefault();
                    RetP.P4 = (from p in pointList.OfType<Point>() where p.Y < MaxY orderby p.X descending select p).FirstOrDefault();


                    RetP.P5 = (from p in pointList.OfType<Point>() where p.Y < RetP.P4.Y orderby p.X descending select p).FirstOrDefault();
                }
            }

            else
            {
                if (RetP.CentP.Y > BC.Points.CentP.Y)
                {
                    RetP.P2 = (from p in pointList.OfType<Point>() where p.Y < MinY orderby p.X descending select p).FirstOrDefault();
                    RetP.P3 = (from p in pointList.OfType<Point>() where p.Y < MinY orderby p.X ascending select p).FirstOrDefault();
                    RetP.P1 = (from p in pointList.OfType<Point>() where p.Y > MinY orderby p.X descending select p).FirstOrDefault();
                    RetP.P4 = (from p in pointList.OfType<Point>() where p.Y > MinY orderby p.X ascending select p).FirstOrDefault();

                    RetP.P5 = (from p in pointList.OfType<Point>() where p.Y > RetP.P4.Y orderby p.X ascending select p).FirstOrDefault();

                }
                else
                {

                    RetP.P2 = (from p in pointList.OfType<Point>() where p.Y > MaxY orderby p.X descending select p).FirstOrDefault();
                    RetP.P3 = (from p in pointList.OfType<Point>() where p.Y > MaxY orderby p.X ascending select p).FirstOrDefault();
                    RetP.P1 = (from p in pointList.OfType<Point>() where p.Y < MaxY orderby p.X descending select p).FirstOrDefault();
                    RetP.P4 = (from p in pointList.OfType<Point>() where p.Y < MaxY orderby p.X ascending select p).FirstOrDefault();


                    RetP.P5 = (from p in pointList.OfType<Point>() where p.Y < RetP.P4.Y orderby p.X ascending select p).FirstOrDefault();

                }
            }
            return RetP;
        }

        private List<PartClass> GetStiffClass(ContourPlate GP, List<TSM.Part> PartListF)
        {
            List<PartClass> partClasses = null;
            List<TSM.Part> Stiff = (from p in PartListF where dc.IsPlateSideView(p) && (Com.CenterPoint(p).X > GP.GetSolid().MinimumPoint.X && Com.CenterPoint(p).X < GP.GetSolid().MaximumPoint.X) && (Com.CenterPoint(p).Y < BC.Points.P1.Y && Com.CenterPoint(p).Y > BC.Points.P2.Y) orderby Com.CenterPoint(p).X ascending select p).ToList();

            if (Stiff != null && Stiff.Count > 0)
            {
                partClasses = new List<PartClass>();

                foreach (TSM.Part st in Stiff)
                {
                    partClasses.Add(Com.GetPartClass(st));
                }

            }

            return partClasses;
        }

        #endregion

        #region Helping Methods

        private double GetDegree(Point P1, Point P2, Point P3)
        {
            double degree = 0;
            try
            {

                AngleDimension angDimA = new AngleDimension(CView, P1, P2, P3, 50);
                degree = angDimA.GetAngle();
            }
            catch (Exception ex)
            { }
            return degree;
        }

        private bool IsBrace(Beam b)
        {
            bool RetCheck = false;
            if (b.Name.ToLower().Contains("brace") || (dc.IsMainPart(b) && !dc.IsPlate(b)))
            {
                if ((b.StartPoint.Y < BC.Points.P1.Y && b.StartPoint.Y > BC.Points.P2.Y) || (b.EndPoint.Y < BC.Points.P1.Y && b.EndPoint.Y > BC.Points.P2.Y))
                    RetCheck = true;
            }

            return RetCheck;
        }

        private Point GetBraceRefPoint(Beam Brace)
        {
            Point RefP = Brace.StartPoint;
            List<Point> CentPlist = MainBeam.GetCenterLine(false).OfType<Point>().ToList();
            Point StartP = Com.MinP(CentPlist, "X");
            Point EndP = Com.MaxP(CentPlist, "X");

            double DistS = Distance.PointToLine(Brace.StartPoint, new TSG.Line(StartP, EndP));
            double DistE = Distance.PointToLine(Brace.EndPoint, new TSG.Line(StartP, EndP));

            if (DistE < DistS)
                RefP = Brace.EndPoint;

            return RefP;
        }

        private Point GetIntSectPoint(BoltGroup bolt, Beam brace, string Position)
        {
            Vector Vect = bolt.GetCoordinateSystem().AxisX;
            PointList PtList = new PointList();
            Point IntSectP = null;
            if (Position == "Top")
            {
                if (Vect.Y > 0)
                    Vect = Com.ChangeVector(Vect);
            }
            else
            {
                if (Vect.Y < 0)
                    Vect = Com.ChangeVector(Vect);
            }

            PtList = dc.ChangePints(bolt, CView, Vect);
            if (PtList.Count > 1)
                IntSectP = Com.GetIntersectionPoint(PtList[0], PtList[1], brace.StartPoint, brace.EndPoint);
            else if (PtList.Count == 1)
                IntSectP = PtList[0];

            return IntSectP;

        }

        private bool IsBG2(TSM.Part part)
        {
            if (Com.GetNote5(part).ToUpper().Contains("BG2"))
                return true;
            else
                return false;
        }
        #endregion

        private class GussetClass
        {
            public TSM.Part GussetPlate { get; set; }
            public BoltGroup BoltM { get; set; }
            public PointList BoltMP { get; set; }
            public PartPoints Points { get; set; }
            public Beam Brace { get; set; }
            public Point RefPBrace { get; set; }
            public Point IntPoint { get; set; }
            public Point IntPointB { get; set; }
            public string BracePos { get; set; }
            public double Degree { get; set; }
            public bool IsGussetSlop = false;

            public List<PartClass> StiffList { get; set; }

        }

        private class GussetClassTV
        {
            public PartClass GussetPlate { get; set; }
            public PartClass StiffNS { get; set; }
            public PartClass StiffFS { get; set; }
        }

        private class BeamClass_BG2
        {
            public Beam beam { get; set; }
            public GussetClass TopGP { get; set; }
            public GussetClass BottGP { get; set; }
            public PartPoints Points { get; set; }
            public PlacingClass PC { get; set; }
            public List<GussetClassTV> GPTV { get; set; }

            public PartClass LeftStiff { get; set; }
            public PartClass RightStiff { get; set; }

            public Point RDPoint { get; set; }
        }

    }




}
