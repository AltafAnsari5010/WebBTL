﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Tekla.Structures;
using Tekla.Structures.Drawing;
using Tekla.Structures.Geometry3d;
using Tekla.Structures.Model;
using TSD = Tekla.Structures.Drawing;
using TSM = Tekla.Structures.Model;
using VirtueleDrawingAutomation;
using TSDD = Tekla.Structures.Datatype;
using TSG = Tekla.Structures.Geometry3d;

namespace Auto_Detailing_Tool_Beam
{
    public class BeamDim_BSP4
    {
        #region Global Variables
        DimCom dc = new DimCom();
        StraightDimensionSet.StraightDimensionSetAttributes StAtrr = new StraightDimensionSet.StraightDimensionSetAttributes("standard");
        StraightDimensionSet.StraightDimensionSetAttributes RdAtrr = new StraightDimensionSet.StraightDimensionSetAttributes("standard");

        public Beam MainBeam = null;
        VirtueleDrawingAutomation.Json.DrawingAttributeInfoJson.AttributeFiles dimAttrClass = null;
        List<TSD.StraightDimension> KnockDim = new List<StraightDimension>();
        BeamClass_BSP4 BC = null;
        BeamClass_BSP4S BCS = null;
        VirtueleDrawingAutomation.Json.AutoDimensionTypesJson.BSP4Json DN = null;
        string Position = "Left";
        TSD.View CView = null;
        string ViewName = "";
        public Point BoltPS = null;

        #endregion

        public void ApplyDim(TSD.View CView, string ViewName, AutoDimensioningTypes autoDimensioningTypes, DrawingAttributeInfo drawingAttributeInfo, string Position)
        {
            try
            {
                Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane());
                //Set model everything to the view
                Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane(CView.DisplayCoordinateSystem));

                this.CView = CView;
                this.dimAttrClass = drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files;
                this.DN = autoDimensioningTypes.BSP4;
                this.Position = Position;
                StAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.StandardDimension);
                RdAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.RunningDimension);
                this.MainBeam = (Com.MyModel.SelectModelObject(new Identifier((CView.GetDrawing() as AssemblyDrawing).AssemblyIdentifier.ID)) as TSM.Assembly).GetMainPart() as TSM.Beam;
                this.MainBeam.Select();
                string ProType = Com.GetProType(MainBeam);
                this.ViewName = ViewName;
                GetBeamClassClass(CView);

                if (Position == "Left")
                {
                    //TestDim();
                    if (ViewName == "Front View")
                        ApplyDimTypeLeft();
                    else if (ViewName == "Top View")
                        ApplyDimTVLeft();
                    else
                    if (ViewName == "Section View")
                        AppySectionDim();

                }

                else if (Position == "Right")
                {
                    //TestDim();
                    if (ViewName == "Front View")
                        ApplyDimTypeRight();
                    else if (ViewName == "Top View")
                        ApplyDimTVRight();
                    else
                    if (ViewName == "Section View")
                        AppySectionDim();
                }
            }
            catch (Exception ex)
            { }
            Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane());


        }

        private void ApplyDimTypeLeft()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            TSD.PointList TempList = new PointList();

            if (BC.BottAngle != null)
            {
                BC.PC.DistLeft = BC.PC.DistInc;
                TempList = new PointList();
                TempList.AddRange(BC.BottAngle.BoltPList);
                BoltPS = Com.MaxP(TempList, "X");
                Vect = new Vector(0, -1, 0);

                // Dim No 4.1
                if (DN.DimIDNo4Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "X"));
                    pointList.Add(BC.BottAngle.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                }

                // Dim No 4
                if (DN.DimIDNo4)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                }

                // Dim No 4.3
                if (DN.DimIDNo4Dot3)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "X"));
                    if (BC.BottAngle.CutPoints != null)
                        pointList.Add(BC.BottAngle.CutPoints.P4);
                    else
                        pointList.Add(BC.BottAngle.Points.P3);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                }

                if (DN.DimIDNo4 || DN.DimIDNo4Dot1 || DN.DimIDNo4Dot3)
                    BC.PC.DistBot += BC.PC.DistInc;


                // Dim No 4.2
                if (DN.DimIDNo4Dot2)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        Com.GroupDim(xDim);

                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }

                // Dim No 5
                if (DN.DimIDNo5 && BC.SurfPoints != null)
                {
                    pointList = new PointList();
                    pointList.Add(BC.SurfPoints.P2);
                    pointList.Add(BC.SurfPoints.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        Com.SetRightUpperDimText(xDim, "PROTECTED ZONE");
                        Com.SetRightLowerDimText(xDim, "ALL AROUND");
                        BC.PC.DistBot += BC.PC.DistInc;
                        StAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.StandardDimension);
                    }
                }

                // Dim No 9.7
                if (DN.DimIDNo9Dot7)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P2);
                    pointList.Add(Com.MinP(TempList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }

                Vect = new Vector(-1, 0, 0);

                // Dim No 1
                if (DN.DimIDNo1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "X"));
                    pointList.Add(BC.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByLeftX(xDim, BC.PC);
                }

                // Dim No 2
                if (DN.DimIDNo2 && BC.MidAngle != null)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "X"));
                    pointList.Add(Com.MinP(BC.MidAngle.BoltPList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByLeftX(xDim, BC.PC);
                }


                // Dim No 3
                if (DN.DimIDNo3)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "X"));
                    pointList.Add(BC.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByLeftX(xDim, BC.PC);
                }

                Vect = new Vector(0, 1, 0);
                // Dim No 8
                if (DN.DimIDNo8 && BC.BottAngle.CutPoints != null)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottAngle.CutPoints.P4);
                    pointList.Add(BC.BottAngle.CutPoints.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlaceByTopY(xDim, BC.PC);
                        Com.SetRightUpperDimText(xDim, "NO WELD {5} (T&B)");
                        Com.SetRightLowerDimText(xDim, "SEE GRAPHIC NO.1");
                        StAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.StandardDimension);
                    }
                }

            }

            // Dim No 14 Elevation Dim
            if (DN.DimIDNo14)
            {


                Vect = new Vector(-1, 0, 0);
                StraightDimensionSet.StraightDimensionSetAttributes ElAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.ElevationDimension);
                ElAtrr.DimensionType = DimensionSetBaseAttributes.DimensionTypes.Elevation;
                ElAtrr.Arrowhead.Head = ArrowheadTypes.FilledArrow;
                pointList = new PointList();

                if (MainBeam.StartPoint.X > MainBeam.EndPoint.X)
                {
                    pointList.Add(MainBeam.EndPoint);
                    pointList.Add(MainBeam.EndPoint);

                }
                else
                {
                    pointList.Add(MainBeam.StartPoint);
                    pointList.Add(MainBeam.StartPoint);
                }

                BC.PC.DistLeft = BC.PC.DistLeft - (BC.Points.P1.X - pointList[0].X);
                xDim = dc.InsertDimm(CView, pointList, Vect, (-BC.PC.DistLeft), ElAtrr);
                if (xDim != null)
                {
                    xDim.Distance = (-BC.PC.DistLeft);
                    xDim.Modify();
                }
                BC.PC.DistLeft += BC.PC.DistInc;

            }

            if (BC.MidAngle != null)
            {
                BC.PC.DistLeft = BC.PC.DistInc;
                TempList = new PointList();
                TempList.AddRange(BC.MidAngle.BoltPList);
                Vect = new Vector(0, 1, 0);

                // Dim No 22,22.1
                if (DN.DimIDNo22 || DN.DimIDNo22Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "Y"));

                    if (DN.DimIDNo22) // Dim No 22
                        pointList.Add(new Point(BC.MidAngle.Points.P1.X, Com.MaxP(TempList, "Y").Y));

                    if (DN.DimIDNo22Dot1) // Dim No 22.1
                        pointList.Add(new Point(BC.MidAngle.Points.P4.X, Com.MaxP(TempList, "Y").Y));

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistInc, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);

                }

                // Dim No 22.2
                if (DN.DimIDNo22Dot2 && BC.SC != null)
                {
                    pointList = new PointList();
                    pointList.Add(new Point(BC.MidAngle.Points.P1.X, Com.MaxP(TempList, "Y").Y));
                    pointList.Add(BC.SC.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistInc, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);
                }

                Vect = new Vector(-1, 0, 0);
                // Dim No 7
                if (DN.DimIDNo7)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    pointList.Add(new Point(pointList[0].X, BC.Points.P1.Y));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.MidAngle.Points.P1.X, BC.PC.DistLeft);
                }

                // Dim No 6
                if (DN.DimIDNo6)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.MidAngle.Points.P1.X, BC.PC.DistLeft);
                }

                // Dim No 6.1
                if (DN.DimIDNo6Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "Y"));
                    pointList.Add(new Point(pointList[0].X, BC.Points.P2.Y));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.MidAngle.Points.P1.X, BC.PC.DistLeft);
                }


                if (DN.DimIDNo7 || DN.DimIDNo6 || DN.DimIDNo6Dot1)
                    BC.PC.DistLeft += BC.PC.DistInc;


                // Dim No 21,21.1
                if (DN.DimIDNo21 || DN.DimIDNo21Dot1)
                {
                    pointList = new PointList();

                    if (DN.DimIDNo21Dot1) // Dim No 21.1
                        pointList.Add(new Point(BC.MidAngle.Points.P1.X, BC.Points.P1.Y));

                    pointList.Add(BC.MidAngle.Points.P1);

                    if (DN.DimIDNo21) // Dim No 21
                        pointList.Add(BC.MidAngle.Points.P2);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.MidAngle.Points.P1.X, BC.PC.DistLeft);

                }

                Vect = new Vector(0, -1, 0);

                // Dim No 9.3, 9.4 RD Dim
                if (DN.DimIDNo9Dot3 || DN.DimIDNo9Dot4)
                {
                    if (DN.DimIDNo9Dot3)
                        BC.PC.DistBot += BC.PC.DistInc;

                    pointList = new PointList();
                    pointList.Add(BC.Points.P2);
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);

                }

            }

            if (BC.SC != null)
            {
                Vect = new Vector(0, 1, 0);

                // Dim No 9, 9.1 RD Dim
                if (DN.DimIDNo9 || DN.DimIDNo9Dot1)
                {
                    if (DN.DimIDNo9)
                        BC.PC.DistTop += BC.PC.DistInc;

                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(BC.SC.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);

                }
            }
        }

        private void ApplyDimTypeRight()
        {

            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            TSD.PointList TempList = new PointList();

            if (BC.BottAngle != null)
            {
                BC.PC.DistRight = BC.PC.DistInc;
                TempList = new PointList();
                TempList.AddRange(BC.BottAngle.BoltPList);
                Vect = new Vector(0, -1, 0);

                // Dim No 4.1
                if (DN.DimIDNo4Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "X"));
                    pointList.Add(BC.BottAngle.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                }

                // Dim No 4
                if (DN.DimIDNo4)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                }

                // Dim No 4.3
                if (DN.DimIDNo4Dot3)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "X"));
                    if (BC.BottAngle.CutPoints != null)
                        pointList.Add(BC.BottAngle.CutPoints.P4);
                    else
                        pointList.Add(BC.BottAngle.Points.P2);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                }


                if (DN.DimIDNo4 || DN.DimIDNo4Dot1 || DN.DimIDNo4Dot3)
                    BC.PC.DistBot += BC.PC.DistInc;


                // Dim No 4.2
                if (DN.DimIDNo4Dot2)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        Com.GroupDim(xDim);

                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }

                // Dim No 5
                if (DN.DimIDNo5 && BC.SurfPoints != null)
                {
                    pointList = new PointList();
                    pointList.Add(BC.SurfPoints.P2);
                    pointList.Add(BC.SurfPoints.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        Com.SetLeftUpperDimText(xDim, "PROTECTED ZONE");
                        Com.SetLeftLowerDimText(xDim, "ALL AROUND");
                        BC.PC.DistBot += BC.PC.DistInc;
                        StAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.StandardDimension);
                    }
                }

                // Dim No 9.6
                if (DN.DimIDNo9Dot6)
                {
                    BC.PC.DistBot += BC.PC.DistInc;
                    pointList = new PointList();
                    pointList.Add(BC.Points.P2);
                    pointList.Add(Com.MinP(TempList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }

                // Dim No 10
                if (DN.DimIDNo10 && BoltPS != null)
                {
                    pointList = new PointList();
                    pointList.Add(BoltPS);
                    pointList.Add(Com.MinP(TempList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }

               

                Vect = new Vector(1, 0, 0);

                // Dim No 1
                if (DN.DimIDNo1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "X"));
                    pointList.Add(BC.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByRightX(xDim, BC.PC);
                }

                // Dim No 2
                if (DN.DimIDNo2 && BC.MidAngle != null)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "X"));
                    pointList.Add(Com.MinP(BC.MidAngle.BoltPList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByRightX(xDim, BC.PC);
                }


                // Dim No 3
                if (DN.DimIDNo3)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "X"));
                    pointList.Add(BC.Points.P4);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByRightX(xDim, BC.PC);
                }

                Vect = new Vector(0, 1, 0);
                // Dim No 8
                if (DN.DimIDNo8 && BC.BottAngle.CutPoints != null)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottAngle.CutPoints.P4);
                    pointList.Add(BC.BottAngle.CutPoints.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlaceByTopY(xDim, BC.PC);
                        Com.SetLeftUpperDimText(xDim, "NO WELD {5} (T&B)");
                        Com.SetLeftLowerDimText(xDim, "SEE GRAPHIC NO.1");
                        StAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.StandardDimension);
                    }
                }


            }

            if (BC.MidAngle != null)
            {
                BC.PC.DistRight = BC.PC.DistInc;
                TempList = new PointList();
                TempList.AddRange(BC.MidAngle.BoltPList);
                Vect = new Vector(0, 1, 0);

                // Dim No 22,22.1
                if (DN.DimIDNo22 || DN.DimIDNo22Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "Y"));

                    if (DN.DimIDNo22) // Dim No 22
                        pointList.Add(new Point(BC.MidAngle.Points.P4.X, Com.MaxP(TempList, "Y").Y));

                    if (DN.DimIDNo22Dot1) // Dim No 22.1
                        pointList.Add(new Point(BC.MidAngle.Points.P1.X, Com.MaxP(TempList, "Y").Y));

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistInc, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);

                }

                // Dim No 22.2
                if (DN.DimIDNo22Dot2 && BC.SC!=null)
                {
                    pointList = new PointList();
                    pointList.Add(new Point(BC.MidAngle.Points.P4.X, Com.MaxP(TempList, "Y").Y));
                    pointList.Add(BC.SC.Points.P4);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistInc, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);
                }

                Vect = new Vector(1, 0, 0);
                // Dim No 7
                if (DN.DimIDNo7)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    pointList.Add(new Point(pointList[0].X, BC.Points.P1.Y));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.MidAngle.Points.P4.X, BC.PC.DistRight);
                }

                // Dim No 6
                if (DN.DimIDNo6)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.MidAngle.Points.P4.X, BC.PC.DistRight);
                }

                // Dim No 6.1
                if (DN.DimIDNo6Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "Y"));
                    pointList.Add(new Point(pointList[0].X, BC.Points.P2.Y));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.MidAngle.Points.P4.X, BC.PC.DistRight);
                }


                if (DN.DimIDNo7 || DN.DimIDNo6 || DN.DimIDNo6Dot1)
                    BC.PC.DistRight += BC.PC.DistInc;


                // Dim No 21,21.1
                if (DN.DimIDNo21 || DN.DimIDNo21Dot1)
                {
                    pointList = new PointList();

                    if (DN.DimIDNo21Dot1) // Dim No 21
                        pointList.Add(new Point(BC.MidAngle.Points.P1.X, BC.Points.P1.Y));

                    pointList.Add(BC.MidAngle.Points.P1);

                    if (DN.DimIDNo21) // Dim No 21
                        pointList.Add(BC.MidAngle.Points.P2);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.MidAngle.Points.P4.X, BC.PC.DistRight);

                }

                Vect = new Vector(0, -1, 0);

                // Dim No 9.3, 9.4 RD Dim
                if (DN.DimIDNo9Dot3 || DN.DimIDNo9Dot4)
                {
                    if (DN.DimIDNo9Dot3)
                        BC.PC.DistBot += BC.PC.DistInc;

                    pointList = new PointList();
                    pointList.Add(BC.Points.P2);
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);

                }

            }

            if (BC.SC != null)
            {
                Vect = new Vector(0, 1, 0);

                // Dim No 9, 9.1 RD Dim
                if (DN.DimIDNo9 || DN.DimIDNo9Dot1)
                {
                    if (DN.DimIDNo9)
                        BC.PC.DistTop += BC.PC.DistInc;

                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(BC.SC.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);

                }
            }
        }

        private void ApplyDimTVLeft()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            TSD.PointList TempList = new PointList();

            if (BC.FLP != null)
            {
                TempList = new PointList();
                TempList.AddRange(BC.FLP.TopBolts);
                TempList.AddRange(BC.FLP.BottBolts);
                TempList = dc.ChangePints(TempList, CView, Vect);
                Vect = new Vector(0, 1, 0);

                // Dim No 30
                if (DN.DimIDNo30)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "X"));
                    pointList.Add(BC.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);

                }

                // Dim No 29
                if (DN.DimIDNo29)
                {
                    BC.PC.DistTop += (BC.PC.DistInc);
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += (BC.PC.DistInc * 1.5);
                    }
                }

                // Dim No 29.1
                else if (DN.DimIDNo29Dot1)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);

                    BC.PC.DistTop += (BC.PC.DistInc);
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(Com.MinP(TempList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);

                    BC.PC.DistTop += BC.PC.DistInc;
                }

                // Dim No 30.1
                if (DN.DimIDNo30Dot1)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        Com.GroupDim(xDim);
                    }
                }

                // Dim No 33
                if (DN.DimIDNo33)
                {
                    Vect = new Vector(0, -1, 0);
                    pointList = new PointList();
                    pointList.Add(BC.FLP.Points.P3);
                    pointList.Add(new Point(BC.FLP.Points.P3.X - 101.6, BC.FLP.Points.P3.Y));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        Com.SetRightUpperDimText(xDim, "NO WELD");
                        Com.SetRightLowerDimText(xDim, "{5a} (T&B)");
                        StAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.StandardDimension);
                        BC.PC.DistBot += BC.PC.DistInc;

                    }
                }

                if (BC.FLP.CutPoints != null)
                {
                    Vect = new Vector(-1, 0, 0);
                    // Dim No 27
                    if (DN.DimIDNo27)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.FLP.CutPoints.P1);
                        pointList.Add(BC.FLP.CutPoints.P5);
                        pointList.Add(BC.FLP.CutPoints.P2);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByLeftX(xDim, BC.PC);
                    }

                    // Dim No 26
                    if (DN.DimIDNo26)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.FLP.CutPoints.P1);
                        pointList.Add(BC.FLP.CutPoints.P2);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByLeftX(xDim, BC.PC);
                    }

                    Vect = new Vector(0, -1, 0);

                    if (BC.FLP.Type2)
                    {
                        // Dim No 35
                        if (DN.DimIDNo35)
                        {
                            pointList = new PointList();
                            pointList.Add(BC.FLP.Points.P2);
                            pointList.Add(BC.FLP.CutPoints.P5);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                            if (xDim != null)
                                PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        }

                        // Dim No 32
                        if (DN.DimIDNo32)
                        {
                            pointList = new PointList();
                            pointList.Add(BC.FLP.CutPoints.P6);
                            pointList.Add(BC.FLP.CutPoints.P5);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                            if (xDim != null)
                                PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        }

                        // Dim No 34
                        if (DN.DimIDNo34)
                        {
                            pointList = new PointList();
                            pointList.Add(BC.FLP.CutPoints.P6);
                            pointList.Add(BC.FLP.Points.P3);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                            if (xDim != null)
                                PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        }

                        if (DN.DimIDNo32 || DN.DimIDNo35 || DN.DimIDNo34)
                            BC.PC.DistBot += BC.PC.DistInc;

                    }
                    else
                    {

                        // Dim No 31
                        if (DN.DimIDNo31)
                        {
                            pointList = new PointList();
                            pointList.Add(BC.FLP.Points.P2);
                            pointList.Add(BC.FLP.CutPoints.P5);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                            if (xDim != null)
                                PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        }

                        // Dim No 32
                        if (DN.DimIDNo32)
                        {
                            pointList = new PointList();
                            pointList.Add(BC.FLP.Points.P3);
                            pointList.Add(BC.FLP.CutPoints.P5);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                            if (xDim != null)
                                PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        }

                        if (DN.DimIDNo32 || DN.DimIDNo31)
                            BC.PC.DistBot += BC.PC.DistInc;
                    }

                    // Dim No 29.2 // RD Dim
                    if (DN.DimIDNo29Dot2)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.Points.P2);
                        pointList.Add(BC.FLP.CutPoints.P5);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                        if (xDim != null)
                            PL.DimPlaceByBottomY(xDim, BC.PC);
                    }
                }

                Vect = new Vector(-1, 0, 0);
                // Dim No 25
                if (DN.DimIDNo25)
                {
                    TempList = new PointList();
                    TempList.AddRange(BC.FLP.TopBolts);
                    TempList.AddRange(BC.FLP.BottBolts);
                    TempList = dc.ChangePints(TempList, CView, Vect);
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    pointList.Add(new Point(BC.FLP.Points.P1.X, BC.Points.CentP.Y));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByLeftX(xDim, BC.PC);
                }

                // Dim No 28 // Angle Dimension
                if (DN.DimIDNo28 && BC.FLP.CutPoints != null)
                {

                    if (BC.FLP.Type2)
                    {
                        RadiusDimension basicDimension = new RadiusDimension(CView, BC.FLP.CutPoints.P2, BC.FLP.CutPoints.P5, BC.FLP.CutPoints.P1, -15);
                        basicDimension.Insert();

                        basicDimension = new RadiusDimension(CView, BC.FLP.CutPoints.P4, BC.FLP.CutPoints.P6, BC.FLP.CutPoints.P3, -15);
                        basicDimension.Insert();

                    }
                    else
                    {
                        RadiusDimension basicDimension = new RadiusDimension(CView, BC.FLP.CutPoints.P2, BC.FLP.CutPoints.P5, BC.FLP.CutPoints.P1, -15);
                        basicDimension.Insert();
                    }
                }
            }

        }

        private void ApplyDimTVRight()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            TSD.PointList TempList = new PointList();

            if (BC.FLP != null)
            {
                TempList = new PointList();
                TempList.AddRange(BC.FLP.TopBolts);
                TempList.AddRange(BC.FLP.BottBolts);
                TempList = dc.ChangePints(TempList, CView, Vect);
                Vect = new Vector(0, 1, 0);

                // Dim No 30
                if (DN.DimIDNo30)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "X"));
                    pointList.Add(BC.Points.P4);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);

                }

                // Dim No 29
                if (DN.DimIDNo29)
                {
                    BC.PC.DistTop += (BC.PC.DistInc * 2);
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }

                // Dim No 29.1
                else if (DN.DimIDNo29Dot1)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);

                    BC.PC.DistTop += (BC.PC.DistInc * 2);
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(Com.MinP(TempList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);

                    BC.PC.DistTop += BC.PC.DistInc;
                }

                // Dim No 30.1
                if (DN.DimIDNo30Dot1)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        Com.GroupDim(xDim);
                    }
                }

                // Dim No 33
                if (DN.DimIDNo33)
                {
                    Vect = new Vector(0, -1, 0);
                    pointList = new PointList();
                    pointList.Add(BC.FLP.Points.P2);
                    pointList.Add(new Point(BC.FLP.Points.P2.X + 101.6, BC.FLP.Points.P2.Y));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        Com.SetLeftUpperDimText(xDim, "NO WELD");
                        Com.SetLeftLowerDimText(xDim, "{5a} (T&B)");
                        StAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.StandardDimension);
                        BC.PC.DistBot += BC.PC.DistInc;

                    }
                }

                if (BC.FLP.CutPoints != null)
                {
                    Vect = new Vector(1, 0, 0);
                    // Dim No 27
                    if (DN.DimIDNo27)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.FLP.CutPoints.P4);
                        pointList.Add(BC.FLP.CutPoints.P5);
                        pointList.Add(BC.FLP.CutPoints.P3);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByRightX(xDim, BC.PC);
                    }

                    // Dim No 26
                    if (DN.DimIDNo26)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.FLP.CutPoints.P4);
                        pointList.Add(BC.FLP.CutPoints.P3);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByRightX(xDim, BC.PC);
                    }

                    Vect = new Vector(0, -1, 0);

                    if (BC.FLP.Type2)
                    {
                        // Dim No 35
                        if (DN.DimIDNo35)
                        {
                            pointList = new PointList();
                            pointList.Add(BC.FLP.Points.P3);
                            pointList.Add(BC.FLP.CutPoints.P5);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                            if (xDim != null)
                                PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        }

                        // Dim No 32
                        if (DN.DimIDNo32)
                        {
                            pointList = new PointList();
                            pointList.Add(BC.FLP.CutPoints.P6);
                            pointList.Add(BC.FLP.CutPoints.P5);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                            if (xDim != null)
                                PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        }

                        // Dim No 34
                        if (DN.DimIDNo34)
                        {
                            pointList = new PointList();
                            pointList.Add(BC.FLP.CutPoints.P6);
                            pointList.Add(BC.FLP.Points.P2);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                            if (xDim != null)
                                PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        }

                        if (DN.DimIDNo32 || DN.DimIDNo35 || DN.DimIDNo34)
                            BC.PC.DistBot += BC.PC.DistInc;

                    }
                    else
                    {

                        // Dim No 31
                        if (DN.DimIDNo31)
                        {
                            pointList = new PointList();
                            pointList.Add(BC.FLP.Points.P3);
                            pointList.Add(BC.FLP.CutPoints.P5);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                            if (xDim != null)
                                PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        }

                        // Dim No 32
                        if (DN.DimIDNo32)
                        {
                            pointList = new PointList();
                            pointList.Add(BC.FLP.Points.P2);
                            pointList.Add(BC.FLP.CutPoints.P5);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                            if (xDim != null)
                                PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        }

                        if (DN.DimIDNo32 || DN.DimIDNo31)
                            BC.PC.DistBot += BC.PC.DistInc;
                    }

                    // Dim No 29.2 // RD Dim
                    if (DN.DimIDNo29Dot2)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.Points.P2);

                        if (BC.FLP.Type2)
                            pointList.Add(BC.FLP.CutPoints.P6);
                        else
                            pointList.Add(BC.FLP.CutPoints.P5);

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                        if (xDim != null)
                            PL.DimPlaceByBottomY(xDim, BC.PC);
                    }
                }

                Vect = new Vector(1, 0, 0);
                // Dim No 25
                if (DN.DimIDNo25)
                {
                    TempList = new PointList();
                    TempList.AddRange(BC.FLP.TopBolts);
                    TempList.AddRange(BC.FLP.BottBolts);
                    TempList = dc.ChangePints(TempList, CView, Vect);
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    pointList.Add(new Point(BC.FLP.Points.P1.X, BC.Points.CentP.Y));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByRightX(xDim, BC.PC);
                }

                // Dim No 28 // Angle Dimension
                if (DN.DimIDNo28 && BC.FLP.CutPoints != null)
                {
                    if (BC.FLP.Type2)
                    {
                        RadiusDimension basicDimension = new RadiusDimension(CView, BC.FLP.CutPoints.P4, BC.FLP.CutPoints.P5, BC.FLP.CutPoints.P3, -5);
                        basicDimension.Insert();

                        basicDimension = new RadiusDimension(CView, BC.FLP.CutPoints.P2, BC.FLP.CutPoints.P6, BC.FLP.CutPoints.P1, -5);
                        basicDimension.Insert();

                    }
                    else
                    {

                        RadiusDimension basicDimension = new RadiusDimension(CView, BC.FLP.CutPoints.P4, BC.FLP.CutPoints.P5, BC.FLP.CutPoints.P3, -5);
                        basicDimension.Insert();
                    }
                }
            }

        }

        private void AppySectionDim()
        {
            StraightDimensionSet xDim = null;
            PointList pointList = new PointList();
            Vector Vect = new Vector(0, 1, 0);

            if (BCS.TypeS == "A")
            {
                //if (BCS.SCL != null && BCS.SCR != null)
                //{
                    if (BCS.MidAR != null)
                    {
                        // Dim No 17, 18
                        if (DN.DimIDNo17 || DN.DimIDNo18)
                        {
                            pointList = new PointList();
                            if (DN.DimIDNo17) // Dim No 17
                                pointList.Add(BCS.MidAR.Points.P4);

                            pointList.Add(BCS.SCR.Points.P4);

                            if (DN.DimIDNo17) // Dim No 18
                                pointList.Add(BCS.MidAR.Points.P1);
                            xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistTop, StAtrr);
                            if (xDim != null)
                                PL.DimPlaceByTopY(xDim, BCS.PC);
                        }

                        // Dim No 23
                        if (DN.DimIDNo23)
                        {
                            pointList = new PointList();
                            pointList.Add(MainBeam.StartPoint);
                            pointList.Add(BCS.MidAR.Points.P1);
                            xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistTop, StAtrr);
                            if (xDim != null)
                                PL.DimPlaceByTopY(xDim, BCS.PC);
                        }

                        // Dim No 19
                        if (DN.DimIDNo19)
                        {
                            pointList = new PointList();
                            pointList.Add(BCS.MidAR.Points.P1);
                            pointList.Add(BCS.MidAR.Points.P4);
                            xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistTop, StAtrr);
                            if (xDim != null)
                                PL.DimPlaceByTopY(xDim, BCS.PC);
                        }

                        // Dim No 16
                        if (DN.DimIDNo16)
                        {
                            pointList = new PointList();
                            pointList.Add(BCS.MidAR.Points.P4);
                            pointList.Add(MainBeam.StartPoint);
                            xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistTop, StAtrr);
                            if (xDim != null)
                                PL.DimPlaceByTopY(xDim, BCS.PC);
                        }
                    }

                    if (BCS.MidAL != null)
                    {
                        BCS.PC.DistTop = BCS.PC.DistInc;

                        if (DN.DimIDNo17 || DN.DimIDNo18)
                        {
                            pointList = new PointList();
                            if (DN.DimIDNo18) // Dim No 18
                                pointList.Add(BCS.MidAL.Points.P1);

                            pointList.Add(BCS.SCL.Points.P1);

                            if (DN.DimIDNo17) // Dim No 17
                                pointList.Add(BCS.MidAL.Points.P4);
                            xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistTop, StAtrr);
                            if (xDim != null)
                                PL.DimPlaceByTopY(xDim, BCS.PC);
                        }

                        // Dim No 23
                        if (DN.DimIDNo23)
                        {
                            pointList = new PointList();
                            pointList.Add(MainBeam.StartPoint);
                            pointList.Add(BCS.MidAL.Points.P4);
                            xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistTop, StAtrr);
                            if (xDim != null)
                                PL.DimPlaceByTopY(xDim, BCS.PC);
                        }

                        // Dim No 19
                        if (DN.DimIDNo19)
                        {
                            pointList = new PointList();
                            pointList.Add(BCS.MidAL.Points.P1);
                            pointList.Add(BCS.MidAL.Points.P4);
                            xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistTop, StAtrr);
                            if (xDim != null)
                                PL.DimPlaceByTopY(xDim, BCS.PC);
                        }

                        // Dim No 16
                        if (DN.DimIDNo16)
                        {
                            pointList = new PointList();
                            pointList.Add(BCS.MidAL.Points.P1);
                            pointList.Add(MainBeam.StartPoint);
                            xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistTop, StAtrr);
                            if (xDim != null)
                                PL.DimPlaceByTopY(xDim, BCS.PC);
                        }
                    }

                    if (DN.DimIDNo15 && BCS.MidAR != null && BCS.MidAL != null)
                    {
                        pointList = new PointList();
                        pointList.Add(BCS.MidAR.Points.P4);
                        pointList.Add(BCS.MidAL.Points.P1);
                        xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByTopY(xDim, BCS.PC);
                    }

                    Vect = new Vector(0, -1, 0);
                    if (BCS.BottAR != null)
                    {

                        // Dim No 19
                        if (DN.DimIDNo19)
                        {
                            pointList = new PointList();
                            pointList.Add(BCS.BottAR.Points.P1);
                            pointList.Add(BCS.BottAR.Points.P4);
                            xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistBot, StAtrr);
                            if (xDim != null)
                                PL.DimPlaceByBottomY(xDim, BCS.PC);
                        }

                        // Dim No 16
                        if (DN.DimIDNo16)
                        {
                            pointList = new PointList();
                            pointList.Add(BCS.BottAR.Points.P1);
                            pointList.Add(MainBeam.StartPoint);
                            xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistBot, StAtrr);
                            if (xDim != null)
                                PL.DimPlaceByBottomY(xDim, BCS.PC);
                        }
                    }

                    if (BCS.BottAL != null)
                    {
                        BCS.PC.DistBot = BCS.PC.DistInc;

                        // Dim No 19
                        if (DN.DimIDNo19)
                        {
                            pointList = new PointList();
                            pointList.Add(BCS.BottAL.Points.P1);
                            pointList.Add(BCS.BottAL.Points.P4);
                            xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistBot, StAtrr);
                            if (xDim != null)
                                PL.DimPlaceByBottomY(xDim, BCS.PC);
                        }

                        // Dim No 16
                        if (DN.DimIDNo16)
                        {
                            pointList = new PointList();
                            pointList.Add(BCS.BottAL.Points.P1);
                            pointList.Add(MainBeam.StartPoint);
                            xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistBot, StAtrr);
                            if (xDim != null)
                                PL.DimPlaceByBottomY(xDim, BCS.PC);
                        }
                    }

                    if (DN.DimIDNo15 && BCS.BottAR != null && BCS.BottAL != null)
                    {
                        pointList = new PointList();
                        pointList.Add(BCS.BottAR.Points.P1);
                        pointList.Add(BCS.BottAL.Points.P1);
                        xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistBot, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByBottomY(xDim, BCS.PC);
                    }

                    if (BCS.SCR != null)
                    {
                        Vect = new Vector(1, 0, 0);
                        // Dim No 24.1
                        if (DN.DimIDNo24Dot1)
                        {
                            pointList = new PointList();
                            pointList.Add(BCS.SCR.Points.P4);
                            pointList.Add(BCS.Points.P4);
                            xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistRight, StAtrr);
                            if (xDim != null)
                                PL.DistPlaceRightP(xDim, BCS.PC.RightX, BCS.PC.DistRight);

                            pointList = new PointList();
                            pointList.Add(BCS.SCR.Points.P3);
                            pointList.Add(BCS.Points.P3);
                            xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistRight, StAtrr);
                            if (xDim != null)
                                PL.DistPlaceRightP(xDim, BCS.PC.RightX, BCS.PC.DistRight);
                        }

                        // Dim No 24
                        if (DN.DimIDNo24)
                        {
                            pointList = new PointList();
                            pointList.Add(BCS.SCR.Points.P4);
                            pointList.Add(BCS.SCR.Points.P3);
                            xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistRight, StAtrr);
                            if (xDim != null)
                                PL.DistPlaceRightP(xDim, BCS.PC.RightX, BCS.PC.DistRight);
                        }

                        if (DN.DimIDNo24Dot1 || DN.DimIDNo24)
                            BCS.PC.DistRight += BCS.PC.DistInc;
                    }
                    else if (BCS.SCL != null)
                    {
                        Vect = new Vector(-1, 0, 0);
                        // Dim No 24.1
                        if (DN.DimIDNo24Dot1)
                        {
                            pointList = new PointList();
                            pointList.Add(BCS.SCL.Points.P1);
                            pointList.Add(BCS.Points.P1);
                            xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistLeft, StAtrr);
                            if (xDim != null)
                                PL.DistPlaceLeftP(xDim, BCS.PC.LeftX, BCS.PC.DistLeft);

                            pointList = new PointList();
                            pointList.Add(BCS.SCR.Points.P2);
                            pointList.Add(BCS.Points.P2);
                            xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistLeft, StAtrr);
                            if (xDim != null)
                                PL.DistPlaceLeftP(xDim, BCS.PC.LeftX, BCS.PC.DistLeft);
                        }

                        // Dim No 24
                        if (DN.DimIDNo24)
                        {
                            pointList = new PointList();
                            pointList.Add(BCS.SCR.Points.P1);
                            pointList.Add(BCS.SCR.Points.P2);
                            xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistLeft, StAtrr);
                            if (xDim != null)
                                PL.DistPlaceLeftP(xDim, BCS.PC.LeftX, BCS.PC.DistLeft);
                        }
                    }

                    // Dim No 24.2
                    if (BC.FLP!=null && DN.DimIDNo24Dot2)
                    {
                        Vect = new Vector(1, 0, 0);
                        pointList = new PointList();
                        pointList.Add(BCS.FLP.Points.P4);
                        pointList.Add(BCS.FLP.Points.P3);
                        xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistRight, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceRightP(xDim, BCS.PC.RightX, BCS.PC.DistRight);

                    }

                //}
            }
            else if(DN.DimIDNo36) // Detail Type B
            {


                Vect = new Vector(-1, 0, 0);
                if (BCS.MidAL != null)
                {
                    pointList = new PointList();
                    pointList.Add(BCS.MidAL.Points.P1);
                    pointList.Add(BCS.MidAL.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByLeftX(xDim, BCS.PC);
                }
                Vect = new Vector(1, 0, 0);
                if (BCS.MidAR != null)
                {
                    pointList = new PointList();
                    pointList.Add(BCS.MidAR.Points.P4);
                    pointList.Add(BCS.MidAR.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByRightX(xDim, BCS.PC);
                }

            }

        }

        #region Get Data

        private void GetBeamClassClass(TSD.View CView)
        {
            if (ViewName == "Front View")
            {
                BC = new BeamClass_BSP4();
                BC.beam = MainBeam;
                BC.Points = Com.GetPartPoints(MainBeam);
                List<TSM.Part> PartListC = BC.beam.GetAssembly().GetSecondaries().OfType<TSM.Part>().ToList();

                BC.SurfPoints = GetSurfPoints();
                GetAngleProperties(PartListC);


                PartListC.Add(MainBeam);
                List<Point> RefPoints = MainBeam.GetReferenceLine(false).OfType<Point>().ToList();

                double MinXP = (from p in RefPoints orderby p.X ascending select p.X).FirstOrDefault();
                double MaxXP = (from p in RefPoints orderby p.X descending select p.X).FirstOrDefault();

                MinXP -= 100;
                MaxXP += 100;

                TSM.Part LeftPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.X ascending select p).FirstOrDefault();
                TSM.Part RightPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.X descending select p).FirstOrDefault();
                TSM.Part TopPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.Y descending select p).FirstOrDefault();
                TSM.Part BottPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.Y ascending select p).FirstOrDefault();

                BC.PC = new PlacingClass();
                BC.PC.TopY = TopPart.GetSolid().MaximumPoint.Y;
                BC.PC.BottomY = BottPart.GetSolid().MinimumPoint.Y;


                BC.PC.LeftX = LeftPart.GetSolid().MinimumPoint.X;// Math.Round(CView.RestrictionBox.MinPoint.X);
                BC.PC.RightX = RightPart.GetSolid().MaximumPoint.X;


                double AvScale = 12;
                double AvDistInc = 100;
                double DistPerScale = AvDistInc / AvScale;
                double CScale = CView.Attributes.Scale;
                BC.PC.DistInc = CScale * DistPerScale;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;
            }
            else if (ViewName == "Section View")
            {

                BCS = new BeamClass_BSP4S();
                BCS.Points = Com.GetPartPoints(MainBeam);
                List<TSM.Part> PartListC = MainBeam.GetAssembly().GetSecondaries().OfType<TSM.Part>().ToList();

                double MaxZ = CView.RestrictionBox.MinPoint.Z;
                List<TSM.Part> PartListF = (from p in PartListC where Com.IsViewObj(p, CView) select p).ToList();
                Point CentP = Com.CenterPoint(MainBeam.StartPoint, MainBeam.EndPoint);

                Beam TopAL = (from p in PartListF.OfType<Beam>() where Com.GetProType(p) == "L" && (Com.CenterPoint(p).X < BCS.Points.CentP.X) && (Com.CenterPoint(p).Y > BCS.Points.P1.Y) select p).FirstOrDefault();
                Beam TopAR = (from p in PartListF.OfType<Beam>() where Com.GetProType(p) == "L" && (Com.CenterPoint(p).X > BCS.Points.CentP.X) && (Com.CenterPoint(p).Y > BCS.Points.P1.Y) select p).FirstOrDefault();

                Beam BottAL = (from p in PartListF.OfType<Beam>() where Com.GetProType(p) == "L" && (Com.CenterPoint(p).X < BCS.Points.CentP.X) && (Com.CenterPoint(p).Y < BCS.Points.P2.Y) select p).FirstOrDefault();
                Beam BottAR = (from p in PartListF.OfType<Beam>() where Com.GetProType(p) == "L" && (Com.CenterPoint(p).X > BCS.Points.CentP.X) && (Com.CenterPoint(p).Y < BCS.Points.P2.Y) select p).FirstOrDefault();

                Beam MidAL = (from p in PartListF.OfType<Beam>() where Com.GetProType(p) == "L" && (Com.CenterPoint(p).X < BCS.Points.CentP.X) && (Com.CenterPoint(p).Y > BCS.Points.P2.Y && Com.CenterPoint(p).Y < BCS.Points.P1.Y) select p).FirstOrDefault();
                Beam MidAR = (from p in PartListF.OfType<Beam>() where Com.GetProType(p) == "L" && (Com.CenterPoint(p).X > BCS.Points.CentP.X) && (Com.CenterPoint(p).Y > BCS.Points.P2.Y && Com.CenterPoint(p).Y < BCS.Points.P1.Y) select p).FirstOrDefault();


                TSM.Part SCL = (from p in PartListF.OfType<TSM.Part>() where Com.GetProType(p) != "L" && (Com.CenterPoint(p).X < BCS.Points.CentP.X) && (Com.CenterPoint(p).Y > BCS.Points.P2.Y && Com.CenterPoint(p).Y < BCS.Points.P1.Y) select p).FirstOrDefault();
                TSM.Part SCR = (from p in PartListF.OfType<TSM.Part>() where Com.GetProType(p) != "L" && (Com.CenterPoint(p).X > BCS.Points.CentP.X) && (Com.CenterPoint(p).Y > BCS.Points.P2.Y && Com.CenterPoint(p).Y < BCS.Points.P1.Y) select p).FirstOrDefault();


                TSM.Part FLP = (from p in PartListF where Com.GetProType(p) != "L" && (Com.CenterPoint(p).Y > BCS.Points.P1.Y) && dc.IsHorzObjN(p) select p).FirstOrDefault();

                if (TopAL != null)
                    BCS.TopAL = GetAngleClassS(TopAL, "Top", "Left");
                if (TopAR != null)
                    BCS.TopAR = GetAngleClassS(TopAR, "Top", "Right");

                if (BottAL != null)
                    BCS.BottAL = GetAngleClassS(BottAL, "Bottom", "Left");
                if (BottAR != null)
                    BCS.BottAR = GetAngleClassS(BottAR, "Bottom", "Right");

                if (MidAL != null)
                {
                    BCS.MidAL = GetAngleClassS(MidAL, "Middle", "Left");
                    BCS.TypeS = GetSectionType(MidAL);
                }
                if (MidAR != null)
                {
                    BCS.MidAR = GetAngleClassS(MidAR, "Middle", "Right");
                    BCS.TypeS = GetSectionType(MidAR);
                }

                if (FLP != null)
                    BCS.FLP = Com.GetPartClass(FLP);

                if (SCL != null)
                {
                    BCS.SCL = new StiffClass();
                    BCS.SCL.Stiff = SCL;
                    BCS.SCL.Points = Com.GetPartPoints(SCL);
                }

                if (SCR != null)
                {
                    BCS.SCR = new StiffClass();
                    BCS.SCR.Stiff = SCR;
                    BCS.SCR.Points = Com.GetPartPoints(SCR);
                }

                TSM.Part LeftPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.X ascending select p).FirstOrDefault();
                TSM.Part RightPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.X descending select p).FirstOrDefault();
                TSM.Part TopPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.Y descending select p).FirstOrDefault();
                TSM.Part BottPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.Y ascending select p).FirstOrDefault();

                BCS.PC = new PlacingClass();
                BCS.PC.TopY = TopPart.GetSolid().MaximumPoint.Y;
                BCS.PC.BottomY = BottPart.GetSolid().MinimumPoint.Y;


                BCS.PC.LeftX = LeftPart.GetSolid().MinimumPoint.X;// Math.Round(CView.RestrictionBox.MinPoint.X);
                BCS.PC.RightX = RightPart.GetSolid().MaximumPoint.X;


                double AvScale = 12;
                double AvDistInc = 100;
                double DistPerScale = AvDistInc / AvScale;
                double CScale = CView.Attributes.Scale;
                BCS.PC.DistInc = CScale * DistPerScale;
                BCS.PC.DistBot = BCS.PC.DistInc;
                BCS.PC.DistTop = BCS.PC.DistInc;
                BCS.PC.DistLeft = BCS.PC.DistInc;
                BCS.PC.DistRight = BCS.PC.DistInc;
            }
            else if (ViewName == "Top View")
            {
                BC = new BeamClass_BSP4();
                BC.beam = MainBeam;
                BC.Points = Com.GetPartPoints(MainBeam);
                List<TSM.Part> PartListC = BC.beam.GetAssembly().GetSecondaries().OfType<TSM.Part>().ToList();

                GetFlanePlateProperties(PartListC);

                PartListC.Add(MainBeam);
                List<Point> RefPoints = MainBeam.GetReferenceLine(false).OfType<Point>().ToList();

                double MinXP = (from p in RefPoints orderby p.X ascending select p.X).FirstOrDefault();
                double MaxXP = (from p in RefPoints orderby p.X descending select p.X).FirstOrDefault();

                MinXP -= 100;
                MaxXP += 100;

                TSM.Part LeftPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.X ascending select p).FirstOrDefault();
                TSM.Part RightPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.X descending select p).FirstOrDefault();
                TSM.Part TopPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.Y descending select p).FirstOrDefault();
                TSM.Part BottPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.Y ascending select p).FirstOrDefault();

                BC.PC = new PlacingClass();
                BC.PC.TopY = TopPart.GetSolid().MaximumPoint.Y;
                BC.PC.BottomY = BottPart.GetSolid().MinimumPoint.Y;


                BC.PC.LeftX = LeftPart.GetSolid().MinimumPoint.X;// Math.Round(CView.RestrictionBox.MinPoint.X);
                BC.PC.RightX = RightPart.GetSolid().MaximumPoint.X;


                double AvScale = 12;
                double AvDistInc = 100;
                double DistPerScale = AvDistInc / AvScale;
                double CScale = CView.Attributes.Scale;
                BC.PC.DistInc = CScale * DistPerScale;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;
            }

        }

        private void GetFlanePlateProperties(List<TSM.Part> PartListC)
        {
            TSM.Part FP = null;
            Point CentP = Com.CenterPoint(BC.beam.StartPoint, BC.beam.EndPoint);
            double Lenght = (BC.beam.GetSolid().MaximumPoint.X - BC.beam.GetSolid().MinimumPoint.X) / 6;
            double MinX = BC.beam.GetSolid().MinimumPoint.X + Lenght;
            double MaxX = BC.beam.GetSolid().MaximumPoint.X - Lenght;

            PartListC = PartListC.Where(x => Com.CenterPoint(x).Z > BC.Points.CentP.Z).ToList();
            if (Position == "Left")
                FP = (from p in PartListC where !dc.IsPlateSideView(p) && (p.GetSolid().MaximumPoint.X < CentP.X && p.GetSolid().MinimumPoint.X <= MinX) select p).FirstOrDefault();
            else
                FP = (from p in PartListC where !dc.IsPlateSideView(p) && (p.GetSolid().MinimumPoint.X > CentP.X && p.GetSolid().MaximumPoint.X >= MaxX) select p).FirstOrDefault();

            if (FP != null)
            {
                BC.FLP = new FlangePlateClass();
                BC.FLP.FLPlate = FP;
                BC.FLP.Points = Com.GetPartPoints(FP);
                List<BoltGroup> Bolts = Com.EnumtoArray(FP.GetBolts()).OfType<BoltGroup>().ToList();
                if (Bolts != null && Bolts.Count > 0)
                {
                    BoltGroup BoltT = (from b in Bolts where b.FirstPosition.Y > BC.Points.CentP.Y select b).FirstOrDefault();
                    BoltGroup BoltB = (from b in Bolts where b.FirstPosition.Y < BC.Points.CentP.Y select b).FirstOrDefault();

                    if (BoltT != null)
                        BC.FLP.TopBolts = Com.GetBoltPoints(BoltT);

                    if (BoltB != null)
                        BC.FLP.BottBolts = Com.GetBoltPoints(BoltB);

                }

                List<BooleanPart> Cuts = Com.EnumtoArray(FP.GetBooleans()).OfType<BooleanPart>().ToList();
                if (Cuts != null && Cuts.Count > 0)
                {
                    BC.FLP.CutPoints = new CutPoints();
                    if (Cuts.Count == 1)
                    {

                        PointList VPlist = dc.GetVertPointList(Cuts[0].OperativePart);
                        if (Position == "Left")
                        {
                            BC.FLP.CutPoints.P1 = Com.MinPofY(VPlist, "X", Com.MaxP(VPlist, "Y").Y);
                            BC.FLP.CutPoints.P2 = Com.MinPofY(VPlist, "X", Com.MinP(VPlist, "Y").Y);
                            BC.FLP.CutPoints.P3 = Com.MaxPofY(VPlist, "X", Com.MinP(VPlist, "Y").Y);
                            BC.FLP.CutPoints.P4 = Com.MaxPofY(VPlist, "X", Com.MaxP(VPlist, "Y").Y);
                            BC.FLP.CutPoints.P5 = Com.MinP(VPlist, "X");
                        }
                        else
                        {
                            BC.FLP.CutPoints.P1 = Com.MinPofY(VPlist, "X", Com.MaxP(VPlist, "Y").Y);
                            BC.FLP.CutPoints.P2 = Com.MinPofY(VPlist, "X", Com.MinP(VPlist, "Y").Y);
                            BC.FLP.CutPoints.P3 = Com.MaxPofY(VPlist, "X", Com.MinP(VPlist, "Y").Y);
                            BC.FLP.CutPoints.P4 = Com.MaxPofY(VPlist, "X", Com.MaxP(VPlist, "Y").Y);
                            BC.FLP.CutPoints.P5 = Com.MaxP(VPlist, "X");
                        }
                    }
                    else
                    {
                        BC.FLP.Type2 = true;
                        BC.FLP.CutPoints = new CutPoints();
                        TSM.Part LeftCut = Cuts[0].OperativePart;
                        TSM.Part RightCut = Cuts[1].OperativePart;

                        if (LeftCut.GetSolid().MinimumPoint.X > RightCut.GetSolid().MinimumPoint.X)
                        {
                            LeftCut = Cuts[1].OperativePart;
                            RightCut = Cuts[0].OperativePart;
                        }

                        PointList VPlistL = dc.GetVertPointList(LeftCut);
                        PointList VPlistR = dc.GetVertPointList(RightCut);



                        BC.FLP.CutPoints.P1 = Com.MinPofY(VPlistL, "X", Com.MaxP(VPlistL, "Y").Y);
                        BC.FLP.CutPoints.P2 = Com.MinPofY(VPlistL, "X", Com.MinP(VPlistL, "Y").Y);
                        BC.FLP.CutPoints.P3 = Com.MaxPofY(VPlistR, "X", Com.MinP(VPlistR, "Y").Y);
                        BC.FLP.CutPoints.P4 = Com.MaxPofY(VPlistR, "X", Com.MaxP(VPlistR, "Y").Y);
                        if (Position == "Left")
                        {
                            BC.FLP.CutPoints.P5 = Com.MinP(VPlistL, "X");
                            BC.FLP.CutPoints.P6 = Com.MaxP(VPlistR, "X");
                        }
                        else
                        {
                            BC.FLP.CutPoints.P5 = Com.MaxP(VPlistR, "X");
                            BC.FLP.CutPoints.P6 = Com.MinP(VPlistL, "X");
                        }




                    }

                }

            }

        }

        private void GetAngleProperties(List<TSM.Part> PartListC)
        {
            Beam TopAng = null;
            Beam MidAng = null;
            Beam BottAng = null;
            Point CentP = Com.CenterPoint(BC.beam.StartPoint, BC.beam.EndPoint);
            double Lenght = (BC.beam.GetSolid().MaximumPoint.X - BC.beam.GetSolid().MinimumPoint.X) / 8;
            double MinX = BC.beam.GetSolid().MinimumPoint.X + Lenght;
            double MaxX = BC.beam.GetSolid().MaximumPoint.X - Lenght;

            if (Position == "Left")
            {
                TopAng = (from p in PartListC.OfType<Beam>() where (p.GetSolid().MaximumPoint.X < CentP.X && p.GetSolid().MinimumPoint.X <= MinX) && (Com.CenterPoint(p).Y > BC.Points.P1.Y) select p).FirstOrDefault();
                BottAng = (from p in PartListC.OfType<Beam>() where (p.GetSolid().MaximumPoint.X < CentP.X && p.GetSolid().MinimumPoint.X <= MinX) && (Com.CenterPoint(p).Y < BC.Points.P2.Y) select p).FirstOrDefault();
                MidAng = (from p in PartListC.OfType<Beam>() where (p.GetSolid().MaximumPoint.X < CentP.X && p.GetSolid().MinimumPoint.X <= MinX) && (Com.CenterPoint(p).Y > BC.Points.P2.Y && Com.CenterPoint(p).Y < BC.Points.P1.Y) select p).FirstOrDefault();
            }
            else
            {

                TopAng = (from p in PartListC.OfType<Beam>() where (p.GetSolid().MinimumPoint.X > CentP.X && p.GetSolid().MaximumPoint.X >= MaxX) && (Com.CenterPoint(p).Y > BC.Points.P1.Y) select p).FirstOrDefault();
                BottAng = (from p in PartListC.OfType<Beam>() where (p.GetSolid().MinimumPoint.X > CentP.X && p.GetSolid().MaximumPoint.X >= MaxX) && (Com.CenterPoint(p).Y < BC.Points.P2.Y) select p).FirstOrDefault();
                MidAng = (from p in PartListC.OfType<Beam>() where (p.GetSolid().MinimumPoint.X > CentP.X && p.GetSolid().MaximumPoint.X >= MaxX) && (Com.CenterPoint(p).Y > BC.Points.P2.Y && Com.CenterPoint(p).Y < BC.Points.P1.Y) select p).FirstOrDefault();
            }

            if (TopAng != null)
                BC.TopAngle = GetAngleClass(TopAng, "Top");

            if (BottAng != null)
                BC.BottAngle = GetAngleClass(BottAng, "Bottom");

            if (MidAng != null)
            {
                BC.MidAngle = GetAngleClass(MidAng, "Middle");

                TSM.Part Stiff = null;
                if (Position == "Left")
                    Stiff = (from p in PartListC where dc.IsPlateSideView(p) && !dc.IsHorzObj(p) && Com.CenterPoint(p).X < Com.CenterPoint(MidAng).X select p).FirstOrDefault();
                else
                    Stiff = (from p in PartListC where dc.IsPlateSideView(p) && !dc.IsHorzObj(p) && Com.CenterPoint(p).X > Com.CenterPoint(MidAng).X select p).FirstOrDefault();

                if (Stiff != null)
                {
                    BC.SC = new StiffClass();
                    BC.SC.Stiff = Stiff;
                    BC.SC.Points = Com.GetPartPoints(Stiff);
                }



            }

        }

        private AngleClass GetAngleClass(Beam ang, string Pos)
        {
            AngleClass AC = new AngleClass();
            AC.Angle = ang;
            AC.Points = Com.GetPartPoints(ang);


            List<BoltGroup> Bolts = (from b in Com.EnumtoArray(ang.GetBolts()).OfType<BoltGroup>() where !dc.IsSideBolt(ang, b) select b).ToList();
            if (Bolts != null && Bolts.Count > 0)
            {
                AC.BoltPList = new PointList();
                Bolts.ForEach(x => AC.BoltPList.AddRange(Com.GetBoltPoints(x)));
            }

            double AngWidthH = GetPartWidth(ang) / 3;
            BooleanPart CutPart = Com.EnumtoArray(ang.GetBooleans()).OfType<BooleanPart>().Where(x => GetPartWidth(x.OperativePart) < AngWidthH).FirstOrDefault();
            if (CutPart != null)
            {
                TSM.Part CT = CutPart.OperativePart;
                PointList CutPoints = Com.GetVertxPointsD(CT);
                if (Pos == "Top")
                {
                    AC.CutPoints = new PartPoints();
                    if (Com.CenterPoint(CT).X < AC.Points.CentP.X) // Left
                    {
                        AC.CutPoints.P1 = Com.MinPofY(CutPoints, "X", Com.MinP(CutPoints, "Y").Y);
                        AC.CutPoints.P2 = Com.MaxPofY(CutPoints, "X", Com.MinP(CutPoints, "Y").Y);
                        AC.CutPoints.P3 = Com.MinPofX(CutPoints, "Y", Com.MaxP(CutPoints, "X").X);
                        AC.CutPoints.P4 = Com.MaxPofX(CutPoints, "Y", Com.MaxP(CutPoints, "X").X);
                    }
                    else
                    {
                        AC.CutPoints.P1 = Com.MaxPofY(CutPoints, "X", Com.MinP(CutPoints, "Y").Y);
                        AC.CutPoints.P2 = Com.MinPofY(CutPoints, "X", Com.MinP(CutPoints, "Y").Y);
                        AC.CutPoints.P3 = Com.MinPofX(CutPoints, "Y", Com.MinP(CutPoints, "X").X);
                        AC.CutPoints.P4 = Com.MaxPofX(CutPoints, "Y", Com.MinP(CutPoints, "X").X);
                    }
                }
                else if (Pos == "Bottom")
                {
                    AC.CutPoints = new PartPoints();
                    if (Com.CenterPoint(CT).X < AC.Points.CentP.X) // Left
                    {
                        AC.CutPoints.P1 = Com.MinPofY(CutPoints, "X", Com.MaxP(CutPoints, "Y").Y);
                        AC.CutPoints.P2 = Com.MaxPofY(CutPoints, "X", Com.MaxP(CutPoints, "Y").Y);
                        AC.CutPoints.P3 = Com.MaxPofX(CutPoints, "Y", Com.MaxP(CutPoints, "X").X);
                        AC.CutPoints.P4 = Com.MinPofX(CutPoints, "Y", Com.MaxP(CutPoints, "X").X);
                    }
                    else
                    {
                        AC.CutPoints.P1 = Com.MaxPofY(CutPoints, "X", Com.MaxP(CutPoints, "Y").Y);
                        AC.CutPoints.P2 = Com.MinPofY(CutPoints, "X", Com.MaxP(CutPoints, "Y").Y);
                        AC.CutPoints.P3 = Com.MaxPofX(CutPoints, "Y", Com.MinP(CutPoints, "X").X);
                        AC.CutPoints.P4 = Com.MinPofX(CutPoints, "Y", Com.MinP(CutPoints, "X").X);
                    }
                }
            }

            return AC;
        }

        private AngleClass GetAngleClassS(Beam ang, string PosV, string PosH)
        {
            AngleClass AC = new AngleClass();
            AC.Angle = ang;
            if (PosV == "Middle")
            {
                double LegWidth = Com.GetPartFlangeThickness(ang);
                AC.Points = Com.GetPartPoints(ang);
                if (PosH == "Left")
                    AC.Points.P5 = new Point(AC.Points.P1.X + LegWidth, AC.Points.P1.Y, AC.Points.P1.Z);
                else
                    AC.Points.P5 = new Point(AC.Points.P4.X - LegWidth, AC.Points.P4.Y, AC.Points.P4.Z);
            }
            else if (PosV == "Top")
            {
                AC.Points = new PartPoints();
                PointList VPList = Com.GetVertxPointsD(ang);
                if (PosH == "Left")
                {
                    AC.Points.P1 = Com.MaxPofX(VPList, "Y", Com.MinP(VPList, "X").X);
                    AC.Points.P2 = Com.MinPofX(VPList, "Y", Com.MinP(VPList, "X").X);
                    AC.Points.P3 = Com.MinPofX(VPList, "Y", Com.MaxP(VPList, "X").X);
                    AC.Points.P4 = Com.MaxPofX(VPList, "Y", Com.MaxP(VPList, "X").X);
                    AC.Points.P5 = Com.MaxPofY(VPList, "X", Com.MaxP(VPList, "Y").Y);
                }
                else
                {
                    AC.Points.P1 = Com.MaxPofX(VPList, "Y", Com.MaxP(VPList, "X").X);
                    AC.Points.P2 = Com.MinPofX(VPList, "Y", Com.MaxP(VPList, "X").X);
                    AC.Points.P3 = Com.MinPofX(VPList, "Y", Com.MinP(VPList, "X").X);
                    AC.Points.P4 = Com.MaxPofX(VPList, "Y", Com.MinP(VPList, "X").X);
                    AC.Points.P5 = Com.MinPofY(VPList, "X", Com.MaxP(VPList, "Y").Y);
                }
            }
            else
            {
                AC.Points = new PartPoints();
                PointList VPList = Com.GetVertxPointsD(ang);
                if (PosH == "Left")
                {
                    AC.Points.P1 = Com.MinPofX(VPList, "Y", Com.MinP(VPList, "X").X);
                    AC.Points.P2 = Com.MaxPofX(VPList, "Y", Com.MinP(VPList, "X").X);
                    AC.Points.P3 = Com.MaxPofX(VPList, "Y", Com.MaxP(VPList, "X").X);
                    AC.Points.P4 = Com.MinPofX(VPList, "Y", Com.MaxP(VPList, "X").X);
                    AC.Points.P5 = Com.MaxPofY(VPList, "X", Com.MinP(VPList, "Y").Y);
                }
                else
                {
                    AC.Points.P1 = Com.MinPofX(VPList, "Y", Com.MaxP(VPList, "X").X);
                    AC.Points.P2 = Com.MaxPofX(VPList, "Y", Com.MaxP(VPList, "X").X);
                    AC.Points.P3 = Com.MaxPofX(VPList, "Y", Com.MinP(VPList, "X").X);
                    AC.Points.P4 = Com.MinPofX(VPList, "Y", Com.MinP(VPList, "X").X);
                    AC.Points.P5 = Com.MinPofY(VPList, "X", Com.MinP(VPList, "Y").Y);
                }
            }

            return AC;
        }

        private PartPoints GetSurfPoints()
        {
            PartPoints SurfPoints = null;
            try
            {
                ModelObjectEnumerator Enum = Com.MyModel.GetModelObjectSelector().GetObjectsByBoundingBox(MainBeam.GetSolid().MinimumPoint, MainBeam.GetSolid().MaximumPoint);
                List<TSM.Part> AllParts = Com.EnumtoArray(Enum).OfType<TSM.Part>().ToList();
                List<TSM.Part> PartListC = BC.beam.GetAssembly().GetSecondaries().OfType<TSM.Part>().ToList();
                List<int> IDs = PartListC.Select(x => x.Identifier.ID).ToList();
                List<TSM.Part> ListExtra = AllParts.Where(x => !IDs.Contains(x.Identifier.ID)).ToList();

                if (ListExtra?.Count > 0)
                {
                    TSM.Part Surface = null;
                    if (Position == "Left")
                        Surface = (from p in ListExtra where p.Material.MaterialString == "Zero_Density" && Com.CenterPoint(p).X < BC.Points.CentP.X orderby p.GetSolid().MinimumPoint.Y select p).FirstOrDefault();
                    else
                        Surface = (from p in ListExtra where p.Material.MaterialString == "Zero_Density" && Com.CenterPoint(p).X > BC.Points.CentP.X orderby p.GetSolid().MinimumPoint.Y select p).FirstOrDefault();

                    if (Surface != null)
                        SurfPoints = Com.GetPartPoints(Surface);

                }
            }
            catch (Exception ex)
            { }
            return SurfPoints;
        }


        #endregion

        #region Helping Methods
        private double GetPartWidth(TSM.Part part)
        {
            return (part.GetSolid().MaximumPoint.X - part.GetSolid().MinimumPoint.X);
        }

        private string GetSectionType(Beam Angle)
        {

            Point P1 = new Point(Angle.StartPoint.X, Angle.StartPoint.Y);
            Point P2 = new Point(Angle.EndPoint.X, Angle.EndPoint.Y);

            double Dist = Distance.PointToPoint(P1, P2);

            if (Dist > 10)
                return "A";
            else
                return "B";
        }

        #endregion

        private class FlangePlateClass
        {
            public TSM.Part FLPlate { get; set; }
            public PointList TopBolts { get; set; }
            public PointList BottBolts { get; set; }
            public PartPoints Points { get; set; }
            public CutPoints CutPoints { get; set; }
            public bool Type2 { get; set; }
        }

        private class BeamClass_BSP4
        {
            public Beam beam { get; set; }
            public AngleClass TopAngle { get; set; }
            public AngleClass BottAngle { get; set; }
            public AngleClass MidAngle { get; set; }
            public StiffClass SC { get; set; }
            public PartPoints Points { get; set; }
            public PlacingClass PC { get; set; }
            public Beam SecBeam { get; set; }
            public PartPoints SurfPoints { get; set; }
            public FlangePlateClass FLP { get; set; }
        }

        private class BeamClass_BSP4S
        {
            public AngleClass TopAL { get; set; }
            public AngleClass TopAR { get; set; }
            public AngleClass BottAL { get; set; }
            public AngleClass BottAR { get; set; }
            public AngleClass MidAL { get; set; }
            public AngleClass MidAR { get; set; }
            public StiffClass SCL { get; set; }
            public StiffClass SCR { get; set; }
            public PartClass FLP { get; set; }
            public PartPoints Points { get; set; }
            public PlacingClass PC { get; set; }
            public string TypeS = "A";
        }

    }

}
