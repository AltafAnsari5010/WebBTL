﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Tekla.Structures;
using Tekla.Structures.Drawing;
using Tekla.Structures.Geometry3d;
using Tekla.Structures.Model;
using TSD = Tekla.Structures.Drawing;
using TSM = Tekla.Structures.Model;
using VirtueleDrawingAutomation;
using TSDD = Tekla.Structures.Datatype;
using TSG = Tekla.Structures.Geometry3d;

namespace Auto_Detailing_Tool_Beam
{
    public class BeamDim_BG12
    {
        #region Global Variables
        DimCom dc = new DimCom();
        StraightDimensionSet.StraightDimensionSetAttributes StAtrr = new StraightDimensionSet.StraightDimensionSetAttributes("standard");
        StraightDimensionSet.StraightDimensionSetAttributes RdAtrr = new StraightDimensionSet.StraightDimensionSetAttributes("standard");

        public Beam MainBeam = null;
        VirtueleDrawingAutomation.Json.DrawingAttributeInfoJson.AttributeFiles dimAttrClass = null;
        List<TSD.StraightDimension> KnockDim = new List<StraightDimension>();
        BeamClass_BG12 BC = null;
        VirtueleDrawingAutomation.Json.AutoDimensionTypesJson.BG12Json DN = null;
        TSD.View CView = null;
        string ViewName = "";
        List<int> Ids = new List<int>();
        #endregion

        public List<int> ApplyDim(TSD.View CView, string ViewName, AutoDimensioningTypes autoDimensioningTypes, DrawingAttributeInfo drawingAttributeInfo, List<int> Ids)
        {
            try
            {
                this.Ids = Ids;
                Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane());
                //Set model everything to the view
                Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane(CView.DisplayCoordinateSystem));

                this.CView = CView;
                this.dimAttrClass = drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files;
                this.DN = autoDimensioningTypes.Bg12;
                StAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.StandardDimension);
                RdAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.RunningDimension);
                StAtrr.Placing.Placing = DimensionSetBaseAttributes.Placings.Fixed;
                RdAtrr.Placing.Placing = DimensionSetBaseAttributes.Placings.Fixed;

                this.MainBeam = (Com.MyModel.SelectModelObject(new Identifier((CView.GetDrawing() as AssemblyDrawing).AssemblyIdentifier.ID)) as TSM.Assembly).GetMainPart() as TSM.Beam;
                this.MainBeam.Select();
                string ProType = Com.GetProType(MainBeam);
                this.ViewName = ViewName;

                GetBeamClassClass(CView);

                if (ViewName == "Top View" || ViewName == "Bottom View")
                {

                    while (BC.TopGP != null || BC.BottGP != null)
                    {
                        ApplyDimType(CView);
                        GetBeamClassClass(CView);
                    }
                }
                else if (ViewName == "Front View")
                {
                    ApplyTBV();
                }
                else if (ViewName == "Section View")
                    AppySectionDim();

                Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane());
            }
            catch (Exception ex)
            { }

            return Ids;
        }


        #region Top / Bottom View Dim
        private void ApplyDimType(TSD.View CView)
        {

            StAtrr.Placing.Placing = DimensionSetBaseAttributes.Placings.Fixed;
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            TSD.PointList TempList = new PointList();
            bool IsVertDim = true;
            Point RefP = null;

            #region Top Gusset
            if (BC.TopGP?.GussetPlate != null)
            {


                ApplyLeftTopG();
                ApplyRightTopG();

                Ids.Add(BC.TopGP.GussetPlate.Identifier.ID);
                // Com.SetCode(BC.TopGP.GussetPlate);
            }
            #endregion


            #region Bottom Gusset
            if (BC.BottGP?.GussetPlate != null)
            {

                ApplyLeftBottG();
                ApplyRightBottG();

                // Com.SetCode(BC.BottGP.GussetPlate);
                Ids.Add(BC.BottGP.GussetPlate.Identifier.ID);
            }
            #endregion

            ApplyRadiusDim();
        }

        private void ApplyLeftTopG()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            TSD.PointList TempList = new PointList();

            if (BC.TopGP?.LB != null)
            {
                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;

                TempList = Com.GetBoltPoints(BC.TopGP.LB.BoltM);
                TSG.Line YLine = new TSG.Line(BC.TopGP.Points.P6, BC.TopGP.Points.P1);
                TSG.Line XLine = new TSG.Line(BC.TopGP.LB.IntPoint, BC.TopGP.LB.RefPBrace);
                Vector LeftVect = BC.TopGP.LB.BoltM.GetCoordinateSystem().AxisY;

                if (LeftVect.X > 0)
                    LeftVect = dc.ChangeVector(LeftVect);

                Vector RightVect = BC.TopGP.LB.BoltM.GetCoordinateSystem().AxisY;
                if (RightVect.X < 0)
                    RightVect = dc.ChangeVector(RightVect);

                Vector TopVect = BC.TopGP.LB.BoltM.GetCoordinateSystem().AxisX;
                if (TopVect.Y < 0)
                    TopVect = dc.ChangeVector(TopVect);

                Vector BottVect = BC.TopGP.LB.BoltM.GetCoordinateSystem().AxisX;
                if (BottVect.Y > 0)
                    BottVect = dc.ChangeVector(BottVect);

                #region Diagonal Right
                BC.PC.DistRight = (BC.PC.DistInc * 0.5);
                TempList = dc.ChangePints(BC.TopGP.LB.BoltMP, CView, RightVect);

                // Dim No 6, 6.1
                if (DN.DimIDNo6 || DN.DimIDNo6Dot1)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo4)// Dim No 6
                        pointList.Add(Com.MinP(TempList, "Y"));

                    pointList.Add(BC.TopGP.LB.IntPointB);
                    if (DN.DimIDNo6Dot1)// Dim No 6.1
                        pointList.Add(BC.TopGP.LB.RefPBrace);

                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }

                }


                // Dim No 5.1 , 5
                if (DN.DimIDNo5Dot1 || DN.DimIDNo5)
                {

                    pointList = new PointList();
                    if (DN.DimIDNo5Dot1)
                    {
                        pointList.Add(Com.MaxP(TempList, "Y"));
                        pointList.Add(BC.TopGP.Points.P6);
                    }
                    if (DN.DimIDNo5)
                        pointList.AddRange(TempList);

                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistRight);
                }

                // Dim No 4
                if (DN.DimIDNo4)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "Y"));
                    pointList.Add(BC.TopGP.LB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistRight);
                }

                if (DN.DimIDNo5Dot1 || DN.DimIDNo5 || DN.DimIDNo4)
                    BC.PC.DistRight += BC.PC.DistInc;

                // Dim No 5.2
                if (DN.DimIDNo5Dot2)
                {
                    if (TempList.Count > 2)
                    {
                        pointList = new PointList();
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                        {
                            PL.DimPlacingDiag(xDim, XLine, BC.PC.DistRight);
                            Com.GroupDim(xDim);
                        }
                    }
                }

                #endregion

                #region Straight Left

                double LeftX = BC.TopGP.Points.P2.X;
                if (BC.BottGP != null && BC.BottGP.Points.P2.X < LeftX)
                    LeftX = BC.BottGP.Points.P2.X;

                Point CentLP = new Point(BC.TopGP.Points.P2.X, BC.Points.CentP.Y);
                Vect = new Vector(-1, 0, 0);
                BC.PC.DistLeft = (BC.PC.DistInc * 2);
                TempList = BC.TopGP.LB.BoltMP;

                // Dim No 9, 9.3
                if (DN.DimIDNo3Dot2 || DN.DimIDNo3Dot1)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo3Dot2)
                        pointList.AddRange(TempList);


                    if (DN.DimIDNo3Dot1)
                    {
                        pointList.Add(Com.MinP(TempList, "Y"));
                        pointList.Add(BC.TopGP.Points.P2);
                    }
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, LeftX, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }

                }


                // Dim No 3.3, 3.4
                if (DN.DimIDNo3Dot3 || DN.DimIDNo3Dot4)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo3Dot3)
                        pointList.Add(Com.MaxP(TempList, "Y"));

                    pointList.Add(BC.TopGP.Points.P2);

                    if (DN.DimIDNo3Dot4)
                        pointList.Add(CentLP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, LeftX, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }

                    if (BC.BottGP != null)
                    {
                        pointList = new PointList();
                        if (DN.DimIDNo3Dot3)
                            pointList.Add(Com.MinP(BC.BottGP.LB.BoltMP, "Y"));

                        pointList.Add(BC.BottGP.Points.P2);

                        if (DN.DimIDNo3Dot4)
                            pointList.Add(CentLP);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceLeftP(xDim, LeftX, BC.PC.DistLeft);
                            BC.PC.DistLeft += BC.PC.DistInc;
                        }
                    }

                }

                // Dim No 3
                if (DN.DimIDNo3)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    pointList.Add(CentLP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, LeftX, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }

                }

                // Dim No 20
                if (DN.DimIDNo20 && BC.BottGP != null)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P1);
                    pointList.Add(BC.TopGP.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, LeftX, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }

                }

                #endregion

                #region RD Dim
                //RD Dim

                Point RdPoint = new Point(BC.Points.P1.X, BC.Points.CentP.Y);

                Vect = new Vector(0, 1, 0);
                TempList = BC.TopGP.LB.BoltMP;
                BC.PC.DistTop = (BC.PC.DistInc * 2);
                // Dim No 9.1
                if (DN.DimIDNo9Dot1)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                // Dim No 9
                if (DN.DimIDNo9)
                {
                    if (TempList.Count > 2)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MaxP(TempList, "Y"));
                        pointList.Add(Com.MinP(TempList, "Y"));
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                            BC.PC.DistTop += BC.PC.DistInc;
                        }
                    }

                }


                // Dim No 2.7, 2.8
                if (DN.DimIDNo2Dot7 || DN.DimIDNo2Dot8)
                {
                    if (BC.Stiffs != null && BC.Stiffs.Count > 0)
                    {
                        foreach (PartClass PC in BC.Stiffs)
                        {
                            pointList = new PointList();
                            pointList.Add(RdPoint);
                            pointList.Add(PC.Points.P1);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                            if (xDim != null)
                            {
                                PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                                BC.PC.DistTop += BC.PC.DistInc;
                            }
                        }
                    }
                }

                // Dim No 2.1
                if (DN.DimIDNo2Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(RdPoint);
                    pointList.Add(BC.TopGP.LB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }

                // Dim No 2.3
                if (DN.DimIDNo2Dot3)
                {
                    pointList = new PointList();
                    pointList.Add(RdPoint);
                    pointList.Add(BC.TopGP.LB.IntPointB);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                // Dim No 2.5
                if (DN.DimIDNo2Dot5)
                {
                    pointList = new PointList();
                    pointList.Add(RdPoint);
                    pointList.Add(Com.MinP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                // Dim No 2.2
                if (DN.DimIDNo2Dot2)
                {
                    pointList = new PointList();
                    pointList.Add(RdPoint);
                    pointList.Add(BC.TopGP.LB.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }



                #endregion

                #region Top Straight Dim

                Vect = new Vector(0, 1, 0);
                TempList = BC.TopGP.LB.BoltMP;
                // Dim No 19, 19.1
                if (DN.DimIDNo19 || DN.DimIDNo19Dot1)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo19)
                        pointList.Add(BC.TopGP.LB.IntPoint);

                    pointList.Add(BC.TopGP.LB.IntPointB);

                    if (DN.DimIDNo19Dot1)
                        pointList.Add(BC.TopGP.LB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);


                    pointList = new PointList();
                    if (DN.DimIDNo19)
                        pointList.Add(BC.TopGP.RB.IntPoint);

                    pointList.Add(BC.TopGP.RB.IntPointB);

                    if (DN.DimIDNo19Dot1)
                        pointList.Add(BC.TopGP.RB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);

                }

                // Dim No 7
                if (DN.DimIDNo7)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P6);
                    pointList.Add(BC.TopGP.LB.IntPoint);
                    pointList.Add(BC.TopGP.LB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);

                }

                // Dim No 8
                if (DN.DimIDNo8)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P6);
                    pointList.Add(BC.TopGP.LB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);

                }

                // Dim No 12
                if (DN.DimIDNo12)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P6);
                    pointList.Add(BC.TopGP.Points.P5);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);

                }


                // Dim No 11
                if (DN.DimIDNo11)
                {
                    if (Ids.Count > 0)
                        BC.PC.DistTop += BC.PC.DistInc;

                    pointList = new PointList();
                    pointList.Add(new Point(BC.Points.P1.X, BC.Points.CentP.Y));
                    pointList.Add(BC.TopGP.LB.RefPBrace);
                    pointList.Add(new Point(BC.Points.P4.X, BC.Points.CentP.Y));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);
                }

                #endregion

                //  Com.DrawLineDotted(CView, BC.TopGP.LB.IntPoint, BC.TopGP.LB.RefPBrace);
                //Dim Code 10 // Angle Dimension
                if (DN.DimIDNo10)
                    Com.InsertAngleDim(CView, BC.TopGP.LB.RefPBrace, BC.TopGP.LB.IntPoint, "Top", 70);

            }
        }

        private void ApplyRightTopG()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            TSD.PointList TempList = new PointList();

            if (BC.TopGP?.RB != null)
            {

                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;

                TempList = Com.GetBoltPoints(BC.TopGP.RB.BoltM);
                TSG.Line YLine = new TSG.Line(BC.TopGP.Points.P6, BC.TopGP.Points.P1);
                TSG.Line XLine = new TSG.Line(BC.TopGP.RB.IntPoint, BC.TopGP.RB.RefPBrace);
                Vector LeftVect = BC.TopGP.RB.BoltM.GetCoordinateSystem().AxisY;

                if (LeftVect.X > 0)
                    LeftVect = dc.ChangeVector(LeftVect);

                Vector RightVect = BC.TopGP.RB.BoltM.GetCoordinateSystem().AxisY;
                if (RightVect.X < 0)
                    RightVect = dc.ChangeVector(RightVect);

                Vector TopVect = BC.TopGP.RB.BoltM.GetCoordinateSystem().AxisX;
                if (TopVect.Y < 0)
                    TopVect = dc.ChangeVector(TopVect);

                Vector BottVect = BC.TopGP.RB.BoltM.GetCoordinateSystem().AxisX;
                if (BottVect.Y > 0)
                    BottVect = dc.ChangeVector(BottVect);


                #region Diagonal Right
                BC.PC.DistRight = (BC.PC.DistInc);
                TempList = dc.ChangePints(BC.TopGP.RB.BoltMP, CView, RightVect);

                // Dim No 6, 6.1
                if (DN.DimIDNo6 || DN.DimIDNo6Dot1)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo4)// Dim No 6
                        pointList.Add(Com.MinP(TempList, "Y"));

                    pointList.Add(BC.TopGP.RB.IntPointB);
                    if (DN.DimIDNo6Dot1)// Dim No 6.1
                        pointList.Add(BC.TopGP.RB.RefPBrace);

                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistInc, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }

                }

                // Dim No 4
                if (DN.DimIDNo4)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "Y"));
                    pointList.Add(BC.TopGP.RB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistRight);
                }

                BC.PC.DistRight = (BC.PC.DistInc);

                // Dim No 5.1 , 5
                if (DN.DimIDNo5Dot1 || DN.DimIDNo5)
                {

                    pointList = new PointList();
                    if (DN.DimIDNo5Dot1)
                    {
                        pointList.Add(Com.MaxP(TempList, "Y"));
                        pointList.Add(BC.TopGP.Points.P5);
                    }
                    if (DN.DimIDNo5)
                        pointList.AddRange(TempList);

                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistRight);
                }



                if (DN.DimIDNo5Dot1 || DN.DimIDNo5)
                    BC.PC.DistRight += BC.PC.DistInc;


                // Dim No 5.2
                if (DN.DimIDNo5Dot2)
                {
                    if (TempList.Count > 2)
                    {
                        pointList = new PointList();
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                        {
                            PL.DimPlacingDiag(xDim, XLine, BC.PC.DistRight);
                            Com.GroupDim(xDim);
                        }
                    }
                }

                #endregion

                #region Straight Right

                double RightX = BC.TopGP.Points.P3.X;
                if (BC.BottGP != null && BC.BottGP.Points.P3.X > RightX)
                    RightX = BC.BottGP.Points.P3.X;

                Point CentLP = new Point(BC.TopGP.Points.P3.X, BC.Points.CentP.Y);
                Vect = new Vector(1, 0, 0);
                BC.PC.DistRight = (BC.PC.DistInc * 2);
                TempList = BC.TopGP.RB.BoltMP;

                // Dim No 9, 9.3
                if (DN.DimIDNo3Dot2 || DN.DimIDNo3Dot1)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo3Dot2)
                        pointList.AddRange(TempList);


                    if (DN.DimIDNo3Dot1)
                    {
                        pointList.Add(Com.MinP(TempList, "Y"));
                        pointList.Add(BC.TopGP.Points.P3);
                    }
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, RightX, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }

                }


                // Dim No 3.3, 3.4
                if (DN.DimIDNo3Dot3 || DN.DimIDNo3Dot4)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo3Dot3)
                        pointList.Add(Com.MaxP(TempList, "Y"));

                    pointList.Add(BC.TopGP.Points.P3);

                    if (DN.DimIDNo3Dot4)
                        pointList.Add(CentLP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, RightX, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }

                    if (BC.BottGP != null)
                    {
                        pointList = new PointList();
                        if (DN.DimIDNo3Dot3)
                            pointList.Add(Com.MinP(BC.BottGP.RB.BoltMP, "Y"));

                        pointList.Add(BC.BottGP.Points.P3);

                        if (DN.DimIDNo3Dot4)
                            pointList.Add(CentLP);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceRightP(xDim, RightX, BC.PC.DistRight);
                            BC.PC.DistRight += BC.PC.DistInc;
                        }
                    }
                }

                // Dim No 3
                if (DN.DimIDNo3)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    pointList.Add(CentLP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, RightX, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }

                }

                #endregion

                #region RD Dim
                //RD Dim

                Point RdPoint = new Point(BC.Points.P1.X, BC.Points.CentP.Y);
                Vect = new Vector(0, 1, 0);
                TempList = BC.TopGP.RB.BoltMP;
                BC.PC.DistTop = (BC.PC.DistInc);
                // Dim No 9.1
                if (DN.DimIDNo9Dot1)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                // Dim No 9
                if (DN.DimIDNo9)
                {
                    if (TempList.Count > 2)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MaxP(TempList, "Y"));
                        pointList.Add(Com.MinP(TempList, "Y"));
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                            BC.PC.DistTop += BC.PC.DistInc;
                        }
                    }

                }

                BC.PC.DistTop += BC.PC.DistInc;

                // Dim No 2.1
                if (DN.DimIDNo2Dot1 && !dc.IsEqualPoints(BC.TopGP.RB.RefPBrace, BC.TopGP.LB.RefPBrace))
                {
                    pointList = new PointList();
                    pointList.Add(RdPoint);
                    pointList.Add(BC.TopGP.RB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        //BC.PC.DistTop += BC.PC.DistInc;
                    }
                }


                // Dim No 2
                if (DN.DimIDNo2)
                {
                    pointList = new PointList();
                    pointList.Add(RdPoint);
                    pointList.Add(BC.TopGP.RB.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                // Dim No 2.6
                if (DN.DimIDNo2Dot6)
                {
                    pointList = new PointList();
                    pointList.Add(RdPoint);
                    pointList.Add(Com.MinP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }



                // Dim No 2.4
                if (DN.DimIDNo2Dot4)
                {
                    pointList = new PointList();
                    pointList.Add(RdPoint);
                    pointList.Add(BC.TopGP.RB.IntPointB);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                BC.PC.DistTop += BC.PC.DistInc;
                #endregion

                #region Top Straight Dim

                Vect = new Vector(0, 1, 0);
                TempList = BC.TopGP.RB.BoltMP;

                BC.PC.DistTop += (BC.PC.DistInc * 2);
                // Dim No 7
                if (DN.DimIDNo7)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P5);
                    pointList.Add(BC.TopGP.RB.IntPoint);
                    pointList.Add(BC.TopGP.RB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);

                }

                // Dim No 8
                if (DN.DimIDNo8)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P5);
                    pointList.Add(BC.TopGP.RB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);

                }

                #endregion

                // Com.DrawLineDotted(CView, BC.TopGP.RB.IntPoint, BC.TopGP.RB.RefPBrace);
                //Dim Code 10 // Angle Dimension
                if (DN.DimIDNo10)
                    Com.InsertAngleDim(CView, BC.TopGP.RB.RefPBrace, BC.TopGP.RB.IntPoint, "Top", 70);

            }
        }

        private void ApplyLeftBottG()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, -1, 0);
            TSD.PointList TempList = new PointList();

            if (BC.BottGP?.LB != null)
            {

                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;

                TempList = Com.GetBoltPoints(BC.BottGP.LB.BoltM);
                TSG.Line YLine = new TSG.Line(BC.BottGP.Points.P6, BC.BottGP.Points.P1);
                TSG.Line XLine = new TSG.Line(BC.BottGP.LB.IntPoint, BC.BottGP.LB.RefPBrace);

                Point IntP = Com.GetIntersectionPoint(BC.BottGP.Points.P6, BC.BottGP.Points.P1, BC.BottGP.LB.IntPoint, BC.BottGP.LB.RefPBrace);

                Vector LeftVect = XLine.Direction.Cross(new Vector(0, 0, -1));

                if (LeftVect.X > 0)
                    LeftVect = dc.ChangeVector(LeftVect);

                Vector RightVect = BC.BottGP.LB.BoltM.GetCoordinateSystem().AxisY;
                if (RightVect.X < 0)
                    RightVect = dc.ChangeVector(RightVect);

                Vector TopVect = BC.BottGP.LB.BoltM.GetCoordinateSystem().AxisX;
                if (TopVect.Y < 0)
                    TopVect = dc.ChangeVector(TopVect);

                Vector BottVect = BC.BottGP.LB.BoltM.GetCoordinateSystem().AxisX;
                if (BottVect.Y > 0)
                    BottVect = dc.ChangeVector(BottVect);



                #region Diagonal Left
                BC.PC.DistLeft = (BC.PC.DistInc);
                TempList = dc.ChangePints(BC.BottGP.LB.BoltMP, CView, LeftVect);

                // Dim No 6, 6.1
                if (DN.DimIDNo6 || DN.DimIDNo6Dot1)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo4)// Dim No 6
                        pointList.Add(Com.MaxP(TempList, "Y"));

                    pointList.Add(BC.BottGP.LB.IntPointB);
                    if (DN.DimIDNo6Dot1)// Dim No 6.1
                        pointList.Add(BC.BottGP.LB.RefPBrace);

                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistInc, StAtrr);
                    if (xDim != null)
                    {
                        // PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);
                        BC.PC.DistLeft += (BC.PC.DistInc);
                    }
                }

                // Dim No 4
                if (DN.DimIDNo4)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    pointList.Add(BC.BottGP.LB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    //if (xDim != null)
                    //    PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);
                }

                BC.PC.DistLeft = (BC.PC.DistInc);

                // Dim No 5.1 , 5
                if (DN.DimIDNo5Dot1 || DN.DimIDNo5)
                {

                    pointList = new PointList();
                    if (DN.DimIDNo5Dot1)
                    {
                        pointList.Add(Com.MinP(TempList, "Y"));
                        pointList.Add(IntP);
                    }
                    if (DN.DimIDNo5)
                        pointList.AddRange(TempList);

                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);
                }



                if (DN.DimIDNo5Dot1 || DN.DimIDNo5)
                    BC.PC.DistLeft += BC.PC.DistInc;

                // Dim No 5.2
                if (DN.DimIDNo5Dot2)
                {
                    if (TempList.Count > 2)
                    {
                        pointList = new PointList();
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                        {
                            PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);
                            Com.GroupDim(xDim);
                        }
                    }
                }

                #endregion

                #region Straight Left

                double LeftX = BC.BottGP.Points.P2.X;
                if (BC.TopGP != null && BC.TopGP.Points.P2.X < LeftX)
                    LeftX = BC.TopGP.Points.P2.X;

                Point CentLP = new Point(BC.BottGP.Points.P2.X, BC.Points.CentP.Y);
                Vect = new Vector(-1, 0, 0);
                BC.PC.DistLeft = (BC.PC.DistInc * 2);
                TempList = BC.BottGP.LB.BoltMP;

                // Dim No 9, 9.3
                if (DN.DimIDNo3Dot2 || DN.DimIDNo3Dot1)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo3Dot2)
                        pointList.AddRange(TempList);


                    if (DN.DimIDNo3Dot1)
                    {
                        pointList.Add(Com.MaxP(TempList, "Y"));
                        pointList.Add(BC.BottGP.Points.P2);
                    }
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, LeftX, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }

                }


                // Dim No 3.3, 3.4
                if ((DN.DimIDNo3Dot3 || DN.DimIDNo3Dot4) && BC.TopGP == null)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo3Dot3)
                        pointList.Add(Com.MinP(BC.BottGP.LB.BoltMP, "Y"));

                    pointList.Add(BC.BottGP.Points.P2);

                    if (DN.DimIDNo3Dot4)
                        pointList.Add(CentLP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, LeftX, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }
                }
                else if (DN.DimIDNo3Dot3 || DN.DimIDNo3Dot4)
                    BC.PC.DistLeft += (BC.PC.DistInc * 2);

                // Dim No 3
                if (DN.DimIDNo3)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "Y"));
                    pointList.Add(CentLP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, LeftX, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }

                }

                #endregion

                #region RD Dim
                //RD Dim
                Point RdPoint = new Point(BC.Points.P1.X, BC.Points.CentP.Y);
                BC.PC.DistBot = (BC.PC.DistInc * 2);
                Vect = new Vector(0, -1, 0);
                TempList = BC.BottGP.LB.BoltMP;

                // Dim No 9.1
                if (DN.DimIDNo9Dot1)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                // Dim No 9
                if (DN.DimIDNo9)
                {
                    if (TempList.Count > 2)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MaxP(TempList, "Y"));
                        pointList.Add(Com.MinP(TempList, "Y"));
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                            BC.PC.DistBot += BC.PC.DistInc;
                        }
                    }

                }


                // Dim No 2.7, 2.8
                if ((DN.DimIDNo2Dot7 || DN.DimIDNo2Dot8) && BC.TopGP == null)
                {
                    if (BC.Stiffs != null && BC.Stiffs.Count > 0)
                    {
                        BC.PC.DistTop += BC.PC.DistInc;
                        Vect = new Vector(0, 1, 0);
                        foreach (PartClass PC in BC.Stiffs)
                        {
                            pointList = new PointList();
                            pointList.Add(RdPoint);
                            pointList.Add(PC.Points.P1);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                            if (xDim != null)
                            {
                                PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                                BC.PC.DistTop += BC.PC.DistInc;
                            }
                        }

                        Vect = new Vector(0, -1, 0);
                    }
                }


                // Dim No 2.1
                if (DN.DimIDNo2Dot1)
                {
                    if (BC.TopGP == null || (BC.TopGP != null && !dc.IsEqualPoints(BC.TopGP.LB.RefPBrace, BC.BottGP.LB.RefPBrace)))
                    {
                        pointList = new PointList();
                        pointList.Add(RdPoint);
                        pointList.Add(BC.BottGP.LB.RefPBrace);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                            BC.PC.DistBot += BC.PC.DistInc;
                        }
                    }

                }

                // Dim No 2.3
                if (DN.DimIDNo2Dot3)
                {
                    pointList = new PointList();
                    pointList.Add(RdPoint);
                    pointList.Add(BC.BottGP.LB.IntPointB);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                // Dim No 2.5
                if (DN.DimIDNo2Dot5)
                {
                    pointList = new PointList();
                    pointList.Add(RdPoint);
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                // Dim No 2.2
                if (DN.DimIDNo2Dot2)
                {
                    pointList = new PointList();
                    pointList.Add(RdPoint);
                    pointList.Add(BC.BottGP.LB.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                #endregion

                #region Bottom Straight Dim

                Vect = new Vector(0, -1, 0);
                TempList = BC.BottGP.LB.BoltMP;
                // Dim No 19, 19.1
                if (DN.DimIDNo19 || DN.DimIDNo19Dot1)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo19)
                        pointList.Add(BC.BottGP.LB.IntPoint);

                    pointList.Add(BC.BottGP.LB.IntPointB);

                    if (DN.DimIDNo19Dot1)
                        pointList.Add(BC.BottGP.LB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);


                    pointList = new PointList();
                    if (DN.DimIDNo19)
                        pointList.Add(BC.BottGP.RB.IntPoint);

                    pointList.Add(BC.BottGP.RB.IntPointB);

                    if (DN.DimIDNo19Dot1)
                        pointList.Add(BC.BottGP.RB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);

                }

                // Dim No 7
                if (DN.DimIDNo7)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P6);
                    pointList.Add(BC.BottGP.LB.IntPoint);
                    pointList.Add(BC.BottGP.LB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);

                }

                // Dim No 8
                if (DN.DimIDNo8)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P6);
                    pointList.Add(BC.BottGP.LB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);

                }

                // Dim No 12
                if (DN.DimIDNo12)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P6);
                    pointList.Add(BC.BottGP.Points.P5);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);

                }

                // Dim No 11
                if (DN.DimIDNo11 && (BC.TopGP == null || (!dc.IsEqualPoints(BC.TopGP.LB.RefPBrace, BC.BottGP.LB.RefPBrace))))
                {
                    if (Ids.Count > 0)
                        BC.PC.DistBot += BC.PC.DistInc;

                    pointList = new PointList();
                    pointList.Add(new Point(BC.Points.P1.X, BC.Points.CentP.Y));
                    pointList.Add(BC.BottGP.LB.RefPBrace);
                    pointList.Add(new Point(BC.Points.P4.X, BC.Points.CentP.Y));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);

                }

                #endregion

                // Com.DrawLineDotted(CView, BC.BottGP.LB.IntPoint, BC.BottGP.LB.RefPBrace);
                //Dim Code 10 // Angle Dimension
                if (DN.DimIDNo10)
                    Com.InsertAngleDim(CView, BC.BottGP.LB.RefPBrace, BC.BottGP.LB.IntPoint, "Bottom", 70);

            }
        }

        private void ApplyRightBottG()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            TSD.PointList TempList = new PointList();

            if (BC.BottGP?.RB != null)
            {

                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;

                TempList = Com.GetBoltPoints(BC.BottGP.RB.BoltM);
                TSG.Line YLine = new TSG.Line(BC.BottGP.Points.P5, BC.BottGP.Points.P4);
                TSG.Line XLine = new TSG.Line(BC.BottGP.RB.IntPoint, BC.BottGP.RB.RefPBrace);
                Point IntP = Com.GetIntersectionPoint(BC.BottGP.Points.P5, BC.BottGP.Points.P4, BC.BottGP.RB.IntPoint, BC.BottGP.RB.RefPBrace);
                //TSG.Line XLine = new TSG.Line(Com.MaxP(TempList, "X"), Com.MaxP(TempList, "Y"));
                Vector LeftVect = XLine.Direction.Cross(new Vector(0, 0, -1));

                if (LeftVect.X > 0)
                    LeftVect = dc.ChangeVector(LeftVect);

                Vector RightVect = BC.BottGP.RB.BoltM.GetCoordinateSystem().AxisY;
                if (RightVect.X < 0)
                    RightVect = dc.ChangeVector(RightVect);

                Vector TopVect = BC.BottGP.RB.BoltM.GetCoordinateSystem().AxisX;
                if (TopVect.Y < 0)
                    TopVect = dc.ChangeVector(TopVect);

                Vector BottVect = BC.BottGP.RB.BoltM.GetCoordinateSystem().AxisX;
                if (BottVect.Y > 0)
                    BottVect = dc.ChangeVector(BottVect);

                #region Diagonal Left
                BC.PC.DistLeft = (BC.PC.DistInc);

                TempList = dc.ChangePints(BC.BottGP.RB.BoltMP, CView, LeftVect);

                // Dim No 6, 6.1
                if (DN.DimIDNo6 || DN.DimIDNo6Dot1)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo4)// Dim No 6
                        pointList.Add(Com.MaxP(TempList, "Y"));

                    pointList.Add(BC.BottGP.RB.IntPointB);
                    if (DN.DimIDNo6Dot1)// Dim No 6.1
                        pointList.Add(BC.BottGP.RB.RefPBrace);

                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        //PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);
                        BC.PC.DistLeft += (BC.PC.DistInc);
                    }
                }

                // Dim No 4
                if (DN.DimIDNo4)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    pointList.Add(BC.BottGP.RB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);
                }

                BC.PC.DistLeft = (BC.PC.DistInc);

                // Dim No 5.1 , 5, 4
                if (DN.DimIDNo5Dot1 || DN.DimIDNo5)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo5Dot1)
                    {
                        pointList.Add(Com.MinP(TempList, "Y"));
                        pointList.Add(IntP);
                    }

                    if (DN.DimIDNo5)
                        pointList.AddRange(TempList);

                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);
                }

                if (DN.DimIDNo5Dot1 || DN.DimIDNo5 || DN.DimIDNo4)
                    BC.PC.DistLeft += (BC.PC.DistInc);

                // Dim No 5.2
                if (DN.DimIDNo5Dot2)
                {
                    if (TempList.Count > 2)
                    {
                        pointList = new PointList();
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                        {
                            PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);
                            Com.GroupDim(xDim);
                        }
                    }
                }

                #endregion

                #region Straight Right

                double RightX = BC.BottGP.Points.P3.X;
                if (BC.TopGP != null && BC.TopGP.Points.P3.X > RightX)
                    RightX = BC.TopGP.Points.P3.X;

                Point CentLP = new Point(BC.BottGP.Points.P3.X, BC.Points.CentP.Y);
                Vect = new Vector(1, 0, 0);
                BC.PC.DistRight = (BC.PC.DistInc * 2);
                TempList = BC.BottGP.RB.BoltMP;

                // Dim No 9, 9.3
                if (DN.DimIDNo3Dot2 || DN.DimIDNo3Dot1)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo3Dot2)
                        pointList.AddRange(TempList);


                    if (DN.DimIDNo3Dot1)
                    {
                        pointList.Add(Com.MaxP(TempList, "Y"));
                        pointList.Add(BC.BottGP.Points.P3);
                    }
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, RightX, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }

                }


                // Dim No 3.3, 3.4
                if ((DN.DimIDNo3Dot3 || DN.DimIDNo3Dot4) && BC.TopGP == null)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo3Dot3)
                        pointList.Add(Com.MinP(TempList, "Y"));

                    pointList.Add(BC.BottGP.Points.P3);

                    if (DN.DimIDNo3Dot4)
                        pointList.Add(CentLP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, RightX, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }

                }
                else if (DN.DimIDNo3Dot3 || DN.DimIDNo3Dot4)
                    BC.PC.DistRight += (BC.PC.DistInc * 2);

                // Dim No 3
                if (DN.DimIDNo3)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "Y"));
                    pointList.Add(CentLP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, RightX, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }

                }

                #endregion

                #region RD Dim
                //RD Dim
                Point RdPoint = new Point(BC.Points.P1.X, BC.Points.CentP.Y);
                Vect = new Vector(0, -1, 0);
                TempList = BC.BottGP.RB.BoltMP;
                BC.PC.DistBot = (BC.PC.DistInc * 2);
                // Dim No 9.1
                if (DN.DimIDNo9Dot1)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                // Dim No 9
                if (DN.DimIDNo9)
                {
                    if (TempList.Count > 2)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MaxP(TempList, "Y"));
                        pointList.Add(Com.MinP(TempList, "Y"));
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                            BC.PC.DistBot += BC.PC.DistInc;
                        }
                    }

                }

                if (DN.DimIDNo2Dot1 && (BC.TopGP == null || (BC.TopGP != null && !dc.IsEqualPoints(BC.TopGP.LB.RefPBrace, BC.BottGP.LB.RefPBrace))))
                    BC.PC.DistBot += BC.PC.DistInc;

                // Dim No 2.1
                if (DN.DimIDNo2Dot1)
                {
                    if (BC.TopGP == null || (BC.TopGP != null && !dc.IsEqualPoints(BC.TopGP.LB.RefPBrace, BC.BottGP.LB.RefPBrace)))
                    {
                        if (!dc.IsEqualPoints(BC.BottGP.LB.RefPBrace, BC.BottGP.RB.RefPBrace))
                        {
                            pointList = new PointList();
                            pointList.Add(RdPoint);
                            pointList.Add(BC.BottGP.RB.RefPBrace);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                            if (xDim != null)
                            {
                                PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                                // BC.PC.DistBot += BC.PC.DistInc;
                            }
                        }
                    }

                }

                // Dim No 2
                if (DN.DimIDNo2)
                {
                    pointList = new PointList();
                    pointList.Add(RdPoint);
                    pointList.Add(BC.BottGP.RB.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                // Dim No 2.6
                if (DN.DimIDNo2Dot6)
                {
                    pointList = new PointList();
                    pointList.Add(RdPoint);
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }



                // Dim No 2.4
                if (DN.DimIDNo2Dot4)
                {
                    pointList = new PointList();
                    pointList.Add(RdPoint);
                    pointList.Add(BC.BottGP.RB.IntPointB);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                #endregion

                #region Bottom Straight Dim

                Vect = new Vector(0, -1, 0);
                TempList = BC.BottGP.RB.BoltMP;
                BC.PC.DistBot += (BC.PC.DistInc * 2);

                // Dim No 7
                if (DN.DimIDNo7)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P5);
                    pointList.Add(BC.BottGP.RB.IntPoint);
                    pointList.Add(BC.BottGP.RB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);

                }

                // Dim No 8
                if (DN.DimIDNo8)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P5);
                    pointList.Add(BC.BottGP.RB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);

                }



                #endregion

                // Com.DrawLineDotted(CView, BC.BottGP.RB.IntPoint, BC.BottGP.RB.RefPBrace);
                //Dim Code 10 // Angle Dimension
                if (DN.DimIDNo10)
                    Com.InsertAngleDim(CView, BC.BottGP.RB.RefPBrace, BC.BottGP.RB.IntPoint, "Bottom", 70);

            }
        }

        private void ApplyRadiusDim()
        {
            if (DN.DimIDNo16)
            {
                if (BC.ContPT != null)
                {
                    if (BC.ContPT.P1 != null)
                    {
                        PointList Plist = dc.GetRadialChampherPointList(BC.ContPT.P1, BC.TopGP.GussetPlate);
                        RadiusDimension Rd = new RadiusDimension(CView, Plist[2], Plist[1], Plist[0], 5);
                        Rd.Attributes.Placing.Placing = DimensionSetBaseAttributes.Placings.Fixed;
                        Rd.Insert();


                    }

                    if (BC.ContPT.P2 != null)
                    {
                        PointList Plist = dc.GetRadialChampherPointList(BC.ContPT.P2, BC.TopGP.GussetPlate);
                        RadiusDimension Rd = new RadiusDimension(CView, Plist[0], Plist[1], Plist[2], 5);
                        Rd.Attributes.Placing.Placing = DimensionSetBaseAttributes.Placings.Fixed;
                        Rd.Insert();


                    }
                }

                if (BC.ContPB != null)
                {
                    if (BC.ContPB.P1 != null)
                    {
                        PointList Plist = dc.GetRadialChampherPointList(BC.ContPB.P1, BC.BottGP.GussetPlate);
                        RadiusDimension Rd = new RadiusDimension(CView, Plist[0], Plist[1], Plist[2], 5);
                        Rd.Attributes.Placing.Placing = DimensionSetBaseAttributes.Placings.Fixed;
                        Rd.Insert();
                    }

                    if (BC.ContPB.P2 != null)
                    {
                        PointList Plist = dc.GetRadialChampherPointList(BC.ContPB.P2, BC.BottGP.GussetPlate);
                        RadiusDimension Rd = new RadiusDimension(CView, Plist[2], Plist[1], Plist[0], 5);
                        Rd.Attributes.Placing.Placing = DimensionSetBaseAttributes.Placings.Fixed;
                        Rd.Insert();


                    }
                }
            }


        }

        #endregion

        // Apply Dim in Front View
        private void ApplyTBV()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            TSD.PointList TempList = new PointList();

            if (BC.GPTV != null)
            {
                double FlThick = Com.GetPartFlangeThickness(MainBeam) + 20;
                if (BC.GPTV.GussetList != null && (DN.DimIDNo1 || DN.DimIDNo1Dot1))
                {
                    int i = 0;

                    foreach (PartClass PC in BC.GPTV.GussetList)
                    {
                        PartPoints Points = PC.Points;
                        if (i % 2 == 0)
                        {
                            Vect = new Vector(1, 0, 0);
                            pointList = new PointList();
                            if (DN.DimIDNo1)
                                pointList.Add(new Point(Points.P4.X, BC.Points.P4.Y));

                            pointList.Add(Points.P4);

                            if (DN.DimIDNo1Dot1)
                                pointList.Add(Points.P3);


                        }
                        else
                        {
                            Vect = new Vector(-1, 0, 0);
                            pointList = new PointList();
                            if (DN.DimIDNo1)
                                pointList.Add(new Point(Points.P1.X, BC.Points.P1.Y));

                            pointList.Add(Points.P1);

                            if (DN.DimIDNo1Dot1)
                                pointList.Add(Points.P2);
                        }

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);

                        i++;

                        Ids.Add(PC.part.Identifier.ID);

                    }
                }

                if (BC.GPTV.StiffList != null)
                {
                    BC.PC.DistTop = (BC.PC.DistInc * 2);

                    Point RdPoint = new Point(BC.Points.P1.X, BC.Points.CentP.Y);

                    foreach (PartClass PC in BC.GPTV.StiffList)
                    {
                        PartPoints Points = PC.Points;

                        double MaxY = BC.Points.P1.Y - FlThick;

                        double MinY = BC.Points.P2.Y + FlThick;

                        // Dim no 15, 15.1
                        if (dc.IsGreater(Points.P1.Y, MaxY) && dc.IsGreater(Points.P2.Y, MinY) && (DN.DimIDNo15 || DN.DimIDNo15Dot1))
                        {
                            Vect = new Vector(0, 1, 0);
                            pointList = new PointList();
                            pointList.Add(RdPoint);
                            pointList.Add(Points.P1);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                            if (xDim != null)
                                PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        }

                        else if (dc.IsLess(Points.P2.Y, MinY) && dc.IsLess(Points.P1.Y, MaxY) && (DN.DimIDNo15Dot3 || DN.DimIDNo15Dot2))   // Dim no 15.3, 15.2
                        {
                            Vect = new Vector(0, -1, 0);
                            pointList = new PointList();
                            pointList.Add(RdPoint);
                            pointList.Add(Points.P2);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                            if (xDim != null)
                                PL.DistPlaceTopP(xDim, BC.PC.BottomY, BC.PC.DistTop);
                        }
                        else if (DN.DimIDNo16 || DN.DimIDNo16Dot1) // Dim no 16, 16.1
                        {
                            Vect = new Vector(0, 1, 0);
                            pointList = new PointList();
                            pointList.Add(RdPoint);
                            pointList.Add(Points.P1);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                            if (xDim != null)
                                PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        }

                    }
                }


            }

        }

        private void AppySectionDim()
        {


            StraightDimensionSet xDim = null;
            PointList pointList = new PointList();
            Vector Vect = new Vector(0, 1, 0);

            bool IsLeftDim = false;

            bool IsRightDim = false;
            if (BC.GPS != null)
            {
                if (BC.GPS.StiffTL == null)
                {
                    // Dim No 18, 18.1
                    if (DN.DimIDNo18 || DN.DimIDNo18Dot1)
                    {
                        if (BC.GPS.StiffL != null)
                        {
                            pointList = new PointList();

                            if (DN.DimIDNo18) // Dim No 18
                                pointList.Add(BC.GPS.StiffL.Points.P1);

                            pointList.Add(BC.GPS.StiffL.Points.P4);

                            if (DN.DimIDNo18Dot1) // Dim No 18.1
                                pointList.Add(MainBeam.StartPoint);

                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                            if (xDim != null)
                                PL.DimPlaceByTopY(xDim, BC.PC);
                        }


                        if (BC.GPS.StiffR != null)
                        {
                            pointList = new PointList();

                            if (DN.DimIDNo18) // Dim No 18
                                pointList.Add(BC.GPS.StiffR.Points.P4);

                            pointList.Add(BC.GPS.StiffR.Points.P1);

                            if (DN.DimIDNo18Dot1) // Dim No 18.1
                                pointList.Add(MainBeam.StartPoint);

                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                            if (xDim != null)
                                PL.DimPlaceByTopY(xDim, BC.PC);
                        }
                    }

                    if (BC.GPS.StiffL != null)
                    {
                        Vect = new Vector(-1, 0, 0);
                        // Dim No 17.1
                        if (DN.DimIDNo17Dot1)
                        {
                            pointList = new PointList();
                            pointList.Add(BC.GPS.StiffL.Points.P1);
                            pointList.Add(BC.Points.P1);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                            if (xDim != null)
                                PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);


                            pointList = new PointList();
                            pointList.Add(BC.GPS.StiffL.Points.P2);
                            pointList.Add(BC.Points.P2);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                            if (xDim != null)
                                PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                        }

                        // Dim No 17
                        if (DN.DimIDNo17)
                        {
                            pointList = new PointList();
                            pointList.Add(BC.GPS.StiffL.Points.P1);
                            pointList.Add(BC.GPS.StiffL.Points.P2);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                            if (xDim != null)
                                PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                        }

                        if (DN.DimIDNo17Dot1 || DN.DimIDNo17)
                            BC.PC.DistLeft += BC.PC.DistInc;

                        Ids.Add(BC.GPS.StiffL.part.Identifier.ID);
                    }

                    if (BC.GPS.StiffR != null)
                    {
                        Vect = new Vector(1, 0, 0);
                        // Dim No 17.1
                        if (DN.DimIDNo17Dot1)
                        {
                            pointList = new PointList();
                            pointList.Add(BC.GPS.StiffR.Points.P4);
                            pointList.Add(BC.Points.P4);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                            if (xDim != null)
                                PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);


                            pointList = new PointList();
                            pointList.Add(BC.GPS.StiffR.Points.P3);
                            pointList.Add(BC.Points.P3);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                            if (xDim != null)
                                PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                        }

                        // Dim No 17
                        if (DN.DimIDNo17)
                        {
                            pointList = new PointList();
                            pointList.Add(BC.GPS.StiffR.Points.P4);
                            pointList.Add(BC.GPS.StiffR.Points.P3);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                            if (xDim != null)
                                PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                        }

                        if (DN.DimIDNo17 || DN.DimIDNo17Dot1)
                            BC.PC.DistRight += BC.PC.DistInc;

                        Ids.Add(BC.GPS.StiffR.part.Identifier.ID);
                    }



                }
                else
                {

                    // Dim No 13, 13.1
                    if (DN.DimIDNo13 || DN.DimIDNo13Dot1)
                    {
                        Vect = new Vector(0, 1, 0);
                        if (BC.GPS.StiffTL != null)
                        {
                            pointList = new PointList();

                            if (DN.DimIDNo13) // Dim No 13
                                pointList.Add(BC.GPS.StiffTL.Points.P1);

                            pointList.Add(BC.GPS.StiffTL.Points.P4);

                            if (DN.DimIDNo13Dot1) // Dim No 13.1
                                pointList.Add(MainBeam.StartPoint);

                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                            if (xDim != null)
                                PL.DimPlaceByTopY(xDim, BC.PC);
                        }


                        if (BC.GPS.StiffTR != null)
                        {
                            pointList = new PointList();

                            if (DN.DimIDNo13) // Dim No 13
                                pointList.Add(BC.GPS.StiffTR.Points.P4);

                            pointList.Add(BC.GPS.StiffTR.Points.P1);

                            if (DN.DimIDNo13Dot1) // Dim No 13.1
                                pointList.Add(MainBeam.StartPoint);

                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                            if (xDim != null)
                                PL.DimPlaceByTopY(xDim, BC.PC);
                        }

                        Vect = new Vector(0, -1, 0);
                        if (BC.GPS.StiffL != null)
                        {
                            pointList = new PointList();

                            if (DN.DimIDNo13) // Dim No 13
                                pointList.Add(BC.GPS.StiffL.Points.P2);

                            pointList.Add(BC.GPS.StiffL.Points.P3);

                            if (DN.DimIDNo13Dot1) // Dim No 13.1
                                pointList.Add(MainBeam.StartPoint);

                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                            if (xDim != null)
                                PL.DimPlaceByBottomY(xDim, BC.PC);
                        }


                        if (BC.GPS.StiffR != null)
                        {
                            pointList = new PointList();

                            if (DN.DimIDNo13) // Dim No 13
                                pointList.Add(BC.GPS.StiffR.Points.P3);

                            pointList.Add(BC.GPS.StiffR.Points.P2);

                            if (DN.DimIDNo13Dot1) // Dim No 13.1
                                pointList.Add(MainBeam.StartPoint);

                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                            if (xDim != null)
                                PL.DimPlaceByBottomY(xDim, BC.PC);
                        }

                    }

                    // Dim No 14.2, 14.1
                    if (DN.DimIDNo14Dot1 || DN.DimIDNo14Dot2)
                    {
                        if (BC.GPS.StiffTL != null)
                        {
                            Vect = new Vector(-1, 0, 0);
                            pointList = new PointList();
                            if (DN.DimIDNo14Dot1)
                                pointList.Add(BC.GPS.StiffTL.Points.P1);
                            pointList.Add(BC.Points.P1);
                            if (DN.DimIDNo14Dot2)
                                pointList.Add(BC.GPS.StiffTL.Points.P2);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                            if (xDim != null)
                                PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);

                            IsLeftDim = true;

                        }

                        if (BC.GPS.StiffTR != null)
                        {
                            Vect = new Vector(1, 0, 0);
                            pointList = new PointList();
                            if (DN.DimIDNo14Dot1)
                                pointList.Add(BC.GPS.StiffTR.Points.P4);
                            pointList.Add(BC.Points.P4);
                            if (DN.DimIDNo14Dot2)
                                pointList.Add(BC.GPS.StiffTR.Points.P3);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                            if (xDim != null)
                                PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);

                            IsRightDim = true;
                        }
                    }



                    // Dim No 14.1, 14.3
                    if (BC.GPS.StiffL != null && (DN.DimIDNo14Dot1 || DN.DimIDNo14Dot3))
                    {
                        Vect = new Vector(-1, 0, 0);
                        pointList = new PointList();
                        if (DN.DimIDNo14Dot3)
                            pointList.Add(BC.GPS.StiffL.Points.P1);

                        pointList.Add(BC.GPS.StiffL.Points.P2);

                        if (DN.DimIDNo14Dot1)
                            pointList.Add(BC.Points.P2);

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);

                        IsLeftDim = true;
                    }

                    // Dim No 14.1, 14
                    if (BC.GPS.StiffR != null && (DN.DimIDNo14Dot1 || DN.DimIDNo14))
                    {
                        Vect = new Vector(1, 0, 0);
                        pointList = new PointList();


                        if (DN.DimIDNo14)
                            pointList.Add(BC.GPS.StiffR.Points.P4);

                        pointList.Add(BC.GPS.StiffR.Points.P3);

                        if (DN.DimIDNo14Dot1)
                            pointList.Add(BC.Points.P3);

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);

                        IsRightDim = true;
                    }


                }


                if (IsLeftDim)
                    BC.PC.DistLeft += BC.PC.DistInc;

                if (IsRightDim)
                    BC.PC.DistRight += BC.PC.DistInc;

                // Dim No 20, 20.1
                if (DN.DimIDNo20 || DN.DimIDNo20Dot1)
                {
                    if (BC.GPS.GPR != null)
                    {
                        Vect = new Vector(1, 0, 0);
                        pointList = new PointList();

                        if (DN.DimIDNo20) // Dim No 20
                            pointList.Add(BC.Points.P4);

                        pointList.Add(new Point(BC.Points.P4.X, BC.GPS.GPR.Points.P4.Y));

                        if (DN.DimIDNo20Dot1) // Dim No 20.1
                            pointList.Add(new Point(BC.Points.P4.X, BC.GPS.GPR.Points.P3.Y));

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByRightX(xDim, BC.PC);
                    }


                    if (BC.GPS.GPL != null)
                    {
                        Vect = new Vector(-1, 0, 0);
                        pointList = new PointList();

                        if (DN.DimIDNo20) // Dim No 20
                            pointList.Add(BC.Points.P1);

                        pointList.Add(new Point(BC.Points.P1.X, BC.GPS.GPL.Points.P1.Y));

                        if (DN.DimIDNo20Dot1) // Dim No 20.1
                            pointList.Add(new Point(BC.Points.P1.X, BC.GPS.GPL.Points.P2.Y));

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByLeftX(xDim, BC.PC);
                    }
                }


            }



        }

        private void TestDim()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;

            Vector Vect = new Vector(0, 1, 0);

            TSD.PointList TempList = new PointList();

            if (BC.TopGP?.GussetPlate != null && BC.BottGP?.GussetPlate != null)
            {
                Point WP = BC.BottGP.LB.RefPBrace;
                Point Temp = new Point(WP.X, WP.Y - 100, WP.Z);
                AngleDimension angDimA = new AngleDimension(CView, WP, BC.BottGP.LB.IntPoint, Temp, 100);
                angDimA.Attributes.Placing.Placing = DimensionSetBaseAttributes.Placings.Fixed;
                angDimA.Insert();

                WP = BC.BottGP.RB.RefPBrace;
                Temp = new Point(WP.X, WP.Y - 100, WP.Z);
                angDimA = new AngleDimension(CView, WP, BC.BottGP.RB.IntPoint, Temp, 100);
                angDimA.Attributes.Placing.Placing = DimensionSetBaseAttributes.Placings.Fixed;
                angDimA.Insert();


                WP = BC.TopGP.RB.RefPBrace;
                Temp = new Point(WP.X, WP.Y + 100, WP.Z);
                angDimA = new AngleDimension(CView, WP, BC.TopGP.RB.IntPoint, Temp, 100);
                angDimA.Attributes.Placing.Placing = DimensionSetBaseAttributes.Placings.Fixed;
                angDimA.Insert();


                WP = BC.TopGP.LB.RefPBrace;
                Temp = new Point(WP.X, WP.Y + 100, WP.Z);
                angDimA = new AngleDimension(CView, WP, BC.TopGP.LB.IntPoint, Temp, 100);
                angDimA.Attributes.Placing.Placing = DimensionSetBaseAttributes.Placings.Fixed;
                angDimA.Insert();
            }


        }

        #region Get Data

        private void GetBeamClassClass(TSD.View CView)
        {
            if (ViewName == "Top View" || ViewName == "Bottom View")
            {
                BC = new BeamClass_BG12();
                BC.beam = MainBeam;
                BC.Points = Com.GetPartPoints(BC.beam);
                List<TSM.Part> PartListC = BC.beam.GetAssembly().GetSecondaries().OfType<TSM.Part>().ToList();


                Point CentP = Com.CenterPoint(BC.beam.StartPoint, BC.beam.EndPoint);
                double Lenght = (BC.beam.GetSolid().MaximumPoint.X - BC.beam.GetSolid().MinimumPoint.X) / 10;
                double MinX = BC.beam.GetSolid().MinimumPoint.X + Lenght;
                double MaxX = BC.beam.GetSolid().MaximumPoint.X - Lenght;

                //List<TSM.Part> PartListF = (from p in PartListC where !Com.IsCode(p) select p).ToList();
                List<TSM.Part> PartListF = (from p in PartListC where !Ids.Contains(p.Identifier.ID) select p).ToList();


                ContourPlate TopGP = (from p in PartListF.OfType<ContourPlate>() where IsBG12(p) && (Com.CenterPoint(p).Y > BC.Points.CentP.Y) && !dc.IsPlateSideView(p) orderby Com.CenterPoint(p).X ascending select p).FirstOrDefault();
                ContourPlate BottGP = (from p in PartListF.OfType<ContourPlate>() where IsBG12(p) && (Com.CenterPoint(p).Y < BC.Points.CentP.Y) && !dc.IsPlateSideView(p) orderby Com.CenterPoint(p).X ascending select p).FirstOrDefault();


                if (TopGP != null)
                {
                    BC.TopGP = GetGussetClass(TopGP, "Top");

                }

                if (BottGP != null)
                {
                    BC.BottGP = GetGussetClass(BottGP, "Bottom");

                }


                PartListC.Add(MainBeam);
                TSM.Part LeftPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.X ascending select p).FirstOrDefault();
                TSM.Part RightPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.X descending select p).FirstOrDefault();
                TSM.Part TopPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.Y descending select p).FirstOrDefault();
                TSM.Part BottPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.Y ascending select p).FirstOrDefault();

                BC.PC = new PlacingClass();
                BC.PC.TopY = TopPart.GetSolid().MaximumPoint.Y;
                BC.PC.BottomY = BottPart.GetSolid().MinimumPoint.Y;



                BC.PC.LeftX = MainBeam.StartPoint.X;// Math.Round(CView.RestrictionBox.MinPoint.X);
                BC.PC.RightX = RightPart.GetSolid().MaximumPoint.X;


                double AvScale = 12;
                double AvDistInc = 100;
                double DistPerScale = AvDistInc / AvScale;
                double CScale = CView.Attributes.Scale;
                BC.PC.DistInc = CScale * DistPerScale;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;
            }

            else if (ViewName == "Front View")
            {
                BC = new BeamClass_BG12();
                BC.beam = MainBeam;
                List<TSM.Part> PartListC = BC.beam.GetAssembly().GetSecondaries().OfType<TSM.Part>().ToList();

                BC.Points = Com.GetPartPoints(BC.beam);

                Point CentP = Com.CenterPoint(BC.beam.StartPoint, BC.beam.EndPoint);
                double Lenght = (BC.beam.GetSolid().MaximumPoint.X - BC.beam.GetSolid().MinimumPoint.X) / 10;
                double MinX = BC.beam.GetSolid().MinimumPoint.X + Lenght;
                double MaxX = BC.beam.GetSolid().MaximumPoint.X - Lenght;

                //List<TSM.Part> PartListF = (from p in PartListC where !Com.IsCode(p) select p).ToList();
                List<TSM.Part> PartListF = (from p in PartListC where !Ids.Contains(p.Identifier.ID) select p).ToList();

                GetGussetClassFV(PartListF);


                PartListC.Add(MainBeam);
                TSM.Part LeftPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.X ascending select p).FirstOrDefault();
                TSM.Part RightPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.X descending select p).FirstOrDefault();
                TSM.Part TopPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.Y descending select p).FirstOrDefault();
                TSM.Part BottPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.Y ascending select p).FirstOrDefault();

                BC.PC = new PlacingClass();
                BC.PC.TopY = TopPart.GetSolid().MaximumPoint.Y;
                BC.PC.BottomY = BottPart.GetSolid().MinimumPoint.Y;



                BC.PC.LeftX = MainBeam.StartPoint.X;// Math.Round(CView.RestrictionBox.MinPoint.X);
                BC.PC.RightX = RightPart.GetSolid().MaximumPoint.X;


                double AvScale = 12;
                double AvDistInc = 100;
                double DistPerScale = AvDistInc / AvScale;
                double CScale = CView.Attributes.Scale;
                BC.PC.DistInc = CScale * DistPerScale;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;
            }

            else if (ViewName == "Section View")
            {
                if (CView.Name.Contains("E") || CView.Name.Contains("B"))
                { }

                BC = new BeamClass_BG12();
                BC.beam = MainBeam;
                BC.Points = Com.GetPartPoints(BC.beam);
                List<TSM.Part> PartListC = BC.beam.GetAssembly().GetSecondaries().OfType<TSM.Part>().ToList();
                PartListC = (from p in PartListC where !Ids.Contains(p.Identifier.ID) select p).ToList();
                double MinZ = CView.RestrictionBox.MinPoint.Z;

                double MaxZ = CView.RestrictionBox.MaxPoint.Z + 100;
                // List<TSM.Part> PartList = (from p in PartListC where Com.GetPartProfileType(p) != "L" && p.GetSolid().MaximumPoint.Z > MinZ && p.GetSolid().MaximumPoint.Z < MaxZ select p).ToList();
                List<TSM.Part> PartList = (from p in PartListC where Com.GetPartProfileType(p) != "L" && Com.IsViewObj(p, CView) select p).ToList();

                TSM.Part GPL = (from p in PartList where dc.IsPlateSideViewN(p) && dc.IsHorzObj(p) && Com.CenterPoint(p).X < BC.Points.CentP.X select p).FirstOrDefault();
                TSM.Part GPR = (from p in PartList where dc.IsPlateSideViewN(p) && dc.IsHorzObj(p) && Com.CenterPoint(p).X > BC.Points.CentP.X select p).FirstOrDefault();

                List<TSM.Part> LeftSt = (from p in PartList where !Com.HasBolt(p) && !dc.IsPlateSideViewN(p) && Com.CenterPoint(p).X < MainBeam.StartPoint.X orderby p.GetSolid().MinimumPoint.Y ascending select p).ToList();
                List<TSM.Part> RightSt = (from p in PartList where !Com.HasBolt(p) && !dc.IsPlateSideViewN(p) && Com.CenterPoint(p).X > MainBeam.StartPoint.X orderby p.GetSolid().MinimumPoint.Y ascending select p).ToList();

                if (GPL != null || GPR != null || LeftSt != null || RightSt != null)
                {
                    BC.GPS = new GussetClassS();

                    if (GPL != null)
                    {
                        BC.GPS.GPL = Com.GetPartClass(GPL);
                        Ids.Add(BC.GPS.GPL.part.Identifier.ID);
                    }

                    if (GPR != null)
                    {
                        BC.GPS.GPR = Com.GetPartClass(GPR);
                        Ids.Add(BC.GPS.GPR.part.Identifier.ID);
                    }

                    if (LeftSt != null && LeftSt.Count > 0)
                    {

                        if (LeftSt.Count == 1)
                        {
                            double BH = Com.GetYDist(MainBeam) / 2;
                            double StH = Com.GetYDist(LeftSt[0]);

                            if (StH > BH)
                                BC.GPS.StiffL = Com.GetPartClass(LeftSt[0]);
                            else
                                BC.GPS.StiffTL = Com.GetPartClass(LeftSt[0]);

                            Ids.Add(LeftSt[0].Identifier.ID);
                        }
                        else
                        {
                            BC.GPS.StiffL = Com.GetPartClass(LeftSt[0]);
                            BC.GPS.StiffTL = Com.GetPartClass(LeftSt[1]);

                            Ids.Add(BC.GPS.StiffL.part.Identifier.ID);
                            Ids.Add(BC.GPS.StiffTL.part.Identifier.ID);
                        }
                    }


                    if (RightSt != null && RightSt.Count > 0)
                    {

                        if (RightSt.Count == 1)
                        {
                            double BH = Com.GetYDist(MainBeam) / 2;
                            double StH = Com.GetYDist(RightSt[0]);

                            if (StH > BH)
                                BC.GPS.StiffR = Com.GetPartClass(RightSt[0]);
                            else
                                BC.GPS.StiffTR = Com.GetPartClass(RightSt[0]);

                            Ids.Add(RightSt[0].Identifier.ID);
                        }
                        else
                        {
                            BC.GPS.StiffR = Com.GetPartClass(RightSt[0]);
                            BC.GPS.StiffTR = Com.GetPartClass(RightSt[1]);
                            Ids.Add(BC.GPS.StiffR.part.Identifier.ID);
                            Ids.Add(BC.GPS.StiffTR.part.Identifier.ID);
                        }
                    }


                }

                PartListC.Add(MainBeam);
                TSM.Part LeftPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.X ascending select p).FirstOrDefault();
                TSM.Part RightPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.X descending select p).FirstOrDefault();
                TSM.Part TopPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.Y descending select p).FirstOrDefault();
                TSM.Part BottPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.Y ascending select p).FirstOrDefault();

                BC.PC = new PlacingClass();
                BC.PC.TopY = TopPart.GetSolid().MaximumPoint.Y;
                BC.PC.BottomY = BottPart.GetSolid().MinimumPoint.Y;



                BC.PC.LeftX = MainBeam.StartPoint.X;// Math.Round(CView.RestrictionBox.MinPoint.X);
                BC.PC.RightX = RightPart.GetSolid().MaximumPoint.X;


                double AvScale = 12;
                double AvDistInc = 100;
                double DistPerScale = AvDistInc / AvScale;
                double CScale = CView.Attributes.Scale;
                BC.PC.DistInc = CScale * DistPerScale;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;
            }

        }

        private GussetClassB GetGussetClass(ContourPlate GP, string Position)
        {
            GussetClassB GC = new GussetClassB();
            GC.GussetPlate = GP;
            GC.Points = GetGussetPoints(GP);

            List<BoltGroup> Bolts = Com.EnumtoArray(GP.GetBolts()).OfType<BoltGroup>().ToList();

            BoltGroup MidBoltL = (from b in Bolts where Com.CenterPoint(b).X < GC.Points.CentP.X select b).FirstOrDefault();
            BoltGroup MidBoltR = (from b in Bolts where Com.CenterPoint(b).X > GC.Points.CentP.X select b).FirstOrDefault();

            if (MidBoltL != null)
            {
                BoltGroup MidBolt = MidBoltL;

                if (MidBolt != null)
                {
                    GC.LB = new GussetBrace();
                    GC.LB.BoltM = MidBolt;
                    GC.LB.BoltMP = Com.GetBoltPoints(MidBolt);

                    Beam brace = GetBrace(GC.LB.BoltM, GP);
                    if (brace != null)
                    {
                        GC.LB.Brace = brace;
                        GC.LB.RefPBrace = dc.NearestPoint(GC.LB.Brace.StartPoint, GC.LB.Brace.EndPoint, GC.LB.BoltM.FirstPosition);
                        GC.LB.IntPoint = GetIntSectPoint(GC.LB.BoltM, brace, Position);

                        double WebThickH = Com.GetPartWebThickness(MainBeam) / 2;
                        if (Position == "Top")
                        {
                            TSD.Line line1 = Com.DrawLineDotted1(CView, new Point(BC.Points.P1.X, BC.Points.CentP.Y + WebThickH), new Point(BC.Points.P4.X, BC.Points.CentP.Y + WebThickH));
                            TSD.Line line2 = Com.DrawLineDotted1(CView, GC.LB.RefPBrace, GC.LB.IntPoint);


                            if (GC.LB.RefPBrace != null && GC.LB.IntPoint != null)
                                GC.LB.IntPointB = Com.GetIntersectionPoint(GC.LB.RefPBrace, GC.LB.IntPoint, new Point(BC.Points.P1.X, BC.Points.CentP.Y + WebThickH), new Point(BC.Points.P4.X, BC.Points.CentP.Y + WebThickH));

                            GC.LB.Degree = GetDegree(GC.LB.IntPointB, GC.LB.IntPoint, BC.Points.P1);

                            line1.Delete();
                            line2.Delete();
                        }
                        else
                        {

                            TSD.Line line1 = Com.DrawLineDotted1(CView, new Point(BC.Points.P2.X, BC.Points.CentP.Y - WebThickH), new Point(BC.Points.P3.X, BC.Points.CentP.Y - WebThickH));
                            TSD.Line line2 = Com.DrawLineDotted1(CView, GC.LB.RefPBrace, GC.LB.IntPoint);

                            if (GC.LB.RefPBrace != null && GC.LB.IntPoint != null)
                                GC.LB.IntPointB = Com.GetIntersectionPoint(GC.LB.RefPBrace, GC.LB.IntPoint, new Point(BC.Points.P2.X, BC.Points.CentP.Y - WebThickH), new Point(BC.Points.P3.X, BC.Points.CentP.Y - WebThickH));


                            GC.LB.Degree = GetDegree(GC.LB.IntPointB, GC.LB.IntPoint, BC.Points.P2);

                            line1.Delete();
                            line2.Delete();
                        }



                    }
                }

            }


            if (MidBoltR != null)
            {
                BoltGroup MidBolt = MidBoltR;

                if (MidBolt != null)
                {
                    GC.RB = new GussetBrace();
                    GC.RB.BoltM = MidBolt;
                    GC.RB.BoltMP = Com.GetBoltPoints(MidBolt);
                    Beam brace = GetBrace(GC.RB.BoltM, GP);
                    double WebThickH = Com.GetPartWebThickness(MainBeam) / 2;
                    if (brace != null)
                    {
                        GC.RB.Brace = brace;
                        GC.RB.RefPBrace = dc.NearestPoint(GC.RB.Brace.StartPoint, GC.RB.Brace.EndPoint, MidBoltR.FirstPosition);
                        GC.RB.IntPoint = GetIntSectPoint(GC.RB.BoltM, brace, Position);
                        if (Position == "Top")
                        {
                            TSD.Line line1 = Com.DrawLineDotted1(CView, new Point(BC.Points.P1.X, BC.Points.CentP.Y + WebThickH), new Point(BC.Points.P4.X, BC.Points.CentP.Y + WebThickH));
                            TSD.Line line2 = Com.DrawLineDotted1(CView, GC.RB.RefPBrace, GC.RB.IntPoint);

                            if (GC.RB.RefPBrace != null && GC.RB.IntPoint != null)
                                GC.RB.IntPointB = Com.GetIntersectionPoint(GC.RB.RefPBrace, GC.RB.IntPoint, new Point(BC.Points.P1.X, BC.Points.CentP.Y + WebThickH), new Point(BC.Points.P4.X, BC.Points.CentP.Y + WebThickH));

                            GC.RB.Degree = GetDegree(GC.RB.IntPointB, GC.RB.IntPoint, BC.Points.P4);

                            line1.Delete();
                            line2.Delete();
                        }
                        else
                        {
                            TSD.Line line1 = Com.DrawLineDotted1(CView, new Point(BC.Points.P2.X, BC.Points.CentP.Y - WebThickH), new Point(BC.Points.P3.X, BC.Points.CentP.Y - WebThickH));
                            TSD.Line line2 = Com.DrawLineDotted1(CView, GC.RB.RefPBrace, GC.RB.IntPoint);

                            if (GC.RB.RefPBrace != null && GC.RB.IntPoint != null)
                                GC.RB.IntPointB = Com.GetIntersectionPoint(GC.RB.RefPBrace, GC.RB.IntPoint, new Point(BC.Points.P2.X, BC.Points.CentP.Y - WebThickH), new Point(BC.Points.P3.X, BC.Points.CentP.Y - WebThickH));

                            GC.RB.Degree = GetDegree(GC.RB.IntPointB, GC.RB.IntPoint, BC.Points.P3);

                            line1.Delete();
                            line2.Delete();
                        }
                    }
                }

            }


            if (BC.Stiffs == null)
            {
                List<TSM.Part> PartListC = BC.beam.GetAssembly().GetSecondaries().OfType<TSM.Part>().ToList();
                double MinX = GP.GetSolid().MinimumPoint.X;
                double MaxX = GP.GetSolid().MaximumPoint.X;

                List<TSM.Part> Parts = (from b in PartListC where !Com.HasBolt(b) && Com.CenterPoint(b).X > MinX && Com.CenterPoint(b).X < MaxX && !dc.IsHorzObjN(b) && dc.IsPlateSideViewN(b) select b).ToList();
                BC.Stiffs = Com.FilterStiff(Parts);
            }

            return GC;
        }

        private void GetGussetClassFV(List<TSM.Part> PartListF)
        {
            List<TSM.Part> GussetPlates = (from p in PartListF where IsBG12(p) && (Com.CenterPoint(p).Y > BC.Points.P2.Y && Com.CenterPoint(p).Y < BC.Points.P1.Y) select p).ToList();
            List<TSM.Part> StiffList = (from p in PartListF where !Com.HasBolt(p) && Com.GetPartProfileType(p) != "L" && !dc.IsHorzObj(p) && (Com.CenterPoint(p).Y > BC.Points.P2.Y && Com.CenterPoint(p).Y < BC.Points.P1.Y) select p).ToList();
            if (GussetPlates != null && GussetPlates.Count > 0)
            {
                BC.GPTV = new GussetClassTV();
                BC.GPTV.GussetList = new List<PartClass>();
                foreach (TSM.Part part in GussetPlates)
                {
                    PartClass GussetClass = Com.GetPartClass(part);
                    BC.GPTV.GussetList.Add(GussetClass);
                }
            }

            if (StiffList != null && StiffList.Count > 0)
            {

                if (BC.GPTV == null)
                    BC.GPTV = new GussetClassTV();

                //BC.GPTV.StiffList = new List<PartClass>();
                //foreach (TSM.Part stiff in StiffList)
                //{
                //    PartClass StiffClass = Com.GetPartClass(stiff);
                //    BC.GPTV.StiffList.Add(StiffClass);
                //}

                BC.GPTV.StiffList = Com.FilterStiff(StiffList);
            }

        }

        private Beam GetBrace(BoltGroup BoltL, TSM.Part GP)
        {

            Beam brace = (from b in Com.GetBoltParts(BoltL).OfType<TSM.Beam>() where b.Identifier.ID != GP.Identifier.ID && (b.Name.ToLower().Contains("brace") || (dc.IsMainPart(b) && !dc.IsPlate(b))) select b).FirstOrDefault();
            if (brace == null)
            {
                List<TSM.Part> PartList = (from b in Com.GetBoltParts(BoltL).OfType<TSM.Part>() where b.Identifier.ID != GP.Identifier.ID select b).ToList();

                foreach (TSM.Part part in PartList)
                {

                    BoltGroup bolt2 = Com.EnumtoArray(part.GetBolts()).OfType<BoltGroup>().Where(x => x.Identifier.ID != BoltL.Identifier.ID).FirstOrDefault();
                    if (bolt2 != null)
                    {
                        brace = (from b in Com.GetBoltParts(bolt2).OfType<TSM.Beam>() where b.Identifier.ID != GP.Identifier.ID && (b.Name.ToLower().Contains("brace") || (dc.IsMainPart(b) && !dc.IsPlate(b))) select b).FirstOrDefault();
                    }

                }

                if (brace == null)
                {
                    foreach (TSM.Part part in PartList)
                    {
                        if (dc.IsMainPart(part) && dc.IsPlate(part))
                        {

                            List<TSM.Part> PartLists = Com.EnumtoArray(part.GetWelds()).OfType<TSM.Weld>().Select(x => x.MainObject).OfType<TSM.Part>().ToList();
                            PartLists.AddRange(Com.EnumtoArray(part.GetWelds()).OfType<TSM.Weld>().Select(x => x.SecondaryObject).OfType<TSM.Part>().ToList());

                            brace = (from b in PartLists.OfType<Beam>() where IsBrace(b) select b).FirstOrDefault();
                            if (brace == null)
                            {
                                PartLists = (from b in PartLists where !dc.IsMainPart(b) select b.GetAssembly().GetMainPart()).OfType<TSM.Part>().ToList();
                                brace = (from b in PartLists.OfType<Beam>() where IsBrace(b) select b).FirstOrDefault();
                                if (brace != null)
                                    break;
                            }


                        }

                    }
                }

                if (brace == null)
                {
                    foreach (TSM.Part part in PartList)
                    {
                        if (dc.IsMainPart(part) && dc.IsPlate(part))
                        {

                            List<BoltGroup> BoltsList = Com.EnumtoArray(part.GetBolts()).OfType<TSM.BoltGroup>().ToList();
                            if (BoltsList != null && BoltsList.Count > 0)
                            {
                                List<TSM.Part> PartLists = new List<TSM.Part>();

                                BoltsList.ForEach(x => PartLists.AddRange(Com.GetBoltParts(x)));

                                brace = (from b in PartLists.OfType<Beam>() where IsBrace(b) select b).FirstOrDefault();
                                if (brace == null)
                                {
                                    PartLists = (from b in PartLists where !dc.IsMainPart(b) select b.GetAssembly().GetMainPart()).OfType<TSM.Part>().ToList();
                                    brace = (from b in PartLists.OfType<Beam>() where IsBrace(b) select b).FirstOrDefault();
                                    if (brace != null)
                                        break;
                                }
                            }


                        }

                    }
                }
            }

            return brace;

        }

        private PartPoints GetGussetPoints(ContourPlate GP)
        {
            PartPoints RetP = new PartPoints();
            PointList pointList = Com.ContPList(GP);
            RetP.CentP = Com.CenterPoint(GP);

            List<ContourPoint> ContPlist = GP.Contour.ContourPoints.OfType<ContourPoint>().Where(x => x.Chamfer != null && x.Chamfer.Type == Chamfer.ChamferTypeEnum.CHAMFER_ARC).ToList();

            if (RetP.CentP.Y > BC.Points.CentP.Y)
            {

                RetP.P1 = (from p in pointList.OfType<Point>() where p.X < RetP.CentP.X orderby p.Y descending select p).FirstOrDefault();
                RetP.P2 = (from p in pointList.OfType<Point>() where p.X < RetP.CentP.X orderby p.Y ascending select p).FirstOrDefault();
                RetP.P6 = (from p in pointList.OfType<Point>() where p.X < RetP.CentP.X && p.Y > RetP.P2.Y orderby p.Y ascending select p).FirstOrDefault();

                RetP.P4 = (from p in pointList.OfType<Point>() where p.X > RetP.CentP.X orderby p.Y descending select p).FirstOrDefault();
                RetP.P3 = (from p in pointList.OfType<Point>() where p.X > RetP.CentP.X orderby p.Y ascending select p).FirstOrDefault();
                RetP.P5 = (from p in pointList.OfType<Point>() where p.X > RetP.CentP.X && p.Y > RetP.P3.Y orderby p.Y ascending select p).FirstOrDefault();


                if (ContPlist != null && ContPlist.Count > 0)
                {
                    ContourPoint P1 = (from p in ContPlist where Com.IsEqual(p.X, RetP.P2.X) && Com.IsEqual(p.Y, RetP.P2.Y) select p).FirstOrDefault();
                    ContourPoint P2 = (from p in ContPlist where Com.IsEqual(p.X, RetP.P3.X) && Com.IsEqual(p.Y, RetP.P3.Y) select p).FirstOrDefault();

                    if (P1 != null || P2 != null)
                    {
                        BC.ContPT = new ContPClass();

                        if (P1 != null)
                            BC.ContPT.P1 = P1;

                        if (P2 != null)
                            BC.ContPT.P2 = P2;
                    }
                }

            }
            else
            {

                RetP.P1 = (from p in pointList.OfType<Point>() where p.X < RetP.CentP.X orderby p.Y ascending select p).FirstOrDefault();
                RetP.P2 = (from p in pointList.OfType<Point>() where p.X < RetP.CentP.X orderby p.Y descending select p).FirstOrDefault();
                RetP.P6 = (from p in pointList.OfType<Point>() where p.X < RetP.CentP.X && p.Y < RetP.P2.Y orderby p.Y descending select p).FirstOrDefault();

                RetP.P4 = (from p in pointList.OfType<Point>() where p.X > RetP.CentP.X orderby p.Y ascending select p).FirstOrDefault();
                RetP.P3 = (from p in pointList.OfType<Point>() where p.X > RetP.CentP.X orderby p.Y descending select p).FirstOrDefault();
                RetP.P5 = (from p in pointList.OfType<Point>() where p.X > RetP.CentP.X && p.Y < RetP.P3.Y orderby p.Y descending select p).FirstOrDefault();


                if (ContPlist != null && ContPlist.Count > 0)
                {
                    ContourPoint P1 = (from p in ContPlist where Com.IsEqual(p.X, RetP.P2.X) && Com.IsEqual(p.Y, RetP.P2.Y) select p).FirstOrDefault();
                    ContourPoint P2 = (from p in ContPlist where Com.IsEqual(p.X, RetP.P3.X) && Com.IsEqual(p.Y, RetP.P3.Y) select p).FirstOrDefault();

                    if (P1 != null || P2 != null)
                    {
                        BC.ContPB = new ContPClass();

                        if (P1 != null)
                            BC.ContPB.P1 = P1;

                        if (P2 != null)
                            BC.ContPB.P2 = P2;
                    }
                }


            }


            return RetP;
        }

        #endregion

        #region Helping Methods

        private double GetDegree(Point P1, Point P2, Point P3)
        {
            double degree = 0;
            try
            {

                AngleDimension angDimA = new AngleDimension(CView, P1, P2, P3, 50);
                degree = angDimA.GetAngle();
            }
            catch (Exception ex)
            { }
            return degree;
        }

        private bool IsBrace(Beam b)
        {
            bool RetCheck = false;
            if (b.Name.ToLower().Contains("brace") || (dc.IsMainPart(b) && !dc.IsPlate(b)))
            {
                if ((b.StartPoint.Y < BC.Points.P1.Y && b.StartPoint.Y > BC.Points.P2.Y) || (b.EndPoint.Y < BC.Points.P1.Y && b.EndPoint.Y > BC.Points.P2.Y))
                    RetCheck = true;
            }

            return RetCheck;
        }

        private Point GetIntSectPoint(BoltGroup bolt, Beam brace, string Position)
        {
            Vector Vect = bolt.GetCoordinateSystem().AxisX;
            PointList PtList = new PointList();
            Point IntSectP = null;
            if (Position == "Top")
            {
                if (Vect.Y > 0)
                    Vect = Com.ChangeVector(Vect);
            }
            else
            {
                if (Vect.Y < 0)
                    Vect = Com.ChangeVector(Vect);
            }

            PtList = dc.ChangePints(bolt, CView, Vect);
            if (PtList.Count > 1)
                IntSectP = Com.GetIntersectionPoint(PtList[0], PtList[1], brace.StartPoint, brace.EndPoint);
            else if (PtList.Count == 1)
                IntSectP = PtList[0];

            if (IntSectP == null)
            {
                if (Position == "Top")
                    IntSectP = Com.MaxP(PtList, "Y");
                else
                    IntSectP = Com.MinP(PtList, "Y");

            }

            return IntSectP;

        }

        private bool IsBG12(TSM.Part part)
        {
            if (Com.GetNote5(part).ToUpper().Contains("BG12"))
                return true;
            else
                return false;
        }
        #endregion


        private class ContPClass
        {
            public ContourPoint P1 { get; set; }
            public ContourPoint P2 { get; set; }
        }

        private class GussetClassTV
        {
            public List<PartClass> GussetList { get; set; }
            public List<PartClass> StiffList { get; set; }

        }

        private class GussetClassS
        {
            public PartClass GPL { get; set; }
            public PartClass GPR { get; set; }
            public PartClass StiffL { get; set; }
            public PartClass StiffR { get; set; }
            public PartClass StiffTL { get; set; }
            public PartClass StiffTR { get; set; }

        }

        private class BeamClass_BG12
        {
            public Beam beam { get; set; }
            public GussetClassB TopGP { get; set; }
            public GussetClassB BottGP { get; set; }
            public PartPoints Points { get; set; }
            public PlacingClass PC { get; set; }
            public GussetClassTV GPTV { get; set; }
            public GussetClassS GPS { get; set; }

            public ContPClass ContPT { get; set; }
            public ContPClass ContPB { get; set; }

            public List<PartClass> Stiffs { get; set; }
        }

    }




}
