﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Tekla.Structures;
using Tekla.Structures.Drawing;
using Tekla.Structures.Geometry3d;
using Tekla.Structures.Model;
using TSD = Tekla.Structures.Drawing;
using TSM = Tekla.Structures.Model;
using VirtueleDrawingAutomation;
using TSDD = Tekla.Structures.Datatype;
using TSG = Tekla.Structures.Geometry3d;

namespace Auto_Detailing_Tool_Beam
{
    public class BeamDim_BS2
    {
        #region Global Variables
        DimCom dc = new DimCom();
        StraightDimensionSet.StraightDimensionSetAttributes StAtrr = new StraightDimensionSet.StraightDimensionSetAttributes("standard");
        StraightDimensionSet.StraightDimensionSetAttributes RdAtrr = new StraightDimensionSet.StraightDimensionSetAttributes("standard");

        public Beam MainBeam = null;
        VirtueleDrawingAutomation.Json.DrawingAttributeInfoJson.AttributeFiles dimAttrClass = null;
        List<TSD.StraightDimension> KnockDim = new List<StraightDimension>();
        BeamClass_BS2 BC = null;
        VirtueleDrawingAutomation.Json.AutoDimensionTypesJson.BS2Json DN = null;
        TSD.View CView = null;

        List<int> Ids = new List<int>();
        string ViewName = "";

        #endregion

        public List<int> ApplyDim(TSD.View CView, string ViewName, AutoDimensioningTypes autoDimensioningTypes, DrawingAttributeInfo drawingAttributeInfo, List<int> Ids)
        {
            try
            {
                this.Ids = Ids;
                Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane());
                //Set model everything to the view
                Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane(CView.DisplayCoordinateSystem));

                this.CView = CView;
                this.dimAttrClass = drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files;
                this.DN = autoDimensioningTypes.Bs2;
                StAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.StandardDimension);
                RdAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.RunningDimension);
                this.MainBeam = (Com.MyModel.SelectModelObject(new Identifier((CView.GetDrawing() as AssemblyDrawing).AssemblyIdentifier.ID)) as TSM.Assembly).GetMainPart() as TSM.Beam;
                this.MainBeam.Select();
                this.ViewName = ViewName;

                string ProType = Com.GetProType(MainBeam);
                GetBeamClassClass();

                ////TestDim();
                if (ViewName == "Front View")
                {
                    while (BC.SHC != null)
                    {
                        ApplyDimTypeFV();
                        GetBeamClassClass();
                    }
                }
                else
                if (ViewName == "Top View" || ViewName == "Bottom View")
                {
                    while (BC.SHC != null)
                    {
                        ApplyDimTypeTV();
                        GetBeamClassClass();
                    }
                }
                else
                if (ViewName == "Section View")
                {
                    while (BC.SHC != null)
                    {
                        ApplyDimTypeSection();
                        GetBeamClassClass();
                    }
                }
                else
                if (ViewName == "Detail View")
                    ApplyDimDetail();

            }
            catch (Exception ex)
            { }
            Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane());

            return Ids;
        }

        private void ApplyDimTypeFV()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            TSD.PointList TempList = new PointList();

            if (BC.SHC != null)
            {
                Vect = new Vector(-1, 0, 0);
                // Dim No 3
                if (DN.DimIDNo3 && BC.SHC.BoltPList != null && BC.SHC.BoltPList.Count > 0)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxPofX(BC.SHC.BoltPList, "Y", Com.MaxP(BC.SHC.BoltPList, "X").X));
                    pointList.Add(new Point(pointList[0].X, BC.Points.P1.Y));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.SHC.Points.P1.X, BC.PC.DistLeft);
                }


                Ids.Add(BC.SHC.part.Identifier.ID);

            }

        }

        private void ApplyDimTypeTV()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            TSD.PointList TempList = new PointList();

            if (BC.SHC != null)
            {
                TSG.Line Xline = new TSG.Line(BC.SHC.Points.P3, BC.SHC.Points.P4);
                TSG.Line Yline = new TSG.Line(BC.SHC.Points.P5, BC.SHC.Points.P6);


                Vector TopVect = Yline.Direction;
                if (TopVect.Y < 0)
                    TopVect = dc.ChangeVector(TopVect);

                Vector BottomVect = Yline.Direction;
                if (BottomVect.Y > 0)
                    BottomVect = dc.ChangeVector(BottomVect);

                Vector LeftVect = Xline.Direction;
                if (LeftVect.X > 0)
                    LeftVect = dc.ChangeVector(LeftVect);

                Vector RightVect = Xline.Direction;
                if (RightVect.X < 0)
                    RightVect = dc.ChangeVector(RightVect);

                #region Bottom 
                if (BC.VPos == "Bottom")
                {

                    if (BC.Direction == "Left")
                    {
                        #region Left
                        BC.PC.DistRight = (BC.PC.DistInc);
                        // Dim No 5.4, 5.3
                        if (DN.DimIDNo5Dot4 || DN.DimIDNo5Dot3)
                        {
                            pointList = new PointList();


                            if (DN.DimIDNo5Dot3)
                                pointList.Add(Com.MaxP(BC.SHC.BoltPList, "Y"));

                            pointList.Add(BC.SHC.Points.P2);

                            if (DN.DimIDNo5Dot4)
                                pointList.Add(BC.SHC.Points.P5);

                            xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                            if (xDim != null)
                                BC.PC.DistRight += BC.PC.DistInc;
                        }

                        // Dim No 5.1, 5
                        if (DN.DimIDNo5Dot1 || DN.DimIDNo5)
                        {
                            pointList = new PointList();


                            if (DN.DimIDNo5)
                                pointList.AddRange(BC.SHC.BoltPList);

                            if (DN.DimIDNo5Dot1)
                            {

                                pointList.Add(Com.MinP(BC.SHC.BoltPList, "Y"));
                                pointList.Add(BC.SHC.Points.P3);
                            }

                            xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);

                        }

                        // Dim No 5.2
                        if (DN.DimIDNo5Dot2)
                        {
                            pointList = new PointList();
                            pointList.Add(Com.MaxP(BC.SHC.BoltPList, "Y"));
                            pointList.Add(BC.SHC.Points.P5);
                            xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);

                        }



                        Vect = new Vector(0, -1, 0);
                        BC.PC.DistBot = (BC.PC.DistInc * 3);
                        // Dim No 2
                        if (DN.DimIDNo2)
                        {
                            pointList = new PointList();
                            pointList.Add(BC.SHC.Points.P1);
                            pointList.Add(BC.SHC.Points.P5);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                            if (xDim != null)
                                PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        }

                        // Dim No 1 Rd Dim
                        if (DN.DimIDNo1)
                        {
                            pointList = new PointList();
                            pointList.Add(BC.Points.P1);
                            pointList.Add(BC.SHC.Points.P1);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                            if (xDim != null)
                                PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        }

                        if (DN.DimIDNo2 || DN.DimIDNo1Dot1)
                            BC.PC.DistBot += BC.PC.DistInc;
                        // Dim No 1.1 Rd Dim
                        if (DN.DimIDNo1Dot1)
                        {
                            pointList = new PointList();
                            pointList.Add(BC.Points.P2);
                            pointList.Add(BC.SHC.Points.P5);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                            if (xDim != null)
                                PL.DimPlaceByBottomY(xDim, BC.PC);
                        }

                        // Dim No 11
                        if (DN.DimIDNo11)
                        {
                            pointList = new PointList();
                            pointList.Add(BC.SHC.Points.P5);
                            pointList.Add(Com.MinP(BC.SHC.BoltPList, "Y"));
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                            if (xDim != null)
                                PL.DimPlaceByBottomY(xDim, BC.PC);
                        }

                        Vect = new Vector(-1, 0, 0);

                        // Dim No 10
                        if (DN.DimIDNo10)
                        {
                            BC.PC.DistLeft += (BC.PC.DistInc * 0.5);
                            pointList = new PointList();
                            pointList.Add(BC.SHC.Points.P1);
                            pointList.Add(Com.MinP(BC.SHC.BoltPList, "Y"));
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                            if (xDim != null)
                                PL.DistPlaceLeftP(xDim, BC.SHC.Points.P4.X, BC.PC.DistLeft);
                        }

                        // Dim No 6, 6.1
                        if (DN.DimIDNo6 || DN.DimIDNo6Dot1)
                        {
                            pointList = new PointList();
                            if (DN.DimIDNo6Dot1)
                                pointList.Add(BC.SHC.Points.P5);

                            pointList.Add(BC.SHC.Points.P3);

                            if (DN.DimIDNo6)
                                pointList.Add(BC.SHC.Points.P4);

                            xDim = dc.InsertDim(CView, pointList, BottomVect, (BC.PC.DistInc), StAtrr);
                            if (xDim != null)
                                PL.DimPlacingDiag(xDim, Xline, BC.PC.DistInc);
                        }
                        // Dim No 7 Angle Dim
                        if (DN.DimIDNo7)
                        {
                            double Dist = CalcDistAngel(BC.SHC.Points.P2, BC.SHC.Points.P3);
                            Com.InsertAngleDim(CView, BC.SHC.Points.P2, BC.SHC.Points.P3, "Bottom", Dist);
                        }
                        #endregion

                    }


                    else
                    {
                        #region Right
                        BC.PC.DistLeft = (BC.PC.DistInc);
                        // Dim No 5.4, 5.3
                        if (DN.DimIDNo5Dot4 || DN.DimIDNo5Dot3)
                        {
                            pointList = new PointList();


                            if (DN.DimIDNo5Dot3)
                                pointList.Add(Com.MaxP(BC.SHC.BoltPList, "Y"));

                            pointList.Add(BC.SHC.Points.P2);

                            if (DN.DimIDNo5Dot4)
                                pointList.Add(BC.SHC.Points.P5);

                            xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                            if (xDim != null)
                                BC.PC.DistLeft += BC.PC.DistInc;
                        }

                        // Dim No 5.1, 5
                        if (DN.DimIDNo5Dot1 || DN.DimIDNo5)
                        {
                            pointList = new PointList();


                            if (DN.DimIDNo5)
                                pointList.AddRange(BC.SHC.BoltPList);

                            if (DN.DimIDNo5Dot1)
                            {

                                pointList.Add(Com.MinP(BC.SHC.BoltPList, "Y"));
                                pointList.Add(BC.SHC.Points.P3);
                            }

                            xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);

                        }

                        // Dim No 5.2
                        if (DN.DimIDNo5Dot2)
                        {
                            pointList = new PointList();
                            pointList.Add(Com.MaxP(BC.SHC.BoltPList, "Y"));
                            pointList.Add(BC.SHC.Points.P5);
                            xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);

                        }



                        Vect = new Vector(0, -1, 0);
                        BC.PC.DistBot = (BC.PC.DistInc * 3);
                        // Dim No 2
                        if (DN.DimIDNo2)
                        {
                            pointList = new PointList();
                            pointList.Add(BC.SHC.Points.P5);
                            pointList.Add(BC.SHC.Points.P1);

                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                            if (xDim != null)
                                PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        }

                        // Dim No 1 Rd Dim
                        if (DN.DimIDNo1)
                        {
                            pointList = new PointList();
                            pointList.Add(BC.Points.P1);
                            pointList.Add(BC.SHC.Points.P1);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                            if (xDim != null)
                                PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        }

                        if (DN.DimIDNo2 || DN.DimIDNo1Dot1)
                            BC.PC.DistBot += BC.PC.DistInc;
                        // Dim No 1.1 Rd Dim
                        if (DN.DimIDNo1Dot1)
                        {
                            pointList = new PointList();
                            pointList.Add(BC.Points.P2);
                            pointList.Add(BC.SHC.Points.P5);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                            if (xDim != null)
                                PL.DimPlaceByBottomY(xDim, BC.PC);
                        }

                        // Dim No 11
                        if (DN.DimIDNo11)
                        {
                            pointList = new PointList();
                            pointList.Add(BC.SHC.Points.P5);
                            pointList.Add(Com.MinP(BC.SHC.BoltPList, "Y"));
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                            if (xDim != null)
                                PL.DimPlaceByBottomY(xDim, BC.PC);
                        }

                        Vect = new Vector(1, 0, 0);

                        // Dim No 10
                        if (DN.DimIDNo10)
                        {
                            BC.PC.DistRight += (BC.PC.DistInc * 0.5);
                            pointList = new PointList();
                            pointList.Add(BC.SHC.Points.P1);
                            pointList.Add(Com.MinP(BC.SHC.BoltPList, "Y"));
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                            if (xDim != null)
                                PL.DistPlaceRightP(xDim, BC.SHC.Points.P4.X, BC.PC.DistRight);
                        }

                        // Dim No 6, 6.1
                        if (DN.DimIDNo6 || DN.DimIDNo6Dot1)
                        {
                            pointList = new PointList();
                            if (DN.DimIDNo6Dot1)
                                pointList.Add(BC.SHC.Points.P5);

                            pointList.Add(BC.SHC.Points.P3);

                            if (DN.DimIDNo6)
                                pointList.Add(BC.SHC.Points.P4);

                            xDim = dc.InsertDim(CView, pointList, BottomVect, (BC.PC.DistInc), StAtrr);
                            if (xDim != null)
                                PL.DimPlacingDiag(xDim, Xline, BC.PC.DistInc);
                        }
                        // Dim No 7 Angle Dim
                        if (DN.DimIDNo7)
                        {
                            double Dist = CalcDistAngel(BC.SHC.Points.P2, BC.SHC.Points.P3);
                            Com.InsertAngleDim(CView, BC.SHC.Points.P2, BC.SHC.Points.P3, "Bottom", Dist);
                        }
                        #endregion
                    }



                }
                #endregion

                #region Top
                else
                {


                    if (BC.Direction == "Left")
                    {

                        #region Left
                        BC.PC.DistRight = (BC.PC.DistInc);
                        // Dim No 5.4, 5.3
                        if (DN.DimIDNo5Dot4 || DN.DimIDNo5Dot3)
                        {
                            pointList = new PointList();



                            if (DN.DimIDNo5Dot3)
                                pointList.Add(Com.MinP(BC.SHC.BoltPList, "Y"));

                            pointList.Add(BC.SHC.Points.P2);

                            if (DN.DimIDNo5Dot4)
                                pointList.Add(BC.SHC.Points.P5);

                            xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                            if (xDim != null)
                                BC.PC.DistRight += BC.PC.DistInc;

                        }

                        // Dim No 5.1, 5
                        if (DN.DimIDNo5Dot1 || DN.DimIDNo5)
                        {
                            pointList = new PointList();

                            if (DN.DimIDNo5)
                                pointList.AddRange(BC.SHC.BoltPList);

                            if (DN.DimIDNo5Dot1)
                            {
                                pointList.Add(Com.MaxP(BC.SHC.BoltPList, "Y"));
                                pointList.Add(BC.SHC.Points.P3);
                            }


                            xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);

                        }

                        // Dim No 5.2
                        if (DN.DimIDNo5Dot2)
                        {
                            pointList = new PointList();
                            pointList.Add(Com.MinP(BC.SHC.BoltPList, "Y"));
                            pointList.Add(BC.SHC.Points.P5);
                            xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);

                        }



                        Vect = new Vector(0, 1, 0);
                        BC.PC.DistTop = (BC.PC.DistInc * 3);
                        // Dim No 2
                        if (DN.DimIDNo2)
                        {
                            pointList = new PointList();
                            pointList.Add(BC.SHC.Points.P1);
                            pointList.Add(BC.SHC.Points.P5);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                            if (xDim != null)
                                PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        }

                        // Dim No 1 Rd Dim
                        if (DN.DimIDNo1)
                        {
                            pointList = new PointList();
                            pointList.Add(BC.Points.P1);
                            pointList.Add(BC.SHC.Points.P1);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                            if (xDim != null)
                                PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        }

                        if (DN.DimIDNo2 || DN.DimIDNo1Dot1)
                            BC.PC.DistTop += BC.PC.DistInc;

                        // Dim No 1.1 Rd Dim
                        if (DN.DimIDNo1Dot1)
                        {
                            pointList = new PointList();
                            pointList.Add(BC.Points.P1);
                            pointList.Add(BC.SHC.Points.P5);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                            if (xDim != null)
                                PL.DimPlaceByTopY(xDim, BC.PC);
                        }

                        // Dim No 11
                        if (DN.DimIDNo11)
                        {
                            pointList = new PointList();
                            pointList.Add(BC.SHC.Points.P5);
                            pointList.Add(Com.MaxP(BC.SHC.BoltPList, "Y"));
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                            if (xDim != null)
                                PL.DimPlaceByTopY(xDim, BC.PC);
                        }

                        Vect = new Vector(-1, 0, 0);

                        // Dim No 10
                        if (DN.DimIDNo10)
                        {
                            BC.PC.DistLeft += (BC.PC.DistInc * 0.5);
                            pointList = new PointList();
                            pointList.Add(BC.SHC.Points.P1);
                            pointList.Add(Com.MaxP(BC.SHC.BoltPList, "Y"));
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                            if (xDim != null)
                                PL.DistPlaceLeftP(xDim, BC.SHC.Points.P4.X, BC.PC.DistLeft);
                        }

                        // Dim No 6, 6.1
                        if (DN.DimIDNo6 || DN.DimIDNo6Dot1)
                        {
                            pointList = new PointList();
                            if (DN.DimIDNo6Dot1)
                                pointList.Add(BC.SHC.Points.P5);

                            pointList.Add(BC.SHC.Points.P3);

                            if (DN.DimIDNo6)
                                pointList.Add(BC.SHC.Points.P4);

                            xDim = dc.InsertDim(CView, pointList, TopVect, (BC.PC.DistInc), StAtrr);
                        }
                        // Dim No 7 Angle Dim
                        if (DN.DimIDNo7)
                        {
                            double Dist = CalcDistAngel(BC.SHC.Points.P2, BC.SHC.Points.P3);
                            Com.InsertAngleDim(CView, BC.SHC.Points.P2, BC.SHC.Points.P3, "Top", Dist);
                        }

                        #endregion

                    }
                    else
                    {
                        #region Right
                        BC.PC.DistLeft = (BC.PC.DistInc);
                        // Dim No 5.4, 5.3
                        if (DN.DimIDNo5Dot4 || DN.DimIDNo5Dot3)
                        {
                            pointList = new PointList();

                            if (DN.DimIDNo5Dot3)
                                pointList.Add(Com.MinP(BC.SHC.BoltPList, "Y"));

                            pointList.Add(BC.SHC.Points.P2);

                            if (DN.DimIDNo5Dot4)
                                pointList.Add(BC.SHC.Points.P5);

                            xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                            if (xDim != null)
                                BC.PC.DistLeft += BC.PC.DistInc;

                        }

                        // Dim No 5.1, 5
                        if (DN.DimIDNo5Dot1 || DN.DimIDNo5)
                        {
                            pointList = new PointList();

                            if (DN.DimIDNo5)
                                pointList.AddRange(BC.SHC.BoltPList);

                            if (DN.DimIDNo5Dot1)
                            {
                                pointList.Add(Com.MaxP(BC.SHC.BoltPList, "Y"));
                                pointList.Add(BC.SHC.Points.P3);
                            }


                            xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);

                        }

                        // Dim No 5.2
                        if (DN.DimIDNo5Dot2)
                        {
                            pointList = new PointList();
                            pointList.Add(Com.MinP(BC.SHC.BoltPList, "Y"));
                            pointList.Add(BC.SHC.Points.P5);
                            xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistRight, StAtrr);

                        }



                        Vect = new Vector(0, 1, 0);
                        BC.PC.DistTop = (BC.PC.DistInc * 3);
                        // Dim No 2
                        if (DN.DimIDNo2)
                        {
                            pointList = new PointList();
                            pointList.Add(BC.SHC.Points.P5);
                            pointList.Add(BC.SHC.Points.P1);

                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                            if (xDim != null)
                                PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        }

                        // Dim No 1 Rd Dim
                        if (DN.DimIDNo1)
                        {
                            pointList = new PointList();
                            pointList.Add(BC.Points.P1);
                            pointList.Add(BC.SHC.Points.P1);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                            if (xDim != null)
                                PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        }

                        if (DN.DimIDNo2 || DN.DimIDNo1Dot1)
                            BC.PC.DistTop += BC.PC.DistInc;

                        // Dim No 1.1 Rd Dim
                        if (DN.DimIDNo1Dot1)
                        {
                            pointList = new PointList();
                            pointList.Add(BC.Points.P1);
                            pointList.Add(BC.SHC.Points.P5);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                            if (xDim != null)
                                PL.DimPlaceByTopY(xDim, BC.PC);
                        }

                        // Dim No 11
                        if (DN.DimIDNo11)
                        {
                            pointList = new PointList();
                            pointList.Add(BC.SHC.Points.P5);
                            pointList.Add(Com.MaxP(BC.SHC.BoltPList, "Y"));
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                            if (xDim != null)
                                PL.DimPlaceByTopY(xDim, BC.PC);
                        }

                        Vect = new Vector(1, 0, 0);

                        // Dim No 10
                        if (DN.DimIDNo10)
                        {
                            BC.PC.DistRight += (BC.PC.DistInc * 0.5);
                            pointList = new PointList();
                            pointList.Add(BC.SHC.Points.P1);
                            pointList.Add(Com.MaxP(BC.SHC.BoltPList, "Y"));
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                            if (xDim != null)
                                PL.DistPlaceLeftP(xDim, BC.SHC.Points.P4.X, BC.PC.DistRight);
                        }

                        // Dim No 6, 6.1
                        if (DN.DimIDNo6 || DN.DimIDNo6Dot1)
                        {
                            pointList = new PointList();



                            if (DN.DimIDNo6)
                                pointList.Add(BC.SHC.Points.P4);

                            pointList.Add(BC.SHC.Points.P3);

                            if (DN.DimIDNo6Dot1)
                                pointList.Add(BC.SHC.Points.P5);

                            xDim = dc.InsertDim(CView, pointList, TopVect, (BC.PC.DistInc), StAtrr);
                            if (xDim != null)
                                PL.DimPlacingDiag(xDim, Xline, BC.PC.DistInc);
                        }
                        // Dim No 7 Angle Dim
                        if (DN.DimIDNo7)
                        {
                            double Dist = CalcDistAngel(BC.SHC.Points.P2, BC.SHC.Points.P3);
                            Com.InsertAngleDim(CView, BC.SHC.Points.P2, BC.SHC.Points.P3, "Top", Dist);
                        }

                        #endregion
                    }


                }

                #endregion

                // Dim 9
                if (DN.DimIDNo9 && Ids.Count == 0)
                    ApplyOverAllDim();


                Ids.Add(BC.SHC.part.Identifier.ID);
            }

        }

        private void ApplyOverAllDim()
        {
            List<TSM.Part> PartListC = BC.beam.GetAssembly().GetSecondaries().OfType<TSM.Part>().ToList();

            List<TSM.Part> ShearPList = (from p in PartListC where IsBS2(p) orderby Com.CenterPoint(p).X ascending select p).ToList();
            if (ShearPList != null && ShearPList.Count > 0)
            {
                if (BC.VPos == "Top")
                {

                    BC.PC.DistTop += BC.PC.DistInc;

                    Vector Vect = new Vector(0, 1, 0);
                    List<Point> SeBPoints = (from p in ShearPList select GetSeCBPoint(p)).ToList();
                    TSD.PointList pointList = new PointList();
                    pointList.Add(BC.Points.P5);
                    pointList.AddRange(Com.PointToPointList(SeBPoints));
                    pointList.Add(BC.Points.P6);
                    StraightDimensionSet xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);
                }
                else
                {
                    BC.PC.DistBot+= BC.PC.DistInc;

                    Vector Vect = new Vector(0, -1, 0);
                    List<Point> SeBPoints = (from p in ShearPList select GetSeCBPoint(p)).ToList();
                    TSD.PointList pointList = new PointList();
                    pointList.Add(BC.Points.P5);
                    pointList.AddRange(Com.PointToPointList(SeBPoints));
                    pointList.Add(BC.Points.P6);
                    StraightDimensionSet xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);
                }

            }


        }

        private void ApplyDimDetail()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);

            if (BC.SHC != null)
            {

                // Dim No 2
                if (DN.DimIDNo2)
                {
                    pointList = new PointList();
                    pointList.Add(BC.SHC.Points.P1);
                    pointList.Add(BC.SHC.Points.P5);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                }


                Ids.Add(BC.SHC.part.Identifier.ID);

            }
        }

        private void ApplyDimTypeSection()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            TSD.PointList TempList = new PointList();

            if (BC.SHC != null)
            {

                if (BC.Direction == "Left")
                {
                    Point CentP = new Point(BC.SHC.Points.CentP.X, BC.Points.P1.Y);

                    if (BC.SHC.BoltPList != null && BC.SHC.BoltPList.Count > 0)
                    {
                        Vect = new Vector(-1, 0, 0);
                        TempList = dc.ChangePints(BC.SHC.BoltPList, CView, Vect);


                        // Dim No 3, 4
                        if ((DN.DimIDNo3 || DN.DimIDNo4))
                        {
                            pointList = new PointList();
                            if (DN.DimIDNo3)
                            {
                                pointList.Add(Com.MaxP(TempList, "Y"));
                                pointList.Add(CentP);
                            }

                            if (DN.DimIDNo4)
                                pointList.AddRange(TempList);

                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                            if (xDim != null)
                                PL.DistPlaceLeftP(xDim, BC.SHC.Points.P1.X, BC.PC.DistLeft);
                        }

                        // Dim No 4.1
                        if (DN.DimIDNo4Dot1)
                        {
                            pointList = new PointList();
                            pointList.Add(Com.MinP(TempList, "Y"));
                            pointList.Add(BC.SHC.Points.P2);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                            if (xDim != null)
                                PL.DistPlaceLeftP(xDim, BC.SHC.Points.P1.X, BC.PC.DistLeft);
                        }

                        if (DN.DimIDNo4Dot1 || DN.DimIDNo3 || DN.DimIDNo4)
                            BC.PC.DistLeft += BC.PC.DistInc;

                        // Dim No 4.2
                        if (DN.DimIDNo4Dot2 && TempList.Count > 2)
                        {
                            pointList = new PointList();
                            pointList.AddRange(TempList);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                            if (xDim != null)
                            {
                                PL.DistPlaceLeftP(xDim, BC.SHC.Points.P1.X, BC.PC.DistLeft);
                                Com.GroupDim(xDim);
                            }
                        }

                        Vect = new Vector(0, 1, 0);
                        TempList = dc.ChangePints(BC.SHC.BoltPList, CView, Vect);

                        if (DN.DimIDNo8 || DN.DimIDNo8Dot1)
                        {
                            pointList = new PointList();
                            if (DN.DimIDNo8Dot1)
                            {
                                pointList.Add(Com.MinP(TempList, "X"));
                                pointList.Add(BC.SHC.Points.P1);
                            }

                            if (DN.DimIDNo8)
                                pointList.AddRange(TempList);

                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                            if (xDim != null)
                                PL.DistPlaceTopP(xDim, BC.Points.P1.Y, BC.PC.DistTop);
                        }
                    }
                }
                else
                {
                    Point CentP = new Point(BC.SHC.Points.CentP.X, BC.Points.P1.Y);

                    if (BC.SHC.BoltPList != null && BC.SHC.BoltPList.Count > 0)
                    {
                        Vect = new Vector(1, 0, 0);
                        TempList = dc.ChangePints(BC.SHC.BoltPList, CView, Vect);


                        // Dim No 3, 4
                        if ((DN.DimIDNo3 || DN.DimIDNo4))
                        {
                            pointList = new PointList();
                            if (DN.DimIDNo3)
                            {
                                pointList.Add(Com.MaxP(TempList, "Y"));
                                pointList.Add(CentP);
                            }

                            if (DN.DimIDNo4)
                                pointList.AddRange(TempList);

                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                            if (xDim != null)
                                PL.DistPlaceRightP(xDim, BC.SHC.Points.P4.X, BC.PC.DistRight);
                        }

                        // Dim No 4.1
                        if (DN.DimIDNo4Dot1)
                        {
                            pointList = new PointList();
                            pointList.Add(Com.MinP(TempList, "Y"));
                            pointList.Add(BC.SHC.Points.P3);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                            if (xDim != null)
                                PL.DistPlaceRightP(xDim, BC.SHC.Points.P4.X, BC.PC.DistRight);
                        }

                        if (DN.DimIDNo4Dot1 || DN.DimIDNo3 || DN.DimIDNo4)
                            BC.PC.DistRight += BC.PC.DistInc;

                        // Dim No 4.2
                        if (DN.DimIDNo4Dot2 && TempList.Count > 2)
                        {
                            pointList = new PointList();
                            pointList.AddRange(TempList);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                            if (xDim != null)
                            {
                                PL.DistPlaceRightP(xDim, BC.SHC.Points.P4.X, BC.PC.DistRight);
                                Com.GroupDim(xDim);
                            }
                        }

                        Vect = new Vector(0, 1, 0);
                        TempList = dc.ChangePints(BC.SHC.BoltPList, CView, Vect);

                        if (DN.DimIDNo8 || DN.DimIDNo8Dot1)
                        {
                            pointList = new PointList();
                            if (DN.DimIDNo8Dot1)
                            {
                                pointList.Add(Com.MaxP(TempList, "X"));
                                pointList.Add(BC.SHC.Points.P4);
                            }

                            if (DN.DimIDNo8)
                                pointList.AddRange(TempList);

                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                            if (xDim != null)
                                PL.DistPlaceTopP(xDim, BC.Points.P1.Y, BC.PC.DistTop);
                        }
                    }
                }


                Ids.Add(BC.SHC.part.Identifier.ID);

            }

        }


        private double CalcDistAngel(Point StartP, Point EndP)
        {
            double Dv = 12 / 0.30;
            double ScalM = (12 - CView.Attributes.Scale) * 5;
            double ScaleD = 0.30 + ((12 - CView.Attributes.Scale) / Dv);


            double Dist = (Distance.PointToPoint(StartP, EndP) * ScaleD);
            Dist += ScalM;
            return Dist;
        }


        #region Get Data

        private void GetBeamClassClass()
        {
            BC = new BeamClass_BS2();
            BC.beam = MainBeam;
            BC.Points = Com.GetPartPoints(BC.beam);
            List<TSM.Part> PartListC = BC.beam.GetAssembly().GetSecondaries().OfType<TSM.Part>().ToList();

            Point CentP = Com.CenterPoint(BC.beam.StartPoint, BC.beam.EndPoint);
            double Lenght = (BC.beam.GetSolid().MaximumPoint.X - BC.beam.GetSolid().MinimumPoint.X) / 10;
            double MinX = BC.beam.GetSolid().MinimumPoint.X + Lenght;
            double MaxX = BC.beam.GetSolid().MaximumPoint.X - Lenght;


            if (ViewName == "Front View")
            {
                List<TSM.Part> PartListF = (from p in PartListC where !Ids.Contains(p.Identifier.ID) select p).ToList();


                TSM.Part ShearP = (from p in PartListF where IsBS2(p) orderby Com.CenterPoint(p).X ascending select p).FirstOrDefault();

                if (ShearP != null)
                    BC.SHC = Com.GetPartClass(ShearP);
            }
            else if (ViewName == "Top View" || ViewName == "Bottom View")
            {
                List<TSM.Part> PartListF = (from p in PartListC where !Ids.Contains(p.Identifier.ID) select p).ToList();
                TSM.Part ShearP = (from p in PartListF where IsBS2(p) orderby Com.CenterPoint(p).X ascending select p).FirstOrDefault();

                if (ShearP != null)
                    GetShearPlateClassTV(ShearP);
            }
            else if (ViewName == "Section View")
            {
                double Minz = CView.RestrictionBox.MinPoint.Z;
                double MaxZ = CView.RestrictionBox.MaxPoint.Z + 100;
                List<TSM.Part> PartList = (from p in PartListC where !Ids.Contains(p.Identifier.ID) && Com.IsViewObj(p, CView) select p).ToList();

                TSM.Part ShearP = (from p in PartList where IsBS2(p) && IsMainView(p) orderby Com.GetXDist(p) descending select p).FirstOrDefault();
                if (ShearP != null)
                    GetShearPlateClassS(ShearP);
            }

            else if (ViewName == "Detail View")
            {

                List<TSM.Part> PartList = (from p in PartListC where Com.IsViewObj(p, CView) select p).ToList();

                TSM.Part ShearP = (from p in PartList where IsBS2(p) orderby p.GetSolid().MaximumPoint.Z descending select p).FirstOrDefault();
                if (ShearP != null)
                    GetShearPlateClassTV(ShearP);
            }

            PartListC.Add(MainBeam);

            TSM.Part LeftPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.X ascending select p).FirstOrDefault();
            TSM.Part RightPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.X descending select p).FirstOrDefault();
            TSM.Part TopPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.Y descending select p).FirstOrDefault();
            TSM.Part BottPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.Y ascending select p).FirstOrDefault();

            BC.Points.P5 = Com.MinP(Com.GetVertxPointsD(LeftPart), "X");
            BC.Points.P6 = Com.MaxP(Com.GetVertxPointsD(RightPart), "X");

            BC.PC = new PlacingClass();
            BC.PC.TopY = TopPart.GetSolid().MaximumPoint.Y;
            BC.PC.BottomY = BottPart.GetSolid().MinimumPoint.Y;

            BC.PC.LeftX = MainBeam.StartPoint.X;// Math.Round(CView.RestrictionBox.MinPoint.X);
            BC.PC.RightX = RightPart.GetSolid().MaximumPoint.X;


            double AvScale = 12;
            double AvDistInc = 100;
            double DistPerScale = AvDistInc / AvScale;
            double CScale = CView.Attributes.Scale;
            BC.PC.DistInc = CScale * DistPerScale;
            BC.PC.DistBot = BC.PC.DistInc;
            BC.PC.DistTop = BC.PC.DistInc;
            BC.PC.DistLeft = BC.PC.DistInc;
            BC.PC.DistRight = BC.PC.DistInc;


            AvScale = 12;
            AvDistInc = 50;
            DistPerScale = AvDistInc / AvScale;
            CScale = AvScale - CView.Attributes.Scale;
            BC.PC.DistIncD = (CScale * 10) + AvDistInc;

        }

        private bool IsMainView(TSM.Part SHP)
        {
            bool RetCheck = false;
            List<Point> PList = SHP.GetReferenceLine(false).OfType<Point>().ToList();

            double ZDiff = Com.MaxP(PList, "Z").Z  - Com.MinP(PList, "Z").Z ;

            if (ZDiff < 50)
                RetCheck = true;

            return RetCheck;
        }

        private void GetShearPlateClassTV(TSM.Part SHP)
        {

            PartClass PC = Com.GetPartClass(SHP);

            BC.SecBeam = GetSecBeam(SHP);
            PointList RefPlist = Com.PointToPointList(BC.SecBeam.GetReferenceLine(false).OfType<Point>().ToList());

            PointList VList = Com.GetVertxPointsD(SHP);
            Point MinYP = Com.MinP(VList, "Y");
            Point MaxYP = Com.MaxP(VList, "Y");
            string Vpos = "Top";
            if (PC.Points.CentP.Y > BC.Points.CentP.Y) // Top
            {
                if (MinYP.X < MaxYP.X) // Right
                {
                    PC.Points.P1 = MinYP;
                    PC.Points.P2 = Com.MinP(VList, "X");
                    PC.Points.P3 = MaxYP;
                    PC.Points.P4 = Com.MaxP(VList, "X");
                    PC.Points.P5 = Com.MinP(RefPlist, "Y");
                    PC.Points.P6 = Com.MaxP(RefPlist, "Y");
                    BC.Direction = "Right";
                }
                else // Left
                {
                    PC.Points.P1 = MinYP;
                    PC.Points.P2 = Com.MaxP(VList, "X");
                    PC.Points.P3 = MaxYP;
                    PC.Points.P4 = Com.MinP(VList, "X");
                    PC.Points.P5 = Com.MinP(RefPlist, "Y");
                    PC.Points.P6 = Com.MaxP(RefPlist, "Y");
                    BC.Direction = "Left";
                }
            }
            else
            {
                Vpos = "Bottom";
                if (MaxYP.X < MinYP.X) // Right
                {
                    PC.Points.P1 = MaxYP;
                    PC.Points.P2 = Com.MinP(VList, "X");
                    PC.Points.P3 = MinYP;
                    PC.Points.P4 = Com.MaxP(VList, "X");
                    PC.Points.P5 = Com.MaxP(RefPlist, "Y");
                    PC.Points.P6 = Com.MinP(RefPlist, "Y");
                    BC.Direction = "Right";

                }
                else // Left
                {
                    PC.Points.P1 = MaxYP;
                    PC.Points.P2 = Com.MaxP(VList, "X");
                    PC.Points.P3 = MinYP;
                    PC.Points.P4 = Com.MinP(VList, "X");
                    PC.Points.P5 = Com.MaxP(RefPlist, "Y");
                    PC.Points.P6 = Com.MinP(RefPlist, "Y");
                    BC.Direction = "Left";
                }

            }

            BC.SHC = PC;
            BC.VPos = Vpos;
        }

        private void GetShearPlateClassS(TSM.Part SHP)
        {
            PartClass PC = Com.GetPartClass(SHP);

            double MaxZ = CView.RestrictionBox.MaxPoint.Z + 100;
            List<Point> PtList = (from p in Com.GetVertxPoints(MainBeam) where p.Z >= CView.RestrictionBox.MinPoint.Z select p).ToList();
            BC.Points.P1 = Com.MinPofY(PtList, "X", Com.MaxP(PtList, "Y").Y);
            BC.Points.P2 = Com.MinPofY(PtList, "X", Com.MinP(PtList, "Y").Y);
            BC.Points.P3 = Com.MaxPofY(PtList, "X", Com.MinP(PtList, "Y").Y);
            BC.Points.P4 = Com.MaxPofY(PtList, "X", Com.MaxP(PtList, "Y").Y);
            BC.Points.CentP = Com.CenterPoint(BC.Points.P1, BC.Points.P3);


            Point CentP = Com.CenterPoint(SHP);
            Point CentPB = null;
            if (PC.BoltPList != null)
            {
                Point MinP = Com.MinPofX(PC.BoltPList, "Y", Com.MinP(PC.BoltPList, "X").X);
                Point MaxP = Com.MaxPofX(PC.BoltPList, "Y", Com.MaxP(PC.BoltPList, "X").X);
                CentPB = Com.CenterPoint(MinP, MaxP);
            }

            if (SHP is ContourPlate)
            {
                PointList PtListC = dc.ContPList(SHP as ContourPlate);
                if (CentPB.X > CentP.X)
                {

                    PC.Points.P4 = Com.MaxPofX(PtListC, "Y", Com.MaxP(PtListC, "X").X);
                    PC.Points.P3 = Com.MinPofX(PtListC, "Y", Com.MaxP(PtListC, "X").X);
                }
                else
                {

                    PC.Points.P1 = Com.MaxPofX(PtListC, "Y", Com.MinP(PtListC, "X").X);
                    PC.Points.P2 = Com.MinPofX(PtListC, "Y", Com.MinP(PtListC, "X").X);

                }
            }

            if (CentPB.X > CentP.X)
            {
                BC.Direction = "Right";
                BC.Points.P4 = new Point(PC.Points.P4.X, BC.Points.P4.Y);
                BC.Points.P3 = new Point(PC.Points.P3.X, BC.Points.P3.Y);
            }
            else
            {
                BC.Direction = "Left";
                BC.Points.P1 = new Point(PC.Points.P1.X, BC.Points.P1.Y);
                BC.Points.P2 = new Point(PC.Points.P2.X, BC.Points.P2.Y);
            }


            BC.SHC = PC;

        }

        private Point GetIntPoint(Point PP1, Point PP2)
        {
            Point IntP = new Point();
            Point P1 = new Point(BC.Points.P1.X, BC.Points.CentP.Y);
            Point P2 = new Point(BC.Points.P2.X, BC.Points.CentP.Y);
            TSD.Line line1 = Com.DrawLineDotted1(CView, PP1, PP2);
            TSD.Line line2 = Com.DrawLineDotted1(CView, P1, P2);
            IntP = Com.GetIntersectionPoint(PP1, PP2, P1, P2);

            line1.Delete();
            line2.Delete();
            return IntP;
        }


        private bool IsBS2(TSM.Part part)
        {
            if (Com.GetNote5(part).ToUpper().Contains("BS2"))
                return true;
            else
                return false;
        }


        private Point GetSeCBPoint(TSM.Part SHP)
        {
            Point SecP = null;
            try
            {
                PartClass PC = Com.GetPartClass(SHP);
                Beam SecBeam = GetSecBeam(SHP);
                PointList RefPlist = Com.PointToPointList(SecBeam.GetReferenceLine(false).OfType<Point>().ToList());

                if (PC.Points.CentP.Y > BC.Points.CentP.Y) // Top
                    SecP = Com.MinP(RefPlist, "Y");
                else
                    SecP = Com.MaxP(RefPlist, "Y");
            }
            catch (Exception ex)
            { }

            return SecP;
        }

        #endregion

        #region Helping Methods
        private Beam GetSecBeam(TSM.Part SHP)
        {
            Beam SecB = null;
            List<BoltGroup> Bolts = Com.EnumtoArray(SHP.GetBolts()).OfType<BoltGroup>().ToList();

            foreach (BoltGroup bolt in Bolts)
            {
                SecB = Com.GetBoltParts(bolt).Where(x => x.Identifier.ID != SHP.Identifier.ID && x.Identifier.ID != MainBeam.Identifier.ID).OfType<Beam>().FirstOrDefault();
                if (SecB != null)
                    break;
            }

            return SecB;
        }

        #endregion

        private class BeamClass_BS2
        {
            public Beam beam { get; set; }
            public PartClass SHC { get; set; }
            public string Direction { get; set; }  // Left or Right
            public string VPos { get; set; }   // Top or Bottom
            public PartPoints Points { get; set; }
            public PlacingClass PC { get; set; }
            public Beam SecBeam { get; set; }


        }


    }

}
