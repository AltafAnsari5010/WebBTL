﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Tekla.Structures;
using Tekla.Structures.Drawing;
using Tekla.Structures.Geometry3d;
using Tekla.Structures.Model;
using TSD = Tekla.Structures.Drawing;
using TSM = Tekla.Structures.Model;
using VirtueleDrawingAutomation;
using TSDD = Tekla.Structures.Datatype;
using TSG = Tekla.Structures.Geometry3d;

namespace Auto_Detailing_Tool_Beam
{
    public class BeamDim_BDP1
    {
        #region Global Variables
        DimCom dc = new DimCom();
        StraightDimensionSet.StraightDimensionSetAttributes StAtrr = new StraightDimensionSet.StraightDimensionSetAttributes("standard");
        StraightDimensionSet.StraightDimensionSetAttributes RdAtrr = new StraightDimensionSet.StraightDimensionSetAttributes("standard");

        public Beam MainBeam = null;
        VirtueleDrawingAutomation.Json.DrawingAttributeInfoJson.AttributeFiles dimAttrClass = null;
        List<TSD.StraightDimension> KnockDim = new List<StraightDimension>();
        BeamClass_BDP1 BC = null;

        VirtueleDrawingAutomation.Json.AutoDimensionTypesJson.BDP1Json DN = null;
        string Position = "Left";
        TSD.View CView = null;
        string ViewName = "";
        public Point BoltPS = null;

        #endregion

        public void ApplyDim(TSD.View CView, string ViewName, AutoDimensioningTypes autoDimensioningTypes, DrawingAttributeInfo drawingAttributeInfo, string Position)
        {
            try
            {
                Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane());
                //Set model everything to the view
                Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane(CView.DisplayCoordinateSystem));

                this.CView = CView;
                this.dimAttrClass = drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files;
                this.DN = autoDimensioningTypes.Bdp1;
                this.Position = Position;
                StAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.StandardDimension);
                RdAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.RunningDimension);
                this.MainBeam = (Com.MyModel.SelectModelObject(new Identifier((CView.GetDrawing() as AssemblyDrawing).AssemblyIdentifier.ID)) as TSM.Assembly).GetMainPart() as TSM.Beam;
                this.MainBeam.Select();
                string ProType = Com.GetProType(MainBeam);
                this.ViewName = ViewName;
                GetBeamClassClass(CView);

                if (Position == "Left")
                {
                    if (ViewName == "Front View")
                        ApplyDimTypeLeft(CView);
                    else if (ViewName == "Section View")
                        AppySectionDim();
                }

                else if (Position == "Right")
                {
                    if (ViewName == "Front View")
                        ApplyDimTypeRight(CView);
                    else if (ViewName == "Section View")
                        AppySectionDim();
                }
            }
            catch (Exception ex)
            { }

            Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane());
        }

        private void ApplyDimTypeLeft(TSD.View CView)
        {

            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(-1, 0, 0);
            TSD.PointList TempList = new PointList();
            if (BC.WP != null)
            {
                if (BC.CutTop != null)
                {
                    Vect = new Vector(-1, 0, 0);
                    // Dim No 3
                    if (DN.DimIDNo3)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.CutTop.P1);
                        pointList.Add(BC.CutTop.P2);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                    }

                    Vect = new Vector(0, 1, 0);
                    // Dim No 4
                    if (DN.DimIDNo4)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.CutTop.P1);
                        pointList.Add(BC.CutTop.P2);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                    }

                }

                if (BC.CutBott != null)
                {
                    Vect = new Vector(-1, 0, 0);
                    // Dim No 6
                    if (DN.DimIDNo6)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.CutBott.P1);
                        pointList.Add(BC.CutBott.P2);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                    }

                    Vect = new Vector(0, -1, 0);
                    // Dim No 7
                    if (DN.DimIDNo7)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.CutBott.P1);
                        pointList.Add(BC.CutBott.P2);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                    }

                }

                //if (DN.DimIDNo4 || BC.CutBott != null || BC.CutTop != null)
                //    BC.PC.DistLeft += BC.PC.DistInc;

                if (DN.DimIDNo7 || BC.CutBott != null)
                    BC.PC.DistBot += BC.PC.DistInc;

                if (DN.DimIDNo4 || BC.CutTop != null)
                    BC.PC.DistTop += BC.PC.DistInc;

                Vect = new Vector(-1, 0, 0);
                if (BC.BoltsE != null && BC.BoltsE.Count > 0)
                {

                    // Dim No 2.3
                    if (DN.DimIDNo2Dot3)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.WP.Points.P1);
                        pointList.Add(Com.MaxPofX(BC.BoltsE, "Y", Com.MaxP(BC.BoltsE, "X").X));

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                            BC.PC.DistLeft += (BC.PC.DistInc / 2);
                        }


                        pointList = new PointList();
                        pointList.Add(Com.MinPofX(BC.BoltsE, "Y", Com.MaxP(BC.BoltsE, "X").X));
                        pointList.Add(BC.WP.Points.P2);

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                            BC.PC.DistLeft += (BC.PC.DistInc);
                        }


                    }


                    // Dim No 2.2
                    if (DN.DimIDNo2Dot2)
                    {
                        if (BC.CutTop != null)
                        {
                            pointList = new PointList();
                            pointList.Add(BC.Points.P1);
                            pointList.Add(Com.MaxPofX(BC.BoltsE, "Y", Com.MaxP(BC.BoltsE, "X").X));

                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                            if (xDim != null)
                            {
                                PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                                BC.PC.DistLeft += (BC.PC.DistInc / 2);
                            }
                        }

                        if (BC.CutBott != null)
                        {
                            pointList = new PointList();
                            pointList.Add(Com.MinPofX(BC.BoltsE, "Y", Com.MaxP(BC.BoltsE, "X").X));
                            pointList.Add(BC.Points.P2);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                            if (xDim != null)
                                PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);

                            BC.PC.DistLeft += BC.PC.DistInc;
                        }
                    }

                    // Dim No 1
                    if (DN.DimIDNo1)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MaxPofX(BC.BoltsE, "Y", Com.MaxP(BC.BoltsE, "X").X));
                        pointList.Add(BC.Points.P5);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                    }

                    TempList = dc.ChangePints(BC.BoltsE, CView, Vect);
                    // Dim No 2
                    if (DN.DimIDNo2)
                    {
                        pointList = new PointList();
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByLeftX(xDim, BC.PC);
                    }

                    //if (DN.DimIDNo15 || DN.DimIDNo14 || DN.DimIDNo1)
                    //    BC.PC.DistLeft += BC.PC.DistInc;

                    // Dim No 2.1
                    if (DN.DimIDNo2Dot1)
                    {
                        if (TempList.Count > 2)
                        {
                            pointList = new PointList();
                            pointList.AddRange(TempList);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                            if (xDim != null)
                            {
                                PL.DimPlaceByLeftX(xDim, BC.PC);
                                Com.GroupDim(xDim);
                            }
                        }
                    }

                    Vect = new Vector(0, 1, 0);
                    TempList = dc.ChangePints(BC.BoltsE, CView, Vect);

                    // Dim No 5.1 // Rd Dim
                    if (DN.DimIDNo5Dot1)
                    {
                        pointList = new PointList();
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByTopY(xDim, BC.PC);


                        pointList = new PointList();
                        pointList.Add(BC.Points.P1);
                        pointList.Add(Com.MinP(TempList, "X"));
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                        if (xDim != null)
                            PL.DimPlaceByTopY(xDim, BC.PC);

                    }
                    else if (DN.DimIDNo5)  // Dim No 5
                    {
                        BC.PC.DistTop += BC.PC.DistInc;
                        pointList = new PointList();
                        pointList.Add(BC.Points.P1);
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                        if (xDim != null)
                            PL.DimPlaceByTopY(xDim, BC.PC);
                    }

                    Vect = new Vector(0, -1, 0);
                    TempList = dc.ChangePints(BC.BoltsE, CView, Vect);

                    // Dim No 5.2
                    if (DN.DimIDNo5Dot2)
                    {

                        pointList = new PointList();
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                        if (xDim != null)
                        {
                            PL.DimPlaceByBottomY(xDim, BC.PC);
                            Com.GroupDim(xDim);
                        }

                        pointList = new PointList();
                        pointList.Add(BC.Points.P2);
                        pointList.Add(Com.MinP(TempList, "X"));
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByBottomY(xDim, BC.PC);
                    }

                    // Dim No 14
                    if (DN.DimIDNo14)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.Points.P2);
                        pointList.Add(BC.WP.Points.P3);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByBottomY(xDim, BC.PC);

                    }
                }

                // Dim No 10 Elevation Dim
                if (DN.DimIDNo10)
                {
                    Vect = new Vector(-1, 0, 0);
                    StraightDimensionSet.StraightDimensionSetAttributes ElAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.ElevationDimension);
                    ElAtrr.DimensionType = DimensionSetBaseAttributes.DimensionTypes.Elevation;
                    ElAtrr.Arrowhead.Head = ArrowheadTypes.FilledArrow;
                    pointList = new PointList();

                    if (MainBeam.StartPoint.X > MainBeam.EndPoint.X)
                    {
                        pointList.Add(MainBeam.EndPoint);
                        pointList.Add(MainBeam.EndPoint);

                    }
                    else
                    {
                        pointList.Add(MainBeam.StartPoint);
                        pointList.Add(MainBeam.StartPoint);
                    }

                    BC.PC.DistLeft = BC.PC.DistLeft - (BC.Points.P1.X - pointList[0].X);
                    xDim = dc.InsertDimm(CView, pointList, Vect, (-BC.PC.DistLeft), ElAtrr);
                    if (xDim != null)
                    {
                        xDim.Distance = (-BC.PC.DistLeft);
                        xDim.Modify();
                    }
                    BC.PC.DistLeft += BC.PC.DistInc;

                }



                Vect = new Vector(0, 1, 0);
                // Dim No 15
                if (DN.DimIDNo15)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "X"));
                    pointList.Add(BC.WP.Points.P4);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistInc, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, (BC.PC.DistInc / 2));

                }

                Vect = new Vector(1, 0, 0);

                // Dim No 18, 17
                if (DN.DimIDNo18 || DN.DimIDNo17)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo18)
                        pointList.Add(new Point(BC.WP.Points.P4.X, BC.Points.P5.Y));
                    pointList.Add(BC.WP.Points.P4);
                    if (DN.DimIDNo17)
                        pointList.Add(BC.WP.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistInc, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.WP.Points.P4.X, (BC.PC.DistInc * 1.5));

                }
            }


        }

        private void ApplyDimTypeRight(TSD.View CView)
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(1, 0, 0);
            TSD.PointList TempList = new PointList();
            if (BC.WP != null)
            {
                if (BC.CutTop != null)
                {
                    Vect = new Vector(1, 0, 0);
                    // Dim No 3
                    if (DN.DimIDNo3)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.CutTop.P1);
                        pointList.Add(BC.CutTop.P2);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                    }

                    Vect = new Vector(0, 1, 0);
                    // Dim No 4
                    if (DN.DimIDNo4)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.CutTop.P1);
                        pointList.Add(BC.CutTop.P2);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                    }

                }

                if (BC.CutBott != null)
                {
                    Vect = new Vector(1, 0, 0);
                    // Dim No 6
                    if (DN.DimIDNo6)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.CutBott.P1);
                        pointList.Add(BC.CutBott.P2);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                    }

                    Vect = new Vector(0, -1, 0);
                    // Dim No 7
                    if (DN.DimIDNo7)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.CutBott.P1);
                        pointList.Add(BC.CutBott.P2);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                    }

                }

                //if (DN.DimIDNo4 || BC.CutBott != null || BC.CutTop != null)
                //    BC.PC.DistLeft += BC.PC.DistInc;

                if (DN.DimIDNo7 || BC.CutBott != null)
                    BC.PC.DistBot += BC.PC.DistInc;

                if (DN.DimIDNo4 || BC.CutTop != null)
                    BC.PC.DistTop += BC.PC.DistInc;

                Vect = new Vector(1, 0, 0);
                if (BC.BoltsE != null && BC.BoltsE.Count > 0)
                {

                    // Dim No 2.3
                    if (DN.DimIDNo2Dot3)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.WP.Points.P4);
                        pointList.Add(Com.MaxPofX(BC.BoltsE, "Y", Com.MinP(BC.BoltsE, "X").X));

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                            BC.PC.DistRight += (BC.PC.DistInc / 2);
                        }


                        pointList = new PointList();

                        pointList.Add(Com.MinPofX(BC.BoltsE, "Y", Com.MinP(BC.BoltsE, "X").X));
                        pointList.Add(BC.WP.Points.P3);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                            BC.PC.DistRight += (BC.PC.DistInc);
                        }


                    }

                    // Dim No 2.2
                    if (DN.DimIDNo2Dot2)
                    {
                        if (BC.CutTop != null)
                        {
                            pointList = new PointList();
                            pointList.Add(BC.Points.P4);
                            pointList.Add(Com.MaxPofX(BC.BoltsE, "Y", Com.MinP(BC.BoltsE, "X").X));

                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                            if (xDim != null)
                            {
                                PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                                BC.PC.DistRight += (BC.PC.DistInc / 2);
                            }
                        }

                        if (BC.CutBott != null)
                        {
                            pointList = new PointList();
                            pointList.Add(Com.MinPofX(BC.BoltsE, "Y", Com.MinP(BC.BoltsE, "X").X));
                            pointList.Add(BC.Points.P3);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                            if (xDim != null)
                            {
                                PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                                BC.PC.DistRight += (BC.PC.DistInc);
                            }
                        }
                    }

                    // Dim No 1
                    if (DN.DimIDNo1)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MaxPofX(BC.BoltsE, "Y", Com.MinP(BC.BoltsE, "X").X));
                        pointList.Add(BC.Points.P8);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                    }

                    TempList = dc.ChangePints(BC.BoltsE, CView, Vect);
                    // Dim No 2
                    if (DN.DimIDNo2)
                    {
                        pointList = new PointList();
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByRightX(xDim, BC.PC);
                    }

                    //if (DN.DimIDNo15 || DN.DimIDNo14 || DN.DimIDNo1)
                    //    BC.PC.DistLeft += BC.PC.DistInc;

                    // Dim No 2.1
                    if (DN.DimIDNo2Dot1)
                    {
                        if (TempList.Count > 2)
                        {
                            pointList = new PointList();
                            pointList.AddRange(TempList);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                            if (xDim != null)
                            {
                                PL.DimPlaceByRightX(xDim, BC.PC);
                                Com.GroupDim(xDim);
                            }
                        }
                    }

                    Vect = new Vector(0, 1, 0);
                    TempList = dc.ChangePints(BC.BoltsE, CView, Vect);

                    // Dim No 5.1 // Rd Dim
                    if (DN.DimIDNo5Dot1)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.Points.P4);
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByTopY(xDim, BC.PC);

                        BC.PC.DistTop += BC.PC.DistInc;
                        pointList = new PointList();
                        pointList.Add(BC.Points.P1);
                        pointList.Add(Com.MinP(TempList, "X"));
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                        if (xDim != null)
                            PL.DimPlaceByTopY(xDim, BC.PC);

                    }
                    else if (DN.DimIDNo5)  // Dim No 5
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MaxP(TempList, "X"));
                        pointList.Add(BC.Points.P4);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByTopY(xDim, BC.PC);

                        BC.PC.DistTop += BC.PC.DistInc;
                        pointList = new PointList();
                        pointList.Add(BC.Points.P1);
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                        if (xDim != null)
                            PL.DimPlaceByTopY(xDim, BC.PC);
                    }

                    Vect = new Vector(0, -1, 0);
                    TempList = dc.ChangePints(BC.BoltsE, CView, Vect);

                    // Dim No 5.2
                    if (DN.DimIDNo5Dot2)
                    {

                        pointList = new PointList();
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                            Com.GroupDim(xDim);
                        }

                        pointList = new PointList();
                        pointList.Add(Com.MaxP(TempList, "X"));
                        pointList.Add(BC.Points.P3);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByBottomY(xDim, BC.PC);

                        BC.PC.DistBot += BC.PC.DistInc;
                        pointList = new PointList();
                        pointList.Add(BC.Points.P2);
                        pointList.Add(Com.MinP(TempList, "X"));
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                        if (xDim != null)
                            PL.DimPlaceByBottomY(xDim, BC.PC);

                    }

                    // Dim No 14
                    if (DN.DimIDNo14)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.Points.P3);
                        pointList.Add(BC.WP.Points.P2);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByBottomY(xDim, BC.PC);

                    }
                }


                Vect = new Vector(0, 1, 0);
                // Dim No 15
                if (DN.DimIDNo15)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "X"));
                    pointList.Add(BC.WP.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistInc, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, (BC.PC.DistInc / 2));

                }

                Vect = new Vector(-1, 0, 0);

                // Dim No 18, 17
                if (DN.DimIDNo18 || DN.DimIDNo17)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo18)
                        pointList.Add(new Point(BC.WP.Points.P1.X, BC.Points.P8.Y));
                    pointList.Add(BC.WP.Points.P1);
                    if (DN.DimIDNo17)
                        pointList.Add(BC.WP.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistInc, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.WP.Points.P1.X, (BC.PC.DistInc * 1.5));

                }
            }


        }

        private void AppySectionDim()
        {
            StraightDimensionSet xDim = null;
            PointList pointList = new PointList();
            Vector Vect = new Vector(0, 1, 0);
            PointList TempList = new PointList();

            if (BC.WP != null)
            {
                Vect = new Vector(0, 1, 0);
                PartPoints Points = BC.WP.Points;
                if (DN.DimIDNo9 || DN.DimIDNo9Dot1)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo9)
                        pointList.Add(Points.P1);
                    pointList.Add(MainBeam.StartPoint);
                    if (DN.DimIDNo9Dot1)
                        pointList.Add(Points.P4);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);

                }
            }


        }

        #region Get Data

        private void GetBeamClassClass(TSD.View CView)
        {
            if (ViewName == "Front View")
            {
                BC = new BeamClass_BDP1();
                BC.beam = MainBeam;
                BC.Points = Com.GetPartPoints(MainBeam);
                List<TSM.Part> PartListC = BC.beam.GetAssembly().GetSecondaries().OfType<TSM.Part>().ToList();

                GetEndProperties(PartListC);

                PartListC.Add(MainBeam);

                TSM.Part LeftPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.X ascending select p).FirstOrDefault();
                TSM.Part RightPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.X descending select p).FirstOrDefault();
                TSM.Part TopPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.Y descending select p).FirstOrDefault();
                TSM.Part BottPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.Y ascending select p).FirstOrDefault();

                BC.PC = new PlacingClass();
                BC.PC.TopY = TopPart.GetSolid().MaximumPoint.Y;
                BC.PC.BottomY = BottPart.GetSolid().MinimumPoint.Y;


                BC.PC.LeftX = LeftPart.GetSolid().MinimumPoint.X;// Math.Round(CView.RestrictionBox.MinPoint.X);
                BC.PC.RightX = RightPart.GetSolid().MaximumPoint.X;

                double AvScale = 12;
                double AvDistInc = 100;
                double DistPerScale = AvDistInc / AvScale;
                double CScale = CView.Attributes.Scale;
                BC.PC.DistInc = CScale * DistPerScale;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;
            }
            else if (ViewName == "Section View")
            {
                BC = new BeamClass_BDP1();
                BC.beam = MainBeam;
                BC.Points = Com.GetPartPoints(MainBeam);
                List<TSM.Part> PartListC = BC.beam.GetAssembly().GetSecondaries().OfType<TSM.Part>().ToList();


                double MaxZ = CView.RestrictionBox.MinPoint.Z;
                //List<TSM.Part> PartList = (from p in PartListC where p.GetSolid().MaximumPoint.Z > MaxZ select p).ToList();
                List<TSM.Part> PartList = (from p in PartListC where Com.IsViewObj(p, CView) select p).ToList();
                Point CentP = Com.CenterPoint(MainBeam.StartPoint, MainBeam.EndPoint);

                TSM.Part WebPlate = (from p in PartList where !dc.IsHorzObjN(p) && Com.GetPartProfileType(p) != "L" && dc.IsPlateSideViewN(p) && Com.CenterPoint(p).Y < BC.Points.P1.Y && Com.CenterPoint(p).Y > BC.Points.P2.Y select p).FirstOrDefault();

                if (WebPlate != null)
                    BC.WP = Com.GetPartClass(WebPlate);


                PartListC.Add(MainBeam);
                List<Point> RefPoints = MainBeam.GetReferenceLine(false).OfType<Point>().ToList();

                if (PartList == null || PartList.Count == 0)
                    PartList.Add(MainBeam);

                TSM.Part LeftPart = (from p in PartList orderby p.GetSolid().MinimumPoint.X ascending select p).FirstOrDefault();
                TSM.Part RightPart = (from p in PartList orderby p.GetSolid().MaximumPoint.X descending select p).FirstOrDefault();
                TSM.Part TopPart = (from p in PartList orderby p.GetSolid().MaximumPoint.Y descending select p).FirstOrDefault();
                TSM.Part BottPart = (from p in PartList orderby p.GetSolid().MinimumPoint.Y ascending select p).FirstOrDefault();

                BC.PC = new PlacingClass();
                BC.PC.TopY = TopPart.GetSolid().MaximumPoint.Y;
                BC.PC.BottomY = BottPart.GetSolid().MinimumPoint.Y;
                BC.PC.LeftX = LeftPart.GetSolid().MinimumPoint.X;// Math.Round(CView.RestrictionBox.MinPoint.X);
                BC.PC.RightX = RightPart.GetSolid().MaximumPoint.X;

                double AvScale = 12;
                double AvDistInc = 100;
                double DistPerScale = AvDistInc / AvScale;
                double CScale = CView.Attributes.Scale;
                BC.PC.DistInc = CScale * DistPerScale;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;
            }


        }

        private void GetEndProperties(List<TSM.Part> PartListC)
        {


            Point CentP = Com.CenterPoint(BC.beam.StartPoint, BC.beam.EndPoint);
            double Lenght = (BC.beam.GetSolid().MaximumPoint.X - BC.beam.GetSolid().MinimumPoint.X) / 8;
            double MinX = BC.beam.GetSolid().MinimumPoint.X + Lenght;
            double MaxX = BC.beam.GetSolid().MaximumPoint.X - Lenght;


            TSM.Part WebPlate = null;
            List<BoltGroup> BoltsE = null;
            BooleanPart BoolTop = null;
            BooleanPart BoolBott = null;
            List<BoltGroup> Bolts = Com.EnumtoArray(MainBeam.GetBolts()).OfType<BoltGroup>().ToList();
            List<BooleanPart> Bools = Com.EnumtoArray(MainBeam.GetBooleans()).OfType<BooleanPart>().ToList();

            double BHeigh = Com.GetPartHeight(MainBeam);

            if (Position == "Left")
            {
                WebPlate = (from p in PartListC where Com.GetPartProfileType(p) != "L" && !dc.IsPlateSideViewN(p) && (p.GetSolid().MaximumPoint.X < CentP.X && p.GetSolid().MinimumPoint.X <= MinX) select p).FirstOrDefault();
                if (WebPlate != null)
                {
                    BoltsE = (from p in Bolts where Com.IsBoltPart(p, WebPlate) && (p.GetSolid().MaximumPoint.X < CentP.X && p.GetSolid().MinimumPoint.X <= MinX) select p).ToList();
                    BoolTop = (from p in Bools where (p.OperativePart.GetSolid().MaximumPoint.X < CentP.X && p.OperativePart.GetSolid().MinimumPoint.X <= MinX) && Com.CenterPoint(p.OperativePart).Y > BC.Points.CentP.Y select p).FirstOrDefault();
                    BoolBott = (from p in Bools where (p.OperativePart.GetSolid().MaximumPoint.X < CentP.X && p.OperativePart.GetSolid().MinimumPoint.X <= MinX) && Com.CenterPoint(p.OperativePart).Y < BC.Points.CentP.Y select p).FirstOrDefault();
                }
            }
            else
            {
                WebPlate = (from p in PartListC where Com.GetPartProfileType(p) != "L" && !dc.IsPlateSideViewN(p) && (p.GetSolid().MinimumPoint.X > CentP.X && p.GetSolid().MaximumPoint.X >= MaxX) select p).FirstOrDefault();

                if (WebPlate != null)
                {
                    BoltsE = (from p in Bolts where Com.IsBoltPart(p, WebPlate) && (p.GetSolid().MinimumPoint.X > CentP.X && p.GetSolid().MaximumPoint.X >= MaxX) select p).ToList();
                    BoolTop = (from p in Bools where (p.OperativePart.GetSolid().MinimumPoint.X > CentP.X && p.OperativePart.GetSolid().MaximumPoint.X >= MaxX) && Com.CenterPoint(p.OperativePart).Y > BC.Points.CentP.Y select p).FirstOrDefault();
                    BoolBott = (from p in Bools where (p.OperativePart.GetSolid().MinimumPoint.X > CentP.X && p.OperativePart.GetSolid().MaximumPoint.X >= MaxX) && Com.CenterPoint(p.OperativePart).Y < BC.Points.CentP.Y select p).FirstOrDefault();
                }
            }


            if (WebPlate != null)
                BC.WP = Com.GetPartClass(WebPlate);

            if (BoltsE != null)
                BC.BoltsE = Com.GetBoltPoints(BoltsE);

            BC.Points.P5 = BC.Points.P1;
            BC.Points.P6 = BC.Points.P2;
            BC.Points.P7 = BC.Points.P3;
            BC.Points.P8 = BC.Points.P4;

            if (BoolTop != null)
            {
                BC.CutTop = new CutPoints();
                if (BoolTop.OperativePart is ContourPlate)
                {
                    PointList ContList = dc.ContPList(BoolTop.OperativePart);
                    ContList = ReviseList(ContList, "Top");
                    if (Position == "Left")
                    {
                        BC.CutTop.P1 = Com.MinPofX(ContList, "Y", Com.MinP(ContList, "X").X);
                        BC.CutTop.P2 = Com.MaxPofY(ContList, "X", Com.MaxP(ContList, "Y").Y);
                        if (!Com.IsEqual(BC.CutTop.P1.Y, BC.CutTop.P2.Y))
                        {

                            BC.Points.P1 = BC.CutTop.P1;
                            BC.Points.P5 = BC.CutTop.P2;
                        }
                        else
                            BC.CutTop = null;

                    }
                    else
                    {
                        BC.CutTop.P1 = Com.MinPofX(ContList, "Y", Com.MaxP(ContList, "X").X);
                        BC.CutTop.P2 = Com.MinPofY(ContList, "X", Com.MaxP(ContList, "Y").Y);

                        if (!Com.IsEqual(BC.CutTop.P1.Y, BC.CutTop.P2.Y))
                        {
                            BC.Points.P4 = BC.CutTop.P1;
                            BC.Points.P8 = BC.CutTop.P2;
                        }
                        else
                            BC.CutTop = null;



                    }
                }
            }

            if (BoolBott != null)
            {
                BC.CutBott = new CutPoints();
                if (BoolBott.OperativePart is ContourPlate)
                {
                    PointList ContList = dc.ContPList(BoolBott.OperativePart);
                    ContList = ReviseList(ContList, "Bottom");
                    if (Position == "Left")
                    {
                        BC.CutBott.P1 = Com.MaxPofX(ContList, "Y", Com.MinP(ContList, "X").X);
                        BC.CutBott.P2 = Com.MaxPofY(ContList, "X", Com.MinP(ContList, "Y").Y);

                        if (!Com.IsEqual(BC.CutBott.P1.Y, BC.CutBott.P2.Y))
                        {

                            BC.Points.P2 = BC.CutBott.P1;
                            BC.Points.P6 = BC.CutBott.P2;
                        }
                        else
                            BC.CutBott = null;



                    }
                    else
                    {
                        BC.CutBott.P1 = Com.MaxPofX(ContList, "Y", Com.MaxP(ContList, "X").X);
                        BC.CutBott.P2 = Com.MinPofY(ContList, "X", Com.MinP(ContList, "Y").Y);

                        if (!Com.IsEqual(BC.CutBott.P1.Y, BC.CutBott.P2.Y))
                        {

                            BC.Points.P3 = BC.CutBott.P1;
                            BC.Points.P7 = BC.CutBott.P2;
                        }
                        else
                            BC.CutBott = null;
                    }
                }
            }


        }

        private PointList ReviseList(PointList Plist, string VPos)
        {
            PointList pointList = new PointList();
            if (Plist.Count > 0)
            {
                foreach (Point p in Plist)
                {
                    Point P1 = p;

                    if (VPos == "Top" && P1.Y > BC.Points.P1.Y)
                        P1 = new Point(P1.X, BC.Points.P1.Y);

                    else if (VPos == "Bottom" && P1.Y < BC.Points.P2.Y)
                        P1 = new Point(P1.X, BC.Points.P2.Y);

                    if (Position == "Left" && P1.X < BC.Points.P1.X)
                        P1 = new Point(BC.Points.P1.X, P1.Y);

                    if (Position == "Right" && P1.X > BC.Points.P4.X)
                        P1 = new Point(BC.Points.P4.X, P1.Y);


                    pointList.Add(P1);
                }


            }
            return pointList;
        }

        #endregion

        #region Helping Methods
        private double GetPartWidth(TSM.Part part)
        {
            return (part.GetSolid().MaximumPoint.X - part.GetSolid().MinimumPoint.X);
        }

        #endregion

        private class BeamClass_BDP1
        {
            public Beam beam { get; set; }
            public PartClass WP { get; set; }
            public PointList BoltsE { get; set; }
            public CutPoints CutTop { get; set; }
            public CutPoints CutBott { get; set; }
            public PartPoints Points { get; set; }
            public PlacingClass PC { get; set; }
        }


    }

}
