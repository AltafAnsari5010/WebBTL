﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Tekla.Structures;
using Tekla.Structures.Drawing;
using Tekla.Structures.Geometry3d;
using Tekla.Structures.Model;
using TSD = Tekla.Structures.Drawing;
using TSM = Tekla.Structures.Model;
using VirtueleDrawingAutomation;
using TSDD = Tekla.Structures.Datatype;
using TSG = Tekla.Structures.Geometry3d;

namespace Auto_Detailing_Tool_Beam
{
    public class BeamDim_BSP3
    {
        #region Global Variables
        DimCom dc = new DimCom();
        StraightDimensionSet.StraightDimensionSetAttributes StAtrr = new StraightDimensionSet.StraightDimensionSetAttributes("standard");
        StraightDimensionSet.StraightDimensionSetAttributes RdAtrr = new StraightDimensionSet.StraightDimensionSetAttributes("standard");

        public Beam MainBeam = null;
        VirtueleDrawingAutomation.Json.DrawingAttributeInfoJson.AttributeFiles dimAttrClass = null;
        List<TSD.StraightDimension> KnockDim = new List<StraightDimension>();
        BeamClass_BSP3 BC = null;
        BeamClass_BSP3S BCS = null;
        VirtueleDrawingAutomation.Json.AutoDimensionTypesJson.BSP3Json DN = null;
        string Position = "Left";
        TSD.View CView = null;
        string ViewName = "";
        public Point BoltPS = null;

        #endregion

        public void ApplyDim(TSD.View CView, string ViewName, AutoDimensioningTypes autoDimensioningTypes, DrawingAttributeInfo drawingAttributeInfo, string Position)
        {
            try
            {
                
                Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane());
                //Set model everything to the view
                Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane(CView.DisplayCoordinateSystem));

                this.CView = CView;
                this.dimAttrClass = drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files;
                this.DN = autoDimensioningTypes.BSP3;
                this.Position = Position;
                StAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.StandardDimension);
                RdAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.RunningDimension);
                this.MainBeam = (Com.MyModel.SelectModelObject(new Identifier((CView.GetDrawing() as AssemblyDrawing).AssemblyIdentifier.ID)) as TSM.Assembly).GetMainPart() as TSM.Beam;
                this.MainBeam.Select();
                string ProType = Com.GetProType(MainBeam);
                this.ViewName = ViewName;
                GetBeamClassClass(CView);

                if (Position == "Left")
                {
                    BoltPS = null;
                    //TestDim();
                    if (ViewName == "Front View")
                        ApplyDimTypeLeft(CView);
                    else
                    if (ViewName == "Section View")
                        AppySectionDim();
                }

                else if (Position == "Right")
                {
                    ////TestDim();
                    if (ViewName == "Front View")
                        ApplyDimTypeRight(CView);
                    else
                    if (ViewName == "Section View")
                        AppySectionDim();
                }
            }
            catch (Exception ex)
            { }
            Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane());


        }

        private void ApplyDimTypeLeft(TSD.View CView)
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            TSD.PointList TempList = new PointList();

            if (BC.TopAngle != null)
            {
                TempList.AddRange(BC.TopAngle.BoltPList);
                Vect = new Vector(0, 1, 0);

                // Dim No 4.1
                if (DN.DimIDNo4Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "X"));
                    pointList.Add(BC.TopAngle.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                }

                // Dim No 4
                if (DN.DimIDNo4)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                }

                // Dim No 4.3
                if (DN.DimIDNo4Dot3)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "X"));
                    if (BC.TopAngle.CutPoints != null)
                        pointList.Add(BC.TopAngle.CutPoints.P4);
                    else
                        pointList.Add(BC.TopAngle.Points.P4);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                }

                if (DN.DimIDNo4 || DN.DimIDNo4Dot1 || DN.DimIDNo4Dot3)
                    BC.PC.DistTop += BC.PC.DistInc;


                // Dim No 4.2
                if (DN.DimIDNo4Dot2 && TempList.Count > 2)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        Com.GroupDim(xDim);
                    }
                }

                // Dim No 8
                if (DN.DimIDNo8 && BC.TopAngle.CutPoints != null)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopAngle.CutPoints.P4);
                    pointList.Add(BC.TopAngle.CutPoints.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        Com.SetRightUpperDimText(xDim, "NO WELD {5} (T&B)");
                        Com.SetRightLowerDimText(xDim, "SEE GRAPHIC NO.1");
                        StAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.StandardDimension);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }

                Vect = new Vector(-1, 0, 0);

                // Dim No 1
                if (DN.DimIDNo1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "X"));
                    pointList.Add(BC.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByLeftX(xDim, BC.PC);
                }

                // Dim No 2
                if (DN.DimIDNo2 && BC.MidAngle != null)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "X"));
                    pointList.Add(Com.MaxP(BC.MidAngle.BoltPList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByLeftX(xDim, BC.PC);
                }

            }

            if (BC.BottAngle != null)
            {
                BC.PC.DistLeft = BC.PC.DistInc;
                TempList = new PointList();
                TempList.AddRange(BC.BottAngle.BoltPList);

                Vect = new Vector(0, -1, 0);

                // Dim No 4.1
                if (DN.DimIDNo4Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "X"));
                    pointList.Add(BC.BottAngle.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                }

                // Dim No 4
                if (DN.DimIDNo4)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                }

                // Dim No 4.3
                if (DN.DimIDNo4Dot3)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "X"));
                    if (BC.BottAngle.CutPoints != null)
                        pointList.Add(BC.BottAngle.CutPoints.P4);
                    else
                        pointList.Add(BC.BottAngle.Points.P3);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                }

                if (DN.DimIDNo4 || DN.DimIDNo4Dot1 || DN.DimIDNo4Dot3)
                    BC.PC.DistBot += BC.PC.DistInc;


                // Dim No 4.2
                if (DN.DimIDNo4Dot2 && TempList.Count > 2)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        Com.GroupDim(xDim);

                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }

                // Dim No 5
                if (DN.DimIDNo5 && BC.SurfPoints != null)
                {
                    pointList = new PointList();
                    pointList.Add(BC.SurfPoints.P2);
                    pointList.Add(BC.SurfPoints.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        Com.SetRightUpperDimText(xDim, "PROTECTED ZONE");
                        Com.SetRightLowerDimText(xDim, "ALL AROUND");
                        StAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.StandardDimension);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }

                Vect = new Vector(-1, 0, 0);

                // Dim No 1
                if (DN.DimIDNo1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "X"));
                    pointList.Add(BC.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByLeftX(xDim, BC.PC);
                }

                // Dim No 2
                if (DN.DimIDNo2 && BC.MidAngle != null)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "X"));
                    pointList.Add(Com.MinP(BC.MidAngle.BoltPList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByLeftX(xDim, BC.PC);
                }


                // Dim No 20
                if (DN.DimIDNo20)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "X"));
                    pointList.Add(BC.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByLeftX(xDim, BC.PC);
                }

                // Dim No 3
                if (DN.DimIDNo3 && BC.TopAngle != null)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "X"));
                    pointList.Add(Com.MaxP(BC.TopAngle.BoltPList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByLeftX(xDim, BC.PC);
                }
            }

            // Dim No 14 Elevation Dim
            if (DN.DimIDNo14)
            {


                Vect = new Vector(-1, 0, 0);
                StraightDimensionSet.StraightDimensionSetAttributes ElAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.ElevationDimension);
                ElAtrr.DimensionType = DimensionSetBaseAttributes.DimensionTypes.Elevation;
                ElAtrr.Arrowhead.Head = ArrowheadTypes.FilledArrow;
                pointList = new PointList();

                if (MainBeam.StartPoint.X > MainBeam.EndPoint.X)
                {
                    pointList.Add(MainBeam.EndPoint);
                    pointList.Add(MainBeam.EndPoint);

                }
                else
                {
                    pointList.Add(MainBeam.StartPoint);
                    pointList.Add(MainBeam.StartPoint);
                }

                BC.PC.DistLeft = BC.PC.DistLeft - (BC.Points.P1.X - pointList[0].X);
                xDim = dc.InsertDimm(CView, pointList, Vect, (-BC.PC.DistLeft), ElAtrr);
                if (xDim != null)
                {
                    xDim.Distance = (-BC.PC.DistLeft);
                    xDim.Modify();
                }
                BC.PC.DistLeft += BC.PC.DistInc;

            }

            if (BC.MidAngle != null)
            {
                BC.PC.DistLeft = BC.PC.DistInc;
                TempList = new PointList();
                TempList.AddRange(BC.MidAngle.BoltPList);
                BoltPS = Com.MaxP(TempList, "X");
                Vect = new Vector(0, 1, 0);

                // Dim No 22,22.1
                if (DN.DimIDNo22 || DN.DimIDNo22Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "Y"));

                    if (DN.DimIDNo22) // Dim No 22
                        pointList.Add(new Point(BC.MidAngle.Points.P1.X, Com.MaxP(TempList, "Y").Y));

                    if (DN.DimIDNo22Dot1) // Dim No 22.1
                        pointList.Add(new Point(BC.MidAngle.Points.P4.X, Com.MaxP(TempList, "Y").Y));

                    xDim = dc.InsertDim(CView, pointList, Vect, 0, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.MidAngle.Points.P1.Y, 0);

                }

                Vect = new Vector(-1, 0, 0);
                BC.PC.DistLeft = (BC.PC.DistInc * 1.5);
                // Dim No 7
                if (DN.DimIDNo7)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    pointList.Add(new Point(pointList[0].X, BC.Points.P1.Y));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.MidAngle.Points.P1.X, BC.PC.DistLeft);
                }

                // Dim No 6
                if (DN.DimIDNo6)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.MidAngle.Points.P1.X, BC.PC.DistLeft);
                }

                // Dim No 6.1
                if (DN.DimIDNo6Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "Y"));
                    pointList.Add(new Point(pointList[0].X, BC.Points.P2.Y));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.MidAngle.Points.P1.X, BC.PC.DistLeft);
                }


                Vect = new Vector(1, 0, 0);
                double RightX = BC.MidAngle.Points.P4.X;
                if (BC.TopAngle != null)
                    RightX = BC.TopAngle.Points.P4.X;

                // Dim No 21,21.1
                if (DN.DimIDNo21 || DN.DimIDNo21Dot1)
                {
                    pointList = new PointList();

                    if (DN.DimIDNo21Dot1) // Dim No 22
                        pointList.Add(new Point(BC.MidAngle.Points.P4.X, BC.Points.P1.Y));

                    pointList.Add(BC.MidAngle.Points.P4);

                    if (DN.DimIDNo22Dot1) // Dim No 22.1
                        pointList.Add(BC.MidAngle.Points.P3);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, RightX, BC.PC.DistLeft);

                }

                Vect = new Vector(0, -1, 0);

                // Dim No 9.3, 9.4 RD Dim
                if (DN.DimIDNo9Dot3 || DN.DimIDNo9Dot4)
                {
                    if (DN.DimIDNo9Dot3)
                        BC.PC.DistBot += BC.PC.DistInc;

                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);

                }

            }

            
            // Dim No 9.2
            if ((DN.DimIDNo9Dot2) && BC.SurfPoints != null)
            {
                pointList = new PointList();
                pointList.Add(BC.Points.P2);
                pointList.Add(BC.SurfPoints.P2);
                xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                if (xDim != null)
                    PL.DimPlaceByBottomY(xDim, BC.PC);
            }

            if (BC.SC != null)
            {
                Vect = new Vector(0, 1, 0);

                // Dim No 9, 9.1 RD Dim
                if (DN.DimIDNo9 || DN.DimIDNo9Dot1)
                {
                    if (DN.DimIDNo9)
                        BC.PC.DistTop += BC.PC.DistInc;

                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(BC.SC.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);

                }
            }
        }

        private void ApplyDimTypeRight(TSD.View CView)
        {

            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            TSD.PointList TempList = new PointList();

            if (BC.TopAngle != null)
            {
                TempList.AddRange(BC.TopAngle.BoltPList);
                Vect = new Vector(0, 1, 0);

                // Dim No 4.1
                if (DN.DimIDNo4Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "X"));
                    pointList.Add(BC.TopAngle.Points.P4);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                }

                // Dim No 4
                if (DN.DimIDNo4)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                }

                // Dim No 4.3
                if (DN.DimIDNo4Dot3)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "X"));
                    if (BC.TopAngle.CutPoints != null)
                        pointList.Add(BC.TopAngle.CutPoints.P4);
                    else
                        pointList.Add(BC.TopAngle.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                }

                if (DN.DimIDNo4 || DN.DimIDNo4Dot1 || DN.DimIDNo4Dot3)
                    BC.PC.DistTop += BC.PC.DistInc;


                // Dim No 4.2
                if (DN.DimIDNo4Dot2 && TempList.Count > 2)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        Com.GroupDim(xDim);
                    }
                }

                // Dim No 8
                if (DN.DimIDNo8 && BC.TopAngle.CutPoints!=null)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopAngle.CutPoints.P4);
                    pointList.Add(BC.TopAngle.CutPoints.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        Com.SetLeftUpperDimText(xDim, "NO WELD {5} (T&B)");
                        Com.SetLeftLowerDimText(xDim, "SEE GRAPHIC NO.1");
                        StAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.StandardDimension);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }

                // Dim No 9.3, 9.4 RD Dim
                if (DN.DimIDNo9Dot3 || DN.DimIDNo9Dot4)
                {
                    if (DN.DimIDNo9Dot3)
                        BC.PC.DistTop += BC.PC.DistInc;

                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(Com.MinP(TempList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);

                }

                Vect = new Vector(1, 0, 0);

                // Dim No 1
                if (DN.DimIDNo1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "X"));
                    pointList.Add(BC.Points.P4);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByRightX(xDim, BC.PC);
                }

                // Dim No 2
                if (DN.DimIDNo2 && BC.MidAngle != null)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "X"));
                    pointList.Add(Com.MaxP(BC.MidAngle.BoltPList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByRightX(xDim, BC.PC);
                }

            }

            if (BC.BottAngle != null)
            {
                BC.PC.DistRight = BC.PC.DistInc;
                TempList = new PointList();
                TempList.AddRange(BC.BottAngle.BoltPList);
                Vect = new Vector(0, -1, 0);

                // Dim No 4.1
                if (DN.DimIDNo4Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "X"));
                    pointList.Add(BC.BottAngle.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                }

                // Dim No 4
                if (DN.DimIDNo4)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                }

                // Dim No 4.3
                if (DN.DimIDNo4Dot3)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "X"));
                    if(BC.BottAngle.CutPoints!=null)
                    pointList.Add(BC.BottAngle.CutPoints.P4);
                    else
                        pointList.Add(BC.BottAngle.Points.P2);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                }


                if (DN.DimIDNo4 || DN.DimIDNo4Dot1 || DN.DimIDNo4Dot3)
                    BC.PC.DistBot += BC.PC.DistInc;


                // Dim No 4.2
                if (DN.DimIDNo4Dot2)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        Com.GroupDim(xDim);

                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }

                // Dim No 5
                if (DN.DimIDNo5 && BC.SurfPoints != null)
                {
                    pointList = new PointList();
                    pointList.Add(BC.SurfPoints.P2);
                    pointList.Add(BC.SurfPoints.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        Com.SetLeftUpperDimText(xDim, "PROTECTED ZONE");
                        Com.SetLeftLowerDimText(xDim, "ALL AROUND");
                        StAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.StandardDimension);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }


                Vect = new Vector(1, 0, 0);

                // Dim No 1
                if (DN.DimIDNo1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "X"));
                    pointList.Add(BC.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByRightX(xDim, BC.PC);
                }

                // Dim No 2
                if (DN.DimIDNo2 && BC.MidAngle != null)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "X"));
                    pointList.Add(Com.MinP(BC.MidAngle.BoltPList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByRightX(xDim, BC.PC);
                }


                // Dim No 20
                if (DN.DimIDNo20)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "X"));
                    pointList.Add(BC.Points.P4);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByRightX(xDim, BC.PC);
                }

                // Dim No 3
                if (DN.DimIDNo3 && BC.TopAngle != null)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "X"));
                    pointList.Add(Com.MinP(BC.TopAngle.BoltPList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByRightX(xDim, BC.PC);
                }
            }

            if (BC.MidAngle != null)
            {
                BC.PC.DistRight = BC.PC.DistInc;
                TempList = new PointList();
                TempList.AddRange(BC.MidAngle.BoltPList);
                Vect = new Vector(0, 1, 0);

                // Dim No 22,22.1
                if (DN.DimIDNo22 || DN.DimIDNo22Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "Y"));

                    if (DN.DimIDNo22) // Dim No 22
                        pointList.Add(new Point(BC.MidAngle.Points.P1.X, Com.MaxP(TempList, "Y").Y));

                    if (DN.DimIDNo22Dot1) // Dim No 22.1
                        pointList.Add(new Point(BC.MidAngle.Points.P4.X, Com.MaxP(TempList, "Y").Y));

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistInc, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.MidAngle.Points.P4.Y, 0);
                }

                Vect = new Vector(1, 0, 0);
                BC.PC.DistRight = (BC.PC.DistInc * 1.5);
                // Dim No 7
                if (DN.DimIDNo7)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    pointList.Add(new Point(pointList[0].X, BC.Points.P1.Y));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.MidAngle.Points.P4.X, BC.PC.DistRight);
                }

                // Dim No 6
                if (DN.DimIDNo6)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.MidAngle.Points.P4.X, BC.PC.DistRight);
                }

                // Dim No 6.1
                if (DN.DimIDNo6Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "Y"));
                    pointList.Add(new Point(pointList[0].X, BC.Points.P2.Y));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.MidAngle.Points.P4.X, BC.PC.DistRight);
                }

                Vect = new Vector(-1, 0, 0);
                double LeftX = BC.MidAngle.Points.P1.X;
                if (BC.TopAngle != null)
                    LeftX = BC.TopAngle.Points.P1.X;

                // Dim No 21,21.1
                if (DN.DimIDNo21 || DN.DimIDNo21Dot1)
                {
                    pointList = new PointList();

                    if (DN.DimIDNo21Dot1) // Dim No 22
                        pointList.Add(new Point(BC.MidAngle.Points.P1.X, BC.Points.P1.Y));

                    pointList.Add(BC.MidAngle.Points.P1);

                    if (DN.DimIDNo22Dot1) // Dim No 22.1
                        pointList.Add(BC.MidAngle.Points.P2);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, LeftX, BC.PC.DistRight);

                }

                Vect = new Vector(0, -1, 0);

                // Dim No 10
                if (DN.DimIDNo10 && BoltPS != null)
                {
                    pointList = new PointList();
                    pointList.Add(BoltPS);
                    pointList.Add(Com.MinP(TempList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }


                // Dim No 9.3, 9.4 RD Dim
                if (DN.DimIDNo9Dot3 || DN.DimIDNo9Dot4)
                {
                    if (DN.DimIDNo9Dot3)
                        BC.PC.DistBot += BC.PC.DistInc;

                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);

                }

            }


            if (BC.BottAngle != null && DN.DimIDNo9Dot4)
            {
                bool Check = true;
                Point P1 = Com.MinP(BC.BottAngle.BoltPList, "X");
                if (BC.MidAngle?.BoltPList?.Count > 0)
                {
                    Point P2 = Com.MinP(BC.MidAngle.BoltPList, "X");
                    if (dc.IsEqual(P1.X, P2.X))
                        Check = false;
                }

                if (Check)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);
                }
            }

            Vect = new Vector(0, -1, 0);

            // Dim No 9.5 RD Dim
            if (DN.DimIDNo9Dot5 && BC.SurfPoints != null)
            {
                pointList = new PointList();
                pointList.Add(BC.Points.P1);
                pointList.Add(BC.SurfPoints.P2);
                xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                if (xDim != null)
                    PL.DimPlaceByBottomY(xDim, BC.PC);

            }

            if (BC.SC != null)
            {
                Vect = new Vector(0, 1, 0);

                // Dim No 9, 9.1 RD Dim
                if (DN.DimIDNo9 || DN.DimIDNo9Dot1)
                {
                    if (DN.DimIDNo9)
                        BC.PC.DistTop += BC.PC.DistInc;

                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(BC.SC.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);

                }
            }
        }

        private void AppySectionDim()
        {
            StraightDimensionSet xDim = null;
            PointList pointList = new PointList();
            Vector Vect = new Vector(0, 1, 0);

            if (BCS.SCL != null && BCS.SCR != null)
            {
                if (BCS.TopAR != null)
                {

                    // Dim No 17, 18
                    if (DN.DimIDNo17 || DN.DimIDNo18)
                    {
                        pointList = new PointList();
                        if (DN.DimIDNo18) // Dim No 18
                            pointList.Add(BCS.TopAR.Points.P1);

                        pointList.Add(BCS.SCR.Points.P4);

                        if (DN.DimIDNo17) // Dim No 17
                            pointList.Add(BCS.TopAR.Points.P4);
                        xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByTopY(xDim, BCS.PC);
                    }

                    // Dim No 23
                    if (DN.DimIDNo23)
                    {
                        pointList = new PointList();
                        pointList.Add(MainBeam.StartPoint);
                        pointList.Add(BCS.TopAR.Points.P4);
                        xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByTopY(xDim, BCS.PC);
                    }

                    // Dim No 19
                    if (DN.DimIDNo19)
                    {
                        pointList = new PointList();
                        pointList.Add(BCS.TopAR.Points.P1);
                        pointList.Add(BCS.TopAR.Points.P4);
                        xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByTopY(xDim, BCS.PC);
                    }

                    // Dim No 16
                    if (DN.DimIDNo16)
                    {
                        pointList = new PointList();
                        pointList.Add(BCS.TopAR.Points.P1);
                        pointList.Add(MainBeam.StartPoint);
                        xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByTopY(xDim, BCS.PC);
                    }
                }

                if (BCS.TopAL != null)
                {
                    BCS.PC.DistTop = BCS.PC.DistInc;

                    if (DN.DimIDNo17 || DN.DimIDNo18)
                    {
                        pointList = new PointList();
                        if (DN.DimIDNo18) // Dim No 18
                            pointList.Add(BCS.TopAL.Points.P1);

                        pointList.Add(BCS.SCL.Points.P1);
                       // pointList.Add(BCS.TopAL.Points.P5);

                        if (DN.DimIDNo17) // Dim No 17
                            pointList.Add(BCS.TopAL.Points.P4);
                        xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByTopY(xDim, BCS.PC);
                    }

                    // Dim No 23
                    if (DN.DimIDNo23)
                    {
                        pointList = new PointList();
                        pointList.Add(MainBeam.StartPoint);
                        pointList.Add(BCS.TopAL.Points.P4);
                        xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByTopY(xDim, BCS.PC);
                    }

                    // Dim No 19
                    if (DN.DimIDNo19)
                    {
                        pointList = new PointList();
                        pointList.Add(BCS.TopAL.Points.P1);
                        pointList.Add(BCS.TopAL.Points.P4);
                        xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByTopY(xDim, BCS.PC);
                    }

                    // Dim No 16
                    if (DN.DimIDNo16)
                    {
                        pointList = new PointList();
                        pointList.Add(BCS.TopAL.Points.P1);
                        pointList.Add(MainBeam.StartPoint);
                        xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByTopY(xDim, BCS.PC);
                    }
                }

                if (BCS.TopAR != null && BCS.TopAL != null && DN.DimIDNo15)
                {
                    pointList = new PointList();
                    pointList.Add(BCS.TopAR.Points.P1);
                    pointList.Add(BCS.TopAL.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BCS.PC);
                }

                Vect = new Vector(0, -1, 0);
                if (BCS.BottAR != null)
                {

                    // Dim No 19
                    if (DN.DimIDNo19)
                    {
                        pointList = new PointList();
                        pointList.Add(BCS.BottAR.Points.P1);
                        pointList.Add(BCS.BottAR.Points.P4);
                        xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistBot, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByBottomY(xDim, BCS.PC);
                    }

                    // Dim No 16
                    if (DN.DimIDNo16)
                    {
                        pointList = new PointList();
                        pointList.Add(BCS.BottAR.Points.P1);
                        pointList.Add(MainBeam.StartPoint);
                        xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistBot, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByBottomY(xDim, BCS.PC);
                    }
                }

                if (BCS.BottAL != null)
                {
                    BCS.PC.DistBot = BCS.PC.DistInc;

                    // Dim No 19
                    if (DN.DimIDNo19)
                    {
                        pointList = new PointList();
                        pointList.Add(BCS.BottAL.Points.P1);
                        pointList.Add(BCS.BottAL.Points.P4);
                        xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistBot, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByBottomY(xDim, BCS.PC);
                    }

                    // Dim No 16
                    if (DN.DimIDNo16)
                    {
                        pointList = new PointList();
                        pointList.Add(BCS.BottAL.Points.P1);
                        pointList.Add(MainBeam.StartPoint);
                        xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistBot, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByBottomY(xDim, BCS.PC);
                    }
                }

                if (BCS.BottAR != null && BCS.BottAL != null && DN.DimIDNo15)
                {
                    pointList = new PointList();
                    pointList.Add(BCS.BottAR.Points.P1);
                    pointList.Add(BCS.BottAL.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BCS.PC);
                }

                if (BCS.SCR != null)
                {
                    Vect = new Vector(1, 0, 0);
                    // Dim No 24.1
                    if (DN.DimIDNo24Dot1)
                    {
                        pointList = new PointList();
                        pointList.Add(BCS.SCR.Points.P4);
                        pointList.Add(BCS.Points.P4);
                        xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistRight, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceRightP(xDim, BCS.PC.RightX, BCS.PC.DistRight);

                        pointList = new PointList();
                        pointList.Add(BCS.SCR.Points.P3);
                        pointList.Add(BCS.Points.P3);
                        xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistRight, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceRightP(xDim, BCS.PC.RightX, BCS.PC.DistRight);
                    }

                    // Dim No 24
                    if (DN.DimIDNo24)
                    {
                        pointList = new PointList();
                        pointList.Add(BCS.SCR.Points.P4);
                        pointList.Add(BCS.SCR.Points.P3);
                        xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistRight, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceRightP(xDim, BCS.PC.RightX, BCS.PC.DistRight);
                    }
                }

                else if (BCS.SCL != null)
                {
                    Vect = new Vector(-1, 0, 0);
                    // Dim No 24.1
                    if (DN.DimIDNo24Dot1)
                    {
                        pointList = new PointList();
                        pointList.Add(BCS.SCL.Points.P1);
                        pointList.Add(BCS.Points.P1);
                        xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistLeft, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceLeftP(xDim, BCS.PC.LeftX, BCS.PC.DistLeft);

                        pointList = new PointList();
                        pointList.Add(BCS.SCR.Points.P2);
                        pointList.Add(BCS.Points.P2);
                        xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistLeft, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceLeftP(xDim, BCS.PC.LeftX, BCS.PC.DistLeft);
                    }

                    // Dim No 24
                    if (DN.DimIDNo24)
                    {
                        pointList = new PointList();
                        pointList.Add(BCS.SCR.Points.P1);
                        pointList.Add(BCS.SCR.Points.P2);
                        xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistLeft, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceLeftP(xDim, BCS.PC.LeftX, BCS.PC.DistLeft);
                    }
                }

                if (BCS.TopAR != null && BCS.BottAR != null)
                    Com.DrawLine(CView, BCS.TopAR.Points.P2, BCS.BottAR.Points.P2);

                if (BCS.TopAL != null && BCS.BottAL != null)
                    Com.DrawLine(CView, BCS.TopAL.Points.P2, BCS.BottAL.Points.P2);

            }




        }

        #region Get Data

        private void GetBeamClassClass(TSD.View CView)
        {
            if (ViewName == "Front View")
            {
                BC = new BeamClass_BSP3();
                BC.beam = MainBeam;
                BC.Points = Com.GetPartPoints(MainBeam);
                List<TSM.Part> PartListC = BC.beam.GetAssembly().GetSecondaries().OfType<TSM.Part>().ToList();

                BC.SurfPoints = GetSurfPoints();
                GetAngleProperties(PartListC);


                PartListC.Add(MainBeam);
                List<Point> RefPoints = MainBeam.GetReferenceLine(false).OfType<Point>().ToList();

                double MinXP = (from p in RefPoints orderby p.X ascending select p.X).FirstOrDefault();
                double MaxXP = (from p in RefPoints orderby p.X descending select p.X).FirstOrDefault();

                MinXP -= 100;
                MaxXP += 100;

                TSM.Part LeftPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.X ascending select p).FirstOrDefault();
                TSM.Part RightPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.X descending select p).FirstOrDefault();
                TSM.Part TopPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.Y descending select p).FirstOrDefault();
                TSM.Part BottPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.Y ascending select p).FirstOrDefault();

                BC.PC = new PlacingClass();
                BC.PC.TopY = TopPart.GetSolid().MaximumPoint.Y;
                BC.PC.BottomY = BottPart.GetSolid().MinimumPoint.Y;


                BC.PC.LeftX = LeftPart.GetSolid().MinimumPoint.X;// Math.Round(CView.RestrictionBox.MinPoint.X);
                BC.PC.RightX = RightPart.GetSolid().MaximumPoint.X;


                double AvScale = 12;
                double AvDistInc = 100;
                double DistPerScale = AvDistInc / AvScale;
                double CScale = CView.Attributes.Scale;
                BC.PC.DistInc = CScale * DistPerScale;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;
            }
            else if (ViewName == "Section View")
            {
                BCS = new BeamClass_BSP3S();
                BCS.Points = Com.GetPartPoints(MainBeam);
                List<TSM.Part> PartListC = MainBeam.GetAssembly().GetSecondaries().OfType<TSM.Part>().ToList();

                double MinZ = CView.RestrictionBox.MinPoint.Z;
                double MaxZ = CView.RestrictionBox.MaxPoint.Z;
                List<TSM.Part> PartList = (from p in PartListC where Com.IsViewObj(p, CView) select p).ToList();
                Point CentP = Com.CenterPoint(MainBeam.StartPoint, MainBeam.EndPoint);

                List<TSM.Part> PartListF = (from p in PartList where !Com.IsCode(p) select p).ToList();


                Beam TopAL = (from p in PartListF.OfType<Beam>() where Com.GetProType(p) == "L" && (Com.CenterPoint(p).X < BCS.Points.CentP.X) && (Com.CenterPoint(p).Y > BCS.Points.P1.Y) select p).FirstOrDefault();
                Beam TopAR = (from p in PartListF.OfType<Beam>() where Com.GetProType(p) == "L" && (Com.CenterPoint(p).X > BCS.Points.CentP.X) && (Com.CenterPoint(p).Y > BCS.Points.P1.Y) select p).FirstOrDefault();

                Beam BottAL = (from p in PartListF.OfType<Beam>() where Com.GetProType(p) == "L" && (Com.CenterPoint(p).X < BCS.Points.CentP.X) && (Com.CenterPoint(p).Y < BCS.Points.P2.Y) select p).FirstOrDefault();
                Beam BottAR = (from p in PartListF.OfType<Beam>() where Com.GetProType(p) == "L" && (Com.CenterPoint(p).X > BCS.Points.CentP.X) && (Com.CenterPoint(p).Y < BCS.Points.P2.Y) select p).FirstOrDefault();

                Beam MidAL = (from p in PartListF.OfType<Beam>() where Com.GetProType(p) == "L" && (Com.CenterPoint(p).X < BCS.Points.CentP.X) && (Com.CenterPoint(p).Y > BCS.Points.P2.Y && Com.CenterPoint(p).Y < BCS.Points.P1.Y) && IsAngleMianView(p) select p).FirstOrDefault();
                Beam MidAR = (from p in PartListF.OfType<Beam>() where Com.GetProType(p) == "L" && (Com.CenterPoint(p).X > BCS.Points.CentP.X) && (Com.CenterPoint(p).Y > BCS.Points.P2.Y && Com.CenterPoint(p).Y < BCS.Points.P1.Y) && IsAngleMianView(p) select p).FirstOrDefault();


                TSM.Part SCL = (from p in PartListF.OfType<TSM.Part>() where Com.GetProType(p) != "L" && (Com.CenterPoint(p).X < BCS.Points.CentP.X) && (Com.CenterPoint(p).Y > BCS.Points.P2.Y && Com.CenterPoint(p).Y < BCS.Points.P1.Y) && !dc.IsHorzObjN(p) select p).FirstOrDefault();
                TSM.Part SCR = (from p in PartListF.OfType<TSM.Part>() where Com.GetProType(p) != "L" && (Com.CenterPoint(p).X > BCS.Points.CentP.X) && (Com.CenterPoint(p).Y > BCS.Points.P2.Y && Com.CenterPoint(p).Y < BCS.Points.P1.Y) && !dc.IsHorzObjN(p) select p).FirstOrDefault();

                if (TopAL != null)
                    BCS.TopAL = GetAngleClassS(TopAL, "Top", "Left");
                if (TopAR != null)
                    BCS.TopAR = GetAngleClassS(TopAR, "Top", "Right");

                if (BottAL != null)
                    BCS.BottAL = GetAngleClassS(BottAL, "Bottom", "Left");
                if (BottAR != null)
                    BCS.BottAR = GetAngleClassS(BottAR, "Bottom", "Right");

                if (MidAL != null)
                    BCS.MidAL = GetAngleClassS(MidAL, "Middle", "Left");
                if (MidAR != null)
                    BCS.MidAR = GetAngleClassS(MidAR, "Middle", "Right");

                if (SCL != null)
                {
                    BCS.SCL = new StiffClass();
                    BCS.SCL.Stiff = SCL;
                    BCS.SCL.Points = Com.GetPartPoints(SCL);
                }

                if (SCR != null)
                {
                    BCS.SCR = new StiffClass();
                    BCS.SCR.Stiff = SCR;
                    BCS.SCR.Points = Com.GetPartPoints(SCR);
                }

                TSM.Part LeftPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.X ascending select p).FirstOrDefault();
                TSM.Part RightPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.X descending select p).FirstOrDefault();
                TSM.Part TopPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.Y descending select p).FirstOrDefault();
                TSM.Part BottPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.Y ascending select p).FirstOrDefault();

                BCS.PC = new PlacingClass();
                BCS.PC.TopY = TopPart.GetSolid().MaximumPoint.Y;
                BCS.PC.BottomY = BottPart.GetSolid().MinimumPoint.Y;


                BCS.PC.LeftX = LeftPart.GetSolid().MinimumPoint.X;// Math.Round(CView.RestrictionBox.MinPoint.X);
                BCS.PC.RightX = RightPart.GetSolid().MaximumPoint.X;


                double AvScale = 12;
                double AvDistInc = 100;
                double DistPerScale = AvDistInc / AvScale;
                double CScale = CView.Attributes.Scale;
                BCS.PC.DistInc = CScale * DistPerScale;
                BCS.PC.DistBot = BCS.PC.DistInc;
                BCS.PC.DistTop = BCS.PC.DistInc;
                BCS.PC.DistLeft = BCS.PC.DistInc;
                BCS.PC.DistRight = BCS.PC.DistInc;
            }

        }

        private bool IsAngleMianView(Beam Angle)
        {

            Point P1 = new Point(Angle.StartPoint.X, Angle.StartPoint.Y);
            Point P2 = new Point(Angle.EndPoint.X, Angle.EndPoint.Y);

            double Dist = Distance.PointToPoint(P1, P2);

            if (Dist > 10)
                return true;
            else
                return false;
        }

        private void GetAngleProperties(List<TSM.Part> PartListC)
        {
            Beam TopAng = null;
            Beam MidAng = null;
            Beam BottAng = null;
            Point CentP = Com.CenterPoint(BC.beam.StartPoint, BC.beam.EndPoint);
            double Lenght = (BC.beam.GetSolid().MaximumPoint.X - BC.beam.GetSolid().MinimumPoint.X) / 8;
            double MinX = BC.beam.GetSolid().MinimumPoint.X + Lenght;
            double MaxX = BC.beam.GetSolid().MaximumPoint.X - Lenght;

            if (Position == "Left")
            {
                TopAng = (from p in PartListC.OfType<Beam>() where dc.IsHorzObjN(p) && (p.GetSolid().MaximumPoint.X < CentP.X && p.GetSolid().MinimumPoint.X <= MinX) && (Com.CenterPoint(p).Y > BC.Points.P1.Y) select p).FirstOrDefault();
                BottAng = (from p in PartListC.OfType<Beam>() where dc.IsHorzObjN(p) && (p.GetSolid().MaximumPoint.X < CentP.X && p.GetSolid().MinimumPoint.X <= MinX) && (Com.CenterPoint(p).Y < BC.Points.P2.Y) select p).FirstOrDefault();

                if (TopAng != null)
                    MinX = TopAng.GetSolid().MaximumPoint.X;
                else if (BottAng != null)
                    MinX = BottAng.GetSolid().MaximumPoint.X;

                MidAng = (from p in PartListC.OfType<Beam>() where !dc.IsHorzObjN(p) && (p.GetSolid().MinimumPoint.X < CentP.X && p.GetSolid().MinimumPoint.X <= MinX) && (Com.CenterPoint(p).Y > BC.Points.P2.Y && Com.CenterPoint(p).Y < BC.Points.P1.Y) select p).FirstOrDefault();
            }
            else
            {

                TopAng = (from p in PartListC.OfType<Beam>() where dc.IsHorzObjN(p) && (p.GetSolid().MinimumPoint.X > CentP.X && p.GetSolid().MaximumPoint.X >= MaxX) && (Com.CenterPoint(p).Y > BC.Points.P1.Y) select p).FirstOrDefault();
                BottAng = (from p in PartListC.OfType<Beam>() where dc.IsHorzObjN(p) && (p.GetSolid().MinimumPoint.X > CentP.X && p.GetSolid().MaximumPoint.X >= MaxX) && (Com.CenterPoint(p).Y < BC.Points.P2.Y) select p).FirstOrDefault();

                if (TopAng != null)
                    MaxX = TopAng.GetSolid().MinimumPoint.X;
                else if (BottAng != null)
                    MaxX = BottAng.GetSolid().MinimumPoint.X;

                MidAng = (from p in PartListC.OfType<Beam>() where !dc.IsHorzObjN(p) && (p.GetSolid().MinimumPoint.X > CentP.X && p.GetSolid().MaximumPoint.X >= MaxX) && (Com.CenterPoint(p).Y > BC.Points.P2.Y && Com.CenterPoint(p).Y < BC.Points.P1.Y) select p).FirstOrDefault();
            }

            if (TopAng != null)
                BC.TopAngle = GetAngleClass(TopAng, "Top");

            if (BottAng != null)
                BC.BottAngle = GetAngleClass(BottAng, "Bottom");

            if (MidAng != null)
            {
                BC.MidAngle = GetAngleClass(MidAng, "Middle");

                TSM.Part Stiff = null;
                if (Position == "Left")
                    Stiff = (from p in PartListC where dc.IsPlateSideView(p) && !dc.IsHorzObj(p) && Com.CenterPoint(p).X < Com.CenterPoint(MidAng).X select p).FirstOrDefault();
                else
                    Stiff = (from p in PartListC where dc.IsPlateSideView(p) && !dc.IsHorzObj(p) && Com.CenterPoint(p).X > Com.CenterPoint(MidAng).X select p).FirstOrDefault();

                if (Stiff != null)
                {
                    BC.SC = new StiffClass();
                    BC.SC.Stiff = Stiff;
                    BC.SC.Points = Com.GetPartPoints(Stiff);
                }



            }

        }

        private AngleClass GetAngleClass(Beam ang, string Pos)
        {
            AngleClass AC = new AngleClass();
            AC.Angle = ang;
            AC.Points = Com.GetPartPoints(ang);


            List<BoltGroup> Bolts = (from b in Com.EnumtoArray(ang.GetBolts()).OfType<BoltGroup>() where !dc.IsSideBolt(ang, b) select b).ToList();
            if (Bolts != null && Bolts.Count > 0)
            {
                AC.BoltPList = new PointList();
                Bolts.ForEach(x => AC.BoltPList.AddRange(Com.GetBoltPoints(x)));
            }

            double AngWidthH = GetPartWidth(ang) / 3;
            BooleanPart CutPart = Com.EnumtoArray(ang.GetBooleans()).OfType<BooleanPart>().Where(x => GetPartWidth(x.OperativePart) < AngWidthH).FirstOrDefault();
            if (CutPart != null)
            {
                TSM.Part CT = CutPart.OperativePart;
                PointList CutPoints = Com.GetVertxPointsD(CT);
                if (Pos == "Top")
                {
                    AC.CutPoints = new PartPoints();
                    if (Com.CenterPoint(CT).X < AC.Points.CentP.X) // Left
                    {
                        AC.CutPoints.P1 = Com.MinPofY(CutPoints, "X", Com.MinP(CutPoints, "Y").Y);
                        AC.CutPoints.P2 = Com.MaxPofY(CutPoints, "X", Com.MinP(CutPoints, "Y").Y);
                        AC.CutPoints.P3 = Com.MinPofX(CutPoints, "Y", Com.MaxP(CutPoints, "X").X);
                        AC.CutPoints.P4 = Com.MaxPofX(CutPoints, "Y", Com.MaxP(CutPoints, "X").X);
                    }
                    else
                    {
                        AC.CutPoints.P1 = Com.MaxPofY(CutPoints, "X", Com.MinP(CutPoints, "Y").Y);
                        AC.CutPoints.P2 = Com.MinPofY(CutPoints, "X", Com.MinP(CutPoints, "Y").Y);
                        AC.CutPoints.P3 = Com.MinPofX(CutPoints, "Y", Com.MinP(CutPoints, "X").X);
                        AC.CutPoints.P4 = Com.MaxPofX(CutPoints, "Y", Com.MinP(CutPoints, "X").X);
                    }
                }
                else if (Pos == "Bottom")
                {
                    AC.CutPoints = new PartPoints();
                    if (Com.CenterPoint(CT).X < AC.Points.CentP.X) // Left
                    {
                        AC.CutPoints.P1 = Com.MinPofY(CutPoints, "X", Com.MaxP(CutPoints, "Y").Y);
                        AC.CutPoints.P2 = Com.MaxPofY(CutPoints, "X", Com.MaxP(CutPoints, "Y").Y);
                        AC.CutPoints.P3 = Com.MaxPofX(CutPoints, "Y", Com.MaxP(CutPoints, "X").X);
                        AC.CutPoints.P4 = Com.MinPofX(CutPoints, "Y", Com.MaxP(CutPoints, "X").X);
                    }
                    else
                    {
                        AC.CutPoints.P1 = Com.MaxPofY(CutPoints, "X", Com.MaxP(CutPoints, "Y").Y);
                        AC.CutPoints.P2 = Com.MinPofY(CutPoints, "X", Com.MaxP(CutPoints, "Y").Y);
                        AC.CutPoints.P3 = Com.MaxPofX(CutPoints, "Y", Com.MinP(CutPoints, "X").X);
                        AC.CutPoints.P4 = Com.MinPofX(CutPoints, "Y", Com.MinP(CutPoints, "X").X);
                    }
                }
            }

            return AC;
        }

        private AngleClass GetAngleClassS(Beam ang, string PosV, string PosH)
        {
            AngleClass AC = new AngleClass();
            AC.Angle = ang;

            if (PosV == "Middle")
                AC.Points = Com.GetPartPoints(ang);
            else if (PosV == "Top")
            {
                AC.Points = new PartPoints();
                PointList VPListM = Com.GetVertxPointsD(ang);
                List<Point> PList = (from p in VPListM.OfType<Point>() orderby p.Z descending select p).ToList();
                PointList VPList = Com.PointToPointList(PList);
                if (PosH == "Left")
                {
                    AC.Points.P1 = Com.MinPofY(VPList, "X", Com.MaxP(VPList, "Y").Y);
                    AC.Points.P2 = Com.MinPofX(VPList, "Y", Com.MinP(VPList, "X").X);
                    AC.Points.P3 = Com.MinPofX(VPList, "Y", Com.MaxP(VPList, "X").X);
                    AC.Points.P4 = Com.MaxPofX(VPList, "Y", Com.MaxP(VPList, "X").X);
                    AC.Points.P5 = Com.MaxPofY(VPList, "X", Com.MaxP(VPList, "Y").Y);
                }
                else
                {
                    AC.Points.P1 = Com.MaxPofX(VPList, "Y", Com.MaxP(VPList, "X").X);
                    AC.Points.P2 = Com.MinPofX(VPList, "Y", Com.MaxP(VPList, "X").X);
                    AC.Points.P3 = Com.MinPofX(VPList, "Y", Com.MinP(VPList, "X").X);
                    AC.Points.P4 = Com.MaxPofX(VPList, "Y", Com.MinP(VPList, "X").X);
                    AC.Points.P5 = Com.MinPofY(VPList, "X", Com.MaxP(VPList, "Y").Y);
                }
            }
            else
            {
                AC.Points = new PartPoints();
                PointList VPListM = Com.GetVertxPointsD(ang);
                List<Point> PList = (from p in VPListM.OfType<Point>() orderby p.Z descending select p).ToList();
                PointList VPList = Com.PointToPointList(PList);
                if (PosH == "Left")
                {
                    AC.Points.P1 = Com.MinPofX(VPList, "Y", Com.MinP(VPList, "X").X);
                    AC.Points.P2 = Com.MaxPofX(VPList, "Y", Com.MinP(VPList, "X").X);
                    AC.Points.P3 = Com.MaxPofX(VPList, "Y", Com.MaxP(VPList, "X").X);
                    AC.Points.P4 = Com.MinPofX(VPList, "Y", Com.MaxP(VPList, "X").X);
                    AC.Points.P5 = Com.MaxPofY(VPList, "X", Com.MinP(VPList, "Y").Y);
                }
                else
                {
                    AC.Points.P1 = Com.MinPofX(VPList, "Y", Com.MaxP(VPList, "X").X);
                    AC.Points.P2 = Com.MaxPofX(VPList, "Y", Com.MaxP(VPList, "X").X);
                    AC.Points.P3 = Com.MaxPofX(VPList, "Y", Com.MinP(VPList, "X").X);
                    AC.Points.P4 = Com.MinPofX(VPList, "Y", Com.MinP(VPList, "X").X);
                    AC.Points.P5 = Com.MinPofY(VPList, "X", Com.MinP(VPList, "Y").Y);
                }
            }

            return AC;
        }

        private PartPoints GetSurfPoints()
        {
            PartPoints SurfPoints = null;
            try
            {
                ModelObjectEnumerator Enum = Com.MyModel.GetModelObjectSelector().GetObjectsByBoundingBox(MainBeam.GetSolid().MinimumPoint, MainBeam.GetSolid().MaximumPoint);
                List<TSM.Part> AllParts = Com.EnumtoArray(Enum).OfType<TSM.Part>().ToList();
                List<TSM.Part> PartListC = BC.beam.GetAssembly().GetSecondaries().OfType<TSM.Part>().ToList();
                List<int> IDs = PartListC.Select(x => x.Identifier.ID).ToList();
                List<TSM.Part> ListExtra = AllParts.Where(x => !IDs.Contains(x.Identifier.ID)).ToList();

                if (ListExtra?.Count > 0)
                {
                    TSM.Part Surface = null;
                    if (Position == "Left")
                        Surface = (from p in ListExtra where p.Material.MaterialString == "Zero_Density" && Com.CenterPoint(p).X < BC.Points.CentP.X orderby p.GetSolid().MinimumPoint.Y select p).FirstOrDefault();
                    else
                        Surface = (from p in ListExtra where p.Material.MaterialString == "Zero_Density" && Com.CenterPoint(p).X > BC.Points.CentP.X orderby p.GetSolid().MinimumPoint.Y select p).FirstOrDefault();

                    if (Surface != null)
                        SurfPoints = Com.GetPartPoints(Surface);

                }
            }
            catch (Exception ex)
            { }
            return SurfPoints;
        }

        #endregion

        #region Helping Methods
        private double GetPartWidth(TSM.Part part)
        {
            return (part.GetSolid().MaximumPoint.X - part.GetSolid().MinimumPoint.X);
        }

        #endregion

        public class BeamClass_BSP3
        {
            public Beam beam { get; set; }
            public AngleClass TopAngle { get; set; }
            public AngleClass BottAngle { get; set; }
            public AngleClass MidAngle { get; set; }
            public StiffClass SC { get; set; }
            public PartPoints Points { get; set; }
            public PlacingClass PC { get; set; }
            public Beam SecBeam { get; set; }
            public PartPoints SurfPoints { get; set; }

        }

        public class BeamClass_BSP3S
        {
            public AngleClass TopAL { get; set; }
            public AngleClass TopAR { get; set; }
            public AngleClass BottAL { get; set; }
            public AngleClass BottAR { get; set; }
            public AngleClass MidAL { get; set; }
            public AngleClass MidAR { get; set; }
            public StiffClass SCL { get; set; }
            public StiffClass SCR { get; set; }
            public PartPoints Points { get; set; }
            public PlacingClass PC { get; set; }

        }

    }

}
