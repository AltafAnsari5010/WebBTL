﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Tekla.Structures;
using Tekla.Structures.Drawing;
using Tekla.Structures.Geometry3d;
using Tekla.Structures.Model;
using TSD = Tekla.Structures.Drawing;
using TSM = Tekla.Structures.Model;
using VirtueleDrawingAutomation;
using TSDD = Tekla.Structures.Datatype;
using TSG = Tekla.Structures.Geometry3d;

namespace Auto_Detailing_Tool_Beam
{
    public class BeamDim_BG5
    {
        #region Global Variables
        DimCom dc = new DimCom();
        StraightDimensionSet.StraightDimensionSetAttributes StAtrr = new StraightDimensionSet.StraightDimensionSetAttributes("standard");
        StraightDimensionSet.StraightDimensionSetAttributes RdAtrr = new StraightDimensionSet.StraightDimensionSetAttributes("standard");

        public Beam MainBeam = null;
        VirtueleDrawingAutomation.Json.DrawingAttributeInfoJson.AttributeFiles dimAttrClass = null;
        List<TSD.StraightDimension> KnockDim = new List<StraightDimension>();
        BeamClass_BG5 BC = null;
        BeamClass_BG5S BCS = null;
        VirtueleDrawingAutomation.Json.AutoDimensionTypesJson.BG5Json DN = null;
        string Position = "Left";
        string ViewName = "";
        TSD.View CView = null;
        #endregion

        public void ApplyDim(TSD.View CView, string ViewName, AutoDimensioningTypes autoDimensioningTypes, DrawingAttributeInfo drawingAttributeInfo, string Position)
        {
            try
            {
                Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane());
                //Set model everything to the view
                Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane(CView.DisplayCoordinateSystem));

                this.CView = CView;
                this.dimAttrClass = drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files;
                this.DN = autoDimensioningTypes.Bg5;
                this.Position = Position;
                StAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.StandardDimension);
                RdAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.RunningDimension);
                this.MainBeam = (Com.MyModel.SelectModelObject(new Identifier((CView.GetDrawing() as AssemblyDrawing).AssemblyIdentifier.ID)) as TSM.Assembly).GetMainPart() as TSM.Beam;
                this.MainBeam.Select();
                string ProType = Com.GetProType(MainBeam);
                this.ViewName = ViewName;
                GetBeamClassClass(CView);

                if (Position == "Left")
                {
                    //TestDim();
                    if (ViewName == "Front View")
                        ApplyDimTypeLeft(CView);
                    else
                    if (ViewName == "Section View")
                        ApplyDimTypeSection(CView);

                }
                else if (Position == "Right")
                {
                    ////TestDim();
                    if (ViewName == "Front View")
                        ApplyDimTypeRight(CView);
                    else
                    if (ViewName == "Section View")
                        ApplyDimTypeSection(CView);
                }
            }
            catch (Exception ex)
            { }

            Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane());


        }

        private void ApplyDimTypeLeft(TSD.View CView)
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;

            Vector Vect = new Vector(0, 1, 0);

            TSD.PointList TempList = new PointList();
            bool IsBoltinLine = CheckBoltLine();
            double MaxLeft = 0;

            if (BC.TopGP?.BoltS != null)
            {
                BC.PC.DistLeft = BC.PC.DistInc;
                Vect = new Vector(-1, 0, 0);
                TempList = dc.ChangePints(BC.TopGP.BoltS, CView, Vect);

                // Dim No 2
                if (DN.DimIDNo2 && BC.LeftBolt != null)
                {
                    PointList ptlist = Com.GetBoltPoints(BC.LeftBolt);
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "Y"));
                    pointList.Add(Com.MaxP(ptlist, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByLeftX(xDim, BC.PC);

                }

                // Dim No 2.1
                if (DN.DimIDNo2Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(Com.MinP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByLeftX(xDim, BC.PC);

                }

                // Dim No 1.3
                if (DN.DimIDNo1Dot3)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    pointList.Add(BC.TopGP.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                }

                // Dim No 1
                if (DN.DimIDNo1)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                }

                if (DN.DimIDNo1 || DN.DimIDNo1Dot3)
                    BC.PC.DistLeft += BC.PC.DistInc;

                // Dim No 1.2
                if (DN.DimIDNo1Dot2)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    pointList.Add(BC.TopAngle.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);


                    //pointList = new PointList();
                    //pointList.Add(Com.MinP(TempList, "Y"));
                    //pointList.Add(BC.TopAngle.Points.P2);
                    //xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    //if (xDim != null)
                    //    PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);

                }

                // Dim No 1.1
                if (DN.DimIDNo1Dot1 && TempList.Count > 2)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                        Com.GroupDim(xDim);
                    }
                }

                if (DN.DimIDNo1Dot1 || DN.DimIDNo1Dot2)
                    BC.PC.DistLeft += BC.PC.DistInc;


                Vect = new Vector(0, 1, 0);
                TempList = dc.ChangePints(BC.TopGP.BoltS, CView, Vect);
                // Dim No 17
                if (DN.DimIDNo17 && BC.TopGP?.RefPBrace != null)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopAngle.Points.P1);
                    pointList.Add(BC.TopGP?.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);
                }

                // Dim No 7
                if (DN.DimIDNo7 && BC.TopGP?.GussetPlate != null)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P1);
                    pointList.Add(BC.TopAngle.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);
                }

                if (BC.IsBoltBothLeg)
                {
                    // Dim No 38, 39
                    if (DN.DimIDNo38 || DN.DimIDNo39)
                    {
                        pointList = new PointList();
                        if (DN.DimIDNo38)  // Dim No 38
                            pointList.Add(BC.TopAngle.Points.P1);
                        pointList.AddRange(TempList);
                        if (DN.DimIDNo38)  // Dim No 39
                            pointList.Add(BC.TopAngle.Points.P4);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByTopY(xDim, BC.PC);
                    }

                    // Dim No 8.3
                    if (DN.DimIDNo8Dot3)
                    {
                        BC.PC.DistTop += BC.PC.DistInc;
                        pointList = new PointList();
                        pointList.Add(BC.Points.P1);
                        pointList.Add(Com.MinP(TempList, "X"));
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                        if (xDim != null)
                            PL.DimPlaceByTopY(xDim, BC.PC);
                    }
                }

                // Dim No 13
                if (DN.DimIDNo13)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopAngle.Points.P1);
                    pointList.Add(BC.TopAngle.Points.P4);
                    xDim = dc.InsertDim(CView, pointList, Vect, (BC.PC.DistInc / 2), StAtrr);

                }
            }

            if (BC.LeftBolt != null)
            {

                BC.PC.DistLeft = (BC.PC.DistInc);
                Vect = new Vector(-1, 0, 0);

                TempList = dc.ChangePints(BC.LeftBolt, CView, Vect);

                // Dim No 3.2
                if (DN.DimIDNo3Dot2)
                {
                    pointList = new PointList();
                    pointList.Add(BC.MidAngle.Points.P2);
                    pointList.Add(Com.MinP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByLeftX(xDim, BC.PC);

                }

                // Dim No 2.2
                if (DN.DimIDNo2Dot2)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByLeftX(xDim, BC.PC);

                }

                // Dim No 3
                if (DN.DimIDNo3)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);

                }

                // Dim No 4
                if (DN.DimIDNo4 && BC.BottGP?.BoltS != null)
                {
                    PointList PtList = Com.GetBoltPoints(BC.BottGP.BoltS);
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "Y"));
                    pointList.Add(Com.MaxP(PtList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                }

                if (DN.DimIDNo3 || DN.DimIDNo4)
                    BC.PC.DistLeft += BC.PC.DistInc;

                // Dim No 3.1
                if (DN.DimIDNo3Dot1)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                        Com.GroupDim(xDim);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }
                }


                // Dim No 5
                if (DN.DimIDNo5)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);

                    if (BC.TopGP?.RefPBrace != null)
                        pointList.Add(BC.TopGP.RefPBrace);
                    else if (BC.BottGP?.RefPBrace != null)
                        pointList.Add(BC.BottGP.RefPBrace);

                    pointList.Add(BC.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByLeftX(xDim, BC.PC);


                    if ((BC.BottGP?.RefPBrace != null && BC.TopGP?.RefPBrace != null) && !dc.IsEqualPoints(BC.BottGP.RefPBrace, BC.TopGP.RefPBrace))
                    {
                        pointList = new PointList();
                        pointList.Add(BC.Points.P1);
                        pointList.Add(BC.BottGP.RefPBrace);
                        pointList.Add(BC.Points.P2);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByLeftX(xDim, BC.PC);
                    }

                }



                // Dim No 6
                if (DN.DimIDNo6 && BC.BottGP?.BoltS != null)
                {
                    PointList PtList = Com.GetBoltPoints(BC.BottGP.BoltS);
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(Com.MaxP(PtList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                }


                if (BC.MidAngle != null)
                {
                    // Dim No 14
                    if (DN.DimIDNo14)
                    {
                        Vect = new Vector(0, -1, 0);
                        pointList = new PointList();
                        pointList.Add(BC.MidAngle.Points.P2);
                        pointList.Add(BC.MidAngle.Points.P3);
                        xDim = dc.InsertDim(CView, pointList, Vect, (BC.PC.DistInc / 3), StAtrr);
                    }

                    if (!IsBoltinLine && BC.IsBoltBothLeg)
                    {
                        Vect = new Vector(0, 1, 0);
                        TempList = dc.ChangePints(BC.LeftBolt, CView, Vect);

                        // Dim No 38, 39
                        if (DN.DimIDNo38 || DN.DimIDNo39)
                        {
                            pointList = new PointList();
                            if (DN.DimIDNo38)
                                pointList.Add(BC.MidAngle.Points.P1);
                            pointList.Add(Com.MinP(TempList, "Y"));
                            if (DN.DimIDNo39)
                                pointList.Add(BC.MidAngle.Points.P4);
                            xDim = dc.InsertDim(CView, pointList, Vect, (BC.PC.DistInc / 3), StAtrr);
                        }

                        // Dim No 8.3 // RD
                        if (DN.DimIDNo8Dot3)
                        {
                            pointList = new PointList();
                            pointList.Add(BC.Points.P1);
                            pointList.Add(Com.MinP(TempList, "Y"));
                            xDim = dc.InsertDim(CView, pointList, Vect, (BC.PC.DistInc), RdAtrr);
                            if (xDim != null)
                                PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistInc);
                        }
                    }

                }

            }

            MaxLeft = BC.PC.DistLeft;

            if (BC.BottGP?.BoltS != null)
            {
                BC.PC.DistLeft = (BC.PC.DistInc);
                Vect = new Vector(-1, 0, 0);
                TempList = dc.ChangePints(BC.BottGP.BoltS, CView, Vect);

                // Dim No 29
                if (DN.DimIDNo29)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P2);
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);

                }

                // Dim No 1.2
                if (DN.DimIDNo1Dot2)
                {

                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "Y"));
                    pointList.Add(BC.BottAngle.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);

                }

                if (DN.DimIDNo29 || DN.DimIDNo1Dot2)
                    BC.PC.DistLeft += BC.PC.DistInc;

                // Dim No 1.3
                if (DN.DimIDNo1Dot3)
                {

                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "Y"));
                    pointList.Add(BC.BottGP.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);

                }

                // Dim No 1
                if (DN.DimIDNo1)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                }


                if (DN.DimIDNo1 || DN.DimIDNo1Dot3)
                    BC.PC.DistLeft += BC.PC.DistInc;

                // Dim No 1.1
                if (DN.DimIDNo1Dot1)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlaceByLeftX(xDim, BC.PC);
                        Com.GroupDim(xDim);
                    }
                }

                Vect = new Vector(0, -1, 0);

                // Dim No 7
                if (DN.DimIDNo7 && BC.BottGP?.GussetPlate != null)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P1);
                    pointList.Add(BC.BottAngle.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);
                }

                // Dim No 17
                if (DN.DimIDNo17)
                {
                    if (BC.TopGP?.RefPBrace != null && !dc.IsEqualPoints(BC.BottGP.RefPBrace, BC.TopGP.RefPBrace))
                    {
                        pointList = new PointList();
                        pointList.Add(BC.BottAngle.Points.P2);
                        pointList.Add(BC.BottGP.RefPBrace);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByBottomY(xDim, BC.PC);
                    }
                }

                if (BC.IsBoltBothLeg)
                {
                    // Dim No 38, 39
                    if (DN.DimIDNo38 || DN.DimIDNo39)
                    {
                        pointList = new PointList();
                        if (DN.DimIDNo38)
                            pointList.Add(BC.BottAngle.Points.P2);

                        pointList.AddRange(TempList);

                        if (DN.DimIDNo39)
                            pointList.Add(BC.BottAngle.Points.P3);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByBottomY(xDim, BC.PC);
                    }

                    // Dim No 8.3
                    if (DN.DimIDNo8Dot3)
                    {
                        BC.PC.DistBot += BC.PC.DistInc;
                        pointList = new PointList();
                        pointList.Add(BC.Points.P2);
                        pointList.Add(Com.MaxP(TempList, "Y"));
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                        if (xDim != null)
                            PL.DimPlaceByBottomY(xDim, BC.PC);
                    }
                }

                // Dim No 13
                if (DN.DimIDNo13)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottAngle.Points.P2);
                    pointList.Add(BC.BottAngle.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, (BC.PC.DistInc / 2), StAtrr);

                }
            }


            CreateLineA();

            if (BC.TopGP?.GussetPlate != null)
            {

                BC.PC.DistLeft = BC.PC.DistInc;

                PointList MidBoltP = Com.GetBoltPoints(BC.TopGP.BoltM);
                TSG.Line YLine = new TSG.Line(BC.TopGP.Points.P4, BC.TopGP.Points.P5);
                TSG.Line XLine = new TSG.Line(Com.MinP(MidBoltP, "Y"), Com.MaxP(MidBoltP, "Y"));
                Vector LeftVect = BC.TopGP.BoltM.GetCoordinateSystem().AxisY;

                if (LeftVect.X > 0)
                    LeftVect = dc.ChangeVector(LeftVect);

                Vector RightVect = BC.TopGP.BoltM.GetCoordinateSystem().AxisY;
                if (RightVect.X < 0)
                    RightVect = dc.ChangeVector(RightVect);

                Vector TopVect = BC.TopGP.BoltM.GetCoordinateSystem().AxisX;
                if (TopVect.Y < 0)
                    TopVect = dc.ChangeVector(TopVect);

                Vector BottVect = BC.TopGP.BoltM.GetCoordinateSystem().AxisX;
                if (BottVect.Y > 0)
                    BottVect = dc.ChangeVector(BottVect);



                #region Top Straight Dim
                Vect = new Vector(0, 1, 0);

                // Dim No 9
                if (DN.DimIDNo9)
                {
                    pointList = new PointList();
                    pointList.AddRange(MidBoltP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistInc);

                }

                // Dim No 40
                if (DN.DimIDNo40)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P1);
                    pointList.Add(BC.TopGP.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);

                }

                // Dim No 19
                if (DN.DimIDNo19)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P1);
                    pointList.Add(BC.TopGP.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);
                }

                // Dim No 42
                if (DN.DimIDNo42)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P1);
                    pointList.Add(BC.TopGP.Points.P3);
                    pointList.Add(BC.TopGP.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);
                }

                // Dim No 31
                if (DN.DimIDNo31)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P1);
                    pointList.Add(BC.TopGP.IntPointB);
                    pointList.Add(BC.TopGP.IntPoint);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);
                }

                // Dim No 41
                if (DN.DimIDNo41)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.RefPBrace);
                    pointList.Add(BC.TopGP.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);
                }

                #endregion

                #region RD Dimensions
                //RD Dim
                Vect = new Vector(0, 1, 0);
                BC.PC.DistTop += (BC.PC.DistInc);
                // Dim No 8.2
                if (DN.DimIDNo8Dot2)
                {
                    if (BC.TopGP.IntPointB.X > BC.Points.P1.X)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.Points.P1);
                        pointList.Add(BC.TopGP.IntPointB);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                        if (xDim != null)
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                    }
                }

                // Dim No 8.1
                if (DN.DimIDNo8Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(BC.TopGP.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                    BC.PC.DistTop += (BC.PC.DistInc);
                }

                // Dim No 8
                if (DN.DimIDNo8)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(Com.MinP(MidBoltP, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                    BC.PC.DistTop += (BC.PC.DistInc);
                }



                #endregion

                #region Right Straight Dim
                Vect = new Vector(1, 0, 0);

                // Dim No 15
                if (DN.DimIDNo15)
                {
                    pointList = new PointList();
                    pointList.AddRange(MidBoltP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.TopGP.Points.P5.X, BC.PC.DistRight);

                    BC.PC.DistRight += BC.PC.DistInc;
                }

                // Dim No 16
                if (DN.DimIDNo16)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P3);
                    pointList.Add(Com.MinP(MidBoltP, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.TopGP.Points.P5.X, BC.PC.DistRight);

                    BC.PC.DistRight += BC.PC.DistInc;
                }

                // Dim No 23
                if (DN.DimIDNo23)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P3);
                    pointList.Add(BC.TopGP.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.TopGP.Points.P5.X, BC.PC.DistRight);

                    BC.PC.DistRight += BC.PC.DistInc;
                }

                #endregion

                #region Diagonal Left


                BC.PC.DistLeft = (BC.PC.DistInc * 9);
                // Dim No 26,26.1
                if (DN.DimIDNo26 || DN.DimIDNo26Dot1)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo26Dot1) // Dim No 26.1
                        pointList.Add(Com.MinP(MidBoltP, "Y"));

                    pointList.Add(BC.TopGP.IntPointB);

                    if (DN.DimIDNo26) // Dim No 26
                        pointList.Add(BC.TopGP.RefPBrace);

                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }
                }


                // Dim No 25.1
                if (DN.DimIDNo25Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(MidBoltP, "Y"));
                    pointList.Add(BC.TopGP.Points.P4);
                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);

                }

                // Dim No 25
                if (DN.DimIDNo25)
                {
                    pointList = new PointList();
                    pointList.AddRange(MidBoltP);
                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);

                }

                // Dim No 30
                if (DN.DimIDNo30)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.RefPBrace);
                    pointList.Add(Com.MinP(MidBoltP, "Y"));
                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);

                }

                if (DN.DimIDNo25Dot1 || DN.DimIDNo25 || DN.DimIDNo30)
                    BC.PC.DistLeft += BC.PC.DistInc;

                // Dim No 25.2
                if (DN.DimIDNo25Dot2)
                {
                    pointList = new PointList();
                    pointList.AddRange(MidBoltP);
                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);
                        Com.GroupDim(xDim);
                    }

                }


                #endregion

                // Com.DrawLineDotted(CView, BC.TopGP.IntPoint, BC.TopGP.RefPBrace);

                //Dim Code 10 // Angle Dimension
                if (DN.DimIDNo10)
                    Com.InsertAngleDim(CView, BC.TopGP.RefPBrace, BC.TopGP.IntPoint, "Top", 130);



                // Com.SetCode(BC.TopGP.GussetPlate);
            }

            if (BC.BottGP?.GussetPlate != null)
            {

                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;

                PointList MidBoltP = Com.GetBoltPoints(BC.BottGP.BoltM);
                TSG.Line YLine = new TSG.Line(BC.BottGP.Points.P4, BC.BottGP.Points.P5);
                TSG.Line XLine = new TSG.Line(BC.BottGP.IntPoint, BC.BottGP.RefPBrace);
                Vector LeftVect = BC.BottGP.BoltM.GetCoordinateSystem().AxisY;

                if (LeftVect.X > 0)
                    LeftVect = dc.ChangeVector(LeftVect);

                Vector RightVect = BC.BottGP.BoltM.GetCoordinateSystem().AxisY;
                if (RightVect.X < 0)
                    RightVect = dc.ChangeVector(RightVect);

                Vector TopVect = BC.BottGP.BoltM.GetCoordinateSystem().AxisX;
                if (TopVect.Y < 0)
                    TopVect = dc.ChangeVector(TopVect);

                Vector BottVect = BC.BottGP.BoltM.GetCoordinateSystem().AxisX;
                if (BottVect.Y > 0)
                    BottVect = dc.ChangeVector(BottVect);



                #region Bottom Straight Dim
                Vect = new Vector(0, -1, 0);


                // Dim No 9
                if (DN.DimIDNo9)
                {
                    pointList = new PointList();
                    pointList.AddRange(MidBoltP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistInc, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistInc);

                }

                // Dim No 40
                if (DN.DimIDNo40)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P1);
                    pointList.Add(BC.BottGP.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistInc, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);

                }

                // Dim No 19
                if (DN.DimIDNo19)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P1);
                    pointList.Add(BC.BottGP.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);
                }

                // Dim No 42
                if (DN.DimIDNo42)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P1);
                    pointList.Add(BC.BottGP.Points.P3);
                    pointList.Add(BC.BottGP.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);
                }

                // Dim No 31
                if (DN.DimIDNo31)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P1);
                    pointList.Add(BC.BottGP.IntPointB);
                    pointList.Add(BC.BottGP.IntPoint);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);
                }

                // Dim No 41
                if (DN.DimIDNo41)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.RefPBrace);
                    pointList.Add(BC.BottGP.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);
                }

                #endregion

                #region RD Dimensions
                //RD Dim
                Vect = new Vector(0, -1, 0);
                BC.PC.DistBot += (BC.PC.DistInc);
                // Dim No 8.2
                if (DN.DimIDNo8Dot2)
                {
                    if (BC.BottGP.IntPointB.X < BC.Points.P4.X)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.Points.P2);
                        pointList.Add(BC.BottGP.IntPointB);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                        if (xDim != null)
                            PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                    }
                }

                // Dim No 8.1
                if (DN.DimIDNo8Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P2);
                    pointList.Add(BC.BottGP.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);

                    BC.PC.DistBot += (BC.PC.DistInc);
                }

                // Dim No 8
                if (DN.DimIDNo8)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P2);
                    pointList.Add(Com.MaxP(MidBoltP, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);

                    BC.PC.DistBot += (BC.PC.DistInc);
                }



                #endregion

                #region Right Straight Dim
                Vect = new Vector(1, 0, 0);

                // Dim No 15
                if (DN.DimIDNo15)
                {
                    pointList = new PointList();
                    pointList.AddRange(MidBoltP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.BottGP.Points.P5.X, BC.PC.DistRight);

                    BC.PC.DistRight += BC.PC.DistInc;
                }

                // Dim No 11
                if (DN.DimIDNo11)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P3);
                    pointList.Add(Com.MaxP(MidBoltP, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.BottGP.Points.P5.X, BC.PC.DistRight);

                    BC.PC.DistRight += BC.PC.DistInc;
                }

                // Dim No 20
                if (DN.DimIDNo20)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P3);
                    pointList.Add(BC.BottGP.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.BottGP.Points.P5.X, BC.PC.DistRight);

                    BC.PC.DistRight += BC.PC.DistInc;
                }

                // Dim No 21
                if (DN.DimIDNo21)
                {
                    pointList = new PointList();
                    pointList.Add(new Point(BC.BottGP.Points.P3.X, BC.Points.P1.Y));
                    pointList.Add(BC.BottGP.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.BottGP.Points.P5.X, BC.PC.DistRight);

                    BC.PC.DistRight += BC.PC.DistInc;
                }

                // Dim No 12
                if (DN.DimIDNo12)
                {
                    pointList = new PointList();
                    pointList.Add(new Point(BC.BottGP.Points.P3.X, BC.Points.P1.Y));
                    pointList.Add(Com.MaxP(MidBoltP, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.BottGP.Points.P5.X, BC.PC.DistRight);

                    BC.PC.DistRight += BC.PC.DistInc;
                }

                // Dim No 22
                if (DN.DimIDNo22 && BC.TopGP?.GussetPlate != null)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P4);
                    pointList.Add(BC.TopGP.Points.P4);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.BottGP.Points.P5.X, BC.PC.DistRight);

                    BC.PC.DistRight += BC.PC.DistInc;
                }

                #endregion


                #region Diagonal Left


                BC.PC.DistLeft = (BC.PC.DistInc * 9);
                // Dim No 26,26.1
                if (DN.DimIDNo26 || DN.DimIDNo26Dot1)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo26Dot1) // Dim No 26.1
                        pointList.Add(Com.MaxP(MidBoltP, "Y"));

                    pointList.Add(BC.BottGP.IntPointB);

                    if (DN.DimIDNo26) // Dim No 26
                        pointList.Add(BC.BottGP.RefPBrace);

                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }
                }


                // Dim No 25.1
                if (DN.DimIDNo25Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(MidBoltP, "Y"));
                    pointList.Add(BC.BottGP.Points.P5);
                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);

                }

                // Dim No 25
                if (DN.DimIDNo25)
                {
                    pointList = new PointList();
                    pointList.AddRange(MidBoltP);
                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);

                }

                // Dim No 30
                if (DN.DimIDNo30)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.RefPBrace);
                    pointList.Add(Com.MaxP(MidBoltP, "Y"));
                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);

                }

                if (DN.DimIDNo25Dot1 || DN.DimIDNo25 || DN.DimIDNo30)
                    BC.PC.DistLeft += BC.PC.DistInc;

                // Dim No 25.2
                if (DN.DimIDNo25Dot2)
                {
                    pointList = new PointList();
                    pointList.AddRange(MidBoltP);
                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);
                        Com.GroupDim(xDim);
                    }

                }

                #endregion

                //  Com.DrawLineDotted(CView, BC.BottGP.IntPoint, BC.BottGP.RefPBrace);

                //Dim Code 10 // Angle Dimension
                if (DN.DimIDNo10)
                    Com.InsertAngleDim(CView, BC.BottGP.RefPBrace, BC.BottGP.IntPoint, "Bottom", 130);

                // Com.SetCode(BC.BottGP.GussetPlate);
            }


            Vect = new Vector(-1, 0, 0);
            // Dim No 18
            if (DN.DimIDNo18)
            {
                StraightDimensionSet.StraightDimensionSetAttributes ElAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.ElevationDimension);
                ElAtrr.DimensionType = DimensionSetBaseAttributes.DimensionTypes.Elevation;
                ElAtrr.Arrowhead.Head = ArrowheadTypes.FilledArrow;
                pointList = new PointList();

                if (MainBeam.StartPoint.X > MainBeam.EndPoint.X)
                {
                    pointList.Add(MainBeam.EndPoint);
                    pointList.Add(MainBeam.EndPoint);

                }
                else
                {
                    pointList.Add(MainBeam.StartPoint);
                    pointList.Add(MainBeam.StartPoint);
                }

                xDim = dc.InsertDimm(CView, pointList, Vect, -MaxLeft, ElAtrr);
                if (xDim != null)
                {
                    xDim.Distance = -MaxLeft;
                    xDim.Modify();
                }

            }


        }

        private void ApplyDimTypeRight(TSD.View CView)
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            TSD.PointList TempList = new PointList();

            bool IsBoltinLine = CheckBoltLine();


            if (BC.TopGP?.BoltS != null)
            {
                BC.PC.DistRight = BC.PC.DistInc;
                Vect = new Vector(1, 0, 0);
                TempList = dc.ChangePints(BC.TopGP.BoltS, CView, Vect);

                // Dim No 2
                if (DN.DimIDNo2 && BC.RightBolt != null)
                {
                    PointList ptlist = Com.GetBoltPoints(BC.RightBolt);
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "Y"));
                    pointList.Add(Com.MaxP(ptlist, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByRightX(xDim, BC.PC);

                }

                // Dim No 2.1
                if (DN.DimIDNo2Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P4);
                    pointList.Add(Com.MinP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByRightX(xDim, BC.PC);

                }

                // Dim No 1.3
                if (DN.DimIDNo1Dot3)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    pointList.Add(BC.TopGP.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                }

                // Dim No 1
                if (DN.DimIDNo1)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                }

                if (DN.DimIDNo1Dot3 || DN.DimIDNo1)
                    BC.PC.DistRight += BC.PC.DistInc;

                // Dim No 1.2
                if (DN.DimIDNo1Dot2)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    pointList.Add(BC.TopAngle.Points.P4);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);


                    //pointList = new PointList();
                    //pointList.Add(Com.MinP(TempList, "Y"));
                    //pointList.Add(BC.TopAngle.Points.P3);
                    //xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    //if (xDim != null)
                    //    PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);

                }

                // Dim No 1.1
                if (DN.DimIDNo1Dot1)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                        Com.GroupDim(xDim);
                    }
                }

                if (DN.DimIDNo1Dot1 || DN.DimIDNo1Dot2)
                    BC.PC.DistRight += BC.PC.DistInc;


                Vect = new Vector(0, 1, 0);

                // Dim No 17
                if (DN.DimIDNo17 && BC.TopGP?.RefPBrace != null)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopAngle.Points.P4);
                    pointList.Add(BC.TopGP?.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);
                }

                // Dim No 7
                if (DN.DimIDNo7 && BC.TopGP?.GussetPlate != null)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P1);
                    pointList.Add(BC.TopAngle.Points.P4);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);
                }


                if (BC.IsBoltBothLeg)
                {
                    // Dim No 38, 39
                    if (DN.DimIDNo38 || DN.DimIDNo39)
                    {
                        pointList = new PointList();
                        if (DN.DimIDNo38)
                            pointList.Add(BC.TopAngle.Points.P1);
                        pointList.AddRange(TempList);
                        if (DN.DimIDNo39)
                            pointList.Add(BC.TopAngle.Points.P4);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByTopY(xDim, BC.PC);
                    }

                    // Dim No 8.3
                    if (DN.DimIDNo8Dot3)
                    {
                        BC.PC.DistTop += BC.PC.DistInc;
                        pointList = new PointList();
                        pointList.Add(BC.Points.P1);
                        pointList.Add(Com.MinP(TempList, "Y"));
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                        if (xDim != null)
                            PL.DimPlaceByTopY(xDim, BC.PC);
                    }
                }

                // Dim No 13
                if (DN.DimIDNo13)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopAngle.Points.P1);
                    pointList.Add(BC.TopAngle.Points.P4);
                    xDim = dc.InsertDim(CView, pointList, Vect, (BC.PC.DistInc / 2), StAtrr);

                }
            }


            if (BC.RightBolt != null)
            {

                BC.PC.DistRight = (BC.PC.DistInc);
                Vect = new Vector(1, 0, 0);

                TempList = dc.ChangePints(BC.RightBolt, CView, Vect);

                // Dim No 3.2
                if (DN.DimIDNo3Dot2)
                {
                    pointList = new PointList();
                    pointList.Add(BC.MidAngle.Points.P3);
                    pointList.Add(Com.MinP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByRightX(xDim, BC.PC);

                }

                // Dim No 2.2
                if (DN.DimIDNo2Dot2)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P4);
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByRightX(xDim, BC.PC);

                }

                // Dim No 3
                if (DN.DimIDNo3)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);

                }

                // Dim No 4
                if (DN.DimIDNo4 && BC.BottGP?.BoltS != null)
                {
                    PointList PtList = Com.GetBoltPoints(BC.BottGP.BoltS);
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "Y"));
                    pointList.Add(Com.MaxP(PtList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                }

                if (DN.DimIDNo3 || DN.DimIDNo4)
                    BC.PC.DistRight += BC.PC.DistInc;

                // Dim No 3.1
                if (DN.DimIDNo3Dot1)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                        Com.GroupDim(xDim);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }
                }


                // Dim No 5
                if (DN.DimIDNo5)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P4);

                    if (BC.TopGP?.RefPBrace != null)
                        pointList.Add(BC.TopGP.RefPBrace);
                    else if (BC.BottGP?.RefPBrace != null)
                        pointList.Add(BC.BottGP.RefPBrace);

                    pointList.Add(BC.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByRightX(xDim, BC.PC);

                    if ((BC.BottGP?.RefPBrace != null && BC.TopGP?.RefPBrace != null) && !dc.IsEqualPoints(BC.BottGP.RefPBrace, BC.TopGP.RefPBrace))
                    {
                        pointList = new PointList();
                        pointList.Add(BC.Points.P4);
                        pointList.Add(BC.BottGP.RefPBrace);
                        pointList.Add(BC.Points.P3);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByRightX(xDim, BC.PC);
                    }

                }

                // Dim No 6
                if (DN.DimIDNo6 && BC.BottGP?.BoltS != null)
                {
                    PointList PtList = Com.GetBoltPoints(BC.BottGP.BoltS);
                    pointList = new PointList();
                    pointList.Add(BC.Points.P4);
                    pointList.Add(Com.MaxP(PtList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                }


                if (BC.MidAngle != null)
                {
                    // Dim No 14
                    if (DN.DimIDNo14)
                    {
                        Vect = new Vector(0, -1, 0);
                        pointList = new PointList();
                        pointList.Add(BC.MidAngle.Points.P2);
                        pointList.Add(BC.MidAngle.Points.P3);
                        xDim = dc.InsertDim(CView, pointList, Vect, (BC.PC.DistInc / 2), StAtrr);
                    }

                    if (!IsBoltinLine && BC.IsBoltBothLeg)
                    {
                        Vect = new Vector(0, 1, 0);
                        TempList = dc.ChangePints(BC.RightBolt, CView, Vect);

                        // Dim No 38, 39
                        if (DN.DimIDNo38 || DN.DimIDNo39)
                        {
                            pointList = new PointList();
                            if (DN.DimIDNo38)
                                pointList.Add(BC.MidAngle.Points.P1);
                            pointList.Add(Com.MinP(TempList, "Y"));
                            if (DN.DimIDNo39)
                                pointList.Add(BC.MidAngle.Points.P4);
                            xDim = dc.InsertDim(CView, pointList, Vect, (BC.PC.DistInc / 4), StAtrr);
                        }

                        // Dim No 8.3 // RD
                        if (DN.DimIDNo8Dot3)
                        {
                            pointList = new PointList();
                            pointList.Add(BC.Points.P1);
                            pointList.Add(Com.MinP(TempList, "Y"));
                            xDim = dc.InsertDim(CView, pointList, Vect, (BC.PC.DistInc), RdAtrr);
                            if (xDim != null)
                                PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistInc);
                        }
                    }


                }

            }


            CreateLineA();

            if (BC.BottGP?.BoltS != null)
            {
                BC.PC.DistRight = (BC.PC.DistInc);
                Vect = new Vector(1, 0, 0);
                TempList = dc.ChangePints(BC.BottGP.BoltS, CView, Vect);

                // Dim No 29
                if (DN.DimIDNo29)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P3);
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);

                }

                // Dim No 1.2
                if (DN.DimIDNo1Dot2)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "Y"));
                    pointList.Add(BC.BottAngle.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);

                }

                if (DN.DimIDNo1Dot2 || DN.DimIDNo29)
                    BC.PC.DistRight += BC.PC.DistInc;

                // Dim No 1.3
                if (DN.DimIDNo1Dot3)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "Y"));
                    pointList.Add(BC.BottGP.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);

                }

                // Dim No 1
                if (DN.DimIDNo1)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                }

                if (DN.DimIDNo1 || DN.DimIDNo1Dot3)
                    BC.PC.DistRight += BC.PC.DistInc;

                // Dim No 1.1
                if (DN.DimIDNo1Dot1)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlaceByRightX(xDim, BC.PC);
                        Com.GroupDim(xDim);
                    }
                }

                Vect = new Vector(0, -1, 0);
                // Dim No 7
                if (DN.DimIDNo7 && BC.BottGP?.GussetPlate != null)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P1);
                    pointList.Add(BC.BottAngle.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);
                }

                // Dim No 17
                if (DN.DimIDNo17)
                {
                    if (BC.TopGP?.RefPBrace != null && !dc.IsEqualPoints(BC.BottGP.RefPBrace, BC.TopGP.RefPBrace))
                    {
                        pointList = new PointList();
                        pointList.Add(BC.BottAngle.Points.P3);
                        pointList.Add(BC.BottGP.RefPBrace);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByBottomY(xDim, BC.PC);
                    }
                }

                if (BC.IsBoltBothLeg)
                {
                    // Dim No 38, 39
                    if (DN.DimIDNo38 || DN.DimIDNo39)
                    {
                        pointList = new PointList();
                        if (DN.DimIDNo38)
                            pointList.Add(BC.BottAngle.Points.P2);
                        pointList.AddRange(TempList);
                        if (DN.DimIDNo39)
                            pointList.Add(BC.BottAngle.Points.P3);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByBottomY(xDim, BC.PC);
                    }

                    // Dim No 8.3
                    if (DN.DimIDNo8Dot3)
                    {
                        BC.PC.DistBot += BC.PC.DistInc;
                        pointList = new PointList();
                        pointList.Add(BC.Points.P2);
                        pointList.Add(Com.MaxP(TempList, "Y"));
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                        if (xDim != null)
                            PL.DimPlaceByBottomY(xDim, BC.PC);
                    }
                }

                // Dim No 13
                if (DN.DimIDNo13)
                {
                    Vect = new Vector(0, 1, 0);
                    pointList = new PointList();
                    pointList.Add(BC.BottAngle.Points.P2);
                    pointList.Add(BC.BottAngle.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, (BC.PC.DistInc / 2), StAtrr);

                }

            }

            if (BC.TopGP?.GussetPlate != null)
            {

                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;

                PointList MidBoltP = Com.GetBoltPoints(BC.TopGP.BoltM);
                TSG.Line YLine = new TSG.Line(BC.TopGP.Points.P4, BC.TopGP.Points.P5);
                TSG.Line XLine = new TSG.Line(BC.TopGP.IntPoint, BC.TopGP.RefPBrace);
                Vector LeftVect = BC.TopGP.BoltM.GetCoordinateSystem().AxisY;

                if (LeftVect.X > 0)
                    LeftVect = dc.ChangeVector(LeftVect);

                Vector RightVect = BC.TopGP.BoltM.GetCoordinateSystem().AxisY;
                if (RightVect.X < 0)
                    RightVect = dc.ChangeVector(RightVect);

                Vector TopVect = BC.TopGP.BoltM.GetCoordinateSystem().AxisX;
                if (TopVect.Y < 0)
                    TopVect = dc.ChangeVector(TopVect);

                Vector BottVect = BC.TopGP.BoltM.GetCoordinateSystem().AxisX;
                if (BottVect.Y > 0)
                    BottVect = dc.ChangeVector(BottVect);



                #region Top Straight Dim
                Vect = new Vector(0, 1, 0);

                // Dim No 9
                if (DN.DimIDNo9)
                {
                    pointList = new PointList();
                    pointList.AddRange(MidBoltP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistInc, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistInc);

                }

                // Dim No 40
                if (DN.DimIDNo40)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P1);
                    pointList.Add(BC.TopGP.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);

                }


                // Dim No 19
                if (DN.DimIDNo19)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P1);
                    pointList.Add(BC.TopGP.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);
                }

                // Dim No 42
                if (DN.DimIDNo42)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P1);
                    pointList.Add(BC.TopGP.Points.P3);
                    pointList.Add(BC.TopGP.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);
                }

                // Dim No 31
                if (DN.DimIDNo31)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P1);
                    pointList.Add(BC.TopGP.IntPointB);
                    pointList.Add(BC.TopGP.IntPoint);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);
                }

                // Dim No 41
                if (DN.DimIDNo41)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.RefPBrace);
                    pointList.Add(BC.TopGP.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);
                }

                #endregion

                #region RD Dimensions
                //RD Dim
                Vect = new Vector(0, 1, 0);
                BC.PC.DistTop += (BC.PC.DistInc);
                // Dim No 8.2
                if (DN.DimIDNo8Dot2 && BC.TopGP.IntPointB.X < BC.Points.P4.X)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(BC.TopGP.IntPointB);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                }

                // Dim No 8.1
                if (DN.DimIDNo8Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(BC.TopGP.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                    BC.PC.DistTop += (BC.PC.DistInc);
                }

                // Dim No 8
                if (DN.DimIDNo8)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(Com.MinP(MidBoltP, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                    BC.PC.DistTop += (BC.PC.DistInc);
                }



                #endregion

                #region Left Straight Dim
                Vect = new Vector(-1, 0, 0);

                // Dim No 15
                if (DN.DimIDNo15)
                {
                    pointList = new PointList();
                    pointList.AddRange(MidBoltP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.TopGP.Points.P5.X, BC.PC.DistLeft);

                    BC.PC.DistLeft += BC.PC.DistInc;
                }

                // Dim No 16
                if (DN.DimIDNo16)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P3);
                    pointList.Add(Com.MinP(MidBoltP, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.TopGP.Points.P5.X, BC.PC.DistLeft);

                    BC.PC.DistLeft += BC.PC.DistInc;
                }

                // Dim No 23
                if (DN.DimIDNo23)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P3);
                    pointList.Add(BC.TopGP.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.TopGP.Points.P5.X, BC.PC.DistLeft);

                    BC.PC.DistLeft += BC.PC.DistInc;
                }

                #endregion


                #region Diagonal Right


                BC.PC.DistRight = (BC.PC.DistInc * 9);
                // Dim No 26,26.1
                if (DN.DimIDNo26 || DN.DimIDNo26Dot1)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo26Dot1) // Dim No 26.1
                        pointList.Add(Com.MinP(MidBoltP, "Y"));

                    pointList.Add(BC.TopGP.IntPointB);

                    if (DN.DimIDNo26) // Dim No 26
                        pointList.Add(BC.TopGP.RefPBrace);

                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }
                }


                // Dim No 25.1
                if (DN.DimIDNo25Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(MidBoltP, "Y"));
                    pointList.Add(BC.TopGP.Points.P5);
                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistRight);


                }

                // Dim No 25
                if (DN.DimIDNo25)
                {
                    pointList = new PointList();
                    pointList.AddRange(MidBoltP);
                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistRight);

                }

                // Dim No 30
                if (DN.DimIDNo30)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.RefPBrace);
                    pointList.Add(Com.MinP(MidBoltP, "Y"));
                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistRight);

                }

                if (DN.DimIDNo25Dot1 || DN.DimIDNo25 || DN.DimIDNo30)
                    BC.PC.DistRight += BC.PC.DistInc;

                // Dim No 25.2
                if (DN.DimIDNo25Dot2)
                {
                    pointList = new PointList();
                    pointList.AddRange(MidBoltP);
                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistRight);
                        Com.GroupDim(xDim);
                    }

                }

                #endregion

                // Com.DrawLineDotted(CView, BC.TopGP.IntPoint, BC.TopGP.RefPBrace);

                //Dim Code 10 // Angle Dimension
                if (DN.DimIDNo10)
                    Com.InsertAngleDim(CView, BC.TopGP.RefPBrace, BC.TopGP.IntPoint, "Top", 130);

            }


            if (BC.BottGP?.GussetPlate != null)
            {

                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;

                PointList MidBoltP = Com.GetBoltPoints(BC.BottGP.BoltM);
                TSG.Line YLine = new TSG.Line(BC.BottGP.Points.P4, BC.BottGP.Points.P5);
                TSG.Line XLine = new TSG.Line(BC.BottGP.IntPoint, BC.BottGP.RefPBrace);
                Vector LeftVect = BC.BottGP.BoltM.GetCoordinateSystem().AxisY;

                if (LeftVect.X > 0)
                    LeftVect = dc.ChangeVector(LeftVect);

                Vector RightVect = BC.BottGP.BoltM.GetCoordinateSystem().AxisY;
                if (RightVect.X < 0)
                    RightVect = dc.ChangeVector(RightVect);

                Vector TopVect = BC.BottGP.BoltM.GetCoordinateSystem().AxisX;
                if (TopVect.Y < 0)
                    TopVect = dc.ChangeVector(TopVect);

                Vector BottVect = BC.BottGP.BoltM.GetCoordinateSystem().AxisX;
                if (BottVect.Y > 0)
                    BottVect = dc.ChangeVector(BottVect);



                #region Bottom Straight Dim
                Vect = new Vector(0, -1, 0);

                // Dim No 9
                if (DN.DimIDNo9)
                {
                    pointList = new PointList();
                    pointList.AddRange(MidBoltP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistInc, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistInc);

                }

                // Dim No 40
                if (DN.DimIDNo40)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P1);
                    pointList.Add(BC.BottGP.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistInc, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);

                }

                // Dim No 19
                if (DN.DimIDNo19)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P1);
                    pointList.Add(BC.BottGP.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);
                }


                // Dim No 42
                if (DN.DimIDNo42)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P1);
                    pointList.Add(BC.BottGP.Points.P3);
                    pointList.Add(BC.BottGP.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);
                }


                // Dim No 31
                if (DN.DimIDNo31)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P1);
                    pointList.Add(BC.BottGP.IntPointB);
                    pointList.Add(BC.BottGP.IntPoint);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);
                }

                // Dim No 41
                if (DN.DimIDNo41)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.RefPBrace);
                    pointList.Add(BC.BottGP.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);
                }

                #endregion

                #region RD Dimensions
                //RD Dim
                Vect = new Vector(0, -1, 0);
                BC.PC.DistBot += (BC.PC.DistInc);
                // Dim No 8.2
                if (DN.DimIDNo8Dot2 && BC.BottGP.IntPointB.X < BC.Points.P4.X)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P2);
                    pointList.Add(BC.BottGP.IntPointB);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                }

                // Dim No 8.1
                if (DN.DimIDNo8Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P2);
                    pointList.Add(BC.BottGP.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);

                    BC.PC.DistBot += (BC.PC.DistInc);
                }

                // Dim No 8
                if (DN.DimIDNo8)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P2);
                    pointList.Add(Com.MaxP(MidBoltP, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);

                    BC.PC.DistBot += (BC.PC.DistInc);
                }



                #endregion

                #region Left Straight Dim
                Vect = new Vector(-1, 0, 0);

                // Dim No 15
                if (DN.DimIDNo15)
                {
                    pointList = new PointList();
                    pointList.AddRange(MidBoltP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.BottGP.Points.P5.X, BC.PC.DistLeft);

                    BC.PC.DistLeft += BC.PC.DistInc;
                }

                // Dim No 11
                if (DN.DimIDNo11)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P3);
                    pointList.Add(Com.MaxP(MidBoltP, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.BottGP.Points.P5.X, BC.PC.DistLeft);

                    BC.PC.DistLeft += BC.PC.DistInc;
                }

                // Dim No 20
                if (DN.DimIDNo20)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P3);
                    pointList.Add(BC.BottGP.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.BottGP.Points.P5.X, BC.PC.DistLeft);

                    BC.PC.DistLeft += BC.PC.DistInc;
                }

                // Dim No 21
                if (DN.DimIDNo21)
                {
                    pointList = new PointList();
                    pointList.Add(new Point(BC.BottGP.Points.P3.X, BC.Points.P1.Y));
                    pointList.Add(BC.BottGP.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.BottGP.Points.P5.X, BC.PC.DistLeft);

                    BC.PC.DistLeft += BC.PC.DistInc;
                }

                // Dim No 12
                if (DN.DimIDNo12)
                {
                    pointList = new PointList();
                    pointList.Add(new Point(BC.BottGP.Points.P3.X, BC.Points.P1.Y));
                    pointList.Add(Com.MaxP(MidBoltP, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.BottGP.Points.P5.X, BC.PC.DistLeft);

                    BC.PC.DistLeft += BC.PC.DistInc;
                }

                // Dim No 22
                if (DN.DimIDNo22 && BC.TopGP?.GussetPlate != null)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P4);
                    pointList.Add(BC.TopGP.Points.P4);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.BottGP.Points.P5.X, BC.PC.DistLeft);

                    BC.PC.DistLeft += BC.PC.DistInc;
                }

                #endregion

                #region Diagonal Right


                BC.PC.DistRight = (BC.PC.DistInc * 9);
                // Dim No 26,26.1
                if (DN.DimIDNo26 || DN.DimIDNo26Dot1)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo26Dot1) // Dim No 26.1
                        pointList.Add(Com.MaxP(MidBoltP, "Y"));

                    pointList.Add(BC.BottGP.IntPointB);

                    if (DN.DimIDNo26) // Dim No 26
                        pointList.Add(BC.BottGP.RefPBrace);

                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }
                }


                // Dim No 25.1
                if (DN.DimIDNo25Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(MidBoltP, "Y"));
                    pointList.Add(BC.BottGP.Points.P5);
                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistRight);

                }

                // Dim No 25
                if (DN.DimIDNo25)
                {
                    pointList = new PointList();
                    pointList.AddRange(MidBoltP);
                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistRight);

                }

                // Dim No 30
                if (DN.DimIDNo30)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.RefPBrace);
                    pointList.Add(Com.MaxP(MidBoltP, "Y"));
                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistRight);

                }

                if (DN.DimIDNo25Dot1 || DN.DimIDNo25 || DN.DimIDNo30)
                    BC.PC.DistRight += BC.PC.DistInc;


                // Dim No 25.2
                if (DN.DimIDNo25Dot2)
                {
                    pointList = new PointList();
                    pointList.AddRange(MidBoltP);
                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistRight);
                        Com.GroupDim(xDim);
                    }

                }

                #endregion

                //  Com.DrawLineDotted(CView, BC.BottGP.IntPoint, BC.BottGP.RefPBrace);


                //Dim Code 10 // Angle Dimension
                if (DN.DimIDNo10)
                    Com.InsertAngleDim(CView, BC.BottGP.RefPBrace, BC.BottGP.IntPoint, "Bottom", 130);



            }

        }

        private void ApplyDimTypeSection(TSD.View CView)
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            TSD.PointList TempList = new PointList();

            bool IsMiddle = true;
            if (BCS.BottAngleL == null && BCS.MidAngleL != null)
            {
                BCS.BottAngleL = BCS.MidAngleL;
                BCS.BottAngleR = BCS.MidAngleR;
                IsMiddle = false;
            }

            else if (BCS.TopAngleL == null && BCS.MidAngleL != null)
            {
                BCS.TopAngleL = BCS.MidAngleL;
                BCS.TopAngleR = BCS.MidAngleR;

                IsMiddle = false;
            }

            if (BCS.TopAngleL != null && BCS.TopAngleR != null)
            {

                Point CentP = new Point(BCS.Points.CentP.X, BCS.Points.P1.Y);
                Vect = new Vector(0, 1, 0);
                // Dim No 34, 34.1
                if (DN.DimIDNo34 || DN.DimIDNo34Dot1)
                {
                    TempList = dc.ChangePints(BCS.TopAngleL.BoltPList, CView, Vect);
                    pointList = new PointList();
                    if (DN.DimIDNo34) // Dim No 34
                        pointList.AddRange(TempList);

                    pointList.Add(BCS.TopAngleL.Points.P4);
                    if (DN.DimIDNo34Dot1) // Dim No 34.1
                        pointList.Add(CentP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BCS.PC);

                    TempList = dc.ChangePints(BCS.TopAngleR.BoltPList, CView, Vect);
                    pointList = new PointList();
                    if (DN.DimIDNo34) // Dim No 34
                        pointList.AddRange(TempList);

                    pointList.Add(BCS.TopAngleR.Points.P1);
                    if (DN.DimIDNo34Dot1) // Dim No 34.1
                        pointList.Add(CentP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BCS.PC);
                }

                TempList = new PointList();
                TempList.AddRange(BCS.TopAngleL.BoltPList);
                TempList.AddRange(BCS.TopAngleR.BoltPList);
                TempList = (dc.ChangePints(TempList, CView, Vect));
                // Dim No 33
                if (DN.DimIDNo33)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    pointList.Add(CentP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BCS.PC);
                }

                // Dim No 32
                if (DN.DimIDNo32)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BCS.PC);
                }
            }

            if (BCS.BottAngleL != null && BCS.BottAngleR != null)
            {
                Point CentP = new Point(BCS.Points.CentP.X, BCS.Points.P2.Y);
                Vect = new Vector(0, -1, 0);
                // Dim No 34, 34.1
                if (DN.DimIDNo34 || DN.DimIDNo34Dot1)
                {
                    pointList = new PointList();

                    TempList = dc.ChangePints(BCS.BottAngleL.BoltPList, CView, Vect);
                    if (DN.DimIDNo34) // Dim No 34
                        pointList.AddRange(TempList);

                    pointList.Add(BCS.BottAngleL.Points.P3);
                    if (DN.DimIDNo34Dot1) // Dim No 34.1
                        pointList.Add(CentP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BCS.PC);


                    pointList = new PointList();

                    TempList = dc.ChangePints(BCS.BottAngleR.BoltPList, CView, Vect);
                    if (DN.DimIDNo34) // Dim No 34
                        pointList.AddRange(TempList);

                    pointList.Add(BCS.BottAngleR.Points.P2);
                    if (DN.DimIDNo34Dot1) // Dim No 34.1
                        pointList.Add(CentP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BCS.PC);
                }

                TempList = new PointList();
                TempList.AddRange(BCS.BottAngleL.BoltPList);
                TempList.AddRange(BCS.BottAngleR.BoltPList);
                TempList = (dc.ChangePints(TempList, CView, Vect));

                // Dim No 33
                if (DN.DimIDNo33)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    pointList.Add(CentP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BCS.PC);
                }

                // Dim No 32
                if (DN.DimIDNo32)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BCS.PC);
                }
            }


            if (IsMiddle && BCS.MidAngleL != null && BCS.MidAngleR != null)
            {
                double dist = (BCS.PC.DistInc / 10);
                Vect = new Vector(0, -1, 0);
                // Dim No 37, 37.1
                if (DN.DimIDNo37 || DN.DimIDNo37Dot1)
                {
                    pointList = new PointList();

                    TempList = dc.ChangePints(BCS.MidAngleL.BoltPList, CView, Vect);
                    if (DN.DimIDNo37) // Dim No 37
                        pointList.AddRange(TempList);

                    pointList.Add(BCS.MidAngleL.Points.P3);
                    if (DN.DimIDNo37Dot1) // Dim No 37.1
                        pointList.Add(BCS.Points.CentP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistInc, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceBottP(xDim, BCS.MidAngleR.Points.P2.Y, 10);

                    dist += (dist * 5);
                    pointList = new PointList();

                    TempList = dc.ChangePints(BCS.MidAngleR.BoltPList, CView, Vect);
                    if (DN.DimIDNo37) // Dim No 37
                        pointList.AddRange(TempList);

                    pointList.Add(BCS.MidAngleR.Points.P2);
                    if (DN.DimIDNo37Dot1) // Dim No 37.1
                        pointList.Add(BCS.Points.CentP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistInc, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceBottP(xDim, BCS.MidAngleR.Points.P2.Y, 70);
                }

                Vect = new Vector(0, 1, 0);
                TempList = new PointList();
                TempList.AddRange(BCS.MidAngleL.BoltPList);
                TempList.AddRange(BCS.MidAngleR.BoltPList);
                TempList = (dc.ChangePints(TempList, CView, Vect));
                dist = (BCS.PC.DistInc / 10);
                // Dim No 36
                if (DN.DimIDNo36)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    pointList.Add(BCS.Points.CentP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistInc, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BCS.MidAngleR.Points.P1.Y, 10);

                    dist += (dist * 5);
                }

                // Dim No 35
                if (DN.DimIDNo35)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistInc, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BCS.MidAngleR.Points.P1.Y, 70);
                }
            }

        }

        private void CreateLineA()
        {
            Point TopP = null;
            Point BottP = null;
            if (Position == "Left")
            {
                if (BC.TopAngle != null)
                    TopP = BC.TopAngle.Points.P1;
                else if (BC.MidAngle != null && BC.BottAngle != null)
                    TopP = BC.MidAngle.Points.P1;

                if (BC.BottAngle != null)
                    BottP = BC.BottAngle.Points.P2;
                else if (BC.MidAngle != null && BC.TopAngle != null)
                    BottP = BC.MidAngle.Points.P2;
            }
            else
            {
                if (BC.TopAngle != null)
                    TopP = BC.TopAngle.Points.P4;
                else if (BC.MidAngle != null && BC.BottAngle != null)
                    TopP = BC.MidAngle.Points.P4;

                if (BC.BottAngle != null)
                    BottP = BC.BottAngle.Points.P3;
                else if (BC.MidAngle != null && BC.TopAngle != null)
                    BottP = BC.MidAngle.Points.P3;
            }

            if (TopP != null && BottP != null && dc.IsEqual(TopP.X, BottP.X))
                Com.DrawLine(CView, TopP, BottP);
        }

        private bool CheckBoltLine()
        {
            bool RetCheck = false;

            if (BC.MidAngle != null)
            {
                if (Position == "Left")
                {
                    if (BC.TopAngle != null && BC.TopGP?.BoltS != null && BC.IsBoltBothLeg)
                    {
                        Point MaxP = Com.MaxP(Com.GetBoltPoints(BC.TopGP.BoltS), "Y");
                        Point MinP = Com.MinP(Com.GetBoltPoints(BC.LeftBolt), "Y");
                        if (dc.IsEqual(MaxP.X, MinP.X))
                        {
                            Com.DrawLine(CView, MaxP, MinP);
                            RetCheck = true;
                        }
                    }

                    if (!RetCheck)
                    {
                        if (BC.BottAngle != null && BC.BottGP?.BoltS != null && BC.IsBoltBothLeg)
                        {
                            Point MaxP = Com.MaxP(Com.GetBoltPoints(BC.LeftBolt), "Y");
                            Point MinP = Com.MinP(Com.GetBoltPoints(BC.BottGP.BoltS), "Y");
                            if (dc.IsEqual(MaxP.X, MinP.X))
                            {
                                Com.DrawLine(CView, MaxP, MinP);
                                RetCheck = true;
                            }
                        }
                    }
                }
                else
                {
                    if (BC.TopAngle != null && BC.TopGP?.BoltS != null && BC.IsBoltBothLeg)
                    {
                        Point MaxP = Com.MaxP(Com.GetBoltPoints(BC.TopGP.BoltS), "Y");
                        Point MinP = Com.MinP(Com.GetBoltPoints(BC.RightBolt), "Y");
                        if (dc.IsEqual(MaxP.X, MinP.X))
                        {
                            Com.DrawLine(CView, MaxP, MinP);
                            RetCheck = true;
                        }
                    }

                    if (!RetCheck)
                    {
                        if (BC.BottAngle != null && BC.BottGP?.BoltS != null && BC.IsBoltBothLeg)
                        {
                            Point MaxP = Com.MaxP(Com.GetBoltPoints(BC.RightBolt), "Y");
                            Point MinP = Com.MinP(Com.GetBoltPoints(BC.BottGP.BoltS), "Y");
                            if (dc.IsEqual(MaxP.X, MinP.X))
                            {
                                Com.DrawLine(CView, MaxP, MinP);
                                RetCheck = true;
                            }
                        }
                    }

                }
            }
            else if (BC.IsBoltBothLeg && BC.TopGP?.BoltS != null && BC.BottGP?.BoltS != null)
            {
                RetCheck = true;
                Point MaxP = Com.MaxP(Com.GetBoltPoints(BC.TopGP.BoltS), "Y");
                Point MinP = Com.MinP(Com.GetBoltPoints(BC.BottGP.BoltS), "Y");
                if (dc.IsEqual(MaxP.X, MinP.X))
                    Com.DrawLine(CView, MaxP, MinP);
            }

            return RetCheck;
        }

        private void TestDim()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;

            Vector Vect = new Vector(0, 1, 0);

            TSD.PointList TempList = new PointList();

            if (DN.DimIDNo10)
            {
                Point Temp = new Point(BC.TopGP.IntPointB.X, BC.TopGP.RefPBrace.Y, BC.TopGP.IntPointB.Z);
                AngleDimension angDimA = new AngleDimension(CView, BC.TopGP.IntPointB, BC.TopGP.RefPBrace, Temp, 50);
                angDimA.Insert();
            }

            //Dim Code 10 // Angle Dimension
            if (DN.DimIDNo10)
            {
                Point Temp = new Point(BC.BottGP.IntPointB.X, BC.BottGP.RefPBrace.Y, BC.BottGP.IntPointB.Z);
                AngleDimension angDimA = new AngleDimension(CView, BC.BottGP.IntPointB, BC.BottGP.RefPBrace, Temp, 50);
                angDimA.Insert();
            }
        }

        #region Get Data

        private BeamClass_BG5 GetBeamClassClass(TSD.View CView)
        {


            if (ViewName == "Front View")
            {
                BC = new BeamClass_BG5();

                BC.beam = MainBeam;
                List<TSM.Part> PartListC = BC.beam.GetAssembly().GetSecondaries().OfType<TSM.Part>().ToList();

                BC.Points = Com.GetPartPoints(BC.beam);
                GetGussetProperties(PartListC);

                PartListC.Add(MainBeam);
                TSM.Part LeftPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.X ascending select p).FirstOrDefault();
                TSM.Part RightPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.X descending select p).FirstOrDefault();
                TSM.Part TopPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.Y descending select p).FirstOrDefault();
                TSM.Part BottPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.Y ascending select p).FirstOrDefault();

                BC.PC = new PlacingClass();
                BC.PC.TopY = TopPart.GetSolid().MaximumPoint.Y;
                BC.PC.BottomY = BottPart.GetSolid().MinimumPoint.Y;
                BC.PC.LeftX = LeftPart.GetSolid().MinimumPoint.X; ;// Math.Round(CView.RestrictionBox.MinPoint.X);
                BC.PC.RightX = RightPart.GetSolid().MaximumPoint.X;

                if (BC.TopGP?.GussetPlate != null)
                    BC.PC.TopY = BC.TopGP.GussetPlate.GetSolid().MaximumPoint.Y;

                if (BC.BottGP?.GussetPlate != null)
                    BC.PC.BottomY = BC.BottGP.GussetPlate.GetSolid().MinimumPoint.Y;

                if (Position == "Left")
                {

                    if (BC.TopGP?.RefPBrace != null && BC.PC.LeftX > BC.TopGP.RefPBrace.X)
                        BC.PC.LeftX = (double)(BC.TopGP?.RefPBrace.X);
                    else if (BC.BottGP?.RefPBrace != null && BC.PC.LeftX > BC.BottGP.RefPBrace.X)
                        BC.PC.LeftX = (double)(BC.BottGP?.RefPBrace.X);
                }

                if (Position == "Right")
                {

                    if (BC.TopGP?.RefPBrace != null && BC.PC.LeftX < BC.TopGP.RefPBrace.X)
                        BC.PC.RightX = (double)(BC.TopGP?.RefPBrace.X);
                    else if (BC.BottGP?.RefPBrace != null && BC.PC.LeftX < BC.BottGP.RefPBrace.X)
                        BC.PC.RightX = (double)(BC.BottGP?.RefPBrace.X);
                }

                double AvScale = 12;
                double AvDistInc = 100;
                double DistPerScale = AvDistInc / AvScale;
                double CScale = CView.Attributes.Scale;
                BC.PC.DistInc = CScale * DistPerScale;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;
            }

            else if (ViewName == "Section View")
            {
                BCS = new BeamClass_BG5S();
                BCS.beam = MainBeam;
                List<TSM.Part> PartListC = BCS.beam.GetAssembly().GetSecondaries().OfType<TSM.Part>().ToList();
                BCS.Points = Com.GetPartPoints(BCS.beam);
                //double MaxZ = MainBeam.GetSolid().MaximumPoint.Z - ((MainBeam.GetSolid().MaximumPoint.Z - MainBeam.GetSolid().MinimumPoint.Z) / 10);
                //List<TSM.Part> PartList = (from p in PartListC where p.GetSolid().MaximumPoint.Z > MaxZ select p).ToList();

                List<TSM.Part> PartList = (from p in PartListC where Com.IsViewObj(p, CView) select p).ToList();
                GetGussetPropertiesSect(PartList);
                PartList.Add(MainBeam);
                TSM.Part LeftPart = (from p in PartList orderby p.GetSolid().MinimumPoint.X ascending select p).FirstOrDefault();
                TSM.Part RightPart = (from p in PartList orderby p.GetSolid().MaximumPoint.X descending select p).FirstOrDefault();
                TSM.Part TopPart = (from p in PartList orderby p.GetSolid().MaximumPoint.Y descending select p).FirstOrDefault();
                TSM.Part BottPart = (from p in PartList orderby p.GetSolid().MinimumPoint.Y ascending select p).FirstOrDefault();

                BCS.PC = new PlacingClass();
                BCS.PC.TopY = TopPart.GetSolid().MaximumPoint.Y;
                BCS.PC.BottomY = BottPart.GetSolid().MinimumPoint.Y;
                BCS.PC.LeftX = LeftPart.GetSolid().MinimumPoint.X; ;// Math.Round(CView.RestrictionBox.MinPoint.X);
                BCS.PC.RightX = RightPart.GetSolid().MaximumPoint.X;

                double AvScale = 12;
                double AvDistInc = 100;
                double DistPerScale = AvDistInc / AvScale;
                double CScale = CView.Attributes.Scale;
                BCS.PC.DistInc = CScale * DistPerScale;
                BCS.PC.DistBot = BCS.PC.DistInc;
                BCS.PC.DistTop = BCS.PC.DistInc;
                BCS.PC.DistLeft = BCS.PC.DistInc;
                BCS.PC.DistRight = BCS.PC.DistInc;
            }




            return BC;

        }

        private void GetGussetProperties(List<TSM.Part> PartListC)
        {

            Point CentP = Com.CenterPoint(BC.beam.StartPoint, BC.beam.EndPoint);
            double Lenght = (BC.beam.GetSolid().MaximumPoint.X - BC.beam.GetSolid().MinimumPoint.X) / 8;
            double MinX = BC.beam.GetSolid().MinimumPoint.X + Lenght;
            double MaxX = BC.beam.GetSolid().MaximumPoint.X - Lenght;

            ContourPlate TopGP = null;
            ContourPlate BottGP = null;

            Beam TopAng = null;
            Beam BottAng = null;
            Beam MidAng = null;

            if (Position == "Left")
            {
                TopAng = (from p in PartListC.OfType<Beam>() where (p.GetSolid().MinimumPoint.X < CentP.X && p.GetSolid().MinimumPoint.X <= MinX) && (Com.CenterPoint(p).Y > BC.Points.P1.Y) select p).FirstOrDefault();
                BottAng = (from p in PartListC.OfType<Beam>() where (p.GetSolid().MinimumPoint.X < CentP.X && p.GetSolid().MinimumPoint.X <= MinX) && (Com.CenterPoint(p).Y < BC.Points.P2.Y) select p).FirstOrDefault();
                MidAng = (from p in PartListC.OfType<Beam>() where (p.GetSolid().MinimumPoint.X < CentP.X && p.GetSolid().MinimumPoint.X <= MinX) && (Com.CenterPoint(p).Y < BC.Points.P1.Y && Com.CenterPoint(p).Y > BC.Points.P2.Y) select p).FirstOrDefault();

                TopGP = (from p in PartListC.OfType<ContourPlate>() where (p.GetSolid().MinimumPoint.X < CentP.X && p.GetSolid().MinimumPoint.X <= MinX) && (Com.CenterPoint(p).Y > BC.Points.CentP.Y) select p).FirstOrDefault();
                BottGP = (from p in PartListC.OfType<ContourPlate>() where (p.GetSolid().MinimumPoint.X < CentP.X && p.GetSolid().MinimumPoint.X <= MinX) && (Com.CenterPoint(p).Y < BC.Points.CentP.Y) select p).FirstOrDefault();
            }
            else
            {
                TopAng = (from p in PartListC.OfType<Beam>() where (p.GetSolid().MaximumPoint.X > CentP.X && p.GetSolid().MaximumPoint.X >= MaxX) && (Com.CenterPoint(p).Y > BC.Points.P1.Y) select p).FirstOrDefault();
                BottAng = (from p in PartListC.OfType<Beam>() where (p.GetSolid().MaximumPoint.X > CentP.X && p.GetSolid().MaximumPoint.X >= MaxX) && (Com.CenterPoint(p).Y < BC.Points.P2.Y) select p).FirstOrDefault();
                MidAng = (from p in PartListC.OfType<Beam>() where (p.GetSolid().MaximumPoint.X > CentP.X && p.GetSolid().MaximumPoint.X >= MaxX) && (Com.CenterPoint(p).Y < BC.Points.P1.Y && Com.CenterPoint(p).Y > BC.Points.P2.Y) select p).FirstOrDefault();

                TopGP = (from p in PartListC.OfType<ContourPlate>() where (p.GetSolid().MaximumPoint.X > CentP.X && p.GetSolid().MaximumPoint.X >= MaxX) && (Com.CenterPoint(p).Y > BC.Points.CentP.Y) select p).FirstOrDefault();
                BottGP = (from p in PartListC.OfType<ContourPlate>() where (p.GetSolid().MaximumPoint.X > CentP.X && p.GetSolid().MaximumPoint.X >= MaxX) && (Com.CenterPoint(p).Y < BC.Points.CentP.Y) select p).FirstOrDefault();
            }

            if (BottAng != null)
            {
                BC.BottAngle = new AngleClass();
                BC.BottAngle.Angle = BottAng;
                BC.BottAngle.Points = Com.GetPartPoints(BottAng);
            }

            if (TopAng != null)
            {
                BC.TopAngle = new AngleClass();
                BC.TopAngle.Angle = TopAng;
                BC.TopAngle.Points = Com.GetPartPoints(TopAng);
            }

            if (MidAng != null)
            {
                BC.MidAngle = new AngleClass();
                BC.MidAngle.Angle = MidAng;
                BC.MidAngle.Points = Com.GetPartPoints(MidAng);
                if (Position == "Left")
                {
                    BC.LeftBolt = (from b in Com.EnumtoArray(MidAng.GetBolts()).OfType<BoltGroup>() where !dc.IsSideBolt(MidAng, b) select b).FirstOrDefault();
                    if (BC.LeftBolt == null)
                        BC.LeftBolt = (from b in Com.EnumtoArray(MidAng.GetBolts()).OfType<BoltGroup>() where dc.IsSideBolt(MidAng, b) select b).FirstOrDefault();
                    else
                        BC.IsBoltBothLeg = true;
                }
                else
                {
                    BC.RightBolt = (from b in Com.EnumtoArray(MidAng.GetBolts()).OfType<BoltGroup>() where !dc.IsSideBolt(MidAng, b) select b).FirstOrDefault();

                    if (BC.RightBolt == null)
                        BC.RightBolt = (from b in Com.EnumtoArray(MidAng.GetBolts()).OfType<BoltGroup>() where dc.IsSideBolt(MidAng, b) select b).FirstOrDefault();
                    else
                        BC.IsBoltBothLeg = true;
                }

            }

            if (TopGP != null)
            {
                BC.TopGP = GetGussetClass(TopGP, "Top");
                if (TopAng != null)
                {
                    BC.TopGP.BoltS = (from b in Com.EnumtoArray(TopAng.GetBolts()).OfType<BoltGroup>() where !dc.IsSideBolt(TopAng, b) select b).FirstOrDefault();
                    if (BC.TopGP.BoltS == null)
                        BC.TopGP.BoltS = (from b in Com.EnumtoArray(TopAng.GetBolts()).OfType<BoltGroup>() where dc.IsSideBolt(TopAng, b) select b).FirstOrDefault();
                    else
                        BC.IsBoltBothLeg = true;
                }
            }

            if (BottGP != null)
            {
                BC.BottGP = GetGussetClass(BottGP, "Bottom");
                if (BottAng != null)
                {
                    BC.BottGP.BoltS = (from b in Com.EnumtoArray(BottAng.GetBolts()).OfType<BoltGroup>() where !dc.IsSideBolt(BottAng, b) select b).FirstOrDefault();

                    if (BC.BottGP.BoltS == null)
                        BC.BottGP.BoltS = (from b in Com.EnumtoArray(BottAng.GetBolts()).OfType<BoltGroup>() where dc.IsSideBolt(BottAng, b) select b).FirstOrDefault();
                    else
                        BC.IsBoltBothLeg = true;
                }
            }

        }

        private void GetGussetPropertiesSect(List<TSM.Part> PartListC)
        {

            Point CentP = Com.CenterPoint(BCS.beam.StartPoint, BCS.beam.EndPoint);

            Beam TopAngL = (from p in PartListC.OfType<Beam>() where (Com.CenterPoint(p).X < CentP.X) && (Com.CenterPoint(p).Y > BCS.Points.P1.Y) select p).FirstOrDefault();
            Beam TopAngR = (from p in PartListC.OfType<Beam>() where (Com.CenterPoint(p).X > CentP.X) && (Com.CenterPoint(p).Y > BCS.Points.P1.Y) select p).FirstOrDefault();
            Beam BottAngL = (from p in PartListC.OfType<Beam>() where (Com.CenterPoint(p).X < CentP.X) && (Com.CenterPoint(p).Y < BCS.Points.P2.Y) select p).FirstOrDefault();
            Beam BottAngR = (from p in PartListC.OfType<Beam>() where (Com.CenterPoint(p).X > CentP.X) && (Com.CenterPoint(p).Y < BCS.Points.P2.Y) select p).FirstOrDefault();
            Beam MidAngL = (from p in PartListC.OfType<Beam>() where (Com.CenterPoint(p).X < CentP.X) && (Com.CenterPoint(p).Y < BCS.Points.P1.Y && Com.CenterPoint(p).Y > BCS.Points.P2.Y) select p).FirstOrDefault();
            Beam MidAngR = (from p in PartListC.OfType<Beam>() where (Com.CenterPoint(p).X > CentP.X) && (Com.CenterPoint(p).Y < BCS.Points.P1.Y && Com.CenterPoint(p).Y > BCS.Points.P2.Y) select p).FirstOrDefault();

            ContourPlate TopGP = (from p in PartListC.OfType<ContourPlate>() where (Com.CenterPoint(p).Y > BCS.Points.CentP.Y) select p).FirstOrDefault();
            ContourPlate BottGP = (from p in PartListC.OfType<ContourPlate>() where (Com.CenterPoint(p).Y < BCS.Points.CentP.Y) select p).FirstOrDefault();

            if (BottAngL != null)
                BCS.BottAngleL = GetAngleClass(BottAngL);

            if (BottAngR != null)
                BCS.BottAngleR = GetAngleClass(BottAngR);

            if (TopAngL != null)
                BCS.TopAngleL = GetAngleClass(TopAngL);


            if (TopAngR != null)
                BCS.TopAngleR = GetAngleClass(TopAngR);

            if (MidAngL != null)
                BCS.MidAngleL = GetAngleClass(MidAngL);

            if (MidAngR != null)
                BCS.MidAngleR = GetAngleClass(MidAngR);

            if (TopGP != null)
            {
                BCS.TopGP = new GussetClass();
                BCS.TopGP.GussetPlate = TopGP;
                BCS.TopGP.Points = Com.GetPartPoints(TopGP);
            }

            if (BottGP != null)
            {
                BCS.BottGP = new GussetClass();
                BCS.BottGP.GussetPlate = BottGP;
                BCS.BottGP.Points = Com.GetPartPoints(BottGP);
            }
        }

        private AngleClass GetAngleClass(Beam Ang)
        {
            AngleClass AC = new AngleClass();
            AC.Angle = Ang;
            AC.Points = Com.GetPartPoints(Ang);
            List<BoltGroup> bolts = (from b in Com.EnumtoArray(Ang.GetBolts()).OfType<BoltGroup>() where !dc.IsSideBolt(Ang, b) select b).ToList();
            if (bolts != null && bolts.Count > 0)
            {
                AC.BoltPList = new PointList();
                foreach (BoltGroup bolt in bolts)
                {
                    AC.BoltPList.AddRange(Com.GetBoltPoints(bolt));
                }
            }

            return AC;
        }

        private GussetClass GetGussetClass(ContourPlate GP, string Position)
        {
            GussetClass GC = new GussetClass();
            GC.GussetPlate = GP;
            GC.Points = GetGussetPoints(GP);

            List<BoltGroup> Bolts = Com.EnumtoArray(GP.GetBolts()).OfType<BoltGroup>().ToList();

            if (Bolts != null && Bolts.Count > 0)
            {
                BoltGroup MidBolt = (from b in Bolts where dc.IsDiagonalBolt(b) select b).FirstOrDefault();
                if (MidBolt != null)
                {
                    GC.BoltM = MidBolt;
                    Beam brace = GetBrace(GC.BoltM, GP);
                    if (brace != null)
                    {
                        GC.Brace = brace;
                        GC.RefPBrace = dc.NearestPoint(GC.Brace.StartPoint, GC.Brace.EndPoint, MidBolt.FirstPosition);
                        GC.IntPoint = GetIntSectPoint(GC.BoltM, brace, Position);
                        if (Position == "Top")
                        {
                            if (GC.RefPBrace != null && GC.IntPoint != null)
                                GC.IntPointB = Com.GetIntersectionPoint(GC.RefPBrace, GC.IntPoint, BC.Points.P1, BC.Points.P4);
                        }
                        else
                        {
                            if (GC.RefPBrace != null && GC.IntPoint != null)
                                GC.IntPointB = Com.GetIntersectionPoint(GC.RefPBrace, GC.IntPoint, BC.Points.P2, BC.Points.P3);
                        }
                    }
                }


            }

            return GC;
        }

        private Beam GetBrace(BoltGroup BoltL, TSM.Part GP)
        {

            Beam brace = (from b in Com.GetBoltParts(BoltL).OfType<TSM.Beam>() where b.Identifier.ID != GP.Identifier.ID && (b.Name.ToLower().Contains("brace") || (dc.IsMainPart(b) && !dc.IsPlate(b))) select b).FirstOrDefault();
            if (brace == null)
            {
                List<TSM.Part> PartList = (from b in Com.GetBoltParts(BoltL).OfType<TSM.Part>() where b.Identifier.ID != GP.Identifier.ID select b).ToList();

                foreach (TSM.Part part in PartList)
                {

                    BoltGroup bolt2 = Com.EnumtoArray(part.GetBolts()).OfType<BoltGroup>().Where(x => x.Identifier.ID != BoltL.Identifier.ID).FirstOrDefault();
                    if (bolt2 != null)
                    {
                        brace = (from b in Com.GetBoltParts(bolt2).OfType<TSM.Beam>() where b.Identifier.ID != GP.Identifier.ID && (b.Name.ToLower().Contains("brace") || (dc.IsMainPart(b) && !dc.IsPlate(b))) select b).FirstOrDefault();
                    }

                }

                if (brace == null)
                {
                    foreach (TSM.Part part in PartList)
                    {
                        if (dc.IsMainPart(part) && dc.IsPlate(part))
                        {

                            List<TSM.Part> PartLists = Com.EnumtoArray(part.GetWelds()).OfType<TSM.Weld>().Select(x => x.MainObject).OfType<TSM.Part>().ToList();
                            PartLists.AddRange(Com.EnumtoArray(part.GetWelds()).OfType<TSM.Weld>().Select(x => x.SecondaryObject).OfType<TSM.Part>().ToList());

                            brace = (from b in PartLists.OfType<Beam>() where IsBrace(b) select b).FirstOrDefault();
                            if (brace == null)
                            {
                                PartLists = (from b in PartLists where !dc.IsMainPart(b) select b.GetAssembly().GetMainPart()).OfType<TSM.Part>().ToList();
                                brace = (from b in PartLists.OfType<Beam>() where IsBrace(b) select b).FirstOrDefault();
                                if (brace != null)
                                    break;
                            }


                        }

                    }
                }

                if (brace == null)
                {
                    foreach (TSM.Part part in PartList)
                    {
                        if (dc.IsMainPart(part) && dc.IsPlate(part))
                        {

                            List<BoltGroup> BoltsList = Com.EnumtoArray(part.GetBolts()).OfType<TSM.BoltGroup>().ToList();
                            if (BoltsList != null && BoltsList.Count > 0)
                            {
                                List<TSM.Part> PartLists = new List<TSM.Part>();

                                BoltsList.ForEach(x => PartLists.AddRange(Com.GetBoltParts(x)));

                                brace = (from b in PartLists.OfType<Beam>() where IsBrace(b) select b).FirstOrDefault();
                                if (brace == null)
                                {
                                    PartLists = (from b in PartLists where !dc.IsMainPart(b) select b.GetAssembly().GetMainPart()).OfType<TSM.Part>().ToList();
                                    brace = (from b in PartLists.OfType<Beam>() where IsBrace(b) select b).FirstOrDefault();
                                    if (brace != null)
                                        break;
                                }
                            }


                        }

                    }
                }
            }

            return brace;

        }

        private PartPoints GetGussetPoints(ContourPlate GP)
        {

            PartPoints RetP = new PartPoints();
            PointList pointList = Com.ContPList(GP);
            RetP.CentP = Com.CenterPoint(GP);
            if (Position == "Left")
            {
                if (RetP.CentP.Y > BC.Points.CentP.Y)
                {
                    RetP.P1 = Com.MaxPofX(pointList, "Y", Com.MinP(pointList, "X").X);
                    RetP.P2 = Com.MinPofY(pointList, "X", Com.MinP(pointList, "Y").Y);
                    RetP.P3 = Com.MaxPofY(pointList, "X", Com.MinP(pointList, "Y").Y);
                    RetP.P4 = Com.MaxPofY(pointList, "X", Com.MaxP(pointList, "Y").Y);

                    RetP.P5 = Com.MaxPofX(pointList, "Y", Com.MaxP(pointList, "X").X);
                }
                else
                {
                    RetP.P1 = Com.MinPofX(pointList, "Y", Com.MinP(pointList, "X").X);
                    RetP.P2 = Com.MinPofY(pointList, "X", Com.MaxP(pointList, "Y").Y);
                    RetP.P3 = Com.MaxPofY(pointList, "X", Com.MaxP(pointList, "Y").Y);
                    RetP.P4 = Com.MaxPofY(pointList, "X", Com.MinP(pointList, "Y").Y);

                    RetP.P5 = Com.MinPofX(pointList, "Y", Com.MaxP(pointList, "X").X);
                }
            }

            else
            {
                if (RetP.CentP.Y > BC.Points.CentP.Y)
                {
                    RetP.P1 = Com.MaxPofX(pointList, "Y", Com.MaxP(pointList, "X").X);
                    RetP.P2 = Com.MaxPofY(pointList, "X", Com.MinP(pointList, "Y").Y);
                    RetP.P3 = Com.MinPofY(pointList, "X", Com.MinP(pointList, "Y").Y);
                    RetP.P4 = Com.MinPofY(pointList, "X", Com.MaxP(pointList, "Y").Y);

                    RetP.P5 = Com.MaxPofX(pointList, "Y", Com.MinP(pointList, "X").X);
                }
                else
                {
                    RetP.P1 = Com.MinPofX(pointList, "Y", Com.MaxP(pointList, "X").X);
                    RetP.P2 = Com.MaxPofY(pointList, "X", Com.MaxP(pointList, "Y").Y);
                    RetP.P3 = Com.MinPofY(pointList, "X", Com.MaxP(pointList, "Y").Y);
                    RetP.P4 = Com.MinPofY(pointList, "X", Com.MinP(pointList, "Y").Y);

                    RetP.P5 = Com.MinPofX(pointList, "Y", Com.MinP(pointList, "X").X);
                }
            }
            return RetP;
        }

        #endregion

        #region Helping Methods

        private bool IsBrace(Beam b)
        {
            bool RetCheck = false;
            if (b.Name.ToLower().Contains("brace") || (dc.IsMainPart(b) && !dc.IsPlate(b)))
            {
                if ((b.StartPoint.Y < BC.Points.P1.Y && b.StartPoint.Y > BC.Points.P2.Y) || (b.EndPoint.Y < BC.Points.P1.Y && b.EndPoint.Y > BC.Points.P2.Y))
                    RetCheck = true;
            }

            return RetCheck;
        }



        private Point GetIntSectPoint(BoltGroup bolt, Beam brace, string Position)
        {
            Vector Vect = bolt.GetCoordinateSystem().AxisX;
            PointList PtList = new PointList();
            Point IntSectP = null;
            if (Position == "Top")
            {
                if (Vect.Y > 0)
                    Vect = Com.ChangeVector(Vect);
            }
            else
            {
                if (Vect.Y < 0)
                    Vect = Com.ChangeVector(Vect);
            }

            PtList = dc.ChangePints(bolt, CView, Vect);
            if (PtList.Count > 1)
                IntSectP = Com.GetIntersectionPoint(PtList[0], PtList[1], brace.StartPoint, brace.EndPoint);
            else if (PtList.Count == 1)
                IntSectP = PtList[0];

            return IntSectP;

        }


        #endregion

    }

    public class BeamClass_BG5
    {
        public Beam beam { get; set; }
        public GussetClass TopGP { get; set; }
        public GussetClass BottGP { get; set; }
        public AngleClass TopAngle { get; set; }
        public AngleClass MidAngle { get; set; }
        public AngleClass BottAngle { get; set; }
        public BoltGroup LeftBolt { get; set; }
        public BoltGroup RightBolt { get; set; }
        public PartPoints Points { get; set; }
        public PlacingClass PC { get; set; }
        public bool IsBoltBothLeg { get; set; }

    }

    public class BeamClass_BG5S
    {
        public Beam beam { get; set; }
        public GussetClass TopGP { get; set; }
        public GussetClass BottGP { get; set; }
        public AngleClass TopAngleL { get; set; }
        public AngleClass TopAngleR { get; set; }
        public AngleClass MidAngleL { get; set; }
        public AngleClass MidAngleR { get; set; }
        public AngleClass BottAngleL { get; set; }
        public AngleClass BottAngleR { get; set; }
        public PartPoints Points { get; set; }
        public PlacingClass PC { get; set; }
        public bool IsBoltBothLeg { get; set; }

    }


}
