﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Tekla.Structures;
using Tekla.Structures.Drawing;
using Tekla.Structures.Geometry3d;
using Tekla.Structures.Model;
using TSD = Tekla.Structures.Drawing;
using TSM = Tekla.Structures.Model;
using VirtueleDrawingAutomation;
using TSDD = Tekla.Structures.Datatype;
using TSG = Tekla.Structures.Geometry3d;

namespace Auto_Detailing_Tool_Beam
{
    public class BeamDim_BG18
    {
        #region Global Variables
        DimCom dc = new DimCom();
        StraightDimensionSet.StraightDimensionSetAttributes StAtrr = new StraightDimensionSet.StraightDimensionSetAttributes("standard");
        StraightDimensionSet.StraightDimensionSetAttributes RdAtrr = new StraightDimensionSet.StraightDimensionSetAttributes("standard");

        public Beam MainBeam = null;
        VirtueleDrawingAutomation.Json.DrawingAttributeInfoJson.AttributeFiles dimAttrClass = null;
        List<TSD.StraightDimension> KnockDim = new List<StraightDimension>();
        BeamClass_BG18 BC = null;
        BeamClass_BG18S BCS = null;
        VirtueleDrawingAutomation.Json.AutoDimensionTypesJson.BG18Json DN = null;
        TSD.View CView = null;
        string ViewName = "";
        List<int> Ids = new List<int>();
        #endregion

        public List<int> ApplyDim(TSD.View CView, string ViewName, AutoDimensioningTypes autoDimensioningTypes, DrawingAttributeInfo drawingAttributeInfo, List<int> Ids)
        {
            try
            {
                this.Ids = Ids;
                Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane());
                //Set model everything to the view
                Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane(CView.DisplayCoordinateSystem));

                this.CView = CView;
                this.dimAttrClass = drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files;
                this.DN = autoDimensioningTypes.Bg18;
                StAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.StandardDimension);
                RdAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.RunningDimension);
                this.MainBeam = (Com.MyModel.SelectModelObject(new Identifier((CView.GetDrawing() as AssemblyDrawing).AssemblyIdentifier.ID)) as TSM.Assembly).GetMainPart() as TSM.Beam;
                this.MainBeam.Select();
                string ProType = Com.GetProType(MainBeam);
                this.ViewName = ViewName;


                GetBeamClassClass(CView);

                //TestDim();
                if (ViewName == "Front View")
                {
                    while (BC.TopGP != null || BC.BottGP != null)
                    {
                        ApplyDimType(CView);
                        GetBeamClassClass(CView);
                    }

                }
                else if (ViewName == "Section View")
                    AppySectionDim();

            }
            catch (Exception ex)
            { }


            Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane());

            return Ids;

        }

        private void ApplyDimType(TSD.View CView)
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            TSD.PointList TempList = new PointList();
            bool IsVertDim = false;
            Point RefP = null;

            #region Top Gusset
            if (BC.TopGP?.GussetPlate != null)
            {
                // BC.TopGP.GussetPlate

                ApplyLeftTopG();
                ApplyRightTopG();


                // Dim No 8
                if (DN.DimIDNo8)
                {
                    Vect = new Vector(1, 0, 0);
                    pointList = new PointList();
                    if (BC.TopGP.LB != null)
                        pointList.Add(BC.TopGP.LB.RefPBrace);
                    else if (BC.TopGP.RB != null)
                        pointList.Add(BC.TopGP.RB.RefPBrace);

                    RefP = pointList[0];
                    pointList.Add(new Point(pointList[0].X, BC.Points.P1.Y));
                    pointList.Add(new Point(pointList[0].X, BC.Points.P2.Y));
                    xDim = dc.InsertDim(CView, pointList, Vect, (BC.PC.DistInc), StAtrr);
                    if (xDim != null)
                        IsVertDim = true;


                }

                Vect = new Vector(0, 1, 0);
                // Dim No 13
                if (DN.DimIDNo13)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P2);

                    if (BC.TopGP.LB != null)
                        pointList.Add(BC.TopGP.LB.RefPBrace);
                    else if (BC.TopGP.RB != null)
                        pointList.Add(BC.TopGP.RB.RefPBrace);

                    pointList.Add(BC.TopGP.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);

                }

                // Dim No 14
                if (DN.DimIDNo14)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P2);
                    pointList.Add(BC.TopGP.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);

                }

                // Dim No 1
                if (DN.DimIDNo1)
                {
                    pointList = new PointList();

                    pointList.Add(BC.Points.P1);
                    if (BC.TopGP.LB != null)
                        pointList.Add(BC.TopGP.LB.RefPBrace);
                    else if (BC.TopGP.RB != null)
                        pointList.Add(BC.TopGP.RB.RefPBrace);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistInc, RdAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.Points.P1.Y, BC.PC.DistInc);
                }


                // Dim No 11
                if (DN.DimIDNo11)
                {

                    pointList = new PointList();

                    pointList.Add(new Point(BC.PC.LeftX, BC.Points.CentP.Y));


                    if (BC.TopGP.LB != null)
                        pointList.Add(BC.TopGP.LB.RefPBrace);
                    else if (BC.TopGP.RB != null)
                        pointList.Add(BC.TopGP.RB.RefPBrace);

                    pointList.Add(new Point(BC.PC.RightX, BC.Points.CentP.Y));

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);
                }


                // Com.SetCode(BC.TopGP.GussetPlate);
                Ids.Add(BC.TopGP.GussetPlate.Identifier.ID);
            }
            #endregion


            #region Bottom Gusset
            if (BC.BottGP?.GussetPlate != null)
            {

                ApplyLeftBottG();
                ApplyRightBottG();

                // Dim No 8
                if (DN.DimIDNo8)
                {
                    Vect = new Vector(-1, 0, 0);
                    pointList = new PointList();
                    if (BC.BottGP?.LB != null)
                        pointList.Add(BC.BottGP.LB.RefPBrace);
                    else if (BC.BottGP?.RB != null)
                        pointList.Add(BC.BottGP.RB.RefPBrace);

                    if ((RefP != null && !dc.IsEqualPoints(pointList[0], RefP)) || !IsVertDim)
                    {
                        pointList.Add(new Point(pointList[0].X, BC.Points.P1.Y));
                        pointList.Add(new Point(pointList[0].X, BC.Points.P2.Y));
                        xDim = dc.InsertDim(CView, pointList, Vect, (BC.PC.DistInc), StAtrr);

                    }

                }

                Vect = new Vector(0, -1, 0);

                // Dim No 13
                if (DN.DimIDNo13)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P2);

                    if (BC.BottGP.LB != null)
                        pointList.Add(BC.BottGP.LB.RefPBrace);
                    else if (BC.BottGP.RB != null)
                        pointList.Add(BC.BottGP.RB.RefPBrace);

                    pointList.Add(BC.BottGP.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);

                }

                // Dim No 14
                if (DN.DimIDNo14)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P2);
                    pointList.Add(BC.BottGP.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);

                }

                // Dim No 1
                if (DN.DimIDNo1)
                {
                    BC.PC.DistTop = BC.PC.DistInc;
                    Point RefP1 = null;
                    if (BC.BottGP?.LB != null)
                        RefP1 = BC.BottGP.LB.RefPBrace;
                    else if (BC.BottGP?.RB != null)
                        RefP1 = BC.BottGP.RB.RefPBrace;

                    if ((RefP != null && RefP1 != null && !dc.IsEqualPoints(RefP1, RefP)) || RefP == null)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.Points.P1);
                        pointList.Add(RefP1);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                        if (xDim != null)
                            PL.DistPlaceBottP(xDim, BC.Points.P2.Y, BC.PC.DistTop);
                    }

                }

                // Dim No 11
                if (DN.DimIDNo11)
                {
                    BC.PC.DistTop = BC.PC.DistInc;
                    Point RefP1 = null;
                    if (BC.BottGP?.LB != null)
                        RefP1 = BC.BottGP.LB.RefPBrace;
                    else if (BC.BottGP?.RB != null)
                        RefP1 = BC.BottGP.RB.RefPBrace;

                    if ((RefP != null && RefP1 != null && !dc.IsEqualPoints(RefP1, RefP)) || RefP == null)
                    {
                        pointList = new PointList();
                        pointList.Add(new Point(BC.PC.LeftX, BC.Points.CentP.Y));
                        pointList.Add(RefP1);
                        pointList.Add(new Point(BC.PC.RightX, BC.Points.CentP.Y));
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByBottomY(xDim, BC.PC);
                    }

                }

                Ids.Add(BC.BottGP.GussetPlate.Identifier.ID);
                // Com.SetCode(BC.BottGP.GussetPlate);
            }
            #endregion

            AppyMidStiff();




        }

        private void ApplyLeftTopG()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            TSD.PointList TempList = new PointList();

            if (BC.TopGP?.LB != null)
            {

                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;

                TempList = Com.GetBoltPoints(BC.TopGP.LB.BoltL);
                TSG.Line YLine = new TSG.Line(BC.TopGP.Points.P6, BC.TopGP.Points.P1);
                TSG.Line XLine = new TSG.Line(Com.MinP(TempList, "X"), Com.MaxP(TempList, "X"));
                Vector LeftVect = BC.TopGP.LB.BoltL.GetCoordinateSystem().AxisY;
                TSG.Line XLine1 = new TSG.Line(BC.TopGP.LB.RefPBrace, BC.TopGP.LB.IntPoint);
                if (LeftVect.X > 0)
                    LeftVect = dc.ChangeVector(LeftVect);

                Vector RightVect = BC.TopGP.LB.BoltL.GetCoordinateSystem().AxisY;
                if (RightVect.X < 0)
                    RightVect = dc.ChangeVector(RightVect);

                Vector TopVect = XLine1.Direction;
                if (TopVect.Y < 0)
                    TopVect = dc.ChangeVector(TopVect);

                Vector BottVect = XLine1.Direction;
                if (BottVect.Y > 0)
                    BottVect = dc.ChangeVector(BottVect);

                #region Diagonal Top

                if (BC.TopGP.LB.Degree > 50)
                {
                    double Deg = BC.TopGP.LB.Degree - 50;
                    BC.PC.DistTop = Deg * ((BC.PC.DistInc * 5) / 10);

                    BC.PC.DistTop += (BC.PC.DistInc * 5);
                }
                else
                    BC.PC.DistTop = (BC.PC.DistInc * 5);


                // Dim No 3
                if (DN.DimIDNo3)
                {
                    pointList = new PointList();
                    pointList.AddRange(dc.ChangePints(BC.TopGP.LB.BoltM, CView, TopVect));
                    pointList.Add(BC.TopGP.LB.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, TopVect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }

                // Dim No 6
                if (DN.DimIDNo6)
                {
                    pointList = new PointList();
                    pointList.AddRange(dc.ChangePints(BC.TopGP.LB.BoltM, CView, TopVect));
                    xDim = dc.InsertDim(CView, pointList, TopVect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistTop);

                }


                // Dim No 6.1
                if (DN.DimIDNo6Dot1)
                {
                    pointList = new PointList();
                    TempList = dc.ChangePints(BC.TopGP.LB.BoltL, CView, TopVect);
                    pointList.Add(Com.MaxP(TempList, "Y"));

                    TempList = dc.ChangePints(BC.TopGP.LB.BoltM, CView, TopVect);
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, TopVect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistTop);


                    pointList = new PointList();
                    TempList = dc.ChangePints(BC.TopGP.LB.BoltR, CView, TopVect);
                    pointList.Add(Com.MinP(TempList, "Y"));

                    TempList = dc.ChangePints(BC.TopGP.LB.BoltM, CView, TopVect);
                    pointList.Add(Com.MinP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, TopVect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistTop);

                }

                if (DN.DimIDNo6 || DN.DimIDNo6Dot1)
                    BC.PC.DistTop += BC.PC.DistInc;

                TempList = Com.GetBoltPoints(BC.TopGP.LB.BoltL);
                TempList.AddRange(Com.GetBoltPoints(BC.TopGP.LB.BoltR));
                TempList = dc.ChangePints(TempList, CView, TopVect);

                // Dim No 4
                if (DN.DimIDNo4)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    pointList.Add(BC.TopGP.LB.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, TopVect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }



                // Dim No 7
                if (DN.DimIDNo7)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, TopVect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }

                #endregion

                #region Diagonal Right

                TempList = Com.GetBoltPoints(BC.TopGP.LB.BoltL);
                TempList.AddRange(Com.GetBoltPoints(BC.TopGP.LB.BoltR));
                TempList = dc.ChangePints(TempList, CView, RightVect);



                // Dim No 9.1
                if (DN.DimIDNo9Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "X"));
                    pointList.Add(BC.TopGP.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistRight);
                }

                // Dim No 9
                if (DN.DimIDNo9)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistRight);
                }

                // Dim No 9.2
                if (DN.DimIDNo9Dot2)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "X"));
                    pointList.Add(BC.TopGP.LB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistRight);
                }

                if (DN.DimIDNo9Dot1 || DN.DimIDNo9Dot2 || DN.DimIDNo9)
                    BC.PC.DistRight += BC.PC.DistInc;

                // Dim No 9.4,9.3
                if (DN.DimIDNo9Dot3 || DN.DimIDNo9Dot4)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo9Dot3)// Dim No 9.3
                        pointList.Add(Com.MaxP(TempList, "X"));

                    pointList.Add(BC.TopGP.LB.IntPointB);
                    if (DN.DimIDNo9Dot3)// Dim No 9.4
                        pointList.Add(BC.TopGP.LB.RefPBrace);

                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistRight);

                    }
                }

                // Dim No 9.5
                if (DN.DimIDNo9Dot5)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistRight);
                        Com.GroupDim(xDim);
                    }
                }

                if (DN.DimIDNo9Dot3 || DN.DimIDNo9Dot4 || DN.DimIDNo9Dot5)
                    BC.PC.DistRight += BC.PC.DistInc;

                #endregion

                #region Straight Left
                Vect = new Vector(-1, 0, 0);
                BC.PC.DistLeft = (BC.PC.DistInc * 3);

                // Dim No 2.4
                if (DN.DimIDNo2Dot4)
                {
                    TempList = Com.GetBoltPoints(BC.TopGP.LB.BoltR);
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "Y"));
                    pointList.Add(BC.TopGP.Points.P2);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, BC.TopGP.Points.P2.X, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }

                }

                // Dim No 2.3
                if (DN.DimIDNo2Dot3)
                {
                    TempList = Com.GetBoltPoints(BC.TopGP.LB.BoltM);
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "X"));
                    pointList.Add(BC.TopGP.LB.IntPoint);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.TopGP.Points.P2.X, BC.PC.DistLeft);

                }
                // Dim No 2.2
                if (DN.DimIDNo2Dot2)
                {
                    TempList = Com.GetBoltPoints(BC.TopGP.LB.BoltM);
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "X"));
                    pointList.Add(BC.TopGP.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.TopGP.Points.P2.X, BC.PC.DistLeft);

                }

                if (DN.DimIDNo2Dot3 || DN.DimIDNo2Dot2)
                    BC.PC.DistLeft += BC.PC.DistInc;

                // Dim No 2
                if (DN.DimIDNo2)
                {

                    pointList = new PointList();
                    pointList.Add(BC.TopGP.LB.IntPoint);
                    pointList.Add(BC.TopGP.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.TopGP.Points.P2.X, BC.PC.DistLeft);

                    BC.PC.DistLeft += BC.PC.DistInc;
                }
                #endregion

                BC.PC.DistTop = (BC.PC.DistInc);

                #region RD Dim
                //RD Dim
                Vect = new Vector(0, 1, 0);

                // Dim No 1.7
                if (DN.DimIDNo1Dot7)
                {
                    TempList = Com.GetBoltPoints(BC.TopGP.LB.BoltR);
                    pointList = new PointList();
                    pointList.Add(BC.RDPoint);
                    pointList.Add(Com.MinP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                // Dim No 1.1
                if (DN.DimIDNo1Dot1)
                {
                    TempList = Com.GetBoltPoints(BC.TopGP.LB.BoltM);
                    pointList = new PointList();
                    pointList.Add(BC.RDPoint);
                    pointList.Add(Com.MinP(TempList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                // Dim No 1.2
                if (DN.DimIDNo1Dot2)
                {
                    pointList = new PointList();
                    pointList.Add(BC.RDPoint);
                    pointList.Add(BC.TopGP.LB.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }



                // Dim No 1.3
                if (DN.DimIDNo1Dot3)
                {
                    pointList = new PointList();
                    pointList.Add(BC.RDPoint);
                    pointList.Add(BC.TopGP.LB.IntPointB);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }


                #endregion

                #region Top Straight Dim

                Vect = new Vector(0, 1, 0);
                // Dim No 10.2
                if (DN.DimIDNo10Dot2)
                {
                    TempList = Com.GetBoltPoints(BC.TopGP.LB.BoltM);
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.LB.IntPoint);
                    pointList.Add(Com.MinP(TempList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);

                }

                // Dim No 10.1
                if (DN.DimIDNo10Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.LB.IntPoint);
                    pointList.Add(BC.TopGP.LB.IntPointB);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);

                }

                // Dim No 10
                if (DN.DimIDNo10)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.LB.RefPBrace);
                    pointList.Add(BC.TopGP.LB.IntPointB);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);

                }


                if (DN.DimIDNo10Dot2 || DN.DimIDNo10Dot1 || DN.DimIDNo10)
                    BC.PC.DistTop += BC.PC.DistInc;


                // Dim No 12
                if (DN.DimIDNo12)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P2);
                    pointList.Add(BC.TopGP.LB.IntPoint);
                    pointList.Add(BC.TopGP.LB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);

                }



                #endregion

                // Com.DrawLineDotted(CView, BC.TopGP.LB.IntPoint, BC.TopGP.LB.RefPBrace);

                //Dim Code 5 // Angle Dimension
                if (DN.DimIDNo5)
                    Com.InsertAngleDim(CView, BC.TopGP.LB.RefPBrace, BC.TopGP.LB.IntPoint, "Top", 160);


            }
        }

        private void ApplyRightTopG()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            TSD.PointList TempList = new PointList();

            if (BC.TopGP?.RB != null)
            {
                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;

                TempList = Com.GetBoltPoints(BC.TopGP.RB.BoltR);
                TSG.Line YLine = new TSG.Line(BC.TopGP.Points.P4, BC.TopGP.Points.P5);
                TSG.Line XLine = new TSG.Line(Com.MinP(TempList, "X"), Com.MaxP(TempList, "X"));
                Vector LeftVect = BC.TopGP.RB.BoltL.GetCoordinateSystem().AxisY;
                TSG.Line XLine1 = new TSG.Line(BC.TopGP.RB.RefPBrace, BC.TopGP.RB.IntPoint);

                if (LeftVect.X > 0)
                    LeftVect = dc.ChangeVector(LeftVect);

                Vector RightVect = BC.TopGP.RB.BoltL.GetCoordinateSystem().AxisY;
                if (RightVect.X < 0)
                    RightVect = dc.ChangeVector(RightVect);

                Vector TopVect = XLine1.Direction;
                if (TopVect.Y < 0)
                    TopVect = dc.ChangeVector(TopVect);

                Vector BottVect = XLine1.Direction;
                if (BottVect.Y > 0)
                    BottVect = dc.ChangeVector(BottVect);



                #region Diagonal Top

                if (BC.TopGP.RB.Degree > 50)
                {
                    double Deg = BC.TopGP.RB.Degree - 50;
                    BC.PC.DistTop = Deg * ((BC.PC.DistInc * 5) / 10);

                    BC.PC.DistTop += (BC.PC.DistInc * 5);
                }
                else
                    BC.PC.DistTop = (BC.PC.DistInc * 5);



                // Dim No 3
                if (DN.DimIDNo3)
                {
                    pointList = new PointList();
                    pointList.AddRange(dc.ChangePints(BC.TopGP.RB.BoltM, CView, TopVect));
                    pointList.Add(BC.TopGP.RB.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, TopVect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }

                // Dim No 6
                if (DN.DimIDNo6)
                {
                    pointList = new PointList();
                    pointList.AddRange(dc.ChangePints(BC.TopGP.RB.BoltM, CView, TopVect));
                    xDim = dc.InsertDim(CView, pointList, TopVect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistTop);

                }


                // Dim No 6.1
                if (DN.DimIDNo6Dot1)
                {
                    pointList = new PointList();
                    TempList = dc.ChangePints(BC.TopGP.RB.BoltL, CView, TopVect);
                    pointList.Add(Com.MaxP(TempList, "Y"));

                    TempList = dc.ChangePints(BC.TopGP.RB.BoltM, CView, TopVect);
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, TopVect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistTop);


                    pointList = new PointList();
                    TempList = dc.ChangePints(BC.TopGP.RB.BoltR, CView, TopVect);
                    pointList.Add(Com.MinP(TempList, "Y"));

                    TempList = dc.ChangePints(BC.TopGP.RB.BoltM, CView, TopVect);
                    pointList.Add(Com.MinP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, TopVect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistTop);

                }

                if (DN.DimIDNo6 || DN.DimIDNo6Dot1)
                    BC.PC.DistTop += BC.PC.DistInc;

                TempList = Com.GetBoltPoints(BC.TopGP.RB.BoltL);
                TempList.AddRange(Com.GetBoltPoints(BC.TopGP.RB.BoltR));
                TempList = dc.ChangePints(TempList, CView, TopVect);

                // Dim No 4
                if (DN.DimIDNo4)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    pointList.Add(BC.TopGP.RB.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, TopVect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }



                // Dim No 7
                if (DN.DimIDNo7)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, TopVect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }

                #endregion

                #region Diagonal Right

                TempList = Com.GetBoltPoints(BC.TopGP.RB.BoltL);
                TempList.AddRange(Com.GetBoltPoints(BC.TopGP.RB.BoltR));
                TempList = dc.ChangePints(TempList, CView, RightVect);



                // Dim No 9.1
                if (DN.DimIDNo9Dot1)
                {
                    BC.PC.DistRight += (BC.PC.DistInc / 2);
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    pointList.Add(BC.TopGP.Points.P5);
                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistRight);

                    BC.PC.DistRight -= (BC.PC.DistInc / 2);
                }

                // Dim No 9
                if (DN.DimIDNo9)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistRight);
                }

                // Dim No 9.2
                if (DN.DimIDNo9Dot2)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "Y"));
                    pointList.Add(BC.TopGP.RB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistRight);
                }

                if (DN.DimIDNo9Dot1 || DN.DimIDNo9Dot2 || DN.DimIDNo9)
                    BC.PC.DistRight += BC.PC.DistInc;

                // Dim No 9.4,9.3
                if (DN.DimIDNo9Dot3 || DN.DimIDNo9Dot4)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo9Dot3)// Dim No 9.3
                        pointList.Add(Com.MinP(TempList, "Y"));

                    pointList.Add(BC.TopGP.RB.IntPointB);
                    if (DN.DimIDNo9Dot3)// Dim No 9.4
                        pointList.Add(BC.TopGP.RB.RefPBrace);

                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistRight);
                    }
                }

                // Dim No 9
                if (DN.DimIDNo9Dot5)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                    {
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistRight);
                        Com.GroupDim(xDim);
                    }
                }

                if (DN.DimIDNo9Dot3 || DN.DimIDNo9Dot4 || DN.DimIDNo9Dot5)
                    BC.PC.DistRight += BC.PC.DistInc;

                #endregion

                #region Straight Right
                Vect = new Vector(1, 0, 0);
                BC.PC.DistRight = (BC.PC.DistInc * 3);

                // Dim No 2.4
                if (DN.DimIDNo2Dot4)
                {
                    TempList = Com.GetBoltPoints(BC.TopGP.RB.BoltR);
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "Y"));
                    pointList.Add(BC.TopGP.Points.P3);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, BC.TopGP.Points.P3.X, BC.PC.DistRight);
                        BC.PC.DistRight += (BC.PC.DistInc);
                    }

                }

                // Dim No 2.3
                if (DN.DimIDNo2Dot3)
                {
                    TempList = Com.GetBoltPoints(BC.TopGP.RB.BoltM);
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "X"));
                    pointList.Add(BC.TopGP.RB.IntPoint);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.TopGP.Points.P3.X, BC.PC.DistRight);

                }
                // Dim No 2.2
                if (DN.DimIDNo2Dot2)
                {
                    TempList = Com.GetBoltPoints(BC.TopGP.RB.BoltM);
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "X"));
                    pointList.Add(BC.TopGP.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.TopGP.Points.P3.X, BC.PC.DistRight);

                }

                if (DN.DimIDNo2Dot3 || DN.DimIDNo2Dot2)
                    BC.PC.DistRight += BC.PC.DistInc;

                // Dim No 2
                if (DN.DimIDNo2)
                {

                    pointList = new PointList();
                    pointList.Add(BC.TopGP.RB.IntPoint);
                    pointList.Add(BC.TopGP.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.TopGP.Points.P3.X, BC.PC.DistRight);

                    BC.PC.DistRight += BC.PC.DistInc;
                }
                #endregion

                BC.PC.DistTop = (BC.PC.DistInc);

                #region RD Dim
                //RD Dim
                Vect = new Vector(0, 1, 0);

                // Dim No 1.8
                if (DN.DimIDNo1Dot8)
                {
                    TempList = Com.GetBoltPoints(BC.TopGP.RB.BoltR);
                    pointList = new PointList();
                    pointList.Add(BC.RDPoint);
                    pointList.Add(Com.MinP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                // Dim No 1.1
                if (DN.DimIDNo1Dot1)
                {
                    TempList = Com.GetBoltPoints(BC.TopGP.RB.BoltM);
                    pointList = new PointList();
                    pointList.Add(BC.RDPoint);
                    pointList.Add(Com.MaxP(TempList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                // Dim No 1.2
                if (DN.DimIDNo1Dot2)
                {
                    pointList = new PointList();
                    pointList.Add(BC.RDPoint);
                    pointList.Add(BC.TopGP.RB.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }



                // Dim No 1.3
                if (DN.DimIDNo1Dot3)
                {
                    pointList = new PointList();
                    pointList.Add(BC.RDPoint);
                    pointList.Add(BC.TopGP.RB.IntPointB);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }


                #endregion

                #region Top Straight Dim

                Vect = new Vector(0, 1, 0);
                // Dim No 10.2
                if (DN.DimIDNo10Dot2)
                {
                    TempList = Com.GetBoltPoints(BC.TopGP.RB.BoltM);
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.RB.IntPoint);
                    pointList.Add(Com.MaxP(TempList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);

                }

                // Dim No 10.1
                if (DN.DimIDNo10Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.RB.IntPoint);
                    pointList.Add(BC.TopGP.RB.IntPointB);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);

                }

                // Dim No 10
                if (DN.DimIDNo10)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.RB.RefPBrace);
                    pointList.Add(BC.TopGP.RB.IntPointB);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);

                }


                if (DN.DimIDNo10Dot2 || DN.DimIDNo10Dot1 || DN.DimIDNo10)
                    BC.PC.DistTop += BC.PC.DistInc;


                // Dim No 12
                if (DN.DimIDNo12)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P3);
                    pointList.Add(BC.TopGP.RB.IntPoint);
                    pointList.Add(BC.TopGP.RB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);

                }



                #endregion

                //  Com.DrawLineDotted(CView, BC.TopGP.RB.IntPoint, BC.TopGP.RB.RefPBrace);

                //Dim Code 5 // Angle Dimension
                if (DN.DimIDNo5)
                    Com.InsertAngleDim(CView, BC.TopGP.RB.RefPBrace, BC.TopGP.RB.IntPoint, "Top", 160);


            }
        }

        private void ApplyLeftBottG()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, -1, 0);
            TSD.PointList TempList = new PointList();

            if (BC.BottGP?.LB != null)
            {

                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;

                TempList = Com.GetBoltPoints(BC.BottGP.LB.BoltL);
                TSG.Line YLine = new TSG.Line(BC.BottGP.Points.P6, BC.BottGP.Points.P1);
                TSG.Line XLine = new TSG.Line(Com.MinP(TempList, "X"), Com.MaxP(TempList, "X"));
                Vector LeftVect = BC.BottGP.LB.BoltL.GetCoordinateSystem().AxisY;

                TSG.Line XLine1 = new TSG.Line(BC.BottGP.LB.RefPBrace, BC.BottGP.LB.IntPoint);

                if (LeftVect.X > 0)
                    LeftVect = dc.ChangeVector(LeftVect);

                Vector RightVect = BC.BottGP.LB.BoltL.GetCoordinateSystem().AxisY;
                if (RightVect.X < 0)
                    RightVect = dc.ChangeVector(RightVect);

                Vector TopVect = XLine1.Direction;
                if (TopVect.Y < 0)
                    TopVect = dc.ChangeVector(TopVect);

                Vector BottVect = XLine1.Direction;
                if (BottVect.Y > 0)
                    BottVect = dc.ChangeVector(BottVect);

                #region Diagonal Top

                if (BC.BottGP.LB.Degree > 50)
                {
                    double Deg = BC.BottGP.LB.Degree - 50;
                    BC.PC.DistBot = Deg * ((BC.PC.DistInc * 5) / 10);

                    BC.PC.DistBot += (BC.PC.DistInc * 5);
                }
                else
                    BC.PC.DistBot = (BC.PC.DistInc * 5);


                // Dim No 3
                if (DN.DimIDNo3)
                {
                    pointList = new PointList();
                    pointList.AddRange(dc.ChangePints(BC.BottGP.LB.BoltM, CView, BottVect));
                    pointList.Add(BC.BottGP.LB.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, BottVect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }

                // Dim No 6
                if (DN.DimIDNo6)
                {
                    pointList = new PointList();
                    pointList.AddRange(dc.ChangePints(BC.BottGP.LB.BoltM, CView, BottVect));
                    xDim = dc.InsertDim(CView, pointList, BottVect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistBot);

                }


                // Dim No 6.1
                if (DN.DimIDNo6Dot1)
                {
                    pointList = new PointList();
                    TempList = dc.ChangePints(BC.BottGP.LB.BoltL, CView, BottVect);
                    pointList.Add(Com.MaxP(TempList, "Y"));

                    TempList = dc.ChangePints(BC.BottGP.LB.BoltM, CView, BottVect);
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, BottVect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistBot);


                    pointList = new PointList();
                    TempList = dc.ChangePints(BC.BottGP.LB.BoltR, CView, BottVect);
                    pointList.Add(Com.MinP(TempList, "Y"));

                    TempList = dc.ChangePints(BC.BottGP.LB.BoltM, CView, BottVect);
                    pointList.Add(Com.MinP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, BottVect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistBot);

                }

                if (DN.DimIDNo6 || DN.DimIDNo6Dot1)
                    BC.PC.DistBot += BC.PC.DistInc;

                TempList = Com.GetBoltPoints(BC.BottGP.LB.BoltL);
                TempList.AddRange(Com.GetBoltPoints(BC.BottGP.LB.BoltR));
                TempList = dc.ChangePints(TempList, CView, BottVect);

                // Dim No 4
                if (DN.DimIDNo4)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    pointList.Add(BC.BottGP.LB.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, BottVect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }



                // Dim No 7
                if (DN.DimIDNo7)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, BottVect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }

                #endregion

                #region Diagonal Left

                TempList = Com.GetBoltPoints(BC.BottGP.LB.BoltL);
                TempList.AddRange(Com.GetBoltPoints(BC.BottGP.LB.BoltR));
                TempList = dc.ChangePints(TempList, CView, LeftVect);


                // Dim No 9.1
                if (DN.DimIDNo9Dot1)
                {
                    BC.PC.DistLeft += (BC.PC.DistInc / 2);
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "Y"));
                    pointList.Add(BC.BottGP.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);

                    BC.PC.DistLeft -= (BC.PC.DistInc / 2);
                }

                // Dim No 9
                if (DN.DimIDNo9)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);
                }

                // Dim No 9.2
                if (DN.DimIDNo9Dot2)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    pointList.Add(BC.BottGP.LB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);
                }

                if (DN.DimIDNo9Dot1 || DN.DimIDNo9Dot2 || DN.DimIDNo9)
                    BC.PC.DistLeft += BC.PC.DistInc;


                // Dim No 9.4,9.3
                if (DN.DimIDNo9Dot3 || DN.DimIDNo9Dot4)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo9Dot3)// Dim No 9.3
                        pointList.Add(Com.MaxP(TempList, "Y"));

                    pointList.Add(BC.BottGP.LB.IntPointB);
                    if (DN.DimIDNo9Dot3)// Dim No 9.4
                        pointList.Add(BC.BottGP.LB.RefPBrace);

                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);

                    }
                }

                // Dim No 9.5
                if (DN.DimIDNo9Dot5)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);
                        Com.GroupDim(xDim);
                    }
                }

                if (DN.DimIDNo9Dot3 || DN.DimIDNo9Dot4 || DN.DimIDNo9Dot5)
                    BC.PC.DistLeft += BC.PC.DistInc;


                #endregion

                #region Straight Left
                Vect = new Vector(-1, 0, 0);
                BC.PC.DistLeft = (BC.PC.DistInc * 3);

                // Dim No 2.4
                if (DN.DimIDNo2Dot4)
                {
                    TempList = Com.GetBoltPoints(BC.BottGP.LB.BoltL);
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    pointList.Add(BC.BottGP.Points.P2);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, BC.BottGP.Points.P2.X, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }

                }

                // Dim No 2.5
                if (DN.DimIDNo2Dot5)
                {
                    TempList = Com.GetBoltPoints(BC.BottGP.LB.BoltL);
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    pointList.Add(new Point(BC.BottGP.Points.P2.X, BC.Points.P1.Y));

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, BC.BottGP.Points.P2.X, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }

                }

                // Dim No 2.3
                if (DN.DimIDNo2Dot3)
                {
                    TempList = Com.GetBoltPoints(BC.BottGP.LB.BoltM);
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "X"));
                    pointList.Add(BC.BottGP.LB.IntPoint);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.BottGP.Points.P2.X, BC.PC.DistLeft);

                }
                // Dim No 2.2
                if (DN.DimIDNo2Dot2)
                {
                    TempList = Com.GetBoltPoints(BC.BottGP.LB.BoltM);
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "X"));
                    pointList.Add(BC.BottGP.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.BottGP.Points.P2.X, BC.PC.DistLeft);

                }

                if (DN.DimIDNo2Dot3 || DN.DimIDNo2Dot2)
                    BC.PC.DistLeft += BC.PC.DistInc;

                // Dim No 2
                if (DN.DimIDNo2)
                {

                    pointList = new PointList();
                    pointList.Add(BC.BottGP.LB.IntPoint);
                    pointList.Add(BC.BottGP.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.BottGP.Points.P2.X, BC.PC.DistLeft);

                    BC.PC.DistLeft += BC.PC.DistInc;
                }

                // Dim No 2.1
                if (DN.DimIDNo2Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.LB.IntPoint);
                    pointList.Add(new Point(BC.BottGP.Points.P2.X, BC.Points.P1.Y));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.BottGP.Points.P2.X, BC.PC.DistLeft);

                    BC.PC.DistLeft += BC.PC.DistInc;
                }

                // Dim No 15
                if (DN.DimIDNo15)
                {
                    if (BC.TopGP?.GussetPlate != null)
                    {
                        Vect = new Vector(-1, 0, 0);

                        pointList = new PointList();
                        pointList.Add(BC.TopGP.Points.P1);
                        pointList.Add(BC.BottGP.Points.P1);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceLeftP(xDim, BC.BottGP.Points.P2.X, BC.PC.DistLeft);
                    }
                }


                #endregion

                BC.PC.DistBot = (BC.PC.DistInc);

                #region RD Dim
                //RD Dim
                Vect = new Vector(0, -1, 0);

                // Dim No 1.7
                if (DN.DimIDNo1Dot7)
                {
                    TempList = Com.GetBoltPoints(BC.BottGP.LB.BoltL);
                    pointList = new PointList();
                    pointList.Add(BC.RDPoint);
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                // Dim No 1.1
                if (DN.DimIDNo1Dot1)
                {
                    TempList = Com.GetBoltPoints(BC.BottGP.LB.BoltM);
                    pointList = new PointList();
                    pointList.Add(BC.RDPoint);
                    pointList.Add(Com.MinP(TempList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                // Dim No 1.2
                if (DN.DimIDNo1Dot2)
                {
                    pointList = new PointList();
                    pointList.Add(BC.RDPoint);
                    pointList.Add(BC.BottGP.LB.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }



                // Dim No 1.3
                if (DN.DimIDNo1Dot3)
                {
                    pointList = new PointList();
                    pointList.Add(BC.RDPoint);
                    pointList.Add(BC.BottGP.LB.IntPointB);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }


                #endregion

                #region Bottom Straight Dim

                Vect = new Vector(0, -1, 0);
                // Dim No 10.2
                if (DN.DimIDNo10Dot2)
                {
                    TempList = Com.GetBoltPoints(BC.BottGP.LB.BoltM);
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.LB.IntPoint);
                    pointList.Add(Com.MinP(TempList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);

                }

                // Dim No 10.1
                if (DN.DimIDNo10Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.LB.IntPoint);
                    pointList.Add(BC.BottGP.LB.IntPointB);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);

                }

                // Dim No 10
                if (DN.DimIDNo10)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.LB.RefPBrace);
                    pointList.Add(BC.BottGP.LB.IntPointB);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);

                }


                if (DN.DimIDNo10Dot2 || DN.DimIDNo10Dot1 || DN.DimIDNo10)
                    BC.PC.DistBot += BC.PC.DistInc;


                // Dim No 12
                if (DN.DimIDNo12)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P2);
                    pointList.Add(BC.BottGP.LB.IntPoint);
                    pointList.Add(BC.BottGP.LB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);

                }



                #endregion

                // Com.DrawLineDotted(CView, BC.BottGP.LB.IntPoint, BC.BottGP.LB.RefPBrace);

                //Dim Code 5 // Angle Dimension
                if (DN.DimIDNo5)
                    Com.InsertAngleDim(CView, BC.BottGP.LB.RefPBrace, BC.BottGP.LB.IntPoint, "Bottom", 160);


            }
        }

        private void ApplyRightBottG()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            TSD.PointList TempList = new PointList();

            if (BC.BottGP?.RB != null)
            {
                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;

                TempList = Com.GetBoltPoints(BC.BottGP.RB.BoltR);
                TSG.Line YLine = new TSG.Line(BC.BottGP.Points.P4, BC.BottGP.Points.P5);
                TSG.Line XLine = new TSG.Line(Com.MinP(TempList, "X"), Com.MaxP(TempList, "X"));
                TSG.Line XLine1 = new TSG.Line(BC.BottGP.RB.RefPBrace, BC.BottGP.RB.IntPoint);

                Vector LeftVect = BC.BottGP.RB.BoltL.GetCoordinateSystem().AxisY;

                if (LeftVect.X > 0)
                    LeftVect = dc.ChangeVector(LeftVect);

                Vector RightVect = BC.BottGP.RB.BoltL.GetCoordinateSystem().AxisY;
                if (RightVect.X < 0)
                    RightVect = dc.ChangeVector(RightVect);

                Vector TopVect = XLine1.Direction;
                if (TopVect.Y < 0)
                    TopVect = dc.ChangeVector(TopVect);

                Vector BottVect = XLine1.Direction;
                if (BottVect.Y > 0)
                    BottVect = dc.ChangeVector(BottVect);

                #region Diagonal Bottom

                if (BC.BottGP.RB.Degree > 50)
                {
                    double Deg = BC.BottGP.RB.Degree - 50;
                    BC.PC.DistBot = Deg * ((BC.PC.DistInc * 5) / 10);

                    BC.PC.DistBot += (BC.PC.DistInc * 5);
                }
                else
                    BC.PC.DistBot = (BC.PC.DistInc * 5);


                // Dim No 3
                if (DN.DimIDNo3)
                {
                    pointList = new PointList();
                    pointList.AddRange(dc.ChangePints(BC.BottGP.RB.BoltM, CView, BottVect));
                    pointList.Add(BC.BottGP.RB.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, BottVect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }

                // Dim No 6
                if (DN.DimIDNo6)
                {
                    pointList = new PointList();
                    pointList.AddRange(dc.ChangePints(BC.BottGP.RB.BoltM, CView, BottVect));
                    xDim = dc.InsertDim(CView, pointList, BottVect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistBot);

                }


                // Dim No 6.1
                if (DN.DimIDNo6Dot1)
                {
                    pointList = new PointList();
                    TempList = dc.ChangePints(BC.BottGP.RB.BoltL, CView, BottVect);
                    pointList.Add(Com.MaxP(TempList, "Y"));

                    TempList = dc.ChangePints(BC.BottGP.RB.BoltM, CView, BottVect);
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, BottVect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistBot);


                    pointList = new PointList();
                    TempList = dc.ChangePints(BC.BottGP.RB.BoltR, CView, BottVect);
                    pointList.Add(Com.MinP(TempList, "Y"));

                    TempList = dc.ChangePints(BC.BottGP.RB.BoltM, CView, BottVect);
                    pointList.Add(Com.MinP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, BottVect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistBot);

                }

                if (DN.DimIDNo6 || DN.DimIDNo6Dot1)
                    BC.PC.DistBot += BC.PC.DistInc;

                TempList = Com.GetBoltPoints(BC.BottGP.RB.BoltL);
                TempList.AddRange(Com.GetBoltPoints(BC.BottGP.RB.BoltR));
                TempList = dc.ChangePints(TempList, CView, BottVect);

                // Dim No 4
                if (DN.DimIDNo4)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    pointList.Add(BC.BottGP.RB.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, BottVect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }



                // Dim No 7
                if (DN.DimIDNo7)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, BottVect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }

                #endregion

                #region Diagonal Left

                TempList = Com.GetBoltPoints(BC.BottGP.RB.BoltL);
                TempList.AddRange(Com.GetBoltPoints(BC.BottGP.RB.BoltR));
                TempList = dc.ChangePints(TempList, CView, LeftVect);



                // Dim No 9.1
                if (DN.DimIDNo9Dot1)
                {
                    BC.PC.DistLeft += (BC.PC.DistInc / 2);
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "X"));
                    pointList.Add(BC.BottGP.Points.P5);
                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);

                    BC.PC.DistLeft -= (BC.PC.DistInc / 2);
                }

                // Dim No 9
                if (DN.DimIDNo9)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);
                }

                // Dim No 9.2
                if (DN.DimIDNo9Dot2)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "X"));
                    pointList.Add(BC.BottGP.RB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);
                }

                if (DN.DimIDNo9Dot1 || DN.DimIDNo9Dot2 || DN.DimIDNo9)
                    BC.PC.DistLeft += BC.PC.DistInc;

                // Dim No 9.4,9.3
                if (DN.DimIDNo9Dot3 || DN.DimIDNo9Dot4)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo9Dot3)// Dim No 9.3
                        pointList.Add(Com.MinP(TempList, "X"));

                    pointList.Add(BC.BottGP.RB.IntPointB);
                    if (DN.DimIDNo9Dot3)// Dim No 9.4
                        pointList.Add(BC.BottGP.RB.RefPBrace);

                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);

                    }
                }

                // Dim No 9.5
                if (DN.DimIDNo9Dot5)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);
                        Com.GroupDim(xDim);
                    }
                }

                if (DN.DimIDNo9Dot3 || DN.DimIDNo9Dot4 || DN.DimIDNo9Dot5)
                    BC.PC.DistLeft += BC.PC.DistInc;

                #endregion

                #region Straight Right
                Vect = new Vector(1, 0, 0);
                BC.PC.DistRight = (BC.PC.DistInc * 3);

                // Dim No 2.4
                if (DN.DimIDNo2Dot4)
                {
                    TempList = Com.GetBoltPoints(BC.BottGP.RB.BoltL);
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    pointList.Add(BC.BottGP.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, BC.BottGP.Points.P3.X, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }

                }

                // Dim No 2.5
                if (DN.DimIDNo2Dot5)
                {
                    TempList = Com.GetBoltPoints(BC.BottGP.RB.BoltL);
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    pointList.Add(new Point(BC.BottGP.Points.P3.X, BC.Points.P1.Y));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, BC.BottGP.Points.P3.X, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }

                }

                // Dim No 2.3
                if (DN.DimIDNo2Dot3)
                {
                    TempList = Com.GetBoltPoints(BC.BottGP.RB.BoltM);
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "X"));
                    pointList.Add(BC.BottGP.RB.IntPoint);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.BottGP.Points.P3.X, BC.PC.DistRight);

                }
                // Dim No 2.2
                if (DN.DimIDNo2Dot2)
                {
                    TempList = Com.GetBoltPoints(BC.BottGP.RB.BoltM);
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "X"));
                    pointList.Add(BC.BottGP.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.BottGP.Points.P3.X, BC.PC.DistRight);

                }

                if (DN.DimIDNo2Dot3 || DN.DimIDNo2Dot2)
                    BC.PC.DistRight += BC.PC.DistInc;

                // Dim No 2
                if (DN.DimIDNo2)
                {

                    pointList = new PointList();
                    pointList.Add(BC.BottGP.RB.IntPoint);
                    pointList.Add(BC.BottGP.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.BottGP.Points.P3.X, BC.PC.DistRight);

                    BC.PC.DistRight += BC.PC.DistInc;
                }

                // Dim No 2.1
                if (DN.DimIDNo2Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.RB.IntPoint);
                    pointList.Add(new Point(BC.BottGP.Points.P3.X, BC.Points.P1.Y));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.BottGP.Points.P3.X, BC.PC.DistRight);

                    BC.PC.DistRight += BC.PC.DistInc;
                }

                #endregion

                BC.PC.DistBot = (BC.PC.DistInc);

                #region RD Dim
                //RD Dim
                Vect = new Vector(0, -1, 0);

                // Dim No 1.8
                if (DN.DimIDNo1Dot8)
                {
                    TempList = Com.GetBoltPoints(BC.BottGP.RB.BoltL);
                    pointList = new PointList();
                    pointList.Add(BC.RDPoint);
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                // Dim No 1.1
                if (DN.DimIDNo1Dot1)
                {
                    TempList = Com.GetBoltPoints(BC.BottGP.RB.BoltM);
                    pointList = new PointList();
                    pointList.Add(BC.RDPoint);
                    pointList.Add(Com.MaxP(TempList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                // Dim No 1.2
                if (DN.DimIDNo1Dot2)
                {
                    pointList = new PointList();
                    pointList.Add(BC.RDPoint);
                    pointList.Add(BC.BottGP.RB.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }



                // Dim No 1.3
                if (DN.DimIDNo1Dot3)
                {
                    pointList = new PointList();
                    pointList.Add(BC.RDPoint);
                    pointList.Add(BC.BottGP.RB.IntPointB);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }


                #endregion

                #region Top Straight Dim

                Vect = new Vector(0, -1, 0);
                // Dim No 10.2
                if (DN.DimIDNo10Dot2)
                {
                    TempList = Com.GetBoltPoints(BC.BottGP.RB.BoltM);
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.RB.IntPoint);
                    pointList.Add(Com.MaxP(TempList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);

                }

                // Dim No 10.1
                if (DN.DimIDNo10Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.RB.IntPoint);
                    pointList.Add(BC.BottGP.RB.IntPointB);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);

                }

                // Dim No 10
                if (DN.DimIDNo10)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.RB.RefPBrace);
                    pointList.Add(BC.BottGP.RB.IntPointB);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);

                }


                if (DN.DimIDNo10Dot2 || DN.DimIDNo10Dot1 || DN.DimIDNo10)
                    BC.PC.DistBot += BC.PC.DistInc;


                // Dim No 12
                if (DN.DimIDNo12)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P3);
                    pointList.Add(BC.BottGP.RB.IntPoint);
                    pointList.Add(BC.BottGP.RB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);

                }



                #endregion

                //Com.DrawLineDotted(CView, BC.BottGP.RB.IntPoint, BC.BottGP.RB.RefPBrace);

                //Dim Code 5 // Angle Dimension
                if (DN.DimIDNo5)
                    Com.InsertAngleDim(CView, BC.BottGP.RB.RefPBrace, BC.BottGP.RB.IntPoint, "Bottom", 160);

            }
        }

        private void AppyMidStiff()
        {
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            // Dim No 16, 16.1
            if (DN.DimIDNo16 || DN.DimIDNo16Dot1)
            {
                if (BC.SCB != null && BC.SCT != null)
                {

                    Vect = new Vector(0, 1, 0);
                    PointList pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(BC.SCT.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                    Vect = new Vector(0, -1, 0);
                    pointList = new PointList();
                    pointList.Add(BC.Points.P2);
                    pointList.Add(BC.SCB.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                else if (BC.SCM != null && (BC.SCB != null || BC.SCT != null))
                {
                    if (BC.SCT == null)
                    {

                        Vect = new Vector(0, 1, 0);
                        PointList pointList = new PointList();
                        pointList.Add(BC.Points.P1);
                        pointList.Add(BC.SCM.Points.P1);

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                            BC.PC.DistTop += BC.PC.DistInc;
                        }

                        Vect = new Vector(0, -1, 0);
                        pointList = new PointList();
                        pointList.Add(BC.Points.P2);
                        pointList.Add(BC.SCB.Points.P2);

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceTopP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                            BC.PC.DistBot += BC.PC.DistInc;
                        }


                    }

                    if (BC.SCB == null)
                    {

                        Vect = new Vector(0, -1, 0);
                        PointList pointList = new PointList();
                        pointList.Add(BC.Points.P2);
                        pointList.Add(BC.SCM.Points.P2);

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceTopP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                            BC.PC.DistBot += BC.PC.DistInc;
                        }

                        Vect = new Vector(0, 1, 0);
                        pointList = new PointList();
                        pointList.Add(BC.Points.P1);
                        pointList.Add(BC.SCT.Points.P1);

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                            BC.PC.DistTop += BC.PC.DistInc;
                        }

                    }
                }

                else if (BC.SCM != null)
                {
                    Vect = new Vector(0, 1, 0);
                    PointList pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(BC.SCM.Points.P1);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }


                }

                if (BC.SCM != null)
                    Com.DrawLine(CView, new Point(BC.SCM.Points.P1.X, BC.Points.P1.Y), new Point(BC.SCM.Points.P2.X, BC.Points.P2.Y));
            }
        }

        private void AppySectionDim()
        {
            StraightDimensionSet xDim = null;
            PointList pointList = new PointList();
            Vector Vect = new Vector(0, 1, 0);

            StiffClassS SC = null;
            if (BCS.SCT != null)
                SC = BCS.SCT;
            else if (BCS.SCM != null)
                SC = BCS.SCM;
            else if (BCS.SCB != null)
                SC = BCS.SCB;

            if (SC != null)
            {
                Vect = new Vector(0, 1, 0);
                // Dim No 17, 17.1
                if (DN.DimIDNo17 || DN.DimIDNo17Dot1)
                {
                    if (SC.SCL != null)
                    {
                        pointList = new PointList();
                        if (DN.DimIDNo17) // Dim No 17
                            pointList.Add(SC.SCL.Points.P1);
                        pointList.Add(SC.SCL.Points.P4);
                        if (DN.DimIDNo17Dot1) // Dim No 17.1
                            pointList.Add(new Point(BCS.Points.CentP.X, SC.SCL.Points.P4.Y));
                        xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistTop, StAtrr);
                        if (xDim != null)
                        {
                            if (BCS.SCT != null)
                                PL.DimPlaceByTopY(xDim, BCS.PC);
                            else
                            {
                                PL.DistPlaceTopP(xDim, BCS.Points.P1.Y, BCS.PC.DistTop);
                                BCS.PC.DistTop += BCS.PC.DistInc;
                            }
                        }
                    }

                    if (SC.SCR != null)
                    {
                        pointList = new PointList();
                        if (DN.DimIDNo17) // Dim No 17
                            pointList.Add(SC.SCR.Points.P4);
                        pointList.Add(SC.SCR.Points.P1);
                        if (DN.DimIDNo17Dot1) // Dim No 17.1
                            pointList.Add(new Point(BCS.Points.CentP.X, SC.SCR.Points.P1.Y));
                        xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistTop, StAtrr);
                        if (xDim != null)
                        {
                            if (BCS.SCT != null)
                                PL.DimPlaceByTopY(xDim, BCS.PC);
                            else
                            {
                                PL.DistPlaceTopP(xDim, BCS.Points.P1.Y, BCS.PC.DistTop);
                                BCS.PC.DistTop += BCS.PC.DistInc;
                            }
                        }
                    }
                }
            }


            if (BCS.SCT != null)
            {
                Vect = new Vector(-1, 0, 0);
                // Dim No 18.4
                if (DN.DimIDNo18Dot4)
                {
                    pointList = new PointList();
                    pointList.Add(BCS.SCT.SCL.Points.P1);
                    pointList.Add(BCS.SCT.SCL.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BCS.PC.LeftX, BCS.PC.DistLeft);

                }

                Vect = new Vector(1, 0, 0);
                // Dim No 18.4
                if (DN.DimIDNo18Dot4)
                {
                    pointList = new PointList();
                    pointList.Add(BCS.SCT.SCR.Points.P4);
                    pointList.Add(BCS.SCT.SCR.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BCS.PC.RightX, BCS.PC.DistRight);

                }
            }

            if (BCS.SCM != null)
            {
                Vect = new Vector(-1, 0, 0);
                // Dim No 18
                if (DN.DimIDNo18 && BCS.SCM.SCL != null)
                {
                    pointList = new PointList();
                    pointList.Add(BCS.SCM.SCL.Points.P1);
                    pointList.Add(BCS.SCM.SCL.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BCS.PC.LeftX, BCS.PC.DistLeft);

                }

                Vect = new Vector(1, 0, 0);
                // Dim No 18
                if (DN.DimIDNo18 && BCS.SCM.SCR != null)
                {
                    pointList = new PointList();
                    pointList.Add(BCS.SCM.SCR.Points.P4);
                    pointList.Add(BCS.SCM.SCR.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BCS.PC.RightX, BCS.PC.DistRight);

                }
            }

            if (BCS.SCB != null)
            {
                Vect = new Vector(-1, 0, 0);
                // Dim No 18.3
                if (DN.DimIDNo18Dot3 && BCS.SCB.SCL != null)
                {
                    pointList = new PointList();
                    pointList.Add(BCS.SCB.SCL.Points.P1);
                    pointList.Add(BCS.SCB.SCL.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BCS.PC.LeftX, BCS.PC.DistLeft);

                }

                Vect = new Vector(1, 0, 0);
                // Dim No 18.3
                if (DN.DimIDNo18Dot3 && BCS.SCB.SCR != null)
                {
                    pointList = new PointList();
                    pointList.Add(BCS.SCB.SCR.Points.P4);
                    pointList.Add(BCS.SCB.SCR.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BCS.PC.RightX, BCS.PC.DistRight);

                }
            }

            BCS.PC.DistLeft += BCS.PC.DistInc;
            BCS.PC.DistRight += BCS.PC.DistInc;

            double FlThick = Com.GetPartFlangeThickness(MainBeam);

            if (BCS.SCT != null || BCS.SCM != null)
            {
                Vect = new Vector(-1, 0, 0);
                // Dim No 18.1
                if (DN.DimIDNo18Dot1)
                {
                    pointList = new PointList();

                    if (BCS.SCT?.SCL != null)
                        pointList.Add(BCS.SCT.SCL.Points.P2);
                    else
                        pointList.Add(BCS.Points.P1);

                    if (BCS.SCT?.SCL != null)
                        pointList.Add(BCS.SCM.SCL.Points.P1);
                    else
                        pointList.Add(new Point(BCS.Points.P1.X, BCS.Points.P1.Y - FlThick));


                    xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BCS.PC.LeftX, BCS.PC.DistLeft);

                }

                Vect = new Vector(1, 0, 0);
                // Dim No 18.1
                if (DN.DimIDNo18Dot1)
                {
                    pointList = new PointList();
                    if (BCS.SCT?.SCR != null)
                        pointList.Add(BCS.SCT.SCR.Points.P3);
                    else
                        pointList.Add(BCS.Points.P4);


                    if (BCS.SCM?.SCR != null)
                        pointList.Add(BCS.SCM.SCR.Points.P4);
                    else
                        pointList.Add(new Point(BCS.Points.P4.X, BCS.Points.P4.Y - FlThick));

                    xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BCS.PC.RightX, BCS.PC.DistRight);

                }
            }

            if (BCS.SCB != null || BCS.SCM != null)
            {


                Vect = new Vector(-1, 0, 0);
                // Dim No 18.2
                if (DN.DimIDNo18Dot2)
                {
                    pointList = new PointList();
                    if (BCS.SCB?.SCL != null)
                        pointList.Add(BCS.SCB.SCL.Points.P1);
                    else
                        pointList.Add(BCS.Points.P2);
                    if (BCS.SCM?.SCL != null)
                        pointList.Add(BCS.SCM.SCL.Points.P2);
                    else
                        pointList.Add(new Point(BCS.Points.P2.X, BCS.Points.P2.Y + FlThick));

                    xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BCS.PC.LeftX, BCS.PC.DistLeft);

                }

                Vect = new Vector(1, 0, 0);
                // Dim No 18.2
                if (DN.DimIDNo18Dot2)
                {
                    pointList = new PointList();
                    if (BCS.SCB?.SCR != null)
                        pointList.Add(BCS.SCB.SCR.Points.P4);
                    else
                        pointList.Add(BCS.Points.P3);
                    if (BCS.SCM?.SCR != null)
                        pointList.Add(BCS.SCM.SCR.Points.P3);
                    else
                        pointList.Add(new Point(BCS.Points.P3.X, BCS.Points.P2.Y + FlThick));

                    xDim = dc.InsertDim(CView, pointList, Vect, BCS.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BCS.PC.RightX, BCS.PC.DistRight);

                }
            }

        }

        private void TestDim()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;

            Vector Vect = new Vector(0, 1, 0);

            TSD.PointList TempList = new PointList();

            if (BC.TopGP?.GussetPlate != null && BC.BottGP?.GussetPlate != null)
            {
                Point P1 = BC.TopGP.LB.RefPBrace;
                Point P2 = BC.TopGP.LB.IntPointB;
                Point P3 = BC.Points.P2;
                double result = Math.Atan2(P3.Y - P1.Y, P3.X - P1.X) -
                Math.Atan2(P2.Y - P1.Y, P2.X - P1.X);


                Point WP = BC.TopGP.LB.RefPBrace;
                Point Temp = new Point(WP.X, WP.Y - 100, WP.Z);
                AngleDimension angDimA = new AngleDimension(CView, P1, P2, P3, 50);
                double degree = angDimA.GetAngle();

                angDimA.Insert();
                //BC.PC.DistLeft = (BC.PC.DistInc * 6);
                //Vect = new Vector(-1, 0, 0);

                //pointList = new PointList();
                //pointList.Add(BC.TopGP.Points.P1);
                //pointList.Add(BC.BottGP.Points.P1);
                //xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                //if (xDim != null)
                //    PL.DistPlaceLeftP(xDim, BC.BottGP.Points.P2.X, BC.PC.DistLeft);
            }


        }

        #region Get Data

        private void GetBeamClassClass(TSD.View CView)
        {
            if (ViewName == "Front View")
            {
                BC = new BeamClass_BG18();
                BC.beam = MainBeam;
                List<TSM.Part> PartListC = BC.beam.GetAssembly().GetSecondaries().OfType<TSM.Part>().ToList();
                PartListC.Add(MainBeam);
                BC.Points = Com.GetPartPoints(BC.beam);

                List<TSM.BoltGroup> BoltDList = Com.EnumtoArray(BC.beam.GetBolts()).OfType<TSM.BoltGroup>().ToList();
                Point CentP = Com.CenterPoint(BC.beam.StartPoint, BC.beam.EndPoint);
                double Lenght = (BC.beam.GetSolid().MaximumPoint.X - BC.beam.GetSolid().MinimumPoint.X) / 6;
                double MinX = BC.beam.GetSolid().MinimumPoint.X + Lenght;
                double MaxX = BC.beam.GetSolid().MaximumPoint.X - Lenght;

                //List<TSM.Part> PartListF = (from p in PartListC where !Com.IsCode(p) select p).ToList();
                List<TSM.Part> PartListF = (from p in PartListC where !Ids.Contains(p.Identifier.ID) select p).ToList();
                ContourPlate TopGP = (from p in PartListF.OfType<ContourPlate>() where IsBG18(p) && (Com.CenterPoint(p).Y > BC.Points.CentP.Y) && !dc.IsPlateSideView(p) select p).FirstOrDefault();
                ContourPlate BottGP = (from p in PartListF.OfType<ContourPlate>() where IsBG18(p) && (Com.CenterPoint(p).Y < BC.Points.CentP.Y) && !dc.IsPlateSideView(p) select p).FirstOrDefault();

                if (TopGP != null)
                {
                    BC.TopGP = GetGussetClass(TopGP, "Top");
                    BC.SCT = GetStiffClass(TopGP, PartListF, "Top");
                    if (BC.SCM == null)
                        BC.SCM = GetStiffClass(TopGP, PartListF, "Middle");
                }

                if (BottGP != null)
                {
                    BC.BottGP = GetGussetClass(BottGP, "Bottom");
                    BC.SCB = GetStiffClass(BottGP, PartListF, "Bottom");
                    if (BC.SCM == null)
                        BC.SCM = GetStiffClass(BottGP, PartListF, "Middle");
                }

                BC.RDPoint = new Point(BC.Points.P1.X, BC.Points.CentP.Y);
               
                TSM.Part LeftPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.X ascending select p).FirstOrDefault();
                TSM.Part RightPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.X descending select p).FirstOrDefault();
                TSM.Part TopPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.Y descending select p).FirstOrDefault();
                TSM.Part BottPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.Y ascending select p).FirstOrDefault();

                BC.PC = new PlacingClass();
                BC.PC.TopY = TopPart.GetSolid().MaximumPoint.Y;
                BC.PC.BottomY = BottPart.GetSolid().MinimumPoint.Y;



                BC.PC.LeftX = LeftPart.GetSolid().MinimumPoint.X;// Math.Round(CView.RestrictionBox.MinPoint.X);
                BC.PC.RightX = RightPart.GetSolid().MaximumPoint.X;

               

                double AvScale = 12;
                double AvDistInc = 100;
                double DistPerScale = AvDistInc / AvScale;
                double CScale = CView.Attributes.Scale;
                BC.PC.DistInc = CScale * DistPerScale;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;
            }

            if (ViewName == "Section View")
            {
                BCS = new BeamClass_BG18S();
                BCS.beam = MainBeam;
                List<TSM.Part> PartListC = BCS.beam.GetAssembly().GetSecondaries().OfType<TSM.Part>().ToList();

                BCS.Points = Com.GetPartPoints(BCS.beam);

                double MinZ = CView.RestrictionBox.MinPoint.Z - 20;
                double MaxZ = CView.RestrictionBox.MaxPoint.Z + 20;
                List<TSM.Part> PartList = (from p in PartListC where Com.IsViewObj(p, CView) select p).ToList();
                //List<TSM.Part> PartList = (from p in PartListC where p.GetSolid().MaximumPoint.Z > MinZ && p.GetSolid().MinimumPoint.Z < MaxZ select p).ToList();
                Point CentP = Com.CenterPoint(BCS.beam.StartPoint, BCS.beam.EndPoint);

                List<TSM.Part> PartListF = (from p in PartList where !Ids.Contains(p.Identifier.ID) select p).ToList();
                // List<TSM.Part> PartListF = (from p in PartList where !Com.IsCode(p) select p).ToList();
                ContourPlate TopGP = (from p in PartListF.OfType<ContourPlate>() where IsBG18(p) && (Com.CenterPoint(p).Y > BCS.Points.CentP.Y) select p).FirstOrDefault();
                ContourPlate BottGP = (from p in PartListF.OfType<ContourPlate>() where IsBG18(p) && (Com.CenterPoint(p).Y < BCS.Points.CentP.Y) select p).FirstOrDefault();

                if (TopGP != null)
                {
                    BCS.TopGP = GetGussetClassS(TopGP, "Top");
                    BCS.SCT = GetStiffClassS(TopGP, PartListF, "Top");
                    if (BCS.SCM == null)
                        BCS.SCM = GetStiffClassS(TopGP, PartListF, "Middle");
                }

                if (BottGP != null)
                {
                    BCS.BottGP = GetGussetClassS(BottGP, "Bottom");
                    BCS.SCB = GetStiffClassS(BottGP, PartListF, "Bottom");
                    if (BCS.SCM == null)
                        BCS.SCM = GetStiffClassS(BottGP, PartListF, "Middle");
                }

                PartList.Add(MainBeam);
                List<Point> RefPoints = MainBeam.GetReferenceLine(false).OfType<Point>().ToList();

                TSM.Part LeftPart = (from p in PartList orderby p.GetSolid().MinimumPoint.X ascending select p).FirstOrDefault();
                TSM.Part RightPart = (from p in PartList orderby p.GetSolid().MaximumPoint.X descending select p).FirstOrDefault();
                TSM.Part TopPart = (from p in PartList orderby p.GetSolid().MaximumPoint.Y descending select p).FirstOrDefault();
                TSM.Part BottPart = (from p in PartList orderby p.GetSolid().MinimumPoint.Y ascending select p).FirstOrDefault();

                BCS.PC = new PlacingClass();
                BCS.PC.TopY = TopPart.GetSolid().MaximumPoint.Y;
                BCS.PC.BottomY = BottPart.GetSolid().MinimumPoint.Y;
                BCS.PC.LeftX = LeftPart.GetSolid().MinimumPoint.X; ;// Math.Round(CView.RestrictionBox.MinPoint.X);
                BCS.PC.RightX = RightPart.GetSolid().MaximumPoint.X;

                double AvScale = 12;
                double AvDistInc = 100;
                double DistPerScale = AvDistInc / AvScale;
                double CScale = CView.Attributes.Scale;
                BCS.PC.DistInc = CScale * DistPerScale;
                BCS.PC.DistBot = BCS.PC.DistInc;
                BCS.PC.DistTop = BCS.PC.DistInc;
                BCS.PC.DistLeft = BCS.PC.DistInc;
                BCS.PC.DistRight = BCS.PC.DistInc;
            }

        }

        private GussetClassB GetGussetClass(ContourPlate GP, string Position)
        {
            GussetClassB GC = new GussetClassB();
            GC.GussetPlate = GP;
            GC.Points = GetGussetPoints(GP);

            List<BoltGroup> Bolts = Com.EnumtoArray(GP.GetBolts()).OfType<BoltGroup>().ToList();

            List<BoltGroup> LeftBolts = (from b in Bolts where Com.CenterPoint(b).X < GC.Points.CentP.X select b).ToList();
            List<BoltGroup> RightBolts = (from b in Bolts where Com.CenterPoint(b).X > GC.Points.CentP.X select b).ToList();

            if (LeftBolts != null && LeftBolts.Count > 0)
            {

                BoltGroup TopBolt = (from b in LeftBolts orderby b.GetSolid().MaximumPoint.Y descending select b).FirstOrDefault();
                BoltGroup BottomBolt = (from b in LeftBolts orderby b.GetSolid().MinimumPoint.Y ascending select b).FirstOrDefault();

                BoltGroup MidBolt = null;

                if (TopBolt != null && BottomBolt != null)
                {
                    MidBolt = (from b in LeftBolts where Com.CenterPoint(b).Y < Com.CenterPoint(TopBolt).Y && Com.CenterPoint(b).Y > Com.CenterPoint(BottomBolt).Y select b).FirstOrDefault();
                    GC.LB = new GussetBrace();
                }

                if (TopBolt != null)
                {
                    GC.LB.BoltL = TopBolt;
                    Beam brace = (from b in Com.GetBoltParts(GC.LB.BoltL).OfType<TSM.Beam>() where b.Identifier.ID != GP.Identifier.ID && (b.Name.ToLower().Contains("brace") || dc.IsMainPart(b)) select b).FirstOrDefault();
                    if (brace != null)
                    {
                        GC.LB.Brace = brace;
                        GC.LB.RefPBrace = dc.NearestPoint(GC.LB.Brace.StartPoint, GC.LB.Brace.EndPoint, TopBolt.FirstPosition);
                    }
                }

                if (BottomBolt != null)
                    GC.LB.BoltR = BottomBolt;

                if (MidBolt != null)
                {
                    GC.LB.BoltM = MidBolt;
                    Beam brace = GetBrace(GC.LB.BoltM, GP);
                    if (brace != null)
                    {
                        GC.LB.Brace = brace;
                        GC.LB.RefPBrace = dc.NearestPoint(GC.LB.Brace.StartPoint, GC.LB.Brace.EndPoint, TopBolt.FirstPosition);
                        GC.LB.IntPoint = GetIntSectPoint(GC.LB.BoltM, brace, Position);
                        if (Position == "Top")
                        {
                            if (GC.LB.RefPBrace != null && GC.LB.IntPoint != null)
                                GC.LB.IntPointB = Com.GetIntersectionPoint(GC.LB.RefPBrace, GC.LB.IntPoint, BC.Points.P1, BC.Points.P4);

                            GC.LB.Degree = GetDegree(GC.LB.IntPointB, GC.LB.IntPoint, BC.Points.P1);

                        }
                        else
                        {
                            if (GC.LB.RefPBrace != null && GC.LB.IntPoint != null)
                                GC.LB.IntPointB = Com.GetIntersectionPoint(GC.LB.RefPBrace, GC.LB.IntPoint, BC.Points.P2, BC.Points.P3);


                            GC.LB.Degree = GetDegree(GC.LB.IntPointB, GC.LB.IntPoint, BC.Points.P2);
                        }



                    }
                }




            }


            if (RightBolts != null && RightBolts.Count > 0)
            {

                BoltGroup TopBolt = (from b in RightBolts orderby b.GetSolid().MaximumPoint.Y descending select b).FirstOrDefault();
                BoltGroup BottomBolt = (from b in RightBolts orderby b.GetSolid().MinimumPoint.Y ascending select b).FirstOrDefault();

                BoltGroup MidBolt = null;

                if (TopBolt != null && BottomBolt != null)
                {
                    MidBolt = (from b in RightBolts where Com.CenterPoint(b).Y < Com.CenterPoint(TopBolt).Y && Com.CenterPoint(b).Y > Com.CenterPoint(BottomBolt).Y select b).FirstOrDefault();
                    GC.RB = new GussetBrace();
                }

                if (TopBolt != null)
                {
                    GC.RB.BoltL = TopBolt;
                    Beam brace = (from b in Com.GetBoltParts(GC.RB.BoltL).OfType<TSM.Beam>() where b.Identifier.ID != GP.Identifier.ID && (b.Name.ToLower().Contains("brace") || dc.IsMainPart(b)) select b).FirstOrDefault();
                    if (brace != null)
                    {
                        GC.RB.Brace = brace;
                        GC.RB.RefPBrace = dc.NearestPoint(GC.RB.Brace.StartPoint, GC.RB.Brace.EndPoint, TopBolt.FirstPosition);
                    }
                }

                if (BottomBolt != null)
                    GC.RB.BoltR = BottomBolt;

                if (MidBolt != null)
                {
                    GC.RB.BoltM = MidBolt;
                    Beam brace = GetBrace(GC.RB.BoltM, GP);
                    if (brace != null)
                    {
                        GC.RB.Brace = brace;
                        GC.RB.RefPBrace = dc.NearestPoint(GC.RB.Brace.StartPoint, GC.RB.Brace.EndPoint, TopBolt.FirstPosition);
                        GC.RB.IntPoint = GetIntSectPoint(GC.RB.BoltM, brace, Position);
                        if (Position == "Top")
                        {
                            if (GC.RB.RefPBrace != null && GC.RB.IntPoint != null)
                                GC.RB.IntPointB = Com.GetIntersectionPoint(GC.RB.RefPBrace, GC.RB.IntPoint, BC.Points.P1, BC.Points.P4);

                            GC.RB.Degree = GetDegree(GC.RB.IntPointB, GC.RB.IntPoint, BC.Points.P4);
                        }
                        else
                        {
                            if (GC.RB.RefPBrace != null && GC.RB.IntPoint != null)
                                GC.RB.IntPointB = Com.GetIntersectionPoint(GC.RB.RefPBrace, GC.RB.IntPoint, BC.Points.P2, BC.Points.P3);

                            GC.RB.Degree = GetDegree(GC.RB.IntPointB, GC.RB.IntPoint, BC.Points.P3);
                        }
                    }
                }




            }

            return GC;
        }

        private GussetClass GetGussetClassS(ContourPlate GP, string Position)
        {
            GussetClass GC = new GussetClass();
            GC.GussetPlate = GP;
            GC.Points = Com.GetPartPoints(GP);

            return GC;
        }

        private StiffClass GetStiffClass(ContourPlate GP, List<TSM.Part> PartListF, string Position)
        {
            StiffClass SC = null;
            TSM.Part Stiff = null;
            if (Position == "Top")
            {
                Stiff = (from p in PartListF where dc.IsPlateSideView(p) && (Com.CenterPoint(p).X > GP.GetSolid().MinimumPoint.X && Com.CenterPoint(p).X < GP.GetSolid().MaximumPoint.X) && (Com.CenterPoint(p).Y > BC.Points.P1.Y) select p).FirstOrDefault();
            }
            else if (Position == "Bottom")
            {
                Stiff = (from p in PartListF where dc.IsPlateSideView(p) && (Com.CenterPoint(p).X > GP.GetSolid().MinimumPoint.X && Com.CenterPoint(p).X < GP.GetSolid().MaximumPoint.X) && (Com.CenterPoint(p).Y < BC.Points.P2.Y) select p).FirstOrDefault();
            }

            else if (Position == "Middle")
            {
                Stiff = (from p in PartListF where dc.IsPlateSideView(p) && (Com.CenterPoint(p).X > GP.GetSolid().MinimumPoint.X && Com.CenterPoint(p).X < GP.GetSolid().MaximumPoint.X) && (Com.CenterPoint(p).Y < BC.Points.P1.Y && Com.CenterPoint(p).Y > BC.Points.P2.Y) select p).FirstOrDefault();
            }

            if (Stiff != null)
            {
                SC = new StiffClass();
                SC.Stiff = Stiff;
                SC.Points = Com.GetPartPoints(Stiff);
            }


            return SC;
        }

        private StiffClassS GetStiffClassS(ContourPlate GP, List<TSM.Part> PartListF, string Position)
        {
            StiffClassS SCS = null;
            TSM.Part StiffL = null;
            TSM.Part StiffR = null;
            if (Position == "Top")
            {
                StiffL = (from p in PartListF where !dc.IsPlateSideView(p) && (Com.CenterPoint(p).X < Com.CenterPoint(GP).X) && (Com.CenterPoint(p).Y > BCS.Points.P1.Y) select p).FirstOrDefault();
                StiffR = (from p in PartListF where !dc.IsPlateSideView(p) && (Com.CenterPoint(p).X > Com.CenterPoint(GP).X) && (Com.CenterPoint(p).Y > BCS.Points.P1.Y) select p).FirstOrDefault();
            }
            else if (Position == "Bottom")
            {
                StiffL = (from p in PartListF where !dc.IsPlateSideView(p) && (Com.CenterPoint(p).X < Com.CenterPoint(GP).X) && (Com.CenterPoint(p).Y < BCS.Points.P2.Y) select p).FirstOrDefault();
                StiffR = (from p in PartListF where !dc.IsPlateSideView(p) && (Com.CenterPoint(p).X > Com.CenterPoint(GP).X) && (Com.CenterPoint(p).Y < BCS.Points.P2.Y) select p).FirstOrDefault();
            }

            else if (Position == "Middle")
            {
                StiffL = (from p in PartListF where !dc.IsPlateSideView(p) && (Com.CenterPoint(p).X < Com.CenterPoint(GP).X) && (Com.CenterPoint(p).Y > BCS.Points.P2.Y && Com.CenterPoint(p).Y < BCS.Points.P1.Y) select p).FirstOrDefault();
                StiffR = (from p in PartListF where !dc.IsPlateSideView(p) && (Com.CenterPoint(p).X > Com.CenterPoint(GP).X) && (Com.CenterPoint(p).Y > BCS.Points.P2.Y && Com.CenterPoint(p).Y < BCS.Points.P1.Y) select p).FirstOrDefault();
            }

            if (StiffL != null)
            {
                if (SCS == null)
                    SCS = new StiffClassS();


                StiffClass SC = new StiffClass();
                SC.Stiff = StiffL;
                SC.Points = Com.GetPartPoints(StiffL);
                SCS.SCL = SC;
            }

            if (StiffR != null)
            {
                if (SCS == null)
                    SCS = new StiffClassS();


                StiffClass SC = new StiffClass();
                SC.Stiff = StiffR;
                SC.Points = Com.GetPartPoints(StiffR);
                SCS.SCR = SC;
            }


            return SCS;
        }

        private Beam GetBrace(BoltGroup BoltL, TSM.Part GP)
        {

            Beam brace = (from b in Com.GetBoltParts(BoltL).OfType<TSM.Beam>() where b.Identifier.ID != GP.Identifier.ID && (b.Name.ToLower().Contains("brace") || (dc.IsMainPart(b) && !dc.IsPlate(b))) select b).FirstOrDefault();
            if (brace == null)
            {
                List<TSM.Part> PartList = (from b in Com.GetBoltParts(BoltL).OfType<TSM.Part>() where b.Identifier.ID != GP.Identifier.ID select b).ToList();

                foreach (TSM.Part part in PartList)
                {

                    BoltGroup bolt2 = Com.EnumtoArray(part.GetBolts()).OfType<BoltGroup>().Where(x => x.Identifier.ID != BoltL.Identifier.ID).FirstOrDefault();
                    if (bolt2 != null)
                    {
                        brace = (from b in Com.GetBoltParts(bolt2).OfType<TSM.Beam>() where b.Identifier.ID != GP.Identifier.ID && (b.Name.ToLower().Contains("brace") || (dc.IsMainPart(b) && !dc.IsPlate(b))) select b).FirstOrDefault();
                    }

                }

                if (brace == null)
                {
                    foreach (TSM.Part part in PartList)
                    {
                        if (dc.IsMainPart(part) && dc.IsPlate(part))
                        {

                            List<TSM.Part> PartLists = Com.EnumtoArray(part.GetWelds()).OfType<TSM.Weld>().Select(x => x.MainObject).OfType<TSM.Part>().ToList();
                            PartLists.AddRange(Com.EnumtoArray(part.GetWelds()).OfType<TSM.Weld>().Select(x => x.SecondaryObject).OfType<TSM.Part>().ToList());

                            brace = (from b in PartLists.OfType<Beam>() where IsBrace(b) select b).FirstOrDefault();
                            if (brace == null)
                            {
                                PartLists = (from b in PartLists where !dc.IsMainPart(b) select b.GetAssembly().GetMainPart()).OfType<TSM.Part>().ToList();
                                brace = (from b in PartLists.OfType<Beam>() where IsBrace(b) select b).FirstOrDefault();
                                if (brace != null)
                                    break;
                            }


                        }

                    }
                }

                if (brace == null)
                {
                    foreach (TSM.Part part in PartList)
                    {
                        if (dc.IsMainPart(part) && dc.IsPlate(part))
                        {

                            List<BoltGroup> BoltsList = Com.EnumtoArray(part.GetBolts()).OfType<TSM.BoltGroup>().ToList();
                            if (BoltsList != null && BoltsList.Count > 0)
                            {
                                List<TSM.Part> PartLists = new List<TSM.Part>();

                                BoltsList.ForEach(x => PartLists.AddRange(Com.GetBoltParts(x)));

                                brace = (from b in PartLists.OfType<Beam>() where IsBrace(b) select b).FirstOrDefault();
                                if (brace == null)
                                {
                                    PartLists = (from b in PartLists where !dc.IsMainPart(b) select b.GetAssembly().GetMainPart()).OfType<TSM.Part>().ToList();
                                    brace = (from b in PartLists.OfType<Beam>() where IsBrace(b) select b).FirstOrDefault();
                                    if (brace != null)
                                        break;
                                }
                            }


                        }

                    }
                }
            }

            return brace;

        }

        private PartPoints GetGussetPoints(ContourPlate GP)
        {
            PartPoints RetP = new PartPoints();
            PointList pointList = Com.ContPList(GP);
            RetP.CentP = Com.CenterPoint(GP);

            if (RetP.CentP.Y > BC.Points.CentP.Y)
            {

                RetP.P1 = (from p in pointList.OfType<Point>() where p.X < RetP.CentP.X orderby p.Y descending select p).FirstOrDefault();
                RetP.P2 = (from p in pointList.OfType<Point>() where p.X < RetP.CentP.X orderby p.Y ascending select p).FirstOrDefault();
                RetP.P6 = (from p in pointList.OfType<Point>() where p.X < RetP.CentP.X && p.Y > RetP.P2.Y orderby p.Y ascending select p).FirstOrDefault();

                RetP.P4 = (from p in pointList.OfType<Point>() where p.X > RetP.CentP.X orderby p.Y descending select p).FirstOrDefault();
                RetP.P3 = (from p in pointList.OfType<Point>() where p.X > RetP.CentP.X orderby p.Y ascending select p).FirstOrDefault();
                RetP.P5 = (from p in pointList.OfType<Point>() where p.X > RetP.CentP.X && p.Y > RetP.P3.Y orderby p.Y ascending select p).FirstOrDefault();
            }
            else
            {

                RetP.P1 = (from p in pointList.OfType<Point>() where p.X < RetP.CentP.X orderby p.Y ascending select p).FirstOrDefault();
                RetP.P2 = (from p in pointList.OfType<Point>() where p.X < RetP.CentP.X orderby p.Y descending select p).FirstOrDefault();
                RetP.P6 = (from p in pointList.OfType<Point>() where p.X < RetP.CentP.X && p.Y < RetP.P2.Y orderby p.Y descending select p).FirstOrDefault();

                RetP.P4 = (from p in pointList.OfType<Point>() where p.X > RetP.CentP.X orderby p.Y ascending select p).FirstOrDefault();
                RetP.P3 = (from p in pointList.OfType<Point>() where p.X > RetP.CentP.X orderby p.Y descending select p).FirstOrDefault();
                RetP.P5 = (from p in pointList.OfType<Point>() where p.X > RetP.CentP.X && p.Y < RetP.P3.Y orderby p.Y descending select p).FirstOrDefault();
            }

            return RetP;
        }

        private bool IsViewObj(TSM.Part part)
        {
            bool RetCheck = false;
            double MinZ = CView.RestrictionBox.MinPoint.Z;
            double MaxZ = CView.RestrictionBox.MaxPoint.Z;

            double MinZP = part.GetSolid().MinimumPoint.Z;
            double MaxZP = part.GetSolid().MaximumPoint.Z;

            if ((MinZP >= MinZ && MaxZP <= MaxZ) || ((MinZ >= MinZP && MinZ <= MaxZP) || (MaxZ >= MinZP && MaxZ <= MaxZP)))
                RetCheck = true;


            return RetCheck;

        }

        #endregion

        #region Helping Methods

        private double GetDegree(Point P1, Point P2, Point P3)
        {
            double degree = 0;
            try
            {

                AngleDimension angDimA = new AngleDimension(CView, P1, P2, P3, 50);
                degree = angDimA.GetAngle();
            }
            catch (Exception ex)
            { }
            return degree;
        }

        private bool IsBrace(Beam b)
        {
            bool RetCheck = false;
            if (b.Name.ToLower().Contains("brace") || (dc.IsMainPart(b) && !dc.IsPlate(b)))
            {
                if ((b.StartPoint.Y < BC.Points.P1.Y && b.StartPoint.Y > BC.Points.P2.Y) || (b.EndPoint.Y < BC.Points.P1.Y && b.EndPoint.Y > BC.Points.P2.Y))
                    RetCheck = true;
            }

            return RetCheck;
        }

        private Point GetIntSectPoint(BoltGroup bolt, Beam brace, string Position)
        {
            Vector Vect = bolt.GetCoordinateSystem().AxisX;
            PointList PtList = new PointList();
            Point IntSectP = null;
            if (Position == "Top")
            {
                if (Vect.Y > 0)
                    Vect = Com.ChangeVector(Vect);
            }
            else
            {
                if (Vect.Y < 0)
                    Vect = Com.ChangeVector(Vect);
            }

            PtList = dc.ChangePints(bolt, CView, Vect);
            if (PtList.Count > 1)
                IntSectP = Com.GetIntersectionPoint(PtList[0], PtList[1], brace.StartPoint, brace.EndPoint);
            else if (PtList.Count == 1)
                IntSectP = PtList[0];

            return IntSectP;

        }

        private bool IsBG18(TSM.Part part)
        {
            if (Com.GetNote5(part).ToUpper().Contains("BG18"))
                return true;
            else
                return false;
        }
        #endregion

        private class StiffClassS
        {
            public StiffClass SCL { get; set; }
            public StiffClass SCR { get; set; }
        }

        private class BeamClass_BG18S
        {
            public Beam beam { get; set; }
            public GussetClass TopGP { get; set; }
            public GussetClass BottGP { get; set; }
            public PartPoints Points { get; set; }
            public PlacingClass PC { get; set; }
            public StiffClassS SCT { get; set; }
            public StiffClassS SCM { get; set; }
            public StiffClassS SCB { get; set; }

        }

        public class BeamClass_BG18
        {
            public Beam beam { get; set; }
            public GussetClassB TopGP { get; set; }
            public GussetClassB BottGP { get; set; }
            public PartPoints Points { get; set; }
            public PlacingClass PC { get; set; }
            public StiffClass SCT { get; set; }
            public StiffClass SCM { get; set; }
            public StiffClass SCB { get; set; }
            public Point RDPoint { get; set; }


        }

    }




}
