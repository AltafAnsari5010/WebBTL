﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Tekla.Structures;
using Tekla.Structures.Drawing;
using Tekla.Structures.Geometry3d;
using Tekla.Structures.Model;
using TSD = Tekla.Structures.Drawing;
using TSM = Tekla.Structures.Model;
using VirtueleDrawingAutomation;
using TSDD = Tekla.Structures.Datatype;
using TSG = Tekla.Structures.Geometry3d;

namespace Auto_Detailing_Tool_Beam
{
    public class BeamDim_BG13
    {
        #region Global Variables
        DimCom dc = new DimCom();
        StraightDimensionSet.StraightDimensionSetAttributes StAtrr = new StraightDimensionSet.StraightDimensionSetAttributes("standard");
        StraightDimensionSet.StraightDimensionSetAttributes RdAtrr = new StraightDimensionSet.StraightDimensionSetAttributes("standard");

        public Beam MainBeam = null;
        VirtueleDrawingAutomation.Json.DrawingAttributeInfoJson.AttributeFiles dimAttrClass = null;
        List<TSD.StraightDimension> KnockDim = new List<StraightDimension>();
        BeamClass_BG13 BC = null;
        VirtueleDrawingAutomation.Json.AutoDimensionTypesJson.BG13Json DN = null;
        TSD.View CView = null;
        string ViewName = "";
        List<int> Ids = new List<int>();
        #endregion

        public List<int> ApplyDim(TSD.View CView, string ViewName, AutoDimensioningTypes autoDimensioningTypes, DrawingAttributeInfo drawingAttributeInfo, List<int> Ids)
        {
            try
            {
                this.Ids = Ids;
            Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane());
            //Set model everything to the view
            Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane(CView.DisplayCoordinateSystem));

            this.CView = CView;
            this.dimAttrClass = drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files;
            this.DN = autoDimensioningTypes.Bg13;
            StAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.StandardDimension);
            RdAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.RunningDimension);
            StAtrr.Placing.Placing = DimensionSetBaseAttributes.Placings.Fixed;
            RdAtrr.Placing.Placing = DimensionSetBaseAttributes.Placings.Fixed;

            this.MainBeam = (Com.MyModel.SelectModelObject(new Identifier((CView.GetDrawing() as AssemblyDrawing).AssemblyIdentifier.ID)) as TSM.Assembly).GetMainPart() as TSM.Beam;
            this.MainBeam.Select();
            string ProType = Com.GetProType(MainBeam);
            this.ViewName = ViewName;

            GetBeamClassClass(CView);

            if (ViewName == "Top View" || ViewName == "Bottom View")
            {

                while (BC.TopGP != null || BC.BottGP != null)
                {
                    //TestDim();
                    ApplyDimType(CView);
                    GetBeamClassClass(CView);
                }
            }
            else if (ViewName == "Front View")
            {
                while (BC.GPTV?.GussetList != null)
                {
                    ApplyTBV();
                    GetBeamClassClass(CView);
                }
            }
            else if (ViewName == "Section View")
                AppySectionDim();

            Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane());
            }
            catch (Exception ex)
            { }

            return Ids;
        }


        #region Top / Bottom View Dim
        private void ApplyDimType(TSD.View CView)
        {

            StAtrr.Placing.Placing = DimensionSetBaseAttributes.Placings.Fixed;
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            TSD.PointList TempList = new PointList();
            bool IsVertDim = true;
            Point RefP = null;

            #region Top Gusset
            if (BC.TopGP?.GussetPlate != null)
            {
                // BC.TopGP.GussetPlate

                ApplyLeftTopG();
                ApplyRightTopG();

                Ids.Add(BC.TopGP.GussetPlate.Identifier.ID);
                // Com.SetCode(BC.TopGP.GussetPlate);
            }
            #endregion


            #region Bottom Gusset
            if (BC.BottGP?.GussetPlate != null)
            {

                ApplyLeftBottG();
                ApplyRightBottG();

                // Com.SetCode(BC.BottGP.GussetPlate);
                Ids.Add(BC.BottGP.GussetPlate.Identifier.ID);
            }
            #endregion

            ApplyRadiusDim();
        }

        private void ApplyLeftTopG()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            TSD.PointList TempList = new PointList();

            if (BC.TopGP?.LB != null)
            {

                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;

                TempList = Com.GetBoltPoints(BC.TopGP.LB.BoltM);
                TSG.Line YLine = new TSG.Line(BC.TopGP.Points.P6, BC.TopGP.Points.P1);
                TSG.Line XLine = new TSG.Line(Com.MinP(TempList, "X"), Com.MinP(TempList, "Y"));
                Vector LeftVect = BC.TopGP.LB.BoltM.GetCoordinateSystem().AxisY;

                if (LeftVect.X > 0)
                    LeftVect = dc.ChangeVector(LeftVect);

                Vector RightVect = BC.TopGP.LB.BoltM.GetCoordinateSystem().AxisY;
                if (RightVect.X < 0)
                    RightVect = dc.ChangeVector(RightVect);

                Vector TopVect = BC.TopGP.LB.BoltM.GetCoordinateSystem().AxisX;
                if (TopVect.Y < 0)
                    TopVect = dc.ChangeVector(TopVect);

                Vector BottVect = BC.TopGP.LB.BoltM.GetCoordinateSystem().AxisX;
                if (BottVect.Y > 0)
                    BottVect = dc.ChangeVector(BottVect);

                #region Diagonal Top

                if (BC.TopGP.LB.Degree > 50)
                {
                    double Deg = BC.TopGP.LB.Degree - 50;
                    BC.PC.DistTop = Deg * ((BC.PC.DistInc) / 10);

                    BC.PC.DistTop += (BC.PC.DistInc * 4);
                }
                else
                    BC.PC.DistTop = (BC.PC.DistInc * 4);

                TempList = dc.ChangePints(BC.TopGP.LB.BoltMP, CView, TopVect);
                // Dim No 6
                if (DN.DimIDNo6)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    pointList.Add(BC.TopGP.LB.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, TopVect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }

                // Dim No 5
                if (DN.DimIDNo5)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, TopVect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistTop);

                }

                #endregion

                #region Diagonal Right
                BC.PC.DistRight += (BC.PC.DistInc * 0.25);
                TempList = dc.ChangePints(BC.TopGP.LB.BoltMP, CView, RightVect);

                // Dim No 4, 4.1
                if (DN.DimIDNo4 || DN.DimIDNo4Dot1)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo4)// Dim No 4
                        pointList.Add(Com.MinP(TempList, "Y"));

                    pointList.Add(BC.TopGP.LB.IntPointB);
                    if (DN.DimIDNo4Dot1)// Dim No 4.1
                        pointList.Add(BC.TopGP.LB.RefPBrace);

                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistRight);
                        BC.PC.DistRight += (BC.PC.DistInc * 0.25);
                    }
                }


                // Dim No 3.1 , 3, 2
                if (DN.DimIDNo3)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo3Dot1)
                    {
                        pointList.Add(Com.MaxP(TempList, "Y"));
                        pointList.Add(BC.TopGP.Points.P6);
                    }
                    if (DN.DimIDNo3)
                        pointList.AddRange(TempList);

                    if (DN.DimIDNo2)
                    {
                        pointList.Add(Com.MinP(TempList, "Y"));
                        pointList.Add(BC.TopGP.LB.RefPBrace);
                    }

                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistRight);
                }
                else
                {

                    if (DN.DimIDNo3Dot1)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MaxP(TempList, "Y"));
                        pointList.Add(BC.TopGP.Points.P6);
                        xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                            PL.DimPlacingDiag(xDim, XLine, BC.PC.DistRight);
                    }

                    if (DN.DimIDNo2)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MinP(TempList, "Y"));
                        pointList.Add(BC.TopGP.LB.RefPBrace);
                        xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                            PL.DimPlacingDiag(xDim, XLine, BC.PC.DistRight);
                    }

                }

                // Dim No 3.1 , 3, 2
                if (DN.DimIDNo3Dot1 || DN.DimIDNo3 || DN.DimIDNo2)
                    BC.PC.DistRight += BC.PC.DistInc;

                // Dim No 3.2
                if (DN.DimIDNo3Dot2)
                {
                    if (TempList.Count > 2)
                    {
                        pointList = new PointList();
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                        {
                            PL.DimPlacingDiag(xDim, XLine, BC.PC.DistRight);
                            Com.GroupDim(xDim);
                        }
                    }
                }

                #endregion

                #region Straight Left

                double LeftX = BC.TopGP.Points.P2.X;
                if (BC.BottGP != null && BC.BottGP.Points.P2.X < LeftX)
                    LeftX = BC.BottGP.Points.P2.X;

                Point CentLP = new Point(BC.TopGP.Points.P2.X, BC.Points.CentP.Y);
                Vect = new Vector(-1, 0, 0);
                BC.PC.DistLeft = (BC.PC.DistInc);

                if (BC.BottGP != null)
                    BC.PC.DistLeft = (BC.PC.DistInc * 2);


                TempList = BC.TopGP.LB.BoltMP;
                // Dim No 23, 23.1
                if (DN.DimIDNo23 || DN.DimIDNo23Dot1)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo23Dot1)
                        pointList.Add(BC.TopGP.LB.IntPoint);

                    pointList.Add(Com.MinP(TempList, "X"));

                    if (DN.DimIDNo23)
                        pointList.Add(Com.MinP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, LeftX, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }

                }


                // Dim No 9, 9.3
                if (DN.DimIDNo9 || DN.DimIDNo9Dot3)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo9)
                        pointList.Add(BC.TopGP.LB.IntPoint);

                    pointList.Add(BC.TopGP.Points.P2);

                    if (DN.DimIDNo9Dot3)
                        pointList.Add(CentLP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, LeftX, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }

                }

                // Dim No 22
                if (DN.DimIDNo22)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "Y"));
                    pointList.Add(CentLP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, LeftX, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }

                }

                // Dim No 9.2
                if (DN.DimIDNo9Dot2)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "X"));
                    pointList.Add(BC.TopGP.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, LeftX, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }

                }

                // Dim No 9.1
                if (DN.DimIDNo9Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "X"));
                    pointList.Add(CentLP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, LeftX, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }

                }

                // Dim No 10
                if (DN.DimIDNo10)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.LB.IntPoint);
                    pointList.Add(CentLP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, LeftX, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }

                }


                #endregion

                BC.PC.DistTop = (BC.PC.DistInc * 2);

                #region RD Dim

                Point RdPoint = new Point(BC.Points.P1.X, BC.Points.CentP.Y);
                //RD Dim
                Vect = new Vector(0, 1, 0);
                TempList = BC.TopGP.LB.BoltMP;
                // Dim No 1
                if (DN.DimIDNo1)
                {
                    pointList = new PointList();
                    pointList.Add(RdPoint);
                    pointList.Add(BC.TopGP.LB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                // Dim No 1.1
                if (DN.DimIDNo1Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(RdPoint);
                    pointList.Add(BC.TopGP.LB.IntPointB);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                // Dim No 1.7
                if (DN.DimIDNo1Dot7)
                {
                    pointList = new PointList();
                    pointList.Add(RdPoint);
                    pointList.Add(Com.MinP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                // Dim No 1.4
                if (DN.DimIDNo1Dot4)
                {
                    pointList = new PointList();
                    pointList.Add(RdPoint);
                    pointList.Add(BC.TopGP.LB.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                // Dim No 1.3
                if (DN.DimIDNo1Dot3)
                {
                    pointList = new PointList();
                    pointList.Add(RdPoint);
                    pointList.Add(Com.MinP(TempList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                #endregion

                #region Top Straight Dim

                Vect = new Vector(0, 1, 0);
                TempList = BC.TopGP.LB.BoltMP;
                // Dim No 7, 7.1
                if (DN.DimIDNo7 || DN.DimIDNo7Dot1)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo7)
                        pointList.Add(Com.MinP(BC.TopGP.LB.BoltMP, "X"));

                    pointList.Add(BC.TopGP.LB.IntPointB);

                    if (DN.DimIDNo7Dot1)
                        pointList.Add(BC.TopGP.LB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);


                    pointList = new PointList();
                    if (DN.DimIDNo7)
                        pointList.Add(Com.MaxP(BC.TopGP.RB.BoltMP, "X"));

                    pointList.Add(BC.TopGP.RB.IntPointB);

                    if (DN.DimIDNo7Dot1)
                        pointList.Add(BC.TopGP.RB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);

                }

                // Dim No 8
                if (DN.DimIDNo8)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "X"));
                    pointList.Add(BC.TopGP.LB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);

                }

                // Dim No 25, 25.1
                if (DN.DimIDNo25 || DN.DimIDNo25Dot1)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo25Dot1)
                        pointList.Add(Com.MinP(TempList, "X"));

                    pointList.Add(BC.TopGP.LB.IntPoint);

                    if (DN.DimIDNo25)
                        pointList.Add(BC.TopGP.LB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);

                }

                // Dim No 13
                if (DN.DimIDNo13)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P6);
                    pointList.Add(BC.TopGP.LB.IntPoint);
                    pointList.Add(BC.TopGP.LB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);

                }

                // Dim No 14
                if (DN.DimIDNo14)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P6);
                    pointList.Add(BC.TopGP.LB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);

                }

                // Dim No 15
                if (DN.DimIDNo15)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P6);
                    pointList.Add(BC.TopGP.Points.P5);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);

                }

                // Dim No 20
                if (DN.DimIDNo20)
                {
                    if (Ids.Count > 0)
                        BC.PC.DistTop += BC.PC.DistInc;

                    pointList = new PointList();
                    pointList.Add(new Point(BC.PC.LeftX, BC.Points.CentP.Y));
                    pointList.Add(BC.TopGP.LB.RefPBrace);
                    pointList.Add(new Point(BC.PC.RightX, BC.Points.CentP.Y));

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);

                }

                #endregion

                // Com.DrawLineDotted(CView, BC.TopGP.LB.IntPoint, BC.TopGP.LB.RefPBrace);
                //Dim Code 11 // Angle Dimension
                if (DN.DimIDNo11)
                {
                    double Dist = CalcDistAngel(BC.TopGP.LB.RefPBrace, BC.TopGP.LB.IntPoint);
                    Com.InsertAngleDim(CView, BC.TopGP.LB.RefPBrace, BC.TopGP.LB.IntPoint, "Top", Dist);
                }

            }
        }

        private void ApplyRightTopG()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            TSD.PointList TempList = new PointList();

            if (BC.TopGP?.RB != null)
            {

                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;

                TempList = Com.GetBoltPoints(BC.TopGP.RB.BoltM);
                TSG.Line YLine = new TSG.Line(BC.TopGP.Points.P6, BC.TopGP.Points.P1);
                TSG.Line XLine = new TSG.Line(Com.MinP(TempList, "X"), Com.MaxP(TempList, "Y"));
                Vector LeftVect = BC.TopGP.RB.BoltM.GetCoordinateSystem().AxisY;

                if (LeftVect.X > 0)
                    LeftVect = dc.ChangeVector(LeftVect);

                Vector RightVect = BC.TopGP.RB.BoltM.GetCoordinateSystem().AxisY;
                if (RightVect.X < 0)
                    RightVect = dc.ChangeVector(RightVect);

                Vector TopVect = BC.TopGP.RB.BoltM.GetCoordinateSystem().AxisX;
                if (TopVect.Y < 0)
                    TopVect = dc.ChangeVector(TopVect);

                Vector BottVect = BC.TopGP.RB.BoltM.GetCoordinateSystem().AxisX;
                if (BottVect.Y > 0)
                    BottVect = dc.ChangeVector(BottVect);

                #region Diagonal Top

                if (BC.TopGP.RB.Degree > 50)
                {
                    double Deg = BC.TopGP.RB.Degree - 50;
                    BC.PC.DistTop = Deg * ((BC.PC.DistInc) / 10);

                    BC.PC.DistTop += (BC.PC.DistInc * 3);
                }
                else
                    BC.PC.DistTop = (BC.PC.DistInc * 3);

                TempList = dc.ChangePints(BC.TopGP.RB.BoltMP, CView, TopVect);
                // Dim No 6
                if (DN.DimIDNo6)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    pointList.Add(BC.TopGP.RB.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, TopVect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }

                // Dim No 5
                if (DN.DimIDNo5)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, TopVect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistTop);

                }

                #endregion

                #region Diagonal Right
                double DistRight = (BC.PC.DistInc * 0.5);
                //BC.PC.DistRight += (BC.PC.DistInc * 0.25);
                TempList = dc.ChangePints(BC.TopGP.RB.BoltMP, CView, RightVect);

                // Dim No 4, 4.1
                if (DN.DimIDNo4 || DN.DimIDNo4Dot1)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo4)// Dim No 4
                        pointList.Add(Com.MinP(TempList, "Y"));

                    pointList.Add(BC.TopGP.RB.IntPointB);
                    if (DN.DimIDNo4Dot1)// Dim No 4.1
                        pointList.Add(BC.TopGP.RB.RefPBrace);

                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, XLine, DistRight);
                        DistRight += (BC.PC.DistInc * 0.8);
                    }
                }


                // Dim No 3.1 , 3, 2
                if (DN.DimIDNo3)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo3Dot1)
                    {
                        pointList.Add(Com.MaxP(TempList, "Y"));
                        pointList.Add(BC.TopGP.Points.P4);
                    }
                    if (DN.DimIDNo3)
                        pointList.AddRange(TempList);

                    if (DN.DimIDNo2)
                    {
                        pointList.Add(Com.MinP(TempList, "Y"));
                        pointList.Add(BC.TopGP.RB.RefPBrace);
                    }

                    xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, DistRight);
                }
                else
                {
                    if (DN.DimIDNo3Dot1)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MaxP(TempList, "Y"));
                        pointList.Add(BC.TopGP.Points.P4);
                        xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                            PL.DimPlacingDiag(xDim, XLine, DistRight);
                    }

                    if (DN.DimIDNo2)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MinP(TempList, "Y"));
                        pointList.Add(BC.TopGP.RB.RefPBrace);
                        xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                            PL.DimPlacingDiag(xDim, XLine, DistRight);
                    }
                }



                if (DN.DimIDNo3Dot1 || DN.DimIDNo3 || DN.DimIDNo2)
                    BC.PC.DistRight += BC.PC.DistInc;

                // Dim No 3.2
                if (DN.DimIDNo3Dot2)
                {
                    if (TempList.Count > 2)
                    {
                        pointList = new PointList();
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, RightVect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                        {
                            PL.DimPlacingDiag(xDim, XLine, DistRight);
                            Com.GroupDim(xDim);
                        }
                    }
                }

                #endregion

                #region Straight Right

                double RightX = BC.TopGP.Points.P3.X;
                if (BC.BottGP != null && BC.BottGP.Points.P3.X < RightX)
                    RightX = BC.BottGP.Points.P3.X;

                Point CentLP = new Point(BC.TopGP.Points.P3.X, BC.Points.CentP.Y);
                Vect = new Vector(1, 0, 0);
                BC.PC.DistRight = (BC.PC.DistInc * 3);
                TempList = BC.TopGP.RB.BoltMP;
                // Dim No 23, 23.1
                if (DN.DimIDNo23 || DN.DimIDNo23Dot1)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo23Dot1)
                        pointList.Add(BC.TopGP.RB.IntPoint);

                    pointList.Add(Com.MaxP(TempList, "X"));

                    if (DN.DimIDNo23)
                        pointList.Add(Com.MinP(TempList, "Y"));

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, RightX, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }

                }

                // Dim No 9, 9.3
                if (DN.DimIDNo9 || DN.DimIDNo9Dot3)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo9)
                        pointList.Add(BC.TopGP.RB.IntPoint);

                    pointList.Add(BC.TopGP.Points.P3);

                    if (DN.DimIDNo9Dot3)
                        pointList.Add(CentLP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, RightX, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }

                }

                // Dim No 22
                if (DN.DimIDNo22)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "Y"));
                    pointList.Add(CentLP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, RightX, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }

                }

                // Dim No 9.2
                if (DN.DimIDNo9Dot2)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "X"));
                    pointList.Add(BC.TopGP.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, RightX, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }

                }

                // Dim No 9.1
                if (DN.DimIDNo9Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "X"));
                    pointList.Add(CentLP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, RightX, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }

                }



                // Dim No 10
                if (DN.DimIDNo10)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.RB.IntPoint);
                    pointList.Add(CentLP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, RightX, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }

                }


                #endregion

                BC.PC.DistTop = (BC.PC.DistInc * 3);

                #region RD Dim
                //RD Dim
                Vect = new Vector(0, 1, 0);
                TempList = BC.TopGP.RB.BoltMP;

                Point RdPoint = new Point(BC.Points.P1.X, BC.Points.CentP.Y);

                // Dim No 1.7
                if (DN.DimIDNo1Dot7)
                {
                    pointList = new PointList();
                    pointList.Add(RdPoint);
                    pointList.Add(Com.MinP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                // Dim No 1.5
                if (DN.DimIDNo1Dot5)
                {
                    pointList = new PointList();
                    pointList.Add(RdPoint);
                    pointList.Add(BC.TopGP.RB.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                // Dim No 1.6
                if (DN.DimIDNo1Dot6)
                {
                    pointList = new PointList();
                    pointList.Add(RdPoint);
                    pointList.Add(Com.MaxP(TempList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                // Dim No 1.2
                if (DN.DimIDNo1Dot2)
                {
                    pointList = new PointList();
                    pointList.Add(RdPoint);
                    pointList.Add(BC.TopGP.RB.IntPointB);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }

                }

                #endregion

                #region Top Straight Dim

                Vect = new Vector(0, 1, 0);
                TempList = BC.TopGP.RB.BoltMP;

                if (DN.DimIDNo7 || DN.DimIDNo7Dot1)
                    BC.PC.DistTop += (BC.PC.DistInc * 2);

                // Dim No 8
                if (DN.DimIDNo8)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "X"));
                    pointList.Add(BC.TopGP.RB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);

                }

                // Dim No 25, 25.1
                if (DN.DimIDNo25 || DN.DimIDNo25Dot1)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo25Dot1)
                        pointList.Add(Com.MaxP(TempList, "X"));

                    pointList.Add(BC.TopGP.RB.IntPoint);

                    if (DN.DimIDNo25)
                        pointList.Add(BC.TopGP.RB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);

                }

                // Dim No 13
                if (DN.DimIDNo13)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P5);
                    pointList.Add(BC.TopGP.RB.IntPoint);
                    pointList.Add(BC.TopGP.RB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);

                }

                // Dim No 14
                if (DN.DimIDNo14)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P5);
                    pointList.Add(BC.TopGP.RB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);

                }

                #endregion

                //  Com.DrawLineDotted(CView, BC.TopGP.RB.IntPoint, BC.TopGP.RB.RefPBrace);
                //Dim Code 11 // Angle Dimension
                if (DN.DimIDNo11)
                {
                    double Dist = CalcDistAngel(BC.TopGP.RB.RefPBrace, BC.TopGP.RB.IntPoint);
                    Com.InsertAngleDim(CView, BC.TopGP.RB.RefPBrace, BC.TopGP.RB.IntPoint, "Top", Dist);
                }

            }
        }

        private void ApplyLeftBottG()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, -1, 0);
            TSD.PointList TempList = new PointList();

            if (BC.BottGP?.LB != null)
            {

                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;

                TempList = Com.GetBoltPoints(BC.BottGP.LB.BoltM);
                TSG.Line YLine = new TSG.Line(BC.BottGP.Points.P6, BC.BottGP.Points.P1);
                TSG.Line XLine = new TSG.Line(Com.MaxP(TempList, "X"), Com.MinP(TempList, "Y"));
                Vector LeftVect = BC.BottGP.LB.BoltM.GetCoordinateSystem().AxisY;

                if (LeftVect.X > 0)
                    LeftVect = dc.ChangeVector(LeftVect);

                Vector RightVect = BC.BottGP.LB.BoltM.GetCoordinateSystem().AxisY;
                if (RightVect.X < 0)
                    RightVect = dc.ChangeVector(RightVect);

                Vector TopVect = BC.BottGP.LB.BoltM.GetCoordinateSystem().AxisX;
                if (TopVect.Y < 0)
                    TopVect = dc.ChangeVector(TopVect);

                Vector BottVect = BC.BottGP.LB.BoltM.GetCoordinateSystem().AxisX;
                if (BottVect.Y > 0)
                    BottVect = dc.ChangeVector(BottVect);

                #region Diagonal Bottom

                if (BC.BottGP.LB.Degree > 50)
                {
                    double Deg = BC.BottGP.LB.Degree - 50;
                    BC.PC.DistBot = Deg * ((BC.PC.DistInc) / 10);

                    BC.PC.DistBot += (BC.PC.DistInc * 4);
                }
                else
                    BC.PC.DistBot = (BC.PC.DistInc * 4);

                TempList = dc.ChangePints(BC.BottGP.LB.BoltMP, CView, BottVect);
                // Dim No 6
                if (DN.DimIDNo6)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    pointList.Add(BC.BottGP.LB.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, BottVect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }

                // Dim No 5
                if (DN.DimIDNo5)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, BottVect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistBot);

                }

                #endregion

                #region Diagonal Left
                BC.PC.DistLeft += (BC.PC.DistInc * 0.75);
                TempList = dc.ChangePints(BC.BottGP.LB.BoltMP, CView, LeftVect);

                // Dim No 4, 4.1
                if (DN.DimIDNo4 || DN.DimIDNo4Dot1)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo4)// Dim No 4
                        pointList.Add(Com.MaxP(TempList, "Y"));

                    pointList.Add(BC.BottGP.LB.IntPointB);
                    if (DN.DimIDNo4Dot1)// Dim No 4.1
                        pointList.Add(BC.BottGP.LB.RefPBrace);

                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);
                        BC.PC.DistLeft += (BC.PC.DistInc * 0.75);
                    }
                }


                // Dim No 3.1 , 3, 2
                if (DN.DimIDNo3)
                {

                    pointList = new PointList();
                    if (DN.DimIDNo3Dot1)
                    {
                        pointList.Add(Com.MinP(TempList, "Y"));
                        pointList.Add(BC.BottGP.Points.P1);
                    }
                    if (DN.DimIDNo3)
                        pointList.AddRange(TempList);

                    if (DN.DimIDNo2)
                    {
                        pointList.Add(Com.MaxP(TempList, "Y"));
                        pointList.Add(BC.BottGP.LB.RefPBrace);
                    }

                    xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);
                }
                else
                {
                   
                    if (DN.DimIDNo3Dot1)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MinP(TempList, "Y"));
                        pointList.Add(BC.BottGP.Points.P1);
                        xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                            PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);
                    }

                    if (DN.DimIDNo2)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MaxP(TempList, "Y"));
                        pointList.Add(BC.BottGP.LB.RefPBrace);
                        xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                            PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);
                    }

                }

                if (DN.DimIDNo3Dot1 || DN.DimIDNo3 || DN.DimIDNo2)
                    BC.PC.DistLeft += BC.PC.DistInc;

                // Dim No 3.2
                if (DN.DimIDNo3Dot2)
                {
                    if (TempList.Count > 2)
                    {
                        pointList = new PointList();
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, LeftVect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                        {
                            PL.DimPlacingDiag(xDim, XLine, BC.PC.DistLeft);
                            Com.GroupDim(xDim);
                        }
                    }
                }

                #endregion

                #region Straight Left

                double LeftX = BC.BottGP.Points.P2.X;
                if (BC.TopGP != null && BC.TopGP.Points.P2.X < LeftX)
                    LeftX = BC.TopGP.Points.P2.X;

                Point CentLP = new Point(BC.BottGP.Points.P2.X, BC.Points.CentP.Y);
                Vect = new Vector(-1, 0, 0);
                BC.PC.DistLeft = (BC.PC.DistInc * 2);
                TempList = BC.BottGP.LB.BoltMP;

                // Dim No 9, 9.3
                if (DN.DimIDNo9 || DN.DimIDNo9Dot3)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo9)
                        pointList.Add(BC.BottGP.LB.IntPoint);

                    pointList.Add(BC.BottGP.Points.P2);

                    if (DN.DimIDNo9Dot3)
                        pointList.Add(CentLP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, LeftX, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }

                }


                // Dim No 23, 23.1
                if (DN.DimIDNo23 || DN.DimIDNo23Dot1)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo23Dot1)
                        pointList.Add(BC.BottGP.LB.IntPoint);

                    pointList.Add(Com.MinP(TempList, "X"));

                    if (DN.DimIDNo23)
                        pointList.Add(Com.MaxP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, LeftX, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }

                }

                // Dim No 22
                if (DN.DimIDNo22)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    pointList.Add(CentLP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, LeftX, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }

                }

                // Dim No 9.2
                if (DN.DimIDNo9Dot2)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "X"));
                    pointList.Add(BC.BottGP.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, LeftX, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }

                }

                // Dim No 9.1
                if (DN.DimIDNo9Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "X"));
                    pointList.Add(CentLP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, LeftX, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }

                }



                // Dim No 10
                if (DN.DimIDNo10)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.LB.IntPoint);
                    pointList.Add(CentLP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, LeftX, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }

                }

                // Dim No 12
                if (DN.DimIDNo12 && BC.TopGP != null)
                {
                    pointList = new PointList();
                    pointList.Add(BC.TopGP.Points.P1);
                    pointList.Add(BC.BottGP.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, LeftX, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }

                }


                #endregion

                BC.PC.DistBot = (BC.PC.DistInc);

                #region RD Dim
                //RD Dim
                Vect = new Vector(0, -1, 0);
                TempList = BC.BottGP.LB.BoltMP;
                Point RdPoint = new Point(BC.Points.P1.X, BC.Points.CentP.Y);

                // Dim No 1
                if (DN.DimIDNo1)
                {
                    if (BC.TopGP == null || (BC.TopGP != null && !dc.IsEqualPoints(BC.TopGP.LB.RefPBrace, BC.BottGP.LB.RefPBrace)))
                    {
                        pointList = new PointList();
                        pointList.Add(RdPoint);
                        pointList.Add(BC.BottGP.LB.RefPBrace);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                            BC.PC.DistBot += BC.PC.DistInc;
                        }
                    }
                    else
                        BC.PC.DistBot += BC.PC.DistInc;

                }

                // Dim No 1.1
                if (DN.DimIDNo1Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(RdPoint);
                    pointList.Add(BC.BottGP.LB.IntPointB);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                // Dim No 1.7
                if (DN.DimIDNo1Dot7)
                {
                    pointList = new PointList();
                    pointList.Add(RdPoint);
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                // Dim No 1.4
                if (DN.DimIDNo1Dot4)
                {
                    pointList = new PointList();
                    pointList.Add(RdPoint);
                    pointList.Add(BC.BottGP.LB.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                // Dim No 1.3
                if (DN.DimIDNo1Dot3)
                {
                    pointList = new PointList();
                    pointList.Add(RdPoint);
                    pointList.Add(Com.MinP(TempList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                #endregion

                #region Bottom Straight Dim

                Vect = new Vector(0, -1, 0);
                TempList = BC.BottGP.LB.BoltMP;
                // Dim No 7, 7.1
                if (DN.DimIDNo7 || DN.DimIDNo7Dot1)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo7)
                        pointList.Add(Com.MinP(BC.BottGP.LB.BoltMP, "X"));

                    pointList.Add(BC.BottGP.LB.IntPointB);

                    if (DN.DimIDNo7Dot1)
                        pointList.Add(BC.BottGP.LB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);

                    pointList = new PointList();
                    if (DN.DimIDNo7)
                        pointList.Add(Com.MaxP(BC.BottGP.RB.BoltMP, "X"));

                    pointList.Add(BC.BottGP.RB.IntPointB);

                    if (DN.DimIDNo7Dot1)
                        pointList.Add(BC.BottGP.RB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);

                }

                // Dim No 8
                if (DN.DimIDNo8)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(TempList, "X"));
                    pointList.Add(BC.BottGP.LB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);

                }

                // Dim No 25, 25.1
                if (DN.DimIDNo25 || DN.DimIDNo25Dot1)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo25Dot1)
                        pointList.Add(Com.MinP(TempList, "X"));

                    pointList.Add(BC.BottGP.LB.IntPoint);

                    if (DN.DimIDNo25)
                        pointList.Add(BC.BottGP.LB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);

                }

                // Dim No 13
                if (DN.DimIDNo13)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P6);
                    pointList.Add(BC.BottGP.LB.IntPoint);
                    pointList.Add(BC.BottGP.LB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);

                }

                // Dim No 14
                if (DN.DimIDNo14)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P6);
                    pointList.Add(BC.BottGP.LB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);

                }

                // Dim No 15
                if (DN.DimIDNo15)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P6);
                    pointList.Add(BC.BottGP.Points.P5);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);

                }

                // Dim No 20
                if (DN.DimIDNo20 && BC.TopGP == null)
                {
                    if (Ids.Count > 0)
                        BC.PC.DistBot += BC.PC.DistInc;

                    pointList = new PointList();
                    pointList.Add(new Point(BC.PC.LeftX, BC.Points.CentP.Y));
                    pointList.Add(BC.BottGP.LB.RefPBrace);
                    pointList.Add(new Point(BC.PC.RightX, BC.Points.CentP.Y));

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);

                }

                #endregion

                // Com.DrawLineDotted(CView, BC.BottGP.LB.IntPoint, BC.BottGP.LB.RefPBrace);
                //Dim Code 11 // Angle Dimension
                if (DN.DimIDNo11)
                {
                    double Dist = CalcDistAngel(BC.BottGP.LB.RefPBrace, BC.BottGP.LB.IntPoint);
                    Com.InsertAngleDim(CView, BC.BottGP.LB.RefPBrace, BC.BottGP.LB.IntPoint, "Bottom", Dist);
                }

            }
        }

        private void ApplyRightBottG()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            TSD.PointList TempList = new PointList();

            if (BC.BottGP?.RB != null)
            {

                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;

                TempList = Com.GetBoltPoints(BC.BottGP.RB.BoltM);
                TSG.Line YLine = new TSG.Line(BC.BottGP.Points.P6, BC.BottGP.Points.P1);
                TSG.Line XLine = new TSG.Line(Com.MaxP(TempList, "X"), Com.MaxP(TempList, "Y"));
                Vector LeftVect = BC.BottGP.RB.BoltM.GetCoordinateSystem().AxisY;

                if (LeftVect.X > 0)
                    LeftVect = dc.ChangeVector(LeftVect);

                Vector RightVect = BC.BottGP.RB.BoltM.GetCoordinateSystem().AxisY;
                if (RightVect.X < 0)
                    RightVect = dc.ChangeVector(RightVect);

                Vector TopVect = BC.BottGP.RB.BoltM.GetCoordinateSystem().AxisX;
                if (TopVect.Y < 0)
                    TopVect = dc.ChangeVector(TopVect);

                Vector BottVect = BC.BottGP.RB.BoltM.GetCoordinateSystem().AxisX;
                if (BottVect.Y > 0)
                    BottVect = dc.ChangeVector(BottVect);

                #region Diagonal Bottom

                if (BC.BottGP.RB.Degree > 50)
                {
                    double Deg = BC.BottGP.RB.Degree - 50;
                    BC.PC.DistBot = Deg * ((BC.PC.DistInc) / 10);

                    BC.PC.DistBot += (BC.PC.DistInc * 3);
                }
                else
                    BC.PC.DistBot = (BC.PC.DistInc * 3);

                TempList = dc.ChangePints(BC.BottGP.RB.BoltMP, CView, BottVect);
                // Dim No 6
                if (DN.DimIDNo6)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    pointList.Add(BC.BottGP.RB.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, BottVect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }

                // Dim No 5
                if (DN.DimIDNo5)
                {
                    pointList = new PointList();
                    pointList.AddRange(TempList);
                    xDim = dc.InsertDim(CView, pointList, BottVect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, YLine, BC.PC.DistBot);

                }

                #endregion

                #region Diagonal Left
                double DistLeft = (BC.PC.DistInc * 0.15);
                //BC.PC.DistRight += (BC.PC.DistInc * 0.25);
                TempList = dc.ChangePints(BC.BottGP.RB.BoltMP, CView, LeftVect);

                // Dim No 4, 4.1
                if (DN.DimIDNo4 || DN.DimIDNo4Dot1)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo4)// Dim No 4
                        pointList.Add(Com.MaxP(TempList, "Y"));

                    pointList.Add(BC.BottGP.RB.IntPointB);

                    if (DN.DimIDNo4Dot1)// Dim No 4.1
                        pointList.Add(BC.BottGP.RB.RefPBrace);

                    xDim = dc.InsertDim(CView, pointList, LeftVect, DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DimPlacingDiag(xDim, XLine, DistLeft);
                        DistLeft += (BC.PC.DistInc * 0.8);
                    }
                }


                // Dim No 3.1 , 3, 2
                if (DN.DimIDNo3)
                {

                    pointList = new PointList();
                    if (DN.DimIDNo3Dot1)
                    {
                        pointList.Add(Com.MinP(TempList, "Y"));
                        pointList.Add(BC.BottGP.Points.P4);
                    }
                    if (DN.DimIDNo3)
                        pointList.AddRange(TempList);

                    if (DN.DimIDNo2)
                    {
                        pointList.Add(Com.MaxP(TempList, "Y"));
                        pointList.Add(BC.BottGP.RB.RefPBrace);
                    }

                    xDim = dc.InsertDim(CView, pointList, LeftVect, DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DimPlacingDiag(xDim, XLine, DistLeft);
                }
                else
                {

                    if (DN.DimIDNo3Dot1)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MinP(TempList, "Y"));
                        pointList.Add(BC.BottGP.Points.P5);
                        xDim = dc.InsertDim(CView, pointList, LeftVect, DistLeft, StAtrr);
                        if (xDim != null)
                            PL.DimPlacingDiag(xDim, XLine, DistLeft);
                    }

                    if (DN.DimIDNo2)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MaxP(TempList, "Y"));
                        pointList.Add(BC.BottGP.RB.RefPBrace);
                        xDim = dc.InsertDim(CView, pointList, LeftVect, DistLeft, StAtrr);
                        if (xDim != null)
                            PL.DimPlacingDiag(xDim, XLine, DistLeft);
                    }

                }

                if (DN.DimIDNo3Dot1 || DN.DimIDNo3 || DN.DimIDNo2)
                    BC.PC.DistRight += BC.PC.DistInc;

                // Dim No 3.2
                if (DN.DimIDNo3Dot2)
                {
                    if (TempList.Count > 2)
                    {
                        pointList = new PointList();
                        pointList.AddRange(TempList);
                        xDim = dc.InsertDim(CView, pointList, LeftVect, DistLeft, StAtrr);
                        if (xDim != null)
                        {
                            PL.DimPlacingDiag(xDim, XLine, DistLeft);
                            Com.GroupDim(xDim);
                        }
                    }
                }

                #endregion

                #region Straight Right

                double RightX = BC.BottGP.Points.P3.X;
                if (BC.TopGP != null && BC.TopGP.Points.P3.X < RightX)
                    RightX = BC.TopGP.Points.P3.X;

                Point CentLP = new Point(BC.BottGP.Points.P3.X, BC.Points.CentP.Y);
                Vect = new Vector(1, 0, 0);
                BC.PC.DistRight = (BC.PC.DistInc * 3);
                TempList = BC.BottGP.RB.BoltMP;

                // Dim No 9, 9.3
                if (DN.DimIDNo9 || DN.DimIDNo9Dot3)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo9)
                        pointList.Add(BC.BottGP.RB.IntPoint);

                    pointList.Add(BC.BottGP.Points.P3);

                    if (DN.DimIDNo9Dot3)
                        pointList.Add(CentLP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, RightX, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }

                }

                // Dim No 23, 23.1
                if (DN.DimIDNo23 || DN.DimIDNo23Dot1)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo23Dot1)
                        pointList.Add(BC.BottGP.RB.IntPoint);

                    pointList.Add(Com.MaxP(TempList, "X"));

                    if (DN.DimIDNo23)
                        pointList.Add(Com.MaxP(TempList, "Y"));

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, RightX, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }

                }

                // Dim No 22
                if (DN.DimIDNo22)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    pointList.Add(CentLP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, RightX, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }

                }

                // Dim No 9.2
                if (DN.DimIDNo9Dot2)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "X"));
                    pointList.Add(BC.BottGP.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, RightX, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }

                }

                // Dim No 9.1
                if (DN.DimIDNo9Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "X"));
                    pointList.Add(CentLP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, RightX, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }

                }



                // Dim No 10
                if (DN.DimIDNo10)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.RB.IntPoint);
                    pointList.Add(CentLP);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, RightX, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }

                }


                #endregion

                BC.PC.DistBot = (BC.PC.DistInc * 2);

                #region RD Dim
                //RD Dim
                Vect = new Vector(0, -1, 0);
                TempList = BC.BottGP.RB.BoltMP;
                Point RdPoint = new Point(BC.Points.P1.X, BC.Points.CentP.Y);

                // Dim No 1.7
                if (DN.DimIDNo1Dot7)
                {
                    pointList = new PointList();
                    pointList.Add(RdPoint);
                    pointList.Add(Com.MaxP(TempList, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                // Dim No 1.5
                if (DN.DimIDNo1Dot5)
                {
                    pointList = new PointList();
                    pointList.Add(RdPoint);
                    pointList.Add(BC.BottGP.RB.IntPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                // Dim No 1.6
                if (DN.DimIDNo1Dot6)
                {
                    pointList = new PointList();
                    pointList.Add(RdPoint);
                    pointList.Add(Com.MaxP(TempList, "X"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                // Dim No 1.2
                if (DN.DimIDNo1Dot2)
                {
                    pointList = new PointList();
                    pointList.Add(RdPoint);
                    pointList.Add(BC.BottGP.RB.IntPointB);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }

                }

                #endregion

                #region Bottom Straight Dim
                //BC.PC.DistBot += BC.PC.DistInc;
                Vect = new Vector(0, -1, 0);
                TempList = BC.BottGP.RB.BoltMP;


                // Dim No 8
                if (DN.DimIDNo8)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MaxP(TempList, "X"));
                    pointList.Add(BC.BottGP.RB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);

                }

                // Dim No 25, 25.1
                if (DN.DimIDNo25 || DN.DimIDNo25Dot1)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo25Dot1)
                        pointList.Add(Com.MaxP(TempList, "X"));

                    pointList.Add(BC.BottGP.RB.IntPoint);

                    if (DN.DimIDNo25)
                        pointList.Add(BC.BottGP.RB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);

                }

                // Dim No 13
                if (DN.DimIDNo13)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P5);
                    pointList.Add(BC.BottGP.RB.IntPoint);
                    pointList.Add(BC.BottGP.RB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);

                }

                // Dim No 14
                if (DN.DimIDNo14)
                {
                    pointList = new PointList();
                    pointList.Add(BC.BottGP.Points.P5);
                    pointList.Add(BC.BottGP.RB.RefPBrace);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByBottomY(xDim, BC.PC);

                }

                #endregion

                // Com.DrawLineDotted(CView, BC.BottGP.RB.IntPoint, BC.BottGP.RB.RefPBrace);
                //Dim Code 11 // Angle Dimension
                if (DN.DimIDNo11)
                {
                    double Dist = CalcDistAngel(BC.BottGP.RB.RefPBrace, BC.BottGP.RB.IntPoint);
                    Com.InsertAngleDim(CView, BC.BottGP.RB.RefPBrace, BC.BottGP.RB.IntPoint, "Bottom", Dist);
                }

            }
        }

        private void ApplyRadiusDim()
        {
            if (DN.DimIDNo16)
            {
                if (BC.ContPT != null)
                {
                    if (BC.ContPT.P1 != null)
                    {
                        PointList Plist = dc.GetRadialChampherPointList(BC.ContPT.P1, BC.TopGP.GussetPlate);
                        RadiusDimension Rd = new RadiusDimension(CView, Plist[2], Plist[1], Plist[0], 5);
                        Rd.Attributes.Placing.Placing = DimensionSetBaseAttributes.Placings.Fixed;
                        Rd.Insert();


                    }

                    if (BC.ContPT.P2 != null)
                    {
                        PointList Plist = dc.GetRadialChampherPointList(BC.ContPT.P2, BC.TopGP.GussetPlate);
                        RadiusDimension Rd = new RadiusDimension(CView, Plist[0], Plist[1], Plist[2], 5);
                        Rd.Attributes.Placing.Placing = DimensionSetBaseAttributes.Placings.Fixed;
                        Rd.Insert();


                    }
                }

                if (BC.ContPB != null)
                {
                    if (BC.ContPB.P1 != null)
                    {
                        PointList Plist = dc.GetRadialChampherPointList(BC.ContPB.P1, BC.BottGP.GussetPlate);
                        RadiusDimension Rd = new RadiusDimension(CView, Plist[0], Plist[1], Plist[2], 5);
                        Rd.Attributes.Placing.Placing = DimensionSetBaseAttributes.Placings.Fixed;
                        Rd.Insert();
                    }

                    if (BC.ContPB.P2 != null)
                    {
                        PointList Plist = dc.GetRadialChampherPointList(BC.ContPB.P2, BC.BottGP.GussetPlate);
                        RadiusDimension Rd = new RadiusDimension(CView, Plist[2], Plist[1], Plist[0], 5);
                        Rd.Attributes.Placing.Placing = DimensionSetBaseAttributes.Placings.Fixed;
                        Rd.Insert();


                    }
                }
            }


        }

        private double CalcDistAngel(Point StartP, Point EndP)
        {
            double Dv = 12 / 0.05;
            double ScalM = (12 - CView.Attributes.Scale) * 12;
            double ScaleD = 0.20 - ((12 - CView.Attributes.Scale) / Dv);
            double Dist = (Distance.PointToPoint(StartP, EndP) * ScaleD);
            Dist += ScalM;
            return Dist;
        }

        #endregion

        // Apply Dim in Front View
        private void ApplyTBV()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(0, 1, 0);
            TSD.PointList TempList = new PointList();

            if (BC.GPTV != null)
            {
                double FlThick = Com.GetPartFlangeThickness(MainBeam) + 20;
                if (BC.GPTV.GussetList != null && (DN.DimIDNo18 || DN.DimIDNo18Dot1))
                {
                    int i = 0;

                    foreach (PartClass PC in BC.GPTV.GussetList)
                    {
                        PartPoints Points = PC.Points;
                        if (i % 2 == 0)
                        {
                            Vect = new Vector(1, 0, 0);
                            pointList = new PointList();
                            if (DN.DimIDNo18)
                                pointList.Add(new Point(Points.P4.X, BC.Points.P4.Y));

                            pointList.Add(Points.P4);

                            if (DN.DimIDNo18Dot1)
                                pointList.Add(Points.P3);


                        }
                        else
                        {
                            Vect = new Vector(-1, 0, 0);
                            pointList = new PointList();
                            if (DN.DimIDNo18)
                                pointList.Add(new Point(Points.P1.X, BC.Points.P1.Y));

                            pointList.Add(Points.P1);

                            if (DN.DimIDNo18Dot1)
                                pointList.Add(Points.P2);
                        }

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);

                        i++;

                        //Ids.Add(PC.part.Identifier.ID);
                    }


                }

                if (BC.GPTV.GussetList?.Count > 0)
                    Ids.AddRange(BC.GPTV.GussetList.Select(x => x.part.Identifier.ID).ToList());

                if (BC.GPTV.StiffList != null)
                {
                    Point RdPoint = new Point(BC.Points.P1.X, BC.Points.CentP.Y);

                    BC.PC.DistTop = (BC.PC.DistInc * 2);
                    foreach (PartClass PC in BC.GPTV.StiffList)
                    {
                        PartPoints Points = PC.Points;

                        double MaxY = BC.Points.P1.Y - FlThick;

                        if (dc.IsGreater(Points.P1.Y, MaxY) && (DN.DimIDNo17 || DN.DimIDNo17Dot1))
                        {
                            Vect = new Vector(0, 1, 0);
                            pointList = new PointList();
                            pointList.Add(RdPoint);
                            pointList.Add(Points.P1);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                            if (xDim != null)
                                PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        }
                        else if (dc.IsEqualOrLess(Points.P1.Y, MaxY) && (DN.DimIDNo17Dot2 || DN.DimIDNo17Dot3))
                        {
                            Vect = new Vector(0, -1, 0);
                            pointList = new PointList();
                            pointList.Add(RdPoint);
                            pointList.Add(Points.P2);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                            if (xDim != null)
                                PL.DistPlaceTopP(xDim, BC.PC.BottomY, BC.PC.DistTop);
                        }

                        Ids.Add(PC.part.Identifier.ID);
                    }
                }


            }

        }

        private void AppySectionDim()
        {
            StraightDimensionSet xDim = null;
            PointList pointList = new PointList();
            Vector Vect = new Vector(0, 1, 0);

            bool IsLeftDim = false;

            bool IsRightDim = false;
            if (BC.GPS != null)
            {
                if (BC.GPS.StiffTL == null)
                {
                    // Dim No 19, 19.1
                    if (DN.DimIDNo19 || DN.DimIDNo19Dot1)
                    {
                        if (BC.GPS.StiffL != null)
                        {
                            pointList = new PointList();

                            if (DN.DimIDNo19) // Dim No 19
                                pointList.Add(BC.GPS.StiffL.Points.P1);

                            pointList.Add(BC.GPS.StiffL.Points.P4);

                            if (DN.DimIDNo19Dot1) // Dim No 19.1
                                pointList.Add(MainBeam.StartPoint);

                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                            if (xDim != null)
                                PL.DimPlaceByTopY(xDim, BC.PC);
                        }


                        if (BC.GPS.StiffR != null)
                        {
                            pointList = new PointList();

                            if (DN.DimIDNo19) // Dim No 19
                                pointList.Add(BC.GPS.StiffR.Points.P4);

                            pointList.Add(BC.GPS.StiffR.Points.P1);

                            if (DN.DimIDNo19Dot1) // Dim No 19.1
                                pointList.Add(MainBeam.StartPoint);

                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                            if (xDim != null)
                                PL.DimPlaceByTopY(xDim, BC.PC);
                        }
                    }

                    if (BC.GPS.StiffL != null)
                    {
                        Vect = new Vector(-1, 0, 0);
                        // Dim No 21.1
                        if (DN.DimIDNo21Dot1)
                        {
                            pointList = new PointList();
                            pointList.Add(BC.GPS.StiffL.Points.P1);
                            pointList.Add(BC.Points.P1);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                            if (xDim != null)
                                PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);


                            pointList = new PointList();
                            pointList.Add(BC.GPS.StiffL.Points.P2);
                            pointList.Add(BC.Points.P2);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                            if (xDim != null)
                                PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                        }

                        // Dim No 21
                        if (DN.DimIDNo21)
                        {
                            pointList = new PointList();
                            pointList.Add(BC.GPS.StiffL.Points.P1);
                            pointList.Add(BC.GPS.StiffL.Points.P2);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                            if (xDim != null)
                                PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                        }

                        if (DN.DimIDNo21Dot1 || DN.DimIDNo21)
                            BC.PC.DistLeft += BC.PC.DistInc;

                        Ids.Add(BC.GPS.StiffL.part.Identifier.ID);
                    }

                    if (BC.GPS.StiffR != null)
                    {
                        Vect = new Vector(1, 0, 0);
                        // Dim No 21.1
                        if (DN.DimIDNo21Dot1)
                        {
                            pointList = new PointList();
                            pointList.Add(BC.GPS.StiffR.Points.P4);
                            pointList.Add(BC.Points.P4);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                            if (xDim != null)
                                PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);


                            pointList = new PointList();
                            pointList.Add(BC.GPS.StiffR.Points.P3);
                            pointList.Add(BC.Points.P3);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                            if (xDim != null)
                                PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                        }

                        // Dim No 21
                        if (DN.DimIDNo21)
                        {
                            pointList = new PointList();
                            pointList.Add(BC.GPS.StiffR.Points.P4);
                            pointList.Add(BC.GPS.StiffR.Points.P3);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                            if (xDim != null)
                                PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                        }

                        if (DN.DimIDNo21Dot1 || DN.DimIDNo21)
                            BC.PC.DistRight += BC.PC.DistInc;

                        Ids.Add(BC.GPS.StiffR.part.Identifier.ID);
                    }



                }
                else
                {

                    // Dim No 28, 28.1
                    if (DN.DimIDNo28 || DN.DimIDNo28Dot1)
                    {
                        Vect = new Vector(0, 1, 0);
                        if (BC.GPS.StiffTL != null)
                        {
                            pointList = new PointList();

                            if (DN.DimIDNo28) // Dim No 28
                                pointList.Add(BC.GPS.StiffTL.Points.P1);

                            pointList.Add(BC.GPS.StiffTL.Points.P4);

                            if (DN.DimIDNo28Dot1) // Dim No 28.1
                                pointList.Add(MainBeam.StartPoint);

                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                            if (xDim != null)
                                PL.DimPlaceByTopY(xDim, BC.PC);
                        }


                        if (BC.GPS.StiffTR != null)
                        {
                            pointList = new PointList();

                            if (DN.DimIDNo28) // Dim No 28
                                pointList.Add(BC.GPS.StiffTR.Points.P4);

                            pointList.Add(BC.GPS.StiffTR.Points.P1);

                            if (DN.DimIDNo28Dot1) // Dim No 28.1
                                pointList.Add(MainBeam.StartPoint);

                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                            if (xDim != null)
                                PL.DimPlaceByTopY(xDim, BC.PC);
                        }

                        Vect = new Vector(0, -1, 0);
                        if (BC.GPS.StiffL != null)
                        {
                            pointList = new PointList();

                            if (DN.DimIDNo28) // Dim No 28
                                pointList.Add(BC.GPS.StiffL.Points.P2);

                            pointList.Add(BC.GPS.StiffL.Points.P3);

                            if (DN.DimIDNo28Dot1) // Dim No 28.1
                                pointList.Add(MainBeam.StartPoint);

                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                            if (xDim != null)
                                PL.DimPlaceByBottomY(xDim, BC.PC);
                        }


                        if (BC.GPS.StiffR != null)
                        {
                            pointList = new PointList();

                            if (DN.DimIDNo28) // Dim No 28
                                pointList.Add(BC.GPS.StiffR.Points.P3);

                            pointList.Add(BC.GPS.StiffR.Points.P2);

                            if (DN.DimIDNo28Dot1) // Dim No 28.1
                                pointList.Add(MainBeam.StartPoint);

                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                            if (xDim != null)
                                PL.DimPlaceByBottomY(xDim, BC.PC);
                        }

                    }

                    // Dim No 24, 24.1
                    if (DN.DimIDNo24Dot1 || DN.DimIDNo24)
                    {
                        if (BC.GPS.StiffTL != null)
                        {
                            Vect = new Vector(-1, 0, 0);
                            pointList = new PointList();
                            if (DN.DimIDNo24Dot1)
                                pointList.Add(BC.GPS.StiffTL.Points.P1);
                            pointList.Add(BC.Points.P1);
                            if (DN.DimIDNo24)
                                pointList.Add(BC.GPS.StiffTL.Points.P2);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                            if (xDim != null)
                                PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);

                            IsLeftDim = true;

                        }

                        if (BC.GPS.StiffTR != null)
                        {
                            Vect = new Vector(1, 0, 0);
                            pointList = new PointList();
                            if (DN.DimIDNo24Dot1)
                                pointList.Add(BC.GPS.StiffTR.Points.P4);
                            pointList.Add(BC.Points.P4);
                            if (DN.DimIDNo24)
                                pointList.Add(BC.GPS.StiffTR.Points.P3);
                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                            if (xDim != null)
                                PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);

                            IsRightDim = true;
                        }
                    }


                    // Dim No 27, 27.1
                    if (DN.DimIDNo27Dot1 || DN.DimIDNo27)
                    {
                        if (BC.GPS.StiffL != null)
                        {
                            Vect = new Vector(-1, 0, 0);
                            pointList = new PointList();
                            if (DN.DimIDNo27)
                                pointList.Add(BC.GPS.StiffL.Points.P1);

                            pointList.Add(BC.GPS.StiffL.Points.P2);

                            if (DN.DimIDNo27Dot1)
                                pointList.Add(BC.Points.P2);

                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                            if (xDim != null)
                                PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);

                            IsLeftDim = true;
                        }

                        if (BC.GPS.StiffR != null)
                        {
                            Vect = new Vector(1, 0, 0);
                            pointList = new PointList();
                            if (DN.DimIDNo27)
                                pointList.Add(BC.GPS.StiffR.Points.P4);

                            pointList.Add(BC.GPS.StiffR.Points.P3);

                            if (DN.DimIDNo27Dot1)
                                pointList.Add(BC.Points.P3);

                            xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                            if (xDim != null)
                                PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);

                            IsRightDim = true;
                        }
                    }

                }


                if (IsLeftDim)
                    BC.PC.DistLeft += BC.PC.DistInc;

                if (IsRightDim)
                    BC.PC.DistRight += BC.PC.DistInc;

                // Dim No 29, 29.1
                if (DN.DimIDNo29 || DN.DimIDNo29Dot1)
                {
                    if (BC.GPS.GPR != null)
                    {
                        Vect = new Vector(1, 0, 0);
                        pointList = new PointList();

                        if (DN.DimIDNo29) // Dim No 29
                            pointList.Add(BC.Points.P4);

                        pointList.Add(new Point(BC.Points.P4.X, BC.GPS.GPR.Points.P4.Y));

                        if (DN.DimIDNo29Dot1) // Dim No 29.1
                            pointList.Add(new Point(BC.Points.P4.X, BC.GPS.GPR.Points.P3.Y));

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByRightX(xDim, BC.PC);
                    }


                    if (BC.GPS.GPL != null)
                    {
                        Vect = new Vector(-1, 0, 0);
                        pointList = new PointList();

                        if (DN.DimIDNo29) // Dim No 29
                            pointList.Add(BC.Points.P1);

                        pointList.Add(new Point(BC.Points.P1.X, BC.GPS.GPR.Points.P1.Y));

                        if (DN.DimIDNo29Dot1) // Dim No 29.1
                            pointList.Add(new Point(BC.Points.P1.X, BC.GPS.GPR.Points.P2.Y));

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByLeftX(xDim, BC.PC);
                    }
                }


            }



        }

        private void TestDim()
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;

            Vector Vect = new Vector(0, 1, 0);

            TSD.PointList TempList = new PointList();

            if (BC.TopGP?.GussetPlate != null && BC.BottGP?.GussetPlate != null)
            {
                double Dist = CalcDistAngel(BC.BottGP.RB.RefPBrace, BC.BottGP.RB.IntPoint);
                Com.InsertAngleDim(CView, BC.BottGP.RB.RefPBrace, BC.BottGP.RB.IntPoint, "Bottom", Dist);

                Dist = CalcDistAngel(BC.BottGP.LB.RefPBrace, BC.BottGP.LB.IntPoint);
                Com.InsertAngleDim(CView, BC.BottGP.LB.RefPBrace, BC.BottGP.LB.IntPoint, "Bottom", Dist);


                Dist = CalcDistAngel(BC.TopGP.RB.RefPBrace, BC.TopGP.RB.IntPoint);
                Com.InsertAngleDim(CView, BC.TopGP.RB.RefPBrace, BC.TopGP.RB.IntPoint, "Top", Dist);

                Dist = CalcDistAngel(BC.TopGP.LB.RefPBrace, BC.TopGP.LB.IntPoint);
                Com.InsertAngleDim(CView, BC.TopGP.LB.RefPBrace, BC.TopGP.LB.IntPoint, "Top", Dist);

                Ids.Add(BC.TopGP.GussetPlate.Identifier.ID);
                Ids.Add(BC.BottGP.GussetPlate.Identifier.ID);
            }


        }

        #region Get Data

        private void GetBeamClassClass(TSD.View CView)
        {
            if (ViewName == "Top View" || ViewName == "Bottom View")
            {
                BC = new BeamClass_BG13();
                BC.beam = MainBeam;
                BC.Points = Com.GetPartPoints(BC.beam);
                List<TSM.Part> PartListC = BC.beam.GetAssembly().GetSecondaries().OfType<TSM.Part>().ToList();

                Point CentP = Com.CenterPoint(BC.beam.StartPoint, BC.beam.EndPoint);
                double Lenght = (BC.beam.GetSolid().MaximumPoint.X - BC.beam.GetSolid().MinimumPoint.X) / 10;
                double MinX = BC.beam.GetSolid().MinimumPoint.X + Lenght;
                double MaxX = BC.beam.GetSolid().MaximumPoint.X - Lenght;

                //List<TSM.Part> PartListF = (from p in PartListC where !Com.IsCode(p) select p).ToList();
                List<TSM.Part> PartListF = (from p in PartListC where !Ids.Contains(p.Identifier.ID) select p).ToList();
                ContourPlate TopGP = (from p in PartListF.OfType<ContourPlate>() where IsBG13(p) && (Com.CenterPoint(p).Y > BC.Points.CentP.Y) && !dc.IsPlateSideView(p) orderby Com.CenterPoint(p).X ascending select p).FirstOrDefault();
                ContourPlate BottGP = (from p in PartListF.OfType<ContourPlate>() where IsBG13(p) && (Com.CenterPoint(p).Y < BC.Points.CentP.Y) && !dc.IsPlateSideView(p) orderby Com.CenterPoint(p).X ascending select p).FirstOrDefault();


                if (TopGP != null)
                    BC.TopGP = GetGussetClass(TopGP, "Top");

                if (BottGP != null)
                    BC.BottGP = GetGussetClass(BottGP, "Bottom");

                PartListC.Add(MainBeam);
                TSM.Part LeftPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.X ascending select p).FirstOrDefault();
                TSM.Part RightPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.X descending select p).FirstOrDefault();
                TSM.Part TopPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.Y descending select p).FirstOrDefault();
                TSM.Part BottPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.Y ascending select p).FirstOrDefault();

                BC.PC = new PlacingClass();
                BC.PC.TopY = TopPart.GetSolid().MaximumPoint.Y;
                BC.PC.BottomY = BottPart.GetSolid().MinimumPoint.Y;

                BC.PC.LeftX = LeftPart.GetSolid().MinimumPoint.X;// Math.Round(CView.RestrictionBox.MinPoint.X);
                BC.PC.RightX = RightPart.GetSolid().MaximumPoint.X;

                double AvScale = 12;
                double AvDistInc = 100;
                double DistPerScale = AvDistInc / AvScale;
                double CScale = CView.Attributes.Scale;
                BC.PC.DistInc = CScale * DistPerScale;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;
            }

            else if (ViewName == "Front View")
            {
                BC = new BeamClass_BG13();
                BC.beam = MainBeam;
                List<TSM.Part> PartListC = BC.beam.GetAssembly().GetSecondaries().OfType<TSM.Part>().ToList();

                BC.Points = Com.GetPartPoints(BC.beam);

                Point CentP = Com.CenterPoint(BC.beam.StartPoint, BC.beam.EndPoint);
                double Lenght = (BC.beam.GetSolid().MaximumPoint.X - BC.beam.GetSolid().MinimumPoint.X) / 10;
                double MinX = BC.beam.GetSolid().MinimumPoint.X + Lenght;
                double MaxX = BC.beam.GetSolid().MaximumPoint.X - Lenght;

                //List<TSM.Part> PartListF = (from p in PartListC where !Com.IsCode(p) select p).ToList();
                List<TSM.Part> PartListF = (from p in PartListC where !Ids.Contains(p.Identifier.ID) select p).ToList();

                GetGussetClassFV(PartListF);

                PartListC.Add(MainBeam);
                TSM.Part LeftPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.X ascending select p).FirstOrDefault();
                TSM.Part RightPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.X descending select p).FirstOrDefault();
                TSM.Part TopPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.Y descending select p).FirstOrDefault();
                TSM.Part BottPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.Y ascending select p).FirstOrDefault();

                BC.PC = new PlacingClass();
                BC.PC.TopY = TopPart.GetSolid().MaximumPoint.Y;
                BC.PC.BottomY = BottPart.GetSolid().MinimumPoint.Y;

                BC.PC.LeftX = MainBeam.StartPoint.X;// Math.Round(CView.RestrictionBox.MinPoint.X);
                BC.PC.RightX = RightPart.GetSolid().MaximumPoint.X;

                double AvScale = 12;
                double AvDistInc = 100;
                double DistPerScale = AvDistInc / AvScale;
                double CScale = CView.Attributes.Scale;
                BC.PC.DistInc = CScale * DistPerScale;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;
            }

            else if (ViewName == "Section View")
            {
                BC = new BeamClass_BG13();
                BC.beam = MainBeam;
                BC.Points = Com.GetPartPoints(BC.beam);
                List<TSM.Part> PartListC = BC.beam.GetAssembly().GetSecondaries().OfType<TSM.Part>().ToList();
                PartListC = (from p in PartListC where !Ids.Contains(p.Identifier.ID) select p).ToList();
                double MinZ = CView.RestrictionBox.MinPoint.Z;

                double MaxZ = CView.RestrictionBox.MaxPoint.Z + 100;
                //List<TSM.Part> PartList = (from p in PartListC where Com.GetPartProfileType(p)!="L" && p.GetSolid().MaximumPoint.Z > MinZ && p.GetSolid().MaximumPoint.Z < MaxZ select p).ToList();
                List<TSM.Part> PartList = (from p in PartListC where Com.GetPartProfileType(p) != "L" && Com.IsViewObj(p, CView) select p).ToList();

                TSM.Part GPL = (from p in PartList where IsBG13(p) && Com.CenterPoint(p).X < BC.Points.CentP.X select p).FirstOrDefault();
                TSM.Part GPR = (from p in PartList where IsBG13(p) && Com.CenterPoint(p).X > BC.Points.CentP.X select p).FirstOrDefault();

                List<TSM.Part> LeftSt = (from p in PartList where !Com.HasBolt(p) && !dc.IsPlateSideViewN(p) && Com.CenterPoint(p).X < MainBeam.StartPoint.X orderby p.GetSolid().MinimumPoint.Y ascending select p).ToList();
                List<TSM.Part> RightSt = (from p in PartList where !Com.HasBolt(p) && !dc.IsPlateSideViewN(p) && Com.CenterPoint(p).X > MainBeam.StartPoint.X orderby p.GetSolid().MinimumPoint.Y ascending select p).ToList();

                if (GPL != null || GPR != null || LeftSt != null || RightSt != null)
                {
                    BC.GPS = new GussetClassS();

                    if (GPL != null)
                    {
                        BC.GPS.GPL = Com.GetPartClass(GPL);
                        Ids.Add(BC.GPS.GPL.part.Identifier.ID);
                    }

                    if (GPR != null)
                    {
                        BC.GPS.GPR = Com.GetPartClass(GPR);
                        Ids.Add(BC.GPS.GPR.part.Identifier.ID);
                    }

                    if (LeftSt != null && LeftSt.Count > 0)
                    {

                        if (LeftSt.Count == 1)
                        {
                            BC.GPS.StiffL = Com.GetPartClass(LeftSt[0]);
                            Ids.Add(BC.GPS.StiffL.part.Identifier.ID);
                        }
                        else
                        {
                            BC.GPS.StiffL = Com.GetPartClass(LeftSt[0]);
                            BC.GPS.StiffTL = Com.GetPartClass(LeftSt[1]);

                            Ids.Add(BC.GPS.StiffL.part.Identifier.ID);
                            Ids.Add(BC.GPS.StiffTL.part.Identifier.ID);
                        }
                    }


                    if (RightSt != null && RightSt.Count > 0)
                    {

                        if (RightSt.Count == 1)
                        {
                            BC.GPS.StiffR = Com.GetPartClass(RightSt[0]);
                            Ids.Add(BC.GPS.StiffR.part.Identifier.ID);
                        }
                        else
                        {
                            BC.GPS.StiffR = Com.GetPartClass(RightSt[0]);
                            BC.GPS.StiffTR = Com.GetPartClass(RightSt[1]);
                            Ids.Add(BC.GPS.StiffR.part.Identifier.ID);
                            Ids.Add(BC.GPS.StiffTR.part.Identifier.ID);
                        }
                    }


                }

                PartListC.Add(MainBeam);
                TSM.Part LeftPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.X ascending select p).FirstOrDefault();
                TSM.Part RightPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.X descending select p).FirstOrDefault();
                TSM.Part TopPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.Y descending select p).FirstOrDefault();
                TSM.Part BottPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.Y ascending select p).FirstOrDefault();

                BC.PC = new PlacingClass();
                BC.PC.TopY = TopPart.GetSolid().MaximumPoint.Y;
                BC.PC.BottomY = BottPart.GetSolid().MinimumPoint.Y;

                BC.PC.LeftX = MainBeam.StartPoint.X;// Math.Round(CView.RestrictionBox.MinPoint.X);
                BC.PC.RightX = RightPart.GetSolid().MaximumPoint.X;

                double AvScale = 12;
                double AvDistInc = 100;
                double DistPerScale = AvDistInc / AvScale;
                double CScale = CView.Attributes.Scale;
                BC.PC.DistInc = CScale * DistPerScale;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;
            }

        }

        private GussetClassB GetGussetClass(ContourPlate GP, string Position)
        {
            GussetClassB GC = new GussetClassB();
            GC.GussetPlate = GP;
            GC.Points = GetGussetPoints(GP);



            List<BoltGroup> Bolts = Com.EnumtoArray(GP.GetBolts()).OfType<BoltGroup>().ToList();

            BoltGroup MidBoltL = (from b in Bolts where Com.CenterPoint(b).X < GC.Points.CentP.X select b).FirstOrDefault();
            BoltGroup MidBoltR = (from b in Bolts where Com.CenterPoint(b).X > GC.Points.CentP.X select b).FirstOrDefault();

            List<BoltGroup> MidBoltsL = (from b in Bolts where Com.CenterPoint(b).X < GC.Points.CentP.X select b).ToList();
            List<BoltGroup> MidBoltsR = (from b in Bolts where Com.CenterPoint(b).X > GC.Points.CentP.X select b).ToList();

            if (MidBoltL != null)
            {

                BoltGroup MidBolt = MidBoltL;

                if (MidBolt != null)
                {
                    GC.LB = new GussetBrace();
                    GC.LB.BoltM = MidBolt;
                    GC.LB.BoltMP = Com.GetBoltPoints(MidBoltsL);

                    Beam brace = GetBrace(GC.LB.BoltM, GP);
                    if (brace != null)
                    {
                        GC.LB.Brace = brace;
                        GC.LB.RefPBrace = dc.NearestPoint(GC.LB.Brace.StartPoint, GC.LB.Brace.EndPoint, GC.LB.BoltM.FirstPosition);
                        GC.LB.IntPoint = GetIntSectPoint(GC.LB.BoltM, brace, Position);

                        double WebThickH = Com.GetPartWebThickness(MainBeam) / 2;
                        if (Position == "Top")
                        {
                            TSD.Line line1 = Com.DrawLineDotted1(CView, new Point(BC.Points.P1.X, BC.Points.CentP.Y + WebThickH), new Point(BC.Points.P4.X, BC.Points.CentP.Y + WebThickH));
                            TSD.Line line2 = Com.DrawLineDotted1(CView, GC.LB.RefPBrace, GC.LB.IntPoint);


                            if (GC.LB.RefPBrace != null && GC.LB.IntPoint != null)
                                GC.LB.IntPointB = Com.GetIntersectionPoint(GC.LB.RefPBrace, GC.LB.IntPoint, new Point(BC.Points.P1.X, BC.Points.CentP.Y + WebThickH), new Point(BC.Points.P4.X, BC.Points.CentP.Y + WebThickH));

                            GC.LB.Degree = GetDegree(GC.LB.IntPointB, GC.LB.IntPoint, BC.Points.P1);

                            line1.Delete();
                            line2.Delete();
                        }
                        else
                        {

                            TSD.Line line1 = Com.DrawLineDotted1(CView, new Point(BC.Points.P2.X, BC.Points.CentP.Y - WebThickH), new Point(BC.Points.P3.X, BC.Points.CentP.Y - WebThickH));
                            TSD.Line line2 = Com.DrawLineDotted1(CView, GC.LB.RefPBrace, GC.LB.IntPoint);

                            if (GC.LB.RefPBrace != null && GC.LB.IntPoint != null)
                                GC.LB.IntPointB = Com.GetIntersectionPoint(GC.LB.RefPBrace, GC.LB.IntPoint, new Point(BC.Points.P2.X, BC.Points.CentP.Y - WebThickH), new Point(BC.Points.P3.X, BC.Points.CentP.Y - WebThickH));


                            GC.LB.Degree = GetDegree(GC.LB.IntPointB, GC.LB.IntPoint, BC.Points.P2);

                            line1.Delete();
                            line2.Delete();
                        }



                    }
                }

            }


            if (MidBoltR != null)
            {
                BoltGroup MidBolt = MidBoltR;

                if (MidBolt != null)
                {
                    GC.RB = new GussetBrace();
                    GC.RB.BoltM = MidBolt;
                    GC.RB.BoltMP = Com.GetBoltPoints(MidBoltsR);
                    Beam brace = GetBrace(GC.RB.BoltM, GP);
                    double WebThickH = Com.GetPartWebThickness(MainBeam) / 2;
                    if (brace != null)
                    {
                        GC.RB.Brace = brace;
                        GC.RB.RefPBrace = dc.NearestPoint(GC.RB.Brace.StartPoint, GC.RB.Brace.EndPoint, MidBoltR.FirstPosition);
                        GC.RB.IntPoint = GetIntSectPoint(GC.RB.BoltM, brace, Position);
                        if (Position == "Top")
                        {
                            TSD.Line line1 = Com.DrawLineDotted1(CView, new Point(BC.Points.P1.X, BC.Points.CentP.Y + WebThickH), new Point(BC.Points.P4.X, BC.Points.CentP.Y + WebThickH));
                            TSD.Line line2 = Com.DrawLineDotted1(CView, GC.RB.RefPBrace, GC.RB.IntPoint);

                            if (GC.RB.RefPBrace != null && GC.RB.IntPoint != null)
                                GC.RB.IntPointB = Com.GetIntersectionPoint(GC.RB.RefPBrace, GC.RB.IntPoint, new Point(BC.Points.P1.X, BC.Points.CentP.Y + WebThickH), new Point(BC.Points.P4.X, BC.Points.CentP.Y + WebThickH));

                            GC.RB.Degree = GetDegree(GC.RB.IntPointB, GC.RB.IntPoint, BC.Points.P4);

                            line1.Delete();
                            line2.Delete();
                        }
                        else
                        {
                            TSD.Line line1 = Com.DrawLineDotted1(CView, new Point(BC.Points.P2.X, BC.Points.CentP.Y - WebThickH), new Point(BC.Points.P3.X, BC.Points.CentP.Y - WebThickH));
                            TSD.Line line2 = Com.DrawLineDotted1(CView, GC.RB.RefPBrace, GC.RB.IntPoint);

                            if (GC.RB.RefPBrace != null && GC.RB.IntPoint != null)
                                GC.RB.IntPointB = Com.GetIntersectionPoint(GC.RB.RefPBrace, GC.RB.IntPoint, new Point(BC.Points.P2.X, BC.Points.CentP.Y - WebThickH), new Point(BC.Points.P3.X, BC.Points.CentP.Y - WebThickH));

                            GC.RB.Degree = GetDegree(GC.RB.IntPointB, GC.RB.IntPoint, BC.Points.P3);

                            line1.Delete();
                            line2.Delete();
                        }
                    }
                }

            }

            return GC;
        }

        private void GetGussetClassFV(List<TSM.Part> PartListF)
        {
            List<TSM.Part> GussetPlates = (from p in PartListF where IsBG13(p) && (Com.CenterPoint(p).Y > BC.Points.P2.Y && Com.CenterPoint(p).Y < BC.Points.P1.Y) select p).ToList();
            List<TSM.Part> StiffList = (from p in PartListF where !Com.HasBolt(p) && Com.GetPartProfileType(p) != "L" && !IsBG13(p) && !dc.IsHorzObj(p) && (Com.CenterPoint(p).Y > BC.Points.P2.Y && Com.CenterPoint(p).Y < BC.Points.P1.Y) select p).ToList();
            if (GussetPlates != null && GussetPlates.Count > 0)
            {
                BC.GPTV = new GussetClassTV();
                BC.GPTV.GussetList = new List<PartClass>();
                foreach (TSM.Part part in GussetPlates)
                {
                    PartClass GussetClass = Com.GetPartClass(part);
                    BC.GPTV.GussetList.Add(GussetClass);
                }
            }

            if (StiffList != null && StiffList.Count > 0)
            {
                if (BC.GPTV == null)
                    BC.GPTV = new GussetClassTV();

                BC.GPTV.StiffList = Com.FilterStiff(StiffList);
                //foreach (TSM.Part stiff in StiffList)
                //{
                //    PartClass StiffClass = Com.GetPartClass(stiff);
                //    BC.GPTV.StiffList.Add(StiffClass);
                //}
            }

        }

        private Beam GetBrace(BoltGroup BoltL, TSM.Part GP)
        {

            Beam brace = (from b in Com.GetBoltParts(BoltL).OfType<TSM.Beam>() where b.Identifier.ID != GP.Identifier.ID && (b.Name.ToLower().Contains("brace") || (dc.IsMainPart(b) && !dc.IsPlate(b))) select b).FirstOrDefault();
            if (brace == null)
            {
                List<TSM.Part> PartList = (from b in Com.GetBoltParts(BoltL).OfType<TSM.Part>() where b.Identifier.ID != GP.Identifier.ID select b).ToList();

                foreach (TSM.Part part in PartList)
                {

                    BoltGroup bolt2 = Com.EnumtoArray(part.GetBolts()).OfType<BoltGroup>().Where(x => x.Identifier.ID != BoltL.Identifier.ID).FirstOrDefault();
                    if (bolt2 != null)
                    {
                        brace = (from b in Com.GetBoltParts(bolt2).OfType<TSM.Beam>() where b.Identifier.ID != GP.Identifier.ID && (b.Name.ToLower().Contains("brace") || (dc.IsMainPart(b) && !dc.IsPlate(b))) select b).FirstOrDefault();
                    }

                }

                if (brace == null)
                {
                    foreach (TSM.Part part in PartList)
                    {
                        if (dc.IsMainPart(part) && dc.IsPlate(part))
                        {

                            List<TSM.Part> PartLists = Com.EnumtoArray(part.GetWelds()).OfType<TSM.Weld>().Select(x => x.MainObject).OfType<TSM.Part>().ToList();
                            PartLists.AddRange(Com.EnumtoArray(part.GetWelds()).OfType<TSM.Weld>().Select(x => x.SecondaryObject).OfType<TSM.Part>().ToList());

                            brace = (from b in PartLists.OfType<Beam>() where IsBrace(b) select b).FirstOrDefault();
                            if (brace == null)
                            {
                                PartLists = (from b in PartLists where !dc.IsMainPart(b) select b.GetAssembly().GetMainPart()).OfType<TSM.Part>().ToList();
                                brace = (from b in PartLists.OfType<Beam>() where IsBrace(b) select b).FirstOrDefault();
                                if (brace != null)
                                    break;
                            }


                        }

                    }
                }

                if (brace == null)
                {
                    foreach (TSM.Part part in PartList)
                    {
                        if (dc.IsMainPart(part) && dc.IsPlate(part))
                        {

                            List<BoltGroup> BoltsList = Com.EnumtoArray(part.GetBolts()).OfType<TSM.BoltGroup>().ToList();
                            if (BoltsList != null && BoltsList.Count > 0)
                            {
                                List<TSM.Part> PartLists = new List<TSM.Part>();

                                BoltsList.ForEach(x => PartLists.AddRange(Com.GetBoltParts(x)));

                                brace = (from b in PartLists.OfType<Beam>() where IsBrace(b) select b).FirstOrDefault();
                                if (brace == null)
                                {
                                    PartLists = (from b in PartLists where !dc.IsMainPart(b) select b.GetAssembly().GetMainPart()).OfType<TSM.Part>().ToList();
                                    brace = (from b in PartLists.OfType<Beam>() where IsBrace(b) select b).FirstOrDefault();
                                    if (brace != null)
                                        break;
                                }
                            }


                        }

                    }
                }
            }

            return brace;

        }

        private PartPoints GetGussetPoints(ContourPlate GP)
        {
            PartPoints RetP = new PartPoints();
            PointList pointList = Com.ContPList(GP);
            RetP.CentP = Com.CenterPoint(GP);

            List<ContourPoint> ContPlist = GP.Contour.ContourPoints.OfType<ContourPoint>().Where(x => x.Chamfer != null && x.Chamfer.Type == Chamfer.ChamferTypeEnum.CHAMFER_ARC).ToList();

            if (RetP.CentP.Y > BC.Points.CentP.Y)
            {

                RetP.P1 = (from p in pointList.OfType<Point>() where p.X < RetP.CentP.X orderby p.Y descending select p).FirstOrDefault();
                RetP.P2 = (from p in pointList.OfType<Point>() where p.X < RetP.CentP.X orderby p.Y ascending select p).FirstOrDefault();
                RetP.P6 = (from p in pointList.OfType<Point>() where p.X < RetP.CentP.X && p.Y > RetP.P2.Y orderby p.Y ascending select p).FirstOrDefault();

                RetP.P4 = (from p in pointList.OfType<Point>() where p.X > RetP.CentP.X orderby p.Y descending select p).FirstOrDefault();
                RetP.P3 = (from p in pointList.OfType<Point>() where p.X > RetP.CentP.X orderby p.Y ascending select p).FirstOrDefault();
                RetP.P5 = (from p in pointList.OfType<Point>() where p.X > RetP.CentP.X && p.Y > RetP.P2.Y orderby p.Y ascending select p).FirstOrDefault();


                if (ContPlist != null && ContPlist.Count > 0)
                {
                    ContourPoint P1 = (from p in ContPlist where Com.IsEqual(p.X, RetP.P2.X) && Com.IsEqual(p.Y, RetP.P2.Y) select p).FirstOrDefault();
                    ContourPoint P2 = (from p in ContPlist where Com.IsEqual(p.X, RetP.P3.X) && Com.IsEqual(p.Y, RetP.P3.Y) select p).FirstOrDefault();

                    if (P1 != null || P2 != null)
                    {
                        BC.ContPT = new ContPClass();

                        if (P1 != null)
                            BC.ContPT.P1 = P1;

                        if (P2 != null)
                            BC.ContPT.P2 = P2;
                    }
                }

            }
            else
            {

                RetP.P1 = (from p in pointList.OfType<Point>() where p.X < RetP.CentP.X orderby p.Y ascending select p).FirstOrDefault();
                RetP.P2 = (from p in pointList.OfType<Point>() where p.X < RetP.CentP.X orderby p.Y descending select p).FirstOrDefault();
                RetP.P6 = (from p in pointList.OfType<Point>() where p.X < RetP.CentP.X && p.Y < RetP.P2.Y orderby p.Y descending select p).FirstOrDefault();

                RetP.P4 = (from p in pointList.OfType<Point>() where p.X > RetP.CentP.X orderby p.Y ascending select p).FirstOrDefault();
                RetP.P3 = (from p in pointList.OfType<Point>() where p.X > RetP.CentP.X orderby p.Y descending select p).FirstOrDefault();
                RetP.P5 = (from p in pointList.OfType<Point>() where p.X > RetP.CentP.X && p.Y < RetP.P2.Y orderby p.Y descending select p).FirstOrDefault();


                if (ContPlist != null && ContPlist.Count > 0)
                {
                    ContourPoint P1 = (from p in ContPlist where Com.IsEqual(p.X, RetP.P2.X) && Com.IsEqual(p.Y, RetP.P2.Y) select p).FirstOrDefault();
                    ContourPoint P2 = (from p in ContPlist where Com.IsEqual(p.X, RetP.P3.X) && Com.IsEqual(p.Y, RetP.P3.Y) select p).FirstOrDefault();

                    if (P1 != null || P2 != null)
                    {
                        BC.ContPB = new ContPClass();

                        if (P1 != null)
                            BC.ContPB.P1 = P1;

                        if (P2 != null)
                            BC.ContPB.P2 = P2;
                    }
                }


            }


            return RetP;
        }

        #endregion

        #region Helping Methods

        private double GetDegree(Point P1, Point P2, Point P3)
        {
            double degree = 0;
            try
            {

                AngleDimension angDimA = new AngleDimension(CView, P1, P2, P3, 50);
                degree = angDimA.GetAngle();
            }
            catch (Exception ex)
            { }
            return degree;
        }

        private bool IsBrace(Beam b)
        {
            bool RetCheck = false;
            if (b.Name.ToLower().Contains("brace") || (dc.IsMainPart(b) && !dc.IsPlate(b)))
            {
                if ((b.StartPoint.Y < BC.Points.P1.Y && b.StartPoint.Y > BC.Points.P2.Y) || (b.EndPoint.Y < BC.Points.P1.Y && b.EndPoint.Y > BC.Points.P2.Y))
                    RetCheck = true;
            }

            return RetCheck;
        }

        private Point GetIntSectPoint(BoltGroup bolt, Beam brace, string Position)
        {
            Vector Vect = bolt.GetCoordinateSystem().AxisX;
            PointList PtList = new PointList();
            Point IntSectP = null;
            if (Position == "Top")
            {
                if (Vect.Y > 0)
                    Vect = Com.ChangeVector(Vect);
            }
            else
            {
                if (Vect.Y < 0)
                    Vect = Com.ChangeVector(Vect);
            }

            PtList = dc.ChangePints(bolt, CView, Vect);
            if (PtList.Count > 1)
                IntSectP = Com.GetIntersectionPoint(PtList[0], PtList[1], brace.StartPoint, brace.EndPoint);
            else if (PtList.Count == 1)
                IntSectP = PtList[0];

            return IntSectP;

        }

        private bool IsBG13(TSM.Part part)
        {
            if (Com.GetNote5(part).ToUpper().Contains("BG13"))
                return true;
            else
                return false;
        }
        #endregion


        private class ContPClass
        {
            public ContourPoint P1 { get; set; }
            public ContourPoint P2 { get; set; }
        }

        private class GussetClassTV
        {
            public List<PartClass> GussetList { get; set; }
            public List<PartClass> StiffList { get; set; }

        }

        private class GussetClassS
        {
            public PartClass GPL { get; set; }
            public PartClass GPR { get; set; }
            public PartClass StiffL { get; set; }
            public PartClass StiffR { get; set; }
            public PartClass StiffTL { get; set; }
            public PartClass StiffTR { get; set; }

        }

        private class BeamClass_BG13
        {
            public Beam beam { get; set; }
            public GussetClassB TopGP { get; set; }
            public GussetClassB BottGP { get; set; }
            public PartPoints Points { get; set; }
            public PlacingClass PC { get; set; }
            public GussetClassTV GPTV { get; set; }
            public GussetClassS GPS { get; set; }

            public ContPClass ContPT { get; set; }
            public ContPClass ContPB { get; set; }
        }

    }




}
