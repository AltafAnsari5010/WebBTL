﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Tekla.Structures;
using Tekla.Structures.Drawing;
using Tekla.Structures.Geometry3d;
using Tekla.Structures.Model;
using TSD = Tekla.Structures.Drawing;
using TSM = Tekla.Structures.Model;
using VirtueleDrawingAutomation;
using TSDD = Tekla.Structures.Datatype;
using TSG = Tekla.Structures.Geometry3d;

namespace Auto_Detailing_Tool_Beam
{
    public class BeamDim_BCR1
    {
        #region Global Variables
        DimCom dc = new DimCom();
        StraightDimensionSet.StraightDimensionSetAttributes StAtrr = new StraightDimensionSet.StraightDimensionSetAttributes("standard");
        StraightDimensionSet.StraightDimensionSetAttributes RdAtrr = new StraightDimensionSet.StraightDimensionSetAttributes("standard");

        public Beam MainBeam = null;
        VirtueleDrawingAutomation.Json.DrawingAttributeInfoJson.AttributeFiles dimAttrClass = null;
        List<TSD.StraightDimension> KnockDim = new List<StraightDimension>();
        BeamClass_BCR1 BC = null;

        VirtueleDrawingAutomation.Json.AutoDimensionTypesJson.BCR1Json DN = null;
        string Position = "Left";
        TSD.View CView = null;
        string ViewName = "";
        public Point BoltPS = null;

        #endregion

        public void ApplyDim(TSD.View CView, string ViewName, AutoDimensioningTypes autoDimensioningTypes, DrawingAttributeInfo drawingAttributeInfo, string Position)
        {
            try
            {
                Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane());
                //Set model everything to the view
                Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane(CView.DisplayCoordinateSystem));

                this.CView = CView;
                this.dimAttrClass = drawingAttributeInfo.dimensioningAttributes.Dimension.Attribute_files;
                this.DN = autoDimensioningTypes.Bcr1;
                this.Position = Position;
                StAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.StandardDimension);
                RdAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.RunningDimension);
                this.MainBeam = (Com.MyModel.SelectModelObject(new Identifier((CView.GetDrawing() as AssemblyDrawing).AssemblyIdentifier.ID)) as TSM.Assembly).GetMainPart() as TSM.Beam;
                this.MainBeam.Select();
                string ProType = Com.GetProType(MainBeam);
                this.ViewName = ViewName;
                GetBeamClassClass(CView);

                if (Position == "Left")
                {
                    if (ViewName == "Front View")
                        ApplyDimTypeLeft(CView);
                    else
                    if (ViewName == "Section View")
                        AppySectionDim();
                }

                else if (Position == "Right")
                {
                    if (ViewName == "Front View")
                        ApplyDimTypeRight(CView);
                    else
                    if (ViewName == "Section View")
                        AppySectionDim();
                }

            }
            catch (Exception ex)
            { }

            Com.MyModel.GetWorkPlaneHandler().SetCurrentTransformationPlane(new TransformationPlane());
        }

        private void ApplyDimTypeLeft(TSD.View CView)
        {

            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(-1, 0, 0);
            TSD.PointList TempList = new PointList();

            if (BC.CutTop != null)
            {
                Vect = new Vector(-1, 0, 0);
                // Dim No 5
                if (DN.DimIDNo5)
                {
                    pointList = new PointList();
                    pointList.Add(BC.CutTop.P1);
                    pointList.Add(BC.CutTop.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                }

                Vect = new Vector(0, 1, 0);
                // Dim No 6, 1
                if (DN.DimIDNo6 || DN.DimIDNo1)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo1 && BC.Angle != null)
                        pointList.Add(BC.Angle.Points.P1);
                    pointList.Add(BC.CutTop.P1);
                    if (DN.DimIDNo6)
                        pointList.Add(BC.CutTop.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                }

            }

            if (BC.CutBott != null)
            {
                Vect = new Vector(-1, 0, 0);
                // Dim No 7
                if (DN.DimIDNo7)
                {
                    pointList = new PointList();
                    pointList.Add(BC.CutBott.P1);
                    pointList.Add(BC.CutBott.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                }

                Vect = new Vector(0, -1, 0);
                // Dim No 8
                if (DN.DimIDNo8)
                {
                    pointList = new PointList();
                    pointList.Add(BC.CutBott.P1);
                    pointList.Add(BC.CutBott.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                }

            }

            //if (DN.DimIDNo4 || BC.CutBott != null || BC.CutTop != null)
            //    BC.PC.DistLeft += BC.PC.DistInc;

            if (DN.DimIDNo8 || BC.CutBott != null)
                BC.PC.DistBot += BC.PC.DistInc;

            if (DN.DimIDNo6 || BC.CutTop != null)
                BC.PC.DistTop += BC.PC.DistInc;

            Vect = new Vector(-1, 0, 0);
            if (BC.BoltsE != null)
            {
                BC.PC.DistLeft = (BC.PC.DistInc * 2);
                // Dim No 2.2
                if (DN.DimIDNo2 || DN.DimIDNo3)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo2)
                    {
                        pointList.Add(BC.Points.P5);
                        pointList.Add(Com.MaxPofX(BC.BoltsE, "Y", Com.MaxP(BC.BoltsE, "X").X));
                    }

                    if (DN.DimIDNo3)
                        pointList.AddRange(BC.BoltsE);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                }

                // Dim No 3.1
                if (DN.DimIDNo3Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinPofX(BC.BoltsE, "Y", Com.MaxP(BC.BoltsE, "X").X));
                    pointList.Add(BC.Angle.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                }

                if (DN.DimIDNo2 || DN.DimIDNo3 || DN.DimIDNo3Dot1)
                    BC.PC.DistLeft += BC.PC.DistInc;



                // Dim No 3.2
                if (DN.DimIDNo3Dot2)
                {
                    if (BC.BoltsE.Count > 2)
                    {
                        pointList = new PointList();
                        pointList.AddRange(BC.BoltsE);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                        {
                            PL.DimPlaceByLeftX(xDim, BC.PC);
                            Com.GroupDim(xDim);
                        }
                    }
                }



                if (BC.IsFrontBolt)
                {
                    Vect = new Vector(0, 1, 0);
                    // Dim No 28.1
                    if (DN.DimIDNo28Dot1)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.Points.P1);
                        pointList.Add(Com.MinP(BC.BoltsE, "Y"));
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, RdAtrr);
                        if (xDim != null)
                            PL.DimPlaceByTopY(xDim, BC.PC);
                    }

                    Vect = new Vector(0, -1, 0);

                    // Dim No 26, 27
                    if (DN.DimIDNo26 || DN.DimIDNo27)
                    {
                        pointList = new PointList();
                        if (DN.DimIDNo26)
                            pointList.Add(BC.Angle.Points.P2);
                        pointList.Add(Com.MaxP(BC.BoltsE, "Y"));
                        if (DN.DimIDNo27)
                            pointList.Add(BC.Angle.Points.P3);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByBottomY(xDim, BC.PC);
                    }

                    // Dim No 28
                    if (DN.DimIDNo28)
                    {
                        BC.PC.DistBot += BC.PC.DistInc;
                        pointList = new PointList();
                        pointList.Add(BC.Points.P2);
                        pointList.Add(Com.MaxP(BC.BoltsE, "Y"));
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                        if (xDim != null)
                            PL.DimPlaceByBottomY(xDim, BC.PC);
                    }

                }

                Vect = new Vector(0, 1, 0);
                // Dim No 4
                if (DN.DimIDNo4)
                {
                    pointList = new PointList();
                    pointList.Add(new Point(BC.Angle.Points.P1.X, BC.Angle.Points.CentP.Y));
                    pointList.Add(new Point(BC.Angle.Points.P4.X, BC.Angle.Points.CentP.Y));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistInc, StAtrr);

                }


            }


            if (BC.DPT != null)
            {
                // Dim No 5.1
                if (DN.DimIDNo5Dot1)
                {
                    Vect = new Vector(-1, 0, 0);
                    pointList = new PointList();

                    pointList.Add(BC.Points.P1);
                    pointList.Add(BC.DPT.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                }

                // Dim No 16, 16.1
                if (DN.DimIDNo16 || DN.DimIDNo16Dot1)
                {
                    Vect = new Vector(1, 0, 0);
                    pointList = new PointList();
                    if (DN.DimIDNo16)
                        pointList.Add(new Point(BC.DPT.Points.P4.X, BC.Points.P5.Y));

                    pointList.Add(BC.DPT.Points.P4);

                    if (DN.DimIDNo16Dot1)
                        pointList.Add(BC.DPT.Points.P3);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceRightP(xDim, BC.DPT.Points.P4.X, BC.PC.DistRight);
                        BC.PC.DistRight += BC.PC.DistInc;
                    }
                }

                // Dim No 15
                if (DN.DimIDNo15)
                {
                    Vect = new Vector(0, 1, 0);
                    pointList = new PointList();
                    pointList.Add(BC.DPT.Points.P1);
                    pointList.Add(BC.DPT.Points.P4);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }
            }


            if (BC.DPB != null)
            {
                // Dim No 7.1
                if (DN.DimIDNo7Dot1)
                {
                    Vect = new Vector(-1, 0, 0);
                    pointList = new PointList();
                    pointList.Add(BC.Points.P2);
                    pointList.Add(BC.DPB.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                }

                // Dim No 17, 17.1
                if (DN.DimIDNo17 || DN.DimIDNo17Dot1)
                {
                    Vect = new Vector(1, 0, 0);
                    pointList = new PointList();
                    if (DN.DimIDNo17)
                        pointList.Add(new Point(BC.DPB.Points.P4.X, BC.Points.P5.Y));

                    pointList.Add(BC.DPB.Points.P4);

                    if (DN.DimIDNo17Dot1)
                        pointList.Add(BC.DPB.Points.P3);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.DPB.Points.P4.X, BC.PC.DistRight);
                }

                // Dim No 15
                if (DN.DimIDNo15)
                {
                    Vect = new Vector(0, -1, 0);
                    pointList = new PointList();
                    pointList.Add(BC.DPB.Points.P2);
                    pointList.Add(BC.DPB.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }
            }



            // Dim No 10 Elevation Dim
            if (DN.DimIDNo10)
            {

                Vect = new Vector(-1, 0, 0);
                StraightDimensionSet.StraightDimensionSetAttributes ElAtrr = new StraightDimensionSet.StraightDimensionSetAttributes(dimAttrClass.ElevationDimension);
                ElAtrr.DimensionType = DimensionSetBaseAttributes.DimensionTypes.Elevation;
                ElAtrr.Arrowhead.Head = ArrowheadTypes.FilledArrow;
                pointList = new PointList();

                if (MainBeam.StartPoint.X > MainBeam.EndPoint.X)
                {
                    pointList.Add(MainBeam.EndPoint);
                    pointList.Add(MainBeam.EndPoint);

                }
                else
                {
                    pointList.Add(MainBeam.StartPoint);
                    pointList.Add(MainBeam.StartPoint);
                }

                BC.PC.DistLeft = BC.PC.DistLeft - (BC.Points.P1.X - pointList[0].X);
                xDim = dc.InsertDimm(CView, pointList, Vect, (-BC.PC.DistLeft), ElAtrr);
                if (xDim != null)
                {
                    xDim.Distance = (-BC.PC.DistLeft);
                    xDim.Modify();
                }
                BC.PC.DistLeft += BC.PC.DistInc;

            }

        }

        private void ApplyDimTypeRight(TSD.View CView)
        {
            TSD.PointList pointList = new PointList();
            StraightDimensionSet xDim = null;
            Vector Vect = new Vector(1, 0, 0);
            TSD.PointList TempList = new PointList();

            if (BC.CutTop != null)
            {
                Vect = new Vector(1, 0, 0);
                // Dim No 5
                if (DN.DimIDNo5)
                {
                    pointList = new PointList();
                    pointList.Add(BC.CutTop.P1);
                    pointList.Add(BC.CutTop.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                }

                Vect = new Vector(0, 1, 0);
                // Dim No 6, 1
                if (DN.DimIDNo6 || DN.DimIDNo1)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo1 && BC.Angle != null)
                        pointList.Add(BC.Angle.Points.P4);
                    pointList.Add(BC.CutTop.P1);
                    if (DN.DimIDNo6)
                        pointList.Add(BC.CutTop.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                }

            }
            else
            {

                Vect = new Vector(0, 1, 0);
                // Dim No 1
                if (DN.DimIDNo1)
                {
                    pointList = new PointList();
                    pointList.Add(BC.Points.P4);
                    pointList.Add(BC.Angle.Points.P4);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                }
            }

            if (BC.CutBott != null)
            {
                Vect = new Vector(1, 0, 0);
                // Dim No 7
                if (DN.DimIDNo7)
                {
                    pointList = new PointList();
                    pointList.Add(BC.CutBott.P1);
                    pointList.Add(BC.CutBott.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                }

                Vect = new Vector(0, -1, 0);
                // Dim No 8
                if (DN.DimIDNo8)
                {
                    pointList = new PointList();
                    pointList.Add(BC.CutBott.P1);
                    pointList.Add(BC.CutBott.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                }

            }

            //if (DN.DimIDNo4 || BC.CutBott != null || BC.CutTop != null)
            //    BC.PC.DistLeft += BC.PC.DistInc;

            if (DN.DimIDNo8 || BC.CutBott != null)
                BC.PC.DistBot += BC.PC.DistInc;

            if (DN.DimIDNo6 || BC.CutTop != null)
                BC.PC.DistTop += BC.PC.DistInc;

            Vect = new Vector(1, 0, 0);
            if (BC.BoltsE != null)
            {
                BC.PC.DistRight = (BC.PC.DistInc * 2);
                // Dim No 2.2
                if (DN.DimIDNo2 || DN.DimIDNo3)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo2)
                    {
                        pointList.Add(BC.Points.P8);
                        pointList.Add(Com.MaxPofX(BC.BoltsE, "Y", Com.MinP(BC.BoltsE, "X").X));
                    }

                    if (DN.DimIDNo3)
                        pointList.AddRange(BC.BoltsE);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                }

                // Dim No 3.1
                if (DN.DimIDNo3Dot1)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinPofX(BC.BoltsE, "Y", Com.MinP(BC.BoltsE, "X").X));
                    pointList.Add(BC.Angle.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                }

                if (DN.DimIDNo2 || DN.DimIDNo3 || DN.DimIDNo3Dot1)
                    BC.PC.DistRight += BC.PC.DistInc;



                // Dim No 3.2
                if (DN.DimIDNo3Dot2)
                {
                    if (BC.BoltsE.Count > 2)
                    {
                        pointList = new PointList();
                        pointList.AddRange(BC.BoltsE);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                        {
                            PL.DimPlaceByRightX(xDim, BC.PC);
                            Com.GroupDim(xDim);
                        }
                    }
                }

                if (BC.IsFrontBolt)
                {
                    Vect = new Vector(0, 1, 0);
                    // Dim No 28.1
                    if (DN.DimIDNo28Dot1)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.Points.P1);
                        pointList.Add(Com.MinP(BC.BoltsE, "Y"));
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, RdAtrr);
                        if (xDim != null)
                            PL.DimPlaceByTopY(xDim, BC.PC);
                    }

                    Vect = new Vector(0, -1, 0);

                    // Dim No 26, 27
                    if (DN.DimIDNo26 || DN.DimIDNo27)
                    {
                        pointList = new PointList();
                        if (DN.DimIDNo26)
                            pointList.Add(BC.Angle.Points.P3);
                        pointList.Add(Com.MaxP(BC.BoltsE, "Y"));
                        if (DN.DimIDNo27)
                            pointList.Add(BC.Angle.Points.P2);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByBottomY(xDim, BC.PC);
                    }

                    // Dim No 28
                    if (DN.DimIDNo28)
                    {
                        BC.PC.DistBot += BC.PC.DistInc;
                        pointList = new PointList();
                        pointList.Add(BC.Points.P2);
                        pointList.Add(Com.MaxP(BC.BoltsE, "Y"));
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                        if (xDim != null)
                            PL.DimPlaceByBottomY(xDim, BC.PC);
                    }

                }



                Vect = new Vector(0, 1, 0);
                // Dim No 4
                if (DN.DimIDNo4)
                {
                    pointList = new PointList();
                    pointList.Add(new Point(BC.Angle.Points.P1.X, BC.Angle.Points.CentP.Y));
                    pointList.Add(new Point(BC.Angle.Points.P4.X, BC.Angle.Points.CentP.Y));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistInc, StAtrr);

                }


            }



            if (BC.DPT != null)
            {
                // Dim No 5.1
                if (DN.DimIDNo5Dot1)
                {
                    Vect = new Vector(1, 0, 0);
                    pointList = new PointList();

                    pointList.Add(BC.Points.P4);
                    pointList.Add(BC.DPT.Points.P4);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                }

                // Dim No 16, 16.1
                if (DN.DimIDNo16 || DN.DimIDNo16Dot1)
                {
                    Vect = new Vector(-1, 0, 0);
                    pointList = new PointList();
                    if (DN.DimIDNo16)
                        pointList.Add(new Point(BC.DPT.Points.P1.X, BC.Points.P5.Y));

                    pointList.Add(BC.DPT.Points.P1);

                    if (DN.DimIDNo16Dot1)
                        pointList.Add(BC.DPT.Points.P2);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceLeftP(xDim, BC.DPT.Points.P1.X, BC.PC.DistLeft);
                        BC.PC.DistLeft += BC.PC.DistInc;
                    }
                }

                // Dim No 15
                if (DN.DimIDNo15)
                {
                    Vect = new Vector(0, 1, 0);
                    pointList = new PointList();
                    pointList.Add(BC.DPT.Points.P1);
                    pointList.Add(BC.DPT.Points.P4);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }

                // Dim No 24 RD Dim
                if (DN.DimIDNo24 || DN.DimIDNo24Dot1)
                {
                    Vect = new Vector(0, 1, 0);
                    pointList = new PointList();
                    pointList.Add(BC.Points.P1);
                    pointList.Add(BC.DPT.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                        BC.PC.DistTop += BC.PC.DistInc;
                    }
                }
            }


            if (BC.DPB != null)
            {
                // Dim No 7.1
                if (DN.DimIDNo7Dot1)
                {
                    Vect = new Vector(1, 0, 0);
                    pointList = new PointList();
                    pointList.Add(BC.Points.P3);
                    pointList.Add(BC.DPB.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                }

                // Dim No 17, 17.1
                if (DN.DimIDNo17 || DN.DimIDNo17Dot1)
                {
                    Vect = new Vector(-1, 0, 0);
                    pointList = new PointList();
                    if (DN.DimIDNo17)
                        pointList.Add(new Point(BC.DPB.Points.P1.X, BC.Points.P5.Y));

                    pointList.Add(BC.DPB.Points.P1);

                    if (DN.DimIDNo17Dot1)
                        pointList.Add(BC.DPB.Points.P2);

                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.DPB.Points.P1.X, BC.PC.DistLeft);
                }

                // Dim No 15
                if (DN.DimIDNo15)
                {
                    Vect = new Vector(0, -1, 0);
                    pointList = new PointList();
                    pointList.Add(BC.DPB.Points.P2);
                    pointList.Add(BC.DPB.Points.P3);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, StAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }


                // Dim No 24 RD Dim
                if (DN.DimIDNo24 || DN.DimIDNo24Dot1)
                {
                    Vect = new Vector(0, -1, 0);
                    pointList = new PointList();
                    pointList.Add(BC.Points.P2);
                    pointList.Add(BC.DPB.Points.P2);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistBot, RdAtrr);
                    if (xDim != null)
                    {
                        PL.DistPlaceBottP(xDim, BC.PC.BottomY, BC.PC.DistBot);
                        BC.PC.DistBot += BC.PC.DistInc;
                    }
                }
            }




        }

        private void AppySectionDim()
        {
            StraightDimensionSet xDim = null;
            PointList pointList = new PointList();
            Vector Vect = new Vector(0, 1, 0);
            PointList TempList = new PointList();

            // Section C
            if (BC.SCL != null && (BC.SCL.Angle == null && BC.SCR.Angle == null))
            {

                #region Top Dim
                PartClass PCL = null;
                PartClass PCR = null;

                if (BC.SCL.DPT != null)
                    PCL = BC.SCL.DPT;
                if (BC.SCL.DPB != null)
                    PCL = BC.SCL.DPB;

                if (BC.SCR?.DPT != null)
                    PCR = BC.SCR.DPT;
                if (BC.SCR?.DPB != null)
                    PCR = BC.SCR.DPB;


                Vect = new Vector(0, 1, 0);
                // Dim No 21, 21.1
                if ((DN.DimIDNo21 || DN.DimIDNo21Dot1) && PCL != null)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo21)
                        pointList.Add(PCL.Points.P1);
                    pointList.Add(PCL.Points.P4);
                    if (DN.DimIDNo21Dot1)
                        pointList.Add(MainBeam.StartPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);
                }

                // Dim No 21, 21.1
                if ((DN.DimIDNo21 || DN.DimIDNo21Dot1) && PCR != null)
                {
                    pointList = new PointList();
                    if (DN.DimIDNo21)
                        pointList.Add(PCR.Points.P4);
                    pointList.Add(PCR.Points.P1);
                    if (DN.DimIDNo21Dot1)
                        pointList.Add(MainBeam.StartPoint);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);
                }

                // Dim No 22
                if (DN.DimIDNo22 && PCL != null)
                {
                    pointList = new PointList();
                    pointList.Add(MainBeam.StartPoint);
                    pointList.Add(PCL.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                }

                // Dim No 22
                if (DN.DimIDNo22 && PCR != null)
                {
                    pointList = new PointList();
                    pointList.Add(MainBeam.StartPoint);
                    pointList.Add(PCR.Points.P4);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceTopP(xDim, BC.PC.TopY, BC.PC.DistTop);
                }


                #endregion

                #region Left Dim
                Vect = new Vector(-1, 0, 0);
                if (BC.SCL.DPT != null)
                {
                    BC.PC.DistLeft = BC.PC.DistInc;
                    if (DN.DimIDNo23)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.SCL.DPT.Points.P1);
                        pointList.Add(BC.SCL.DPT.Points.P2);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByLeftX(xDim, BC.PC);
                    }

                    if (DN.DimIDNo19)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.SCL.DPT.Points.P1);
                        pointList.Add(BC.Points.P1);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                    }
                }


                if (BC.SCL.DPB != null)
                {
                    BC.PC.DistLeft = BC.PC.DistInc;
                    if (DN.DimIDNo23)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.SCL.DPB.Points.P2);
                        pointList.Add(BC.SCL.DPB.Points.P1);

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByLeftX(xDim, BC.PC);
                    }

                    if (DN.DimIDNo19Dot1)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.SCL.DPB.Points.P1);
                        pointList.Add(BC.Points.P2);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                    }
                }


                if (BC.SCL.DPB != null && BC.SCL.DPT != null && DN.DimIDNo20)
                {
                    pointList = new PointList();
                    pointList.Add(BC.SCL.DPB.Points.P1);
                    pointList.Add(BC.SCL.DPT.Points.P1);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                }

                #endregion

                #region Right Dim
                Vect = new Vector(1, 0, 0);
                if (BC.SCR?.DPT != null)
                {
                    BC.PC.DistRight = BC.PC.DistInc;
                    if (DN.DimIDNo23)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.SCR.DPT.Points.P4);
                        pointList.Add(BC.SCR.DPT.Points.P3);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByRightX(xDim, BC.PC);
                    }

                    if (DN.DimIDNo19)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.SCR.DPT.Points.P4);
                        pointList.Add(BC.Points.P4);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                    }
                }


                if (BC.SCR?.DPB != null)
                {
                    BC.PC.DistRight = BC.PC.DistInc;
                    if (DN.DimIDNo23)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.SCR.DPB.Points.P3);
                        pointList.Add(BC.SCR.DPB.Points.P4);

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByRightX(xDim, BC.PC);
                    }

                    if (DN.DimIDNo19Dot1)
                    {
                        pointList = new PointList();
                        pointList.Add(BC.SCR.DPB.Points.P4);
                        pointList.Add(BC.Points.P3);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                    }
                }


                if (BC.SCR?.DPB != null && BC.SCR?.DPT != null && DN.DimIDNo20)
                {
                    pointList = new PointList();
                    pointList.Add(BC.SCR.DPB.Points.P4);
                    pointList.Add(BC.SCR.DPT.Points.P4);
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                    if (xDim != null)
                        PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                }

                #endregion
            }
            else if ((BC.SCL != null && BC.SCL.Angle != null) || (BC.SCR != null && BC.SCR.Angle != null))
            {
                BC.PC.DistLeft = (BC.PC.DistInc * 1.25);
                BC.PC.DistRight = (BC.PC.DistInc * 1.25);

                #region Top Dim
                // Dim No 18, 18.1
                if (DN.DimIDNo18 || DN.DimIDNo18Dot1)
                {
                    if (BC.SCL?.Angle != null)
                    {
                        pointList = new PointList();
                        if (DN.DimIDNo18)
                            pointList.Add(Com.MinP(BC.SCL.Bolts, "Y"));
                        pointList.Add(BC.SCL.Angle.Points.P4);
                        if (DN.DimIDNo18Dot1)
                            pointList.Add(MainBeam.StartPoint);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByTopY(xDim, BC.PC);
                    }

                    if (BC.SCR?.Angle != null)
                    {
                        pointList = new PointList();
                        if (DN.DimIDNo18)
                            pointList.Add(Com.MinP(BC.SCR.Bolts, "Y"));
                        pointList.Add(BC.SCR.Angle.Points.P1);
                        if (DN.DimIDNo18Dot1)
                            pointList.Add(MainBeam.StartPoint);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByTopY(xDim, BC.PC);
                    }
                }


                // Dim No 9, 9.2
                if (DN.DimIDNo9 || DN.DimIDNo9Dot2)
                {
                    if (BC.SCL?.Angle != null)
                    {
                        pointList = new PointList();
                        if (DN.DimIDNo9Dot2)
                            pointList.Add(BC.SCL.Angle.Points.P1);

                        pointList.Add(Com.MinP(BC.SCL.Bolts, "Y"));

                        if (DN.DimIDNo9)
                            pointList.Add(MainBeam.StartPoint);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByTopY(xDim, BC.PC);
                    }

                    if (BC.SCR?.Angle != null)
                    {
                        pointList = new PointList();
                        if (DN.DimIDNo9Dot2)
                            pointList.Add(BC.SCR.Angle.Points.P4);

                        pointList.Add(Com.MinP(BC.SCR.Bolts, "Y"));

                        if (DN.DimIDNo9)
                            pointList.Add(MainBeam.StartPoint);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                        if (xDim != null)
                            PL.DimPlaceByTopY(xDim, BC.PC);
                    }
                }

                // Dim No 9.1
                if (DN.DimIDNo9Dot1 && BC.SCL?.Angle != null && BC.SCR?.Angle != null)
                {
                    pointList = new PointList();
                    pointList.Add(Com.MinP(BC.SCR.Bolts, "Y"));
                    pointList.Add(Com.MinP(BC.SCL.Bolts, "Y"));
                    xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistTop, StAtrr);
                    if (xDim != null)
                        PL.DimPlaceByTopY(xDim, BC.PC);

                }


                #endregion

                #region Left Dim
                Vect = new Vector(-1, 0, 0);
                if (BC.SCL?.Angle != null)
                {
                    // Dim No 2, 3
                    if (DN.DimIDNo2 || DN.DimIDNo3)
                    {
                        pointList = new PointList();
                        if (DN.DimIDNo2)
                        {
                            pointList.Add(BC.Points.P1);
                            pointList.Add(Com.MaxP(BC.SCL.Bolts, "Y"));
                        }

                        if (DN.DimIDNo3)
                            pointList.AddRange(BC.SCL.Bolts);

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                    }

                    // Dim No 3.1
                    if (DN.DimIDNo3Dot1)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MinP(BC.SCL.Bolts, "Y"));
                        pointList.Add(BC.SCL.Angle.Points.P2);

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                    }

                    if (DN.DimIDNo2 || DN.DimIDNo3 || DN.DimIDNo3Dot1)
                        BC.PC.DistLeft += BC.PC.DistInc;

                    // Dim No 3.2
                    if (DN.DimIDNo3Dot2 && BC.SCL.Bolts.Count > 2)
                    {
                        pointList = new PointList();
                        pointList.AddRange(BC.SCL.Bolts);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistLeft, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceLeftP(xDim, BC.PC.LeftX, BC.PC.DistLeft);
                            Com.GroupDim(xDim);
                        }
                    }
                }
                #endregion

                #region Right Dim
                Vect = new Vector(1, 0, 0);
                if (BC.SCR?.Angle != null)
                {
                    // Dim No 2, 3
                    if (DN.DimIDNo2 || DN.DimIDNo3)
                    {
                        pointList = new PointList();
                        if (DN.DimIDNo2)
                        {
                            pointList.Add(BC.Points.P4);
                            pointList.Add(Com.MaxP(BC.SCR.Bolts, "Y"));
                        }

                        if (DN.DimIDNo3)
                            pointList.AddRange(BC.SCR.Bolts);

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                    }

                    // Dim No 3.1
                    if (DN.DimIDNo3Dot1)
                    {
                        pointList = new PointList();
                        pointList.Add(Com.MinP(BC.SCR.Bolts, "Y"));
                        pointList.Add(BC.SCR.Angle.Points.P3);

                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                            PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                    }

                    if (DN.DimIDNo2 || DN.DimIDNo3 || DN.DimIDNo3Dot1)
                        BC.PC.DistRight += BC.PC.DistInc;

                    // Dim No 3.2
                    if (DN.DimIDNo3Dot2 && BC.SCR.Bolts.Count > 2)
                    {
                        pointList = new PointList();
                        pointList.AddRange(BC.SCR.Bolts);
                        xDim = dc.InsertDim(CView, pointList, Vect, BC.PC.DistRight, StAtrr);
                        if (xDim != null)
                        {
                            PL.DistPlaceRightP(xDim, BC.PC.RightX, BC.PC.DistRight);
                            Com.GroupDim(xDim);
                        }
                    }

                }
                #endregion

            }
        }

        #region Get Data

        private void GetBeamClassClass(TSD.View CView)
        {
            if (ViewName == "Front View")
            {
                BC = new BeamClass_BCR1();
                BC.beam = MainBeam;
                BC.Points = Com.GetPartPoints(MainBeam);
                List<TSM.Part> PartListC = BC.beam.GetAssembly().GetSecondaries().OfType<TSM.Part>().ToList();

                GetEndProperties(PartListC);

                PartListC.Add(MainBeam);

                TSM.Part LeftPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.X ascending select p).FirstOrDefault();
                TSM.Part RightPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.X descending select p).FirstOrDefault();
                TSM.Part TopPart = (from p in PartListC orderby p.GetSolid().MaximumPoint.Y descending select p).FirstOrDefault();
                TSM.Part BottPart = (from p in PartListC orderby p.GetSolid().MinimumPoint.Y ascending select p).FirstOrDefault();

                BC.PC = new PlacingClass();
                BC.PC.TopY = TopPart.GetSolid().MaximumPoint.Y;
                BC.PC.BottomY = BottPart.GetSolid().MinimumPoint.Y;


                BC.PC.LeftX = LeftPart.GetSolid().MinimumPoint.X;// Math.Round(CView.RestrictionBox.MinPoint.X);
                BC.PC.RightX = RightPart.GetSolid().MaximumPoint.X;

                double AvScale = 12;
                double AvDistInc = 100;
                double DistPerScale = AvDistInc / AvScale;
                double CScale = CView.Attributes.Scale;
                BC.PC.DistInc = CScale * DistPerScale;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;
            }
            else if (ViewName == "Section View")
            {
                BC = new BeamClass_BCR1();
                BC.beam = MainBeam;
                BC.Points = Com.GetPartPoints(MainBeam);
                List<TSM.Part> PartListC = BC.beam.GetAssembly().GetSecondaries().OfType<TSM.Part>().ToList();

                double Minz = CView.RestrictionBox.MinPoint.Z;
                double MaxZ = CView.RestrictionBox.MaxPoint.Z + 100;
                List<TSM.Part> PartList = (from p in PartListC where Com.IsViewObj(p, CView) select p).ToList();
                //List<TSM.Part> PartList = (from p in PartListC where p.GetSolid().MaximumPoint.Z > Minz && p.GetSolid().MinimumPoint.Z < MaxZ select p).ToList();
                Point CentP = Com.CenterPoint(MainBeam.StartPoint, MainBeam.EndPoint);


                BC.SCL = GetEndPropertiesS(PartList, "Left");
                BC.SCR = GetEndPropertiesS(PartList, "Right");

                PartListC.Add(MainBeam);
                List<Point> RefPoints = MainBeam.GetReferenceLine(false).OfType<Point>().ToList();
                PartList.Add(MainBeam);
                TSM.Part LeftPart = (from p in PartList orderby p.GetSolid().MinimumPoint.X ascending select p).FirstOrDefault();
                TSM.Part RightPart = (from p in PartList orderby p.GetSolid().MaximumPoint.X descending select p).FirstOrDefault();
                TSM.Part TopPart = (from p in PartList orderby p.GetSolid().MaximumPoint.Y descending select p).FirstOrDefault();
                TSM.Part BottPart = (from p in PartList orderby p.GetSolid().MinimumPoint.Y ascending select p).FirstOrDefault();

                BC.PC = new PlacingClass();
                BC.PC.TopY = TopPart.GetSolid().MaximumPoint.Y;
                BC.PC.BottomY = BottPart.GetSolid().MinimumPoint.Y;
                BC.PC.LeftX = LeftPart.GetSolid().MinimumPoint.X;// Math.Round(CView.RestrictionBox.MinPoint.X);
                BC.PC.RightX = RightPart.GetSolid().MaximumPoint.X;

                double AvScale = 12;
                double AvDistInc = 100;
                double DistPerScale = AvDistInc / AvScale;
                double CScale = CView.Attributes.Scale;
                BC.PC.DistInc = CScale * DistPerScale;
                BC.PC.DistBot = BC.PC.DistInc;
                BC.PC.DistTop = BC.PC.DistInc;
                BC.PC.DistLeft = BC.PC.DistInc;
                BC.PC.DistRight = BC.PC.DistInc;
            }


        }

        private void GetEndProperties(List<TSM.Part> PartListC)
        {
            PartListC = (from p in PartListC orderby p.GetSolid().MaximumPoint.Z descending select p).ToList();

            Point CentP = Com.CenterPoint(BC.beam.StartPoint, BC.beam.EndPoint);
            double Lenght = (BC.beam.GetSolid().MaximumPoint.X - BC.beam.GetSolid().MinimumPoint.X) / 8;
            double MinX = BC.beam.GetSolid().MinimumPoint.X + Lenght;
            double MaxX = BC.beam.GetSolid().MaximumPoint.X - Lenght;


            TSM.Beam Angle = null;
            TSM.Part DPT = null;
            TSM.Part DPB = null;

            BooleanPart BoolTop = null;
            BooleanPart BoolBott = null;

            List<BooleanPart> Bools = Com.EnumtoArray(MainBeam.GetBooleans()).OfType<BooleanPart>().ToList();

            double BHeigh = Com.GetPartHeight(MainBeam);

            if (Position == "Left")
            {
                Angle = (from p in PartListC.OfType<Beam>() where Com.GetPartProfileType(p) == "L" && !dc.IsPlateSideViewN(p) && (p.GetSolid().MaximumPoint.X < CentP.X && p.GetSolid().MinimumPoint.X <= MinX) select p).FirstOrDefault();

                BoolTop = (from p in Bools where (p.OperativePart.GetSolid().MaximumPoint.X < CentP.X && p.OperativePart.GetSolid().MinimumPoint.X <= MinX) && Com.CenterPoint(p.OperativePart).Y > BC.Points.CentP.Y select p).FirstOrDefault();
                BoolBott = (from p in Bools where (p.OperativePart.GetSolid().MaximumPoint.X < CentP.X && p.OperativePart.GetSolid().MinimumPoint.X <= MinX) && Com.CenterPoint(p.OperativePart).Y < BC.Points.CentP.Y select p).FirstOrDefault();

                DPT = (from p in PartListC where Com.GetPartProfileType(p) != "L" && dc.IsPlateSideViewN(p) && dc.IsHorzObj(p) && (p.GetSolid().MaximumPoint.X < CentP.X && p.GetSolid().MinimumPoint.X <= MinX) && Com.CenterPoint(p).Y > BC.Points.CentP.Y select p).FirstOrDefault();

                DPB = (from p in PartListC where Com.GetPartProfileType(p) != "L" && dc.IsPlateSideViewN(p) && dc.IsHorzObj(p) && (p.GetSolid().MaximumPoint.X < CentP.X && p.GetSolid().MinimumPoint.X <= MinX) && Com.CenterPoint(p).Y < BC.Points.CentP.Y select p).FirstOrDefault();

            }
            else
            {
                Angle = (from p in PartListC.OfType<Beam>() where Com.GetPartProfileType(p) == "L" && !dc.IsPlateSideViewN(p) && (p.GetSolid().MinimumPoint.X > CentP.X && p.GetSolid().MaximumPoint.X >= MaxX) select p).FirstOrDefault();

                BoolTop = (from p in Bools where (p.OperativePart.GetSolid().MinimumPoint.X > CentP.X && p.OperativePart.GetSolid().MaximumPoint.X >= MaxX) && Com.CenterPoint(p.OperativePart).Y > BC.Points.CentP.Y select p).FirstOrDefault();
                BoolBott = (from p in Bools where (p.OperativePart.GetSolid().MinimumPoint.X > CentP.X && p.OperativePart.GetSolid().MaximumPoint.X >= MaxX) && Com.CenterPoint(p.OperativePart).Y < BC.Points.CentP.Y select p).FirstOrDefault();


                DPT = (from p in PartListC where Com.GetPartProfileType(p) != "L" && dc.IsPlateSideViewN(p) && dc.IsHorzObj(p) && (p.GetSolid().MinimumPoint.X > CentP.X && p.GetSolid().MaximumPoint.X >= MaxX) && Com.CenterPoint(p).Y > BC.Points.CentP.Y select p).FirstOrDefault();

                DPB = (from p in PartListC where Com.GetPartProfileType(p) != "L" && dc.IsPlateSideViewN(p) && dc.IsHorzObj(p) && (p.GetSolid().MinimumPoint.X > CentP.X && p.GetSolid().MaximumPoint.X >= MaxX) && Com.CenterPoint(p).Y < BC.Points.CentP.Y select p).FirstOrDefault();

            }


            if (Angle != null)
            {
                BC.Angle = Com.GetPartClass(Angle);
                BC.BoltsE = Com.GetPartBoltPoint(Angle);

                if (BC.BoltsE != null)
                {
                    if (Position == "Left")
                    {

                        BoltGroup BoltsG = (from b in Com.EnumtoArray(Angle.GetBolts()).OfType<BoltGroup>() orderby Com.CenterPoint(b).X descending select b).FirstOrDefault();
                        double Xval = Angle.GetSolid().MinimumPoint.X + ((Angle.GetSolid().MaximumPoint.X - Angle.GetSolid().MinimumPoint.X) / 3);
                        if (Com.CenterPoint(BoltsG).X > Xval)
                            BC.IsFrontBolt = true;


                        BC.BoltsE = Com.GetBoltPoints(BoltsG);
                    }
                    else
                    {
                        BoltGroup BoltsG = (from b in Com.EnumtoArray(Angle.GetBolts()).OfType<BoltGroup>() orderby Com.CenterPoint(b).X ascending select b).FirstOrDefault();
                        double Xval = Angle.GetSolid().MaximumPoint.X - ((Angle.GetSolid().MaximumPoint.X - Angle.GetSolid().MinimumPoint.X) / 3);
                        if (Com.CenterPoint(BoltsG).X < Xval)
                            BC.IsFrontBolt = true;

                        BC.BoltsE = Com.GetBoltPoints(BoltsG);
                    }


                }
            }

            if (DPT != null)
                BC.DPT = Com.GetPartClass(DPT);

            if (DPB != null)
                BC.DPB = Com.GetPartClass(DPB);

            BC.Points.P5 = BC.Points.P1;
            BC.Points.P6 = BC.Points.P2;
            BC.Points.P7 = BC.Points.P3;
            BC.Points.P8 = BC.Points.P4;

            if (BoolTop != null)
            {
                BC.CutTop = new CutPoints();

                if (BoolTop.OperativePart is ContourPlate)
                {
                    PointList ContList = dc.ContPList(BoolTop.OperativePart);
                    ContList = ReviseList(ContList, "Top");
                    if (Position == "Left")
                    {
                        BC.CutTop.P1 = Com.MinPofX(ContList, "Y", Com.MinP(ContList, "X").X);
                        BC.CutTop.P2 = Com.MaxPofY(ContList, "X", Com.MaxP(ContList, "Y").Y);
                        if (!Com.IsEqual(BC.CutTop.P1.Y, BC.CutTop.P2.Y))
                        {
                            BC.Points.P1 = BC.CutTop.P1;
                            BC.Points.P5 = BC.CutTop.P2;
                        }
                        else
                            BC.CutTop = null;
                    }
                    else
                    {
                        BC.CutTop.P1 = Com.MinPofX(ContList, "Y", Com.MaxP(ContList, "X").X);
                        BC.CutTop.P2 = Com.MinPofY(ContList, "X", Com.MaxP(ContList, "Y").Y);

                        if (!Com.IsEqual(BC.CutTop.P1.Y, BC.CutTop.P2.Y))
                        {
                            BC.Points.P4 = BC.CutTop.P1;
                            BC.Points.P8 = BC.CutTop.P2;
                        }
                        else
                            BC.CutTop = null;
                    }
                }
            }

            if (BoolBott != null)
            {
                BC.CutBott = new CutPoints();

                if (BoolBott.OperativePart is ContourPlate)
                {
                    PointList ContList = dc.ContPList(BoolBott.OperativePart);
                    ContList = ReviseList(ContList, "Bottom");
                    if (Position == "Left")
                    {
                        BC.CutBott.P1 = Com.MaxPofX(ContList, "Y", Com.MinP(ContList, "X").X);
                        BC.CutBott.P2 = Com.MaxPofY(ContList, "X", Com.MinP(ContList, "Y").Y);

                        if (!Com.IsEqual(BC.CutBott.P1.Y, BC.CutBott.P2.Y))
                        {
                            BC.Points.P2 = BC.CutBott.P1;
                            BC.Points.P6 = BC.CutBott.P2;
                        }
                        else
                            BC.CutBott = null;
                    }
                    else
                    {
                        BC.CutBott.P1 = Com.MaxPofX(ContList, "Y", Com.MaxP(ContList, "X").X);
                        BC.CutBott.P2 = Com.MinPofY(ContList, "X", Com.MinP(ContList, "Y").Y);
                        
                        if (!Com.IsEqual(BC.CutBott.P1.Y, BC.CutBott.P2.Y))
                        {
                            BC.Points.P3 = BC.CutBott.P1;
                            BC.Points.P7 = BC.CutBott.P2;
                        }
                        else
                            BC.CutBott = null;
                    }
                }
            }


        }

        private SecClass GetEndPropertiesS(List<TSM.Part> PartListC, string PosV)
        {
            SecClass SC = null;
            if (PosV == "Left")
                PartListC = (from p in PartListC where Com.CenterPoint(p).X < MainBeam.StartPoint.X orderby p.GetSolid().MaximumPoint.Z descending select p).ToList();
            else
                PartListC = (from p in PartListC where Com.CenterPoint(p).X > MainBeam.StartPoint.X orderby p.GetSolid().MaximumPoint.Z descending select p).ToList();


            if (PartListC != null && PartListC.Count > 0)
            {
                TSM.Beam Angle = null;
                TSM.Part DPT = null;
                TSM.Part DPB = null;

                double BHeigh = Com.GetPartHeight(MainBeam);

                if (Position == "Left")
                {
                    Angle = (from p in PartListC.OfType<Beam>() where Com.GetPartProfileType(p) == "L" select p).FirstOrDefault();



                    DPT = (from p in PartListC where Com.GetPartProfileType(p) != "L" && dc.IsHorzObj(p) && Com.CenterPoint(p).Y > BC.Points.CentP.Y select p).FirstOrDefault();

                    DPB = (from p in PartListC where Com.GetPartProfileType(p) != "L" && dc.IsHorzObj(p) && Com.CenterPoint(p).Y < BC.Points.CentP.Y select p).FirstOrDefault();

                }
                else
                {
                    Angle = (from p in PartListC.OfType<Beam>() where Com.GetPartProfileType(p) == "L" select p).FirstOrDefault();



                    DPT = (from p in PartListC where Com.GetPartProfileType(p) != "L" && dc.IsPlateSideViewN(p) && dc.IsHorzObj(p) && Com.CenterPoint(p).Y > BC.Points.CentP.Y select p).FirstOrDefault();

                    DPB = (from p in PartListC where Com.GetPartProfileType(p) != "L" && dc.IsPlateSideViewN(p) && dc.IsHorzObj(p) && Com.CenterPoint(p).Y < BC.Points.CentP.Y select p).FirstOrDefault();

                }

                if (Angle != null || DPT != null || DPB != null)
                {
                    SC = new SecClass();

                    if (Angle != null)
                    {
                        SC.Angle = Com.GetPartClass(Angle);
                        SC.Bolts = Com.GetPartBoltPoint(Angle);

                        BoltGroup BoltsG = null;

                        if (PosV == "Left")
                            BoltsG = (from b in Com.EnumtoArray(Angle.GetBolts()).OfType<BoltGroup>() orderby Com.CenterPoint(b).X ascending select b).FirstOrDefault();
                        else
                            BoltsG = (from b in Com.EnumtoArray(Angle.GetBolts()).OfType<BoltGroup>() orderby Com.CenterPoint(b).X descending select b).FirstOrDefault();

                        if (BoltsG != null)
                            SC.Bolts = Com.GetBoltPoints(BoltsG);
                    }

                    if (DPT != null)
                        SC.DPT = Com.GetPartClass(DPT);

                    if (DPB != null)
                        SC.DPB = Com.GetPartClass(DPB);
                }
            }

            return SC;

        }

        private PointList ReviseList(PointList Plist, string VPos)
        {
            PointList pointList = new PointList();
            if (Plist.Count > 0)
            {
                foreach (Point p in Plist)
                {
                    Point P1 = p;

                    if (VPos == "Top" && P1.Y > BC.Points.P1.Y)
                        P1 = new Point(P1.X, BC.Points.P1.Y);

                    else if (VPos == "Bottom" && P1.Y < BC.Points.P2.Y)
                        P1 = new Point(P1.X, BC.Points.P2.Y);

                    if (Position == "Left" && P1.X < BC.Points.P1.X)
                        P1 = new Point(BC.Points.P1.X, P1.Y);

                    if (Position == "Right" && P1.X > BC.Points.P4.X)
                        P1 = new Point(BC.Points.P4.X, P1.Y);


                    pointList.Add(P1);
                }


            }
            return pointList;
        }

        #endregion

        #region Helping Methods
        private double GetPartWidth(TSM.Part part)
        {
            return (part.GetSolid().MaximumPoint.X - part.GetSolid().MinimumPoint.X);
        }

        #endregion

        private class SecClass
        {
            public PartClass Angle { get; set; }
            public PointList Bolts { get; set; }
            public PartClass DPT { get; set; }
            public PartClass DPB { get; set; }
        }

        private class BeamClass_BCR1
        {
            public Beam beam { get; set; }
            public PartClass Angle { get; set; }
            public PartClass DPT { get; set; }
            public PartClass DPB { get; set; }
            public PointList BoltsE { get; set; }
            public CutPoints CutTop { get; set; }
            public CutPoints CutBott { get; set; }
            public PartPoints Points { get; set; }
            public PlacingClass PC { get; set; }
            public bool IsFrontBolt = false;
            public SecClass SCL { get; set; }
            public SecClass SCR { get; set; }
        }


    }

}
